                     #NNM"""""""Qg
                              _QN'   _gM"""Mg     p!"""Ng
                         _  _pM^     Bg    _N    #      Tg
                         "QNQ_        jNm*NQ_   jf      jQ
                       j@"          jM      TQ  Tg      jM
                    _gF`            Qg     _pF  "Qg    _#'
                   "MNNNNNMMM""""^`  "MN**M"      9N**!^
    _yggQQgg  pggggggggg,jggggggggg    pggg    jggg     pggggggggg,jggg   jggg
   jQQNNNQQQg NNNQQQNNNN_QQQNNNNNNM  _QQQQQ    QQQf     NNNQQQNNNN_QQQf  jQQQ'
  jQQQy__ ""'   jQQN    pQQQ____    jQQNQQQ   jQQM        jQQN    pQQQyyyQQQF
   MQQQQQQg    jQQQ'   jQQQQQQQQF  pQQM QQQ  jQQQ        jQQQ'   jQQQQQQQQQN
 ggg  `"QQQf   QQQF   _QQQf      jQQQQQQQQQ  QQQf        QQQF   _QQQf  jQQQ'
 QQQQgQQQQF   jQQN    pQQQQQQQQQgQQNMMMMQQQ jQQQQQQQQ   jQQN    pQQF   QQQF
 `MNNNNM"     7NN'    NNNNNNNNNMNNM     TNN TNNNNNNNF   7NN'    NNN    NNM

*****************************************************************************
*                                                                           *
*           Z80Stealth ZX Spectrum emulator for Windows v1.23               *
*    	        Copyright(c) 1999-2014 by Kirill Kolpakov	            *
*                                                                           *
* 		        AY-3-8910(12)/YM2149F emulation                     *  
*		      Copyright(c) 2000-2001 by Hacker KAY		    *
*                                                                           *
*		idea, parts of Border Creator code by zebest                *
*                                                                           *
*****************************************************************************
 ----------------------------------------------------------------------------
  	        Z80Stealth IS FREEWARE  AND CAN BE DISTRIBUTED 
    FREELY AS LONG AS CONTENTS OF Z80Stealth DISTRIBUTION IS NOT MODIFIED.
 ----------------------------------------------------------------------------

       PLEASE READ THIS DOC CAREFULLY BEFORE RUNNING EMULATOR
		THANKS FOR YOUR INTEREST IN OUR WORK

	1. Introduction.
	2. Features.
        3. System requirements
	4. Usage.
	5. Debugger howto
	6. Future plans.
	7. Greetings.
	8. Contact me.

        DISCLAIMER

--------------------------------------------------------------------------
	1. Introduction.

  Z80Stealth is the Speccy 128,Pentagon 128/512/1024,Scorpion ZS 256, Profi 1024, 
  KAY 1024 emulator for Windows. 
  Main goal is to emulate Speccy's hardware as close as possible. 
  Main features: very good z80 emulation, 
  _perfect_ AY-3-8910(12)/YM2149F and General Sound emulation,
  beeper, Covox, SounDrive emulation.
  KP1818VG93 (Betadisk/TRDOS) emulation, menus to load/save/browse your 
  collection of Speccy's snaps,tapes,disks.
  Emulation of such hardware as Cache,GIGASCREEN,Flash-color,16col,CMOS etc
  It supports popular file formats:
	Snapshots - Z80 (+ Z80Stealth's enhanced version),
		    SNA,SLT,SP,PRG,ACH,SIT
	Tape - TAP,TZX,PZX
  TR-DOS Disk format supported: TRD, SCL (both are with auto-boot feature!).
  I'm writing & optimizing it almost everyday so future versions will 
  be faster and with more features.
--------------------------------------------------------------------------
	2. Features.

	- Spectrum 128 emulation.
	- Pentagon 128/512/1024 emulation.
	- Scorpion ZS-256 Turbo+ emulation
	- Profi 1024 emulation (not finished yet)
	- KAY 1024 emulation (not finished yet)
	- Z80 CPU emulation using my own code. All documented and 
	  undocumented flags and opcodes.
	- General Sound emulation
	- 2 Debuggers: for Speccy's Z80 & General Sound board: 
	  Disasm,Assembler,Stack,Memory Dump,Memory map,Ports
	- AY-3-8910(12)/YM2149F emulation 
	  Includes Digital sound feature.
	  ABC/ACB/BAC stereo modes.
	  Excellent noise emulation.
	  Sound is 100% close to the real AY/YM chips!
	- Betadisk (4 drives).
	- KP1818VG93 emulation
	- HDD emulation
	- Beeper,Covox,SounDrive emulation.
	- Support for 88Khz & 114Khz sound mode
	- Cache (Shadow RAM) emulation.
	- 16K RAMDISK for Pentagon 
	- GIGASCREEN emulation.
	- FLASH-color emulation.
	- 512x192 B&W
	- 16COL
	- Compability: almost everything works ok)
	- Interrupt modes 0,1,2.
	- Keyboard issues 2 and 3 emulation
	- Joystick : Kempston, Cursor, Sinclair 1, Sinlair 2
	  emulation via arrow keys+CTRL.
	- Kempston mouse emulation.
	- Menu to Load/Save files (F1)
	- Ability to create PSG or EPSG files. Read about EPSG in z80s.faq
--------------------------------------------------------------------------
	3. System requirements
	
	- CPU:    PIII+ is required
	- Video:  Any VGA compatible card
	- Sound:  Any DirectX compatible sound card
	- OS:     Win95, Win98, Win ME,Win NT,Windows 2000,Windows Vista or Windows 7.
		  Z80Stealth shoul work ok under Linux + DOSemus (Wine).
--------------------------------------------------------------------------
	4. Usage.
	Ok first you must edit z80s.cfg - there's comments for 
	every option so it's not very difficult.
	After that just run z80s.exe to bootup Speccy 128 or Pentagon.
		
	
	About TAP files:
	 After selecting tape file you can load it as it was on real Speccy:
	Tape Loader in the 128K menu or go to 48K Basic and type LOAD "".
	If game doesnt load you should try both methods.
	
         Keys:

	 F1  - Load/Save snapshots menu 
	       In this menu:
	        F4 - Joystick type (Cursor,Kempston,Sinclair 1,Sinclair 2)
	             it will be emulated via cursor keys+Ctrl 
		     (read about F11 below)
		F5 - AY(YM) stereo mode (ABC,ACB,BAC)
		F6 - Music chip type (AY,YM)
		F7 - Covox On/Off
		F8 - SounDrive On/Off
	  	F9 - TRDOS mode with traps on/off
               In 'Load' menu Alt-D to change drive
               In 'Browse tape' menu 
		F4 - Unload VOC/WAV from memory
	 F2  - PSG file create/close menu
	 F3  - Load/Save disk images
	       In this menu:
		F4 - Remove disk
		F6 - Toggle write protection on/off
		F9 - Save disk 
	 F9  - Max Speed On/Off
         F10 - Exit
	 F12 - Reset
	 Delete - Debugger 
	 End - Debugger for General Sound board
	 PageUp - Built-in boot for TRDOS
--------------------------------------------------------------------------	
	5. Debugger howto
	Press Delete to invoke debugger.
        In debugger:
	F1 - menu to load/save snapshots,disks,open/close PSG file,raise NMI
       	F6,Tab - switch between windows
       	ALT-1,2,3,4 - switch to certain window
       	F4 - Hex/Dec
       	F7 - Trace
	F8 - Step over
	Ctrl-G - jump to certain address (in dump,disasm,stack windows)	
       	ENTER - enter new value (in stack,registers windows,
	in memory dump window you can simply press 0-9,a-f to enter values
	or ' to enter character instead of numeric value)


	Disasm window:
	=============================
	F2 - set/remove breakpoints (in disasm windows)
	Ctrl-R - remove all breakpoints
	+ - disasm 1byte backward
	- - disasm 1byte forward
	Assembler: If disasm window is active you can easily type in
	asm mnemonic. For hex numbers put '#' before number or 'h' after it.
	JR/DJNZ - you can input direct address or +/- offset like this:
		jr nz,+120
		jr nz,-12 
		jr nz,ffffh (or jr nz,#ffff or jr nz,65535)
--------------------------------------------------------------------------
	6. Future plans.
	
	- Better Profi 1024 emulation.
	- FDI,TD0,FDD disk images support
	- Add more features to debugger
	- Printer emulation
	- Optional onscreen indicators of disk activity,Turbo on/off etc
	- SMUC,GMX,PC keyboard controller,full General Sound emulation
	- ATM and other clones emulation.
	- Better Z80 timing emulation.
	- Perfect video timing for all models.
	- Saving screenshots in GIF,JPG,PNG, whatever else 
	- Joystick emulation using PC joystick
	- More compability.
	- A lot of other small things and bugfixes.
--------------------------------------------------------------------------
	7. Greetings/Thanks.

 My Family - thanks for all. I love you.

 Hacker KAY - the author of AY-3-8910(12)/YM2149F emulation for Z80Stealth!
  Also he wrote ESS driver,UART procedures & smth else i forgot ;)
  Thanks for your support,ideas,a lot of bugreports ;) ...
  Also thanks for nice ANSI logo you've made for this doc.

 Sean Young  - thanks a lot for your docs about z80 

 Martin van der Heide - World of Spectrum is the best

 Himik - thanks for bugreports. and reminders about Profi ;)

 Eugene Palenock - thanks for tech info, schemes, bugreports 

 Dmitriy D - thanks a lot for techinfo,schemes and soft!

 Alexander Melkov - thanks for Profi disk dumps

 Illuminator - thanks for writing WSS driver for my emu!

 Paul Pavlov - thanks for creating VT - it rulez

 DJ Psych - Psycho team rulez forever!

 Mac Buster - thanks for tech info about Betadisk

 Dmitry Kozlov - thanks for your FAR plugins and sources of td0->trd converter

 Sergey Vladimirovich Bulba - author of cool AY-3-8910 Emulator/Player.
  Thanks for info about PSG files. 

 Alexandr Ageev - thanks for report about slowdown caused by ISA video card.

 Carl Murray - thanks for bugreport about Num Lock + cursor keys.

 Raul Gomez Sanchez - author of very good speccy emulator

 Rodolfo Edison Guerra - author of SpecBASE. Thanks for supporting my
   emu in SpecBASE and for sending soluting of 'emm386' trouble

 Miodrag Stancevic - thanks for your report about trouble with Blava demo &
   saying that my emu is a bit faster than a real Speccy.

 Thomas Harte - thanks for your letter about Puzznic. It gave me the idea
   to implement line-by-line rendering in my emu.	

 K.Uglekov - wrote best speccy emulator-debugger. 

 Oleg Prokhorov - thanks for 32lite.exe. One of the best dos32 exe packer.

 Eugene Roshal - wrote FAR - best Win32 file manager.

 Harald Thunem - thanks for HTScreen library
--------------------------------------------------------------------------
	9. Contact me.
	  
	e-mail: Mr.Kirill@starlink.ru	
	Feel free to drop me a letter.

	Z80Stealth linx: http://z80.emu-russia.net

