=========================  \  /    ===============================
==========================  \/     ===============================
=========================== /\ EON ===============================
========================== /  \    ===============================

======================= Version: 1.0 =============================

Author: SF

---------- Description:

Xeon is an X-Box emulator for the PC.  Currently it supports one
commercial game, and support for more will be added in the future
along with other features.

---------- Compatibility:

Halo (NTSC version only)

---------- Requirements:

Windows XP
DirectX 9.0a
Pentium 3/Athlon XP processor
Recommended graphics card: GeForce FX/Radeon 9200 Pro or higher

---------- Instructions:

Extract all of the files to some directory.  You will need an ISO
image of the game you want to run.  Since ISO reading is not
implemented yet, you will need to use a tool such as xISO
(www.yursoft.cjb.net) to extract all of the files in the ISO.  Make
sure to preserve the directory structure inside the ISO file when
extracting.  Start up Xeon.exe and select File->Load XBE.
Navigate to the directory where you extracted the ISO and select
the default.xbe file.  You can also supply the XBE filename as a
command-line argument to Xeon.exe and it will be loaded automatically.

---------- Credits:

caustik for XBE file documentation
Datarescue for their excellent disassembler, IDA


______--== SF ==--______
  Heed the Messenger!