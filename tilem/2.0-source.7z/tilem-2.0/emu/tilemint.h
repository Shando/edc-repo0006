#ifndef _TILEMINT_H
#define _TILEMINT_H

#ifdef HAVE_STDINTS1_H
# include <stdints1.h>
#elif defined(HAVE_STDINTS2_H)
# include <stdints2.h>
#else
# include <stdint.h>
#endif

#endif
