CPCEMU v1.7 - The CPC Emulator for modern computer systems
----------------------------------------------------------

What is CPCEMU ?
  CPCEMU emulates an Amstrad CPC on your computer. You need at least an
  AT 386 with VGA graphics.  The CPC ROMs as shipped in UK are included.


Fast start:
DOS:
  Copy the archive CPCEMUxx.ZIP into a directory of your hard disk and
  decompress it with  'PKUNZIP CPCEMUxx.ZIP' .
  Then use INSTALL.BAT. Now run CPC6128.BAT to have a first look.
Linux:
  Copy the archive cpcemu-linux-x86-1.7.tar.gz into a directory of your
  hard disk and decompress it with 'tar xvzf cpcemu-linux-x86-1.7.tar.gz'.
  Then change the directory with 'cd cpcemu-1.7'. Now run './cpc6128' to
  have a first look.
Windows:
  Copy the setup program cpcemu-win32-x86-1.7.exe into a directory of your
  hard disk and start it. Select a directory to install. Now use
  'CPCemu/CPC6128' in start menu to have a first look.

  You can try the new online help by pressing F1.
  When questions arise, simply read the completely new documentation
  CPCEMU_E.TXT. No panic, it is shorter as it seems at the first glance.
  The user part ends with chapter 6.

New in v1.7:
------------
  - Keyboard layout is adjustable and, in cpcemu.dat, configurable

New in v1.6:
------------
  - Changes for a wider spectrum of operating systems and CPUs
  - first versions for Linux/x86 and Windows/x86 (yes, there are
    indeed versions of Windows for Non-x86)
  - other plattforms are being planned (Linux/Alpha, FreeBSD/x86)
  - whole user interface converted to graphics mode (1 window)
  - same for debugger and other user inputs
  - completetly new graphics and sound routines
  - hence, better multimodes are depicted better (without flickering colours)
  - whole RAM access converted to linear addressing mode
  - file and directory access generalized for unixish OSes
  - help file adjusted and independent from character set
  - besides of "descript.ion", now "00_index.txt" is used
  - small bugfixes
  - unfortunately, some limitations (keyboard layout hard coded etc.)


New in v1.5:
------------
  - perfect Soundblaster sound support by Ulrich Doewich
  - complete Spanish documentation thanks to Gerardo Briseno
  - updated French documentation thanks to Jean-Pierre Marquet
  - autostart of BASIC programs from disk images
  - 4DOS descriptions in file selection menus
  - online help now allows topics including spaces
  - path names in configurations are saved relative
  - file selection: now up to 1500 directory entries (formerly 500)
  - direct printer port access when using PRINTER=""
  - set data rate with CPCTRANS v2.3g
  - SNA2GIF v1.2: user-configurable colour palette, better auto-scale
  - CPCPARA v1.2: possible to disable fast sending (e.g. for Vortex)
  - extended poke database
  - some minor changes


New in v1.4:
------------
  - GUS sound support by Ulrich Doewich
  - online help system in English, German, French and Spanish
  - complete French documentation
  - support for 2 joysticks
  - VESA videomodes for higher resolutions
  - improved setup menu and configuration file
  - load and save configurations from setup menu
  - improved FDC routines for non-standard formats
  - Extended disk format
  - user-configurable colours and keys
  - improved CPCTRANS (v2.3)
  - new SNA2GIF (v1.1): grab screens from snapshots


New in v1.3b:
------------

  - Since v1.3 there was no Soundblaster sound with some (non Pro)
    cards.


New in v1.3a:
------------

  - With v1.3 of CPCEMU, the interrupt mode 2 of the Z80 did not work
    (try Boulder Dash).


New in v1.3:
------------
  - realtime CPC: In this mode CPCEMU tries to be as fast as a real CPC.
  - the ROMs are (c) by Amstrad and Locomotive Software
  - French documentation
  - menu system with mouse support
  - poke database for easy "poking"
  - re-format disk images with CPCEMU
  - insert disk images with read-only DOS attribute
  - debug menu: 'find' added
  - 'fast Z80': does not crash the computer when using Z80 instructions
    with word access at 0xffff
  - parallele adapter: new PCPARA, CPCPARA with up to 19000 baud
  - CPCTRANS: compiled for 8086 to use it also on an XT
  - ...



  You can find further information in the English, German, French or
  Spanish documentation CPCEMU_E.TXT, CPCEMU_D.TXT, CPCEMU_F.TXT,
  CPCEMU_S.TXT respectively.


Write your comments to:

        Marco Vieth
        Auf dem Uekern 4
        33165 Lichtenau
        Germany

        or by e-mail:
          cpcemu@hotmail.com
          (ali@uni-paderborn.de  only valid until 10/01/98)

        or to:
        Rainer Loritz
        (rainer@loritz.net)

-------------------
