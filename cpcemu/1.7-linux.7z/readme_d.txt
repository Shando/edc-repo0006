CPCEMU v1.7 - Der CPC-Emulator f�r moderne Computersysteme
----------------------------------------------------------

Was ist CPCEMU ?
  CPCEMU emuliert einen Amstrad-CPC auf Ihrem Computer. Sie ben�tigen
  mindestens einen AT 386 mit VGA-Grafik.  Die CPC-ROMs, wie sie mit
  deutschen CPCs ausgeliefert wurden, sind mit dabei.


Schneller Einstieg:
DOS:
  Kopieren Sie das Archiv CPCEMUxx.ZIP in ein Verzeichnis auf Ihrer
  Festplatte und entpacken es durch  'PKUNZIP CPCEMUxx.ZIP' .
  Danach rufen Sie einfach INSTALL.BAT auf. Dann starten Sie
  CPC6128.BAT und k�nnen schon einmal "reinschnuppern". 
Linux:
  Kopieren Sie das Archiv cpcemu-linux-x86-1.7.tar.gz in ein Verzeichnis
  auf Ihrer Festplatte und entpacken Sie es durch
  'tar xvzf cpcemu-linux-x86-1.7.tar.gz'. Dann wechseln Sie mit
  'cd cpcemu-1.7' in das Verzeichnis. Mit './cpc6128' k�nnen sie
  schon einmal reinschnuppern.
Windows:
  Kopieren Sie das Installationsprogramm cpcemu-win32-x86-1.7.exe in ein
  Verzeichnis auf Ihrer Festplatte und starten Sie es. W�hlen Sie ein
  geeignetes Installationsverzeichnis. Mit "CPCemu/CPC6128" im Startmen�
  k�nnen Sie schon einmal reinschnuppern.

  Die integrierte On-Line-Hilfe wird mit 'F1' aktiviert. Mit 'F7' und 'T'
  und '1' k�nnen Sie die deutsche Tastaturbelegung aktivieren.
  Tiefergehende Erl�uterungen k�nnen Sie in der umfangreichen
  Dokumentation CPCEMU_D.TXT nachlesen. Keine Bange, sie ist nicht so lang
  wie sie aussieht. Mit Kapitel 6 ist der Anwenderteil zuende.

Neu in v1.7:
------------
  - Tastaturlayout einstell- und in cpcemu.dat konfigurierbar

Neu in v1.6:
------------
  - Anlagen f�r ein breiteres Spektrum von Betriebssystemen und CPUs
  - erste Versionen f�r Linux/x86 und Windows/x86 (ja, es gibt auch
    Windows-Versionen f�r Non-x86)
  - andere Plattformen sind in Planung (Linux/Alpha, FreeBSD/x86)
  - gesamte Benutzerf�hrung umgesetzt in den Grafikmodus (1 Fenster)
  - ebenso Debugger und andere Eingaben
  - gesamte Grafik- und Soundroutinen neu verfa�t
  - dadurch bessere Multimodedarstellung (ohne Farbenflimmern)
  - gesamter RAM-Zugriff f�r lineare Adressierung umgebaut
  - Datei- und Verzeichniszugriffe f�r unixartige OS verallgemeinert
  - Hilfedatei angepa�t und zeichensatzunabh�ngig
  - au�er "descript.ion" wird nun auch "00_index.txt" ausgewertet
  - kleinere Bugfixes
  - leider noch einige Funktionseinschr�nkungen (Tastaturlayout fest etc.)


Neu in v1.5:
------------
  - perfekter Soundblaster-Sound von Ulrich Doewich
  - vollst�ndige spanische Dokumentation dank Gerardo Briseno
  - angepa�te franz�sische Dokumentation dank Jean-Pierre Marquet
  - Autostart von BASIC-Programmen aus Disketten-Abbildern
  - 4DOS-Beschreibungen bei der Datei-Auswahl
  - die Online-Hilfe erlaubt jetzt Themen mit Leerzeichen
  - Pfade in Konfigurationen werden jetzt relativ abgespeichert
  - Dateiauswahl: Jetzt bis zu 1500 Eintr�ge (vorher 500)
  - direkte Druckerport-Ansteuerung mit PRINTER=""
  - Datenrate bei CPCTRANS v2.3g setzen
  - SNA2GIF v1.2: benutzerdefinierbare Farbpalette, bessere Autoskalierung
  - CPCPARA v1.2: schnelles Senden abschaltbar (z.B. f�r Vortex)
  - Poke-Datenbank erweitert
  - einige kleinere �nderungen


Neu in v1.4:
------------
  - GUS-Soundunterst�tzung von Ulrich Doewich
  - Online-Hilfe in Deutsch, Englisch, Franz�sisch und Spanisch
  - vollst�ndige franz�sische Dokumentation
  - Unterst�tzung f�r 2 Joysticks
  - VESA-Videomodes f�r hohe Aufl�sungen
  - Setup-Men� und Konfigurationsdatei �berarbeitet
  - Konfigurationen laden und speichern vom Setup-Men� aus
  - verbesserte FDC-Routinen f�r Fremdformate
  - Erweitertes Disketten-Format
  - Benutzerdefinierbare Farben und Tasten
  - �berarbeitetes CPCTRANS (v2.3)
  - neues SNA2GIF (v1.1) zum Kopieren von Bildern aus Snapshots



Neu in v1.3b:
-------------
  - Auf manchen Soundblaster-Karten (<>Pro) war kein Sound mehr zu h�ren.


Neu in v1.3a:
-------------
  - In der Version v1.3 funktionierte der Z80-Interrupt Modus 2 nicht mehr,
    so da� z.B. Boulder Dash nicht mehr funktionierte.


Neu in v1.3:
------------
  - Realtime-CPC: In diesem Modus versucht CPCEMU genauso schnell zu sein,
    wie ein echter CPC.
  - die ROMs sind (c) von Amstrad und Locomotive Software
  - franz�sische Dokumentation
  - erweitertes Setup-Men� mit Mausunterst�tzung
  - Poke-Datenbank zum einfachen "Poken"
  - Disketten-Abbilder mit CPCEMU re-formatieren
  - Disketten-Abbilder mit read-only DOS Attribut einlegen m�glich
  - Debug-Menu: 'find' hinzugef�gt
  - 'schneller Z80': kann jetzt bei Z80-Befehlen mit Wortzugriff auf 0xffff
    nicht mehr abst�rzen
  - paralleler Adapter: neues PCPARA, CPCPARA mit h�herer Geschwindigkeit
  - CPCTRANS f�r 8086 compiliert, damit auf XT einsetzbar
  - usw. ...



  Weitere Informationen finden Sie in der deutschen, englischen,
  franz�sichen oder spanischen Anleitung
    CPCEMU_D.TXT, CPCEMU_E.TXT, CPCEMU_F.TXT bzw. CPCEMU_S.TXT.


Schreiben Sie Ihre Kommentare an:

        Marco Vieth
        Auf dem �kern 4
        33165 Lichtenau

        oder per E-mail:
          cpcemu@hotmail.com

        oder an:
        Rainer Loritz
        (rainer@loritz.net)

-------------------
