/*
 *  KCemu -- the KC 85/3 and KC 85/4 Emulator
 *  Copyright (C) 1997-2006 Torsten Paul
 *
 *  $Id: rc.cc,v 1.6 2002/10/31 01:46:35 torsten_paul Exp $
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>

#include <algorithm>

#include "kc/system.h"

#include "kc/kc.h"
#include "kc/rc.h"

#include "libdbg/dbg.h"

using namespace std;

RC *RC::_instance = 0;

static void print(RC::rc_map_pair_t p)
{
  DBG(0, form("KCemu/RC",
              "- %-40s <=> %s\n",
              p.first, p.second));
}

static void deallocate(RC::rc_map_pair_t p)
{
  /*
   *  data is allocated with strdup() so it has
   *  to be freed by free()
   */
  free((void *)p.first);
  free((void *)p.second);
}
                  
RC::RC(void)
{
  /*
   *  inserting into the map rejects new items that have a
   *  key that is already present
   *  so we need to read the personal file first
   */

  if (kcemu_configfile != NULL)
    {
      load_file(kcemu_configfile);
    }

  if (kcemu_homedir != NULL)
    {
      string dir(kcemu_homedir);
      string filename = dir + "/.kcemurc";
      load_file(filename.c_str());
    }

  /*
   *  load .kcemurc from current directory
   */
  load_file(".kcemurc");

  /*
   *  load .kcemurc from data directory
   */
  string datadir(kcemu_datadir);
  string filename = datadir + "/.kcemurc";
  load_file(filename.c_str());

  DBG(0, form("KCemu/RC",
              "--- dumping ressource database ---\n\n"));
  for_each(_map.begin(), _map.end(), print);
  DBG(0, form("KCemu/RC",
              "\n----------------------------------\n"));
}

RC::~RC(void)
{
  for_each(_map.begin(), _map.end(), deallocate);
  _map.clear();
}

void
RC::load_file(const char *filename)
{
  ifstream is;
  char *name, *arg, *tmp;
  char line[4096];
  
  is.open(filename);
  if (!is)
    {
      DBG(0, form("KCemu/RC",
		  "RC: can't open file '%s'\n", filename));
      return;
    }

  DBG(0, form("KCemu/RC",
	      "RC: reading configuration from '%s'\n", filename));

  while (242)
    {
      is.getline(line, 4096);
      if (is.eof())
	break;

      name = line;
      while ((*name == ' ') || (*name == '\t')) name++;
      if (*name != '#')
        {
          arg = strchr(name, ':');
          if (arg && (arg != name))
            {
              tmp = arg - 1;
              *arg++ = '\0';
              while ((*tmp == ' ') || (*tmp == '\t')) *tmp-- = '\0';
              while ((*arg == ' ') || (*arg == '\t')) arg++;
              tmp = strchr(arg, '\0');
              if (tmp && (tmp != arg))
                {
                  tmp--;
                  while ((*tmp == ' ') || (*tmp == '\t')) *tmp-- = '\0';
                  _map.insert(rc_map_pair_t(strdup(name), strdup(arg)));
                }
            }
        }
    }

  is.close();
}

void
RC::init(void)
{
  if (_instance == 0)
    _instance = new RC();
}

void
RC::done(void)
{
  delete _instance;
}

RC *
RC::instance(void)
{
  if (_instance == 0)
    {
      cerr << "RC::instance(void): RC::init() not called!" << endl;
      exit(1);
    }
  return _instance;
}

int
RC::get_int(const char *key, int def_val)
{
  long val;
  char *endptr;
  const char *ptr;
  item_map_t::iterator it;
  
  if (!key) return def_val;
  it = _map.find(key);
  if (it != _map.end())
    {
      ptr = (*it).second;
      val = strtol(ptr, &endptr, 0);
      if ((*ptr != '\0') && (*endptr == '\0'))
        return val;
    }
  return def_val;
}

const char *
RC::get_string(const char *key, const char *def_val)
{
  item_map_t::iterator it;

  if (!key) return def_val;
  it = _map.find(key);
  if (it != _map.end())
    return (*it).second;
  return def_val;  
}

int
RC::get_int_i(int idx, const char *key, int def_val)
{
  char *tmp;
  int val;

  if (!key) return def_val;
  tmp = new char[strlen(key) + 10];
  sprintf(tmp, "%s_%08X", key, idx);
  val = get_int(tmp, def_val);
  delete tmp;
  return val;
}

const char *
RC::get_string_i(int idx, const char *key, const char *def_val)
{
  char *tmp;
  const char *val;

  if (!key) return def_val;
  tmp = new char[strlen(key) + 10];
  sprintf(tmp, "%s_%08X", key, idx);
  val = get_string(tmp, def_val);
  delete[] tmp;
  return val;
}
