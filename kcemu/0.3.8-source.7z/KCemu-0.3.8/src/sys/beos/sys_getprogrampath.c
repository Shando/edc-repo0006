#include <stdio.h>

#include "kc/config.h"
#include "sys/sysdep.h"

char *
sys_getprogrampath(void)
{
  return NULL;
}
