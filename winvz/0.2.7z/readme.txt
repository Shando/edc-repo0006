You can now load and play your favourite vz games in a window the size of a
postage stamp. I'll get cracking on the larger screen sizes. To ease the
pain a bit  set your windows res to 640x480.

Also added the "extended keys",  PC arrow keys now work as VZ cursor keys,
as well as the insert & delete keys. The PC "End" key toggles inverse mode.

Just thinking about it I might also add a "soft reset" key, ie pressing the
Home key will cold boot the VZ.  Next version...

BTW: Basic program loading will not work properly because I'm not setting
the VZ system pointers yet - so circus & knights and dragons etc don't work.
Short basic programs work ok, ie the ones that just poke in the start
address.

