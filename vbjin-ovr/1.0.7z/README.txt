VBjin-OVR is a Virtual Boy Emulator for Windows with support for the Oculus Rift VR display device.

Find out more about the Oculus Rift at: http://www.oculusvr.com

The original repository for VBjin is located at: http://code.google.com/p/vbjin/
Many thanks to the authors of VBjin, PCEjin, and Mednafen for making this possible!


HOW TO
=======
To use this with the Oculus Rift, make sure you select the following settings in the menu:

Under View->Coloring, select either Red for the traditional experience, or Greyscale.
Under View->Splitting Mode, select Oculus Rift
Under View->Video Display, select Both
Go to File->Open Rom, and once the game loads, press ALT+ENTER to go fullscreen.
Keyboard/Joystick/Gamepad controls can be configured under Config->Input Config