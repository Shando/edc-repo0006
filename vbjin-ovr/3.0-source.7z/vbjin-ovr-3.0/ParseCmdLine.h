void ParseCmdLine(LPSTR lpCmdLine, HWND HWnd);
extern bool startPaused;
extern int stateToLoad;