#ifndef _READWRITE_H_
#define _READWRITE_H_
/*
//#include "../core.h"
#include <iostream>
#include <cstdio>
#include "inttypes.h"
#include "prefix.h"
#include "unixstuff.h"

//well. just for the sake of consistency
int write8le(uint8 b, FILE *fp);
int write8le(uint8 b, std::ostream *os);
int write16le(uint16 b, FILE *fp);
int write16le(uint16 b, std::ostream* os);
int write32le(uint32 b, FILE *fp);
int write32le(uint32 b, std::ostream* os);
int write64le(uint64 b, std::ostream* os);
int read64le(uint64 *Bufo, std::istream *is);
int read32le(uint32 *Bufo, std::istream *is);
inline int read32le(int *Bufo, std::istream *is) { return read32le((uint32*)Bufo,is); }
int read32le(uint32 *Bufo, FILE *fp);
int read16le(uint16 *Bufo, std::istream *is);
//inline int read16le(s16 *Bufo, std::istream* is) { return read16le((uint16*)Bufo,is); }
int read8le(uint8 *Bufo, std::istream *is);
*/
#endif
