#ifndef __MDFN_PNG_H
#define __MDFN_PNG_H

#include "../video.h"

int MDFN_SavePNGSnapshot(const char *fname, const MDFN_Surface *src, const MDFN_Rect *rect);

#endif

