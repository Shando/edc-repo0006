#include "../mednafen.h"
#include "../video.h"
#include "../general.h"
#include "../state.h"
//#include "../movie.h"
//#include "../driver.h"

