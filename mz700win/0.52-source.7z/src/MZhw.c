//----------------------------------------------------------------------------
// File:MZhw.c
// MZ-700/1500 Emulator MZ700WIN for Windows9x/NT/2000
// mz700win:Hardware Emulation Module
// ($Id: MZhw.c,v 1.6 2000/10/26 16:08:28 marukun Exp $)
//
// 'mz700win' by Takeshi Maruyama, based on Russell Marks's 'mz700em'.
// Z80 emulation from 'Z80em' Copyright (C) Marcel de Kogel 1996,1997
//----------------------------------------------------------------------------

#define MZHW_H_

#include <windows.h>

#include "resource.h"

#include "mz700win.h"

#include "fileio.h"
#include "win.h"
#include "fileset.h"

#include "Z80.h"
#include "Z80codes.h"

#include "defkey.h"
#include "MZhw.h"
#include "mzmon1em.h"
#include "mzmon2em.h"

#include "MZmain.h"
#include "MZddraw.h"
#include "MZscrn.h"
#include "dssub.h"

#define TEMPO_STROBE_TIME		14								/* �e���|�r�b�g�����Ԋu */
#define PIT_DEBUG 0

/*** for z80.c ***/
int IFreq = 60;
int CpuSpeed=100;
int Z80_IRQ;

/* for memories of MZ */
UINT8	*mem;													/* Main Memory */
UINT8	*junk;													/* to give mmio somewhere to point at */

UINT8 *mz1r12_ptr;												/* pointer for MZ-1R12 */
UINT8 *mz1r18_ptr;												/* pointer for MZ-1R18 (Ram File) */

UINT8 *font;													/* Font ROM (4K) */
UINT8 *pcg700_font;												/* PCG700 font (2K) */
UINT8 *pcg1500_font_blue;										/* MZ-1500 PCG-BLUE (8K) */
UINT8 *pcg1500_font_red;										/* MZ-1500 PCG-RED (8K) */
UINT8 *pcg1500_font_green;										/* MZ-1500 PCG-GREEN (8K) */

int rom1_mode;													/* ROM-1 ���ʗp�t���O */
int rom2_mode;													/* ROM-2 ���ʗp�t���O */

/* HARDWARE STATUS WORK */
THW700_STAT		hw700;
T700_TS			ts700;

THW1500_STAT	hw1500;
T1500_TS		ts1500;

/* 8253�֘A���[�N */
T8253_DAT		_8253_dat;
T8253_STAT		_8253_stat[3];

/* PIO�֘A���[�N */
TZ80PIO_STAT	Z80PIO_stat[2];

/* MZ-1500PSG */
TMZ1500PSG		mz1500psg[8];											// (3+1)*2

/* for Keyboard Matrix */
UINT8 keyports[10] ={ 0,0,0,0,0, 0,0,0,0,0 };

// MZ�̃��C���������̃o���N�|���������Ή��\
static UINT8	*memptr[32];

//
void update_membank(void)
{
	TMEMBANK *mb;
	UINT8 *baseptr;
	int i;
	UINT8 at;

	for (i=0; i<32; i++)
	{
		mb = &hw700.memctrl[i];
		at = 0;

		switch (mb->base)
		{
		case MB_ROM1:
			baseptr = mem + ROM_START;
			break;

		case MB_ROM2:
			baseptr = mem + ROM2_START;
			break;

		case MB_RAM:
			baseptr = mem + RAM_START;
			at = 1;
			break;

		case MB_VRAM:
			baseptr = mem + VID_START;
			at = 5;
			break;

		case MB_DUMMY:
			baseptr = junk;
			at = 2;
			break;

		case MB_FONT:
			baseptr = font;
			at = 0;
			break;

		case MB_PCGB:
			baseptr = pcg1500_font_blue;
			at = 5;
			break;

		case MB_PCGR:
			baseptr = pcg1500_font_red;
			at = 5;
			break;

		case MB_PCGG:
			baseptr = pcg1500_font_green;
			at = 5;
			break;

		default:
			baseptr = junk;
			break;
		}

		mb->attr = at;
		memptr[i] = baseptr + (UINT32) mb->ofs;
	}

}

//
void vblnk_start(void)
{
	ts700.vsync_tstates = ts700.cpu_tstates;
}

// Keyport Buffer Clear
void mz_keyport_init(void)
{
	FillMemory(keyports, 10, 0xFF );
}

///////////////
// WM_KEYDOWN
///////////////
void mz_keydown(WPARAM wParam)
{
	int i = (int) wParam;
	UINT8 *kptr = get_keymattbl_ptr() + (menu.keytype << 8);
	int n,b;

	if (kptr[i]==0xFF) return;
	
#if _DEBUG	
	if ( Z80_Trace ) return;
#endif
	
	n = kptr[i] >> 4;
	b = kptr[i] & 0x0F;
	keyports[n] &= (~(1 << b));
#if _DEBUG
//	dprintf("keydown : kptr = %02x idx%d bit%d\n",i,n,b);
#endif	
	
}

////////////
// WM_KEYUP
////////////
void mz_keyup(WPARAM wParam)
{
	int i = (int) wParam;
	UINT8 *kptr = get_keymattbl_ptr() + (menu.keytype << 8);
	int n,b;
	
	if (kptr[i]==0xFF) return;

#if _DEBUG	
	if ( Z80_Trace ) return;
#endif	
	
	n = kptr[i] >> 4;
	b = kptr[i] & 0x0F;
	keyports[n] |= (1 << b);
#if _DEBUG
//	dprintf("keyup : kptr = %02x idx%d bit%d\n",i,n,b);
#endif	
}

/* �l�y�����Z�b�g���� */
void mz_reset(void)
{
	int i,a;
	TMEMBANK *mp;
	Z80_Regs StartRegs;

	/* �W�Q�T�R���[�N�̏����� */
	ZeroMemory(&_8253_stat,sizeof(_8253_stat));
	ZeroMemory(&_8253_dat,sizeof(_8253_dat));

	/* �l�y���[�N�̏����� */
	ZeroMemory(&hw700,sizeof(hw700));
	ZeroMemory(&ts700,sizeof(ts700));
	ZeroMemory(&hw1500,sizeof(hw1500));
	ZeroMemory(&ts1500,sizeof(ts1500));

	/* �o�h�s������ */
	pit_init();

	/* �y�W�O���W�X�^�̏����� */
	Z80_SetRegs(&StartRegs);

	/* �o���N�\���������� */
	for (a=0,i=0; i<26; i++)
	{
		mp = &hw700.memctrl[i];
		mp->ofs = a;
		mp->base = MB_RAM;
		a += 0x800;
	}

	Z80_Out(0xE4,0);			// $0000-$0FFF:ROM  $E000-$FFFF:MMIO/ROM2
	update_membank();

	/* 1500�o�r�f������ */
	mz_psg_init();

	/* �L�[�|�[�g�̏����� */
	mz_keyport_init();

	/* RDINFwork Clear */
	clr_rdinf_buf();

    if (rom1_mode <= MON_OTHERS || rom1_mode >= MON_NEWMON700)
    {
        // ���j�^���[�N�̏�����
        ZeroMemory(mem + RAM_START + 0x1000, 0x200);
        // VRAM�̏�����
        ZeroMemory(mem + VID_START , 0x0400);
        FillMemory(mem + VID_START + 0x800 , 0x0400, (bk_color) ? bk_color : 0x71);
    }
	// ���blt�t���O
	mz_refresh_screen(REFSC_ALL);

	Z80_intflag=0;
	
	mz_palet_init();											/* 1500�p���b�g������ */

//	hw700.pcg700_mode=8;
	hw700.tempo_strobe=1;

	hw700.retrace=1;
	hw700.motor=1;												/* �J�Z�b�g���[�^�[ */

	/* �T�E���h(8253#0)�̏����� */
	_8253_dat.beep_mask=1;
	_8253_dat.int_mask=4;
	
	hw1500.e5_bak = -1;
	
	/* �y�W�O�̃��Z�b�g */
	Z80_Reset();

	/* �X���b�h�@�J�n */
	start_thread();
}

/////////////////////////////////////////////////////////////////
// 8253 PIT
/////////////////////////////////////////////////////////////////

//////////////
// PIT ������
//////////////
void pit_init(void)
{
	T8253_STAT *st;
	int i;

	for (i=0;i<2;i++)
	{
		st = &_8253_stat[i];
		st->rl = st->rl_bak = 3;
		st->counter_base = st->counter = st->counter_lat = 0x0000;
		st->counter_out = 0;
		st->lat_flag = 0;
	}

	_8253_dat.int_mask = 0;
	
	_8253_dat.bcd = 0;
	_8253_dat.m = 0;
	_8253_dat.rl = 3;
	_8253_dat.sc = 0;
}

////////////////////////////
// 8253 control word write
////////////////////////////
void write_8253_cw(int cw)
{
	T8253_STAT *st;
	
	_8253_dat.bcd = cw & 1;
	_8253_dat.m = (cw >> 1) & 7;
	_8253_dat.rl = (cw >> 4) & 3;
	_8253_dat.sc = (cw >> 6) & 3;

	st = &_8253_stat[_8253_dat.sc];

//	if (_8253_dat.sc==2) st->counter_out = 0;								/* count#2,then clr */
	st->counter_out = 0;								/* count clr */

	/* �J�E���^�E���b�`�E�I�y���[�V���� */
	if (_8253_dat.rl==0)
	{
		st->counter_lat = st->counter;
		st->lat_flag = 1;
#if PIT_DEBUG	
	dprintf("Count%d latch\n",_8253_dat.sc);
#endif
		return;
	}

	st->bit_hl = 0;
	st->lat_flag = 0;
	st->rl = _8253_dat.rl;
	st->bcd = _8253_dat.bcd;
	st->mode = _8253_dat.m;

#if PIT_DEBUG	
	dprintf("Count%d mode=%d rl=%d bcd=%d\n",_8253_dat.sc,_8253_dat.m,
		_8253_dat.rl,_8253_dat.bcd);
#endif
	
}

////////////////////////////
// Z80 PIO Control Register
////////////////////////////
void mz_z80pio_ctrl(int port,int value)
{
	TZ80PIO_STAT *pio;
	
	pio = &Z80PIO_stat[port];

	if (pio->cont == 1)
	{
		pio->iosel = value;
		pio->cont = 0;
#if _DEBUG
		dprintf("Z80PIO:%d:iosel=$%02x\n",port,pio->iosel);
#endif		
		return;
	}
	else
	if (pio->cont == 2)
	{
		pio->imask = value;
		pio->cont = 0;
#if _DEBUG
		dprintf("Z80PIO:%d:imask=$%02x\n",port,pio->imask);
#endif		
		return;
	}
		
	if ( (value & 0x0F) == 0x0F)										/* ���[�h�E���[�h�ł��邱�Ƃ̈� */
	{
		pio->mode = (value >> 6) & 3;
#if _DEBUG
		dprintf("Z80PIO:%d:mode=%d\n",port,pio->mode);
#endif
		if (pio->mode == 3)
			pio->cont = 1;												/* mode 2nd */
	}
	else
	if ( (value & 0x0F) == 0x07)										/* �����ݐ��䃏�[�h�ł��邱�Ƃ̈� */
	{
		pio->intw = value & 0xF0;
#if _DEBUG
		dprintf("Z80PIO:%d:intw=$%02x\n",port,pio->intw);
#endif		
		if (pio->intw & 0x10)
			pio->cont = 2;												/* mask follows 2nd */
	}
	else
	if ( (value & 0x0F) == 0x03)										/* �����݋����[�h�ł��邱�Ƃ̈� */
	{
		pio->intw &= 0x70;
		pio->intw |= (value & 0x80);
#if _DEBUG
		dprintf("Z80PIO:%d:intw=$%02x\n",port,pio->intw);
#endif		
	}
	else
	if ( (value & 0x01) == 0x00)										/* �x�N�g�����[�h�ł��邱�Ƃ̈� */
	{
		pio->intv = value;												/* �x�N�g���E���[�h */
#if _DEBUG
		dprintf("Z80PIO:%d:intv=$%02x\n",port,pio->intv);
#endif		
	}
		
}

// Z80 PIO Data Register
void mz_z80pio_data(int port,int value)
{


}

// Z80PIO �����ݏ������s
void pio_intjob(int out)
{
	if (Z80PIO_stat[0].intw & 0x80)										/* ���荞�ݎg�p�̗L�� */
	{
//		dprintf("intv=$%02x\n",Z80PIO_stat[0].intv);
		Z80_intflag |= 2;
		if (out == 0)
			Z80PIO_stat[0].pin |= 0x10;									/* (INT 0)�ǂݍ��܂��f�[�^�̏����� */
		else
			Z80PIO_stat[0].pin |= 0x20;									/* (INT 1)�ǂݍ��܂��f�[�^�̏����� */
		Interrupt((int)(Z80PIO_stat[0].intv));
	}
}

// Z80PIO���荞�ݗp�J�E���^
int pio_pitcount(void)
{
	T8253_STAT *st;
	int out;
	
	st = &_8253_stat[0];
	out = 0;

	// pio int=INT1(A4)
	// pit int=INT0(A3) or CPU INT
	if (_8253_dat.makesound)											/* e008 makesound=gate */
	{
		if (st->mode != 3)												/* ���`�g�̌J��Ԃ��g�`����Ȃ������珈�� */
		{
			if (pitcount_job(0,PIO_TIMER_RESO))
			{
				out = 1;
			}
		}
	}
	
	return out;
}

//
int pitcount_job(int no,int cou)
{
	T8253_STAT *st;
	int out;
	
	st = &_8253_stat[no];
	out = 0;

	switch (st->mode)
	{
		/* mode 0 */
	case 0:
		if (st->counter <= 0)
		{
			out=1;
			st->counter = 0;
		}
		else
		{
			st->counter-=cou;
		}
		break;

		/* mode 2 */
	case 2:
		st->counter-=cou;
		if (st->counter<=0)
		{
			/* �J�E���^�����l�Z�b�g */
			st->counter = (int) st->counter_base;
//			do{
//			st->counter += (int) st->counter_base;
//			}while (st->counter<0);
			out=1;														/* out pulse */
		}

		break;
		
	case 3:
		break;	

		/* mode 4 */
	case 4:
		st->counter-=cou;
		if (st->counter<=0)
		{
			/* �J�E���^�����l�Z�b�g */
			st->counter = -1;
			out=1;														/* out pulse (1 time only) */
		}
		break;

	default:
		break;
	}

	st->counter_out = out;
	return out;
}

//
int pit_count(void)
{
	int ret;

	/* �J�E���^�P��i�߂� */
	if (pitcount_job(1,1))
	{
		/* �J�E���^�Q��i�߂� */
		ret = pitcount_job(2,1);
	}

	return ret;
}

/////////////////////////////////////////////////////////////////
// 8253 SOUND / PSG
/////////////////////////////////////////////////////////////////
//
void play8253(void)
{
	int freq2,freqtmp;

	if (sound_di) return;

	if ((!_8253_dat.beep_mask)  )
	{
		if (_8253_dat.setsound)
		{
			_8253_dat.setsound = 0;
			StopWaveBuffer(0);
		}
		return;
	}

	/* �T�E���h��炷 */
	freqtmp = _8253_stat[0].counter_base;		
	if (_8253_dat.makesound == 0)
	{
		if (GetWaveBufferStat(0))
		{
			SetWaveVol(0, DSBVOLUME_MIN);
			while (GetWaveVol(0) != DSBVOLUME_MIN);
		}
		else
		{
			StopWaveBuffer(0);
			_8253_dat.setsound = 0;
		}

	}
	else
	if (freqtmp>2 && freqtmp<0x4000)
	{
		// play
		freq2 = ((895000/2) / freqtmp) * (44100/880);
		if (!GetWaveBufferStat(0))
		{
			StartWaveBuffer(0, freq2, 0, DSBVOLUME_MAX, DSBPLAY_LOOPING);
			_8253_dat.setsound = 1;
		}
		else
		{
			SetWaveFreq(0, freq2);
			SetWaveVol(0, DSBVOLUME_MAX);
			while (GetWaveVol(0) != DSBVOLUME_MAX);
		}
	}
	else
	{
		// stop
		if (_8253_dat.setsound)
		{
			SetWaveVol(0, DSBVOLUME_MIN);
			while (GetWaveVol(0) != DSBVOLUME_MIN);
		}
		else
		{
			StopWaveBuffer(0);
		}
	}
	
}

///////////////////////////////
// MZ700,1500 sound initiailze
///////////////////////////////
void mzsnd_init(void)
{
	int i;

	/* 1500Sound������ */
	for (i=0;i<=8;i++)
	{
		Set700Sound(i);													// 0:8253 / 1-8:PSG
		if (i)
		{
			mz1500psg[i-1].setsound = 0;
			mz1500psg[i-1].dosound = DOSND_STOP;
		}
	}
	
}

// PSG Initialize
void mz_psg_init(void)
{
	int i;

	if (sound_di) return;

	for (i=0;i<8;i++)
	{
		StopWaveBuffer(i+1);
	}

}

// PSG Out
void mz_psg_out(int port,int value)
{
	static TMZ1500PSG *psgp;
	int a;
	int r;

	M_CSTATE(32);													// Wait for PSG (32Clock)

	if (value & 128)
	{
		r = (value >> 5)&3;

		/* ���� */
//		psgp = &mz1500psg[(port<<2)+((value >> 5)&3)];
		a = (port<<2)+r;
//		dprintf("psgout port=%d value=%02x a=%d\n",port,value,a);
		psgp = &mz1500psg[a];

		if (value & 16)
		{
			/* ���� */
			a = value & 15;
			if (psgp->psgvol != a) psgp->dosound |= DOSND_VOL;			// ���ʍX�V
			psgp->psgvol = a;
			
			if (a == 15)
			{
				psgp->psgfreq = 0xffff;
				psgp->dosound = DOSND_STOP;								// ����~
			}
		}
		else
		{
			psgp->psgfreq_bak = psgp->psgfreq;
			if (r < 3)
			{
				/* tone ���g�� */
				psgp->psgfreq &= 0x3F0;
				psgp->psgfreq |= (value & 15);
//				dprintf("low:port=%d freq=$%04X\n",port,psgp->psgfreq);
				if (psgp->psgfreq != psgp->psgfreq_bak)
				{
					psgp->dosound |= DOSND_FREQ;
				}
			}
			else
			{
				/* noise */
				psgp->psgfreq = value & 7;
				if (psgp->psgfreq != psgp->psgfreq_bak)
				{
					psgp->dosound |= DOSND_FREQ;
				}
			}
		}


	}
	else
	{
		/* ��� */
		psgp->psgfreq_bak = psgp->psgfreq;
		psgp->psgfreq &= 0x0F;
		psgp->psgfreq |= (value & 0x3F)<<4;
//		dprintf("hi :port=%d freq=$%04X\n",port,psgp->psgfreq);
		if (psgp->psgfreq<=1) psgp->dosound = DOSND_STOP;				// �����`�F�b�N
		else
		if (psgp->psgfreq_bak != psgp->psgfreq)
			psgp->dosound |= DOSND_FREQ;								// ���g���X�V
	}


}

// PSG Play
void playPSG(void)
{
	int freq2;
	int i,j,pid,a;
	int pan,vol;
	TMZ1500PSG *psgp;

	if (sound_di) return;
	
	/* �o�r�f��炷 */
	if (sound_md == 0)
	{
		// �ʏ폈��
		for (j=0;j<2;j++)
		{
			for (i=3;i>=0;i--)
			{
				pid = (j<<2)+i;
				psgp = &mz1500psg[pid];
				vol = -(psgp->psgvol*200);
				pan = (pid<4) ? -10000 : 10000;
				if (psgp->dosound & DOSND_STOP)
				{
					/* stop */
					if (i < 3)
						SetWaveVol(pid+1, DSBVOLUME_MIN); 
					else
						StopWaveBuffer(pid+1);

					psgp->psgfreq = 0xFFFF;
					psgp->setsound = 0;
					psgp->dosound = 0;
				}
				else
				if ((psgp->dosound & DOSND_ALL))
				{
					if (i == 3)			// Noise
					{
						if (!psgp->setsound)
						{
							/* play Noise */
							freq2 = mz1500psg[pid-1].psgfreq;
							SetRuntimeNoise(pid, psgp->psgfreq, freq2);
							StartWaveBuffer(pid+1, 0 ,
											pan ,
											vol ,
											DSBPLAY_LOOPING);
							psgp->dosound = 1;
						}
						else
						{
							if (psgp->dosound & DOSND_VOL)
							{
								SetWaveVol(pid+1, vol );
							}
						}

						psgp->dosound &= ~DOSND_ALL;
					}
					else
					{
						// Tone
						if ( (psgp->dosound & DOSND_FREQ) || (!psgp->setsound) )
						{
							psgp->dosound &= ~DOSND_ALL;
							/* Play TONE */
							a=(psgp->psgfreq & 0x3FF) * 32;
							if (!a) a++;
							freq2 = (CPU_SPEED_BASE/2) / a;
							StartWaveBuffer(pid+1, freq2*(44100/880) ,
											pan ,
											vol ,
											DSBPLAY_LOOPING);
							psgp->dosound = 1;
						}
						else
						if (psgp->dosound & DOSND_VOL)
						{
							psgp->dosound &= ~DOSND_VOL;

							SetWaveVol(pid+1, vol );
						}
					}

				} //	if ((psgp->dosound & DOSND_ALL))
			}

		}

	}
	else
	{
		// �h���C�o�Ƃ̑����΍�
		for (j=0;j<2;j++)
		{
			for (i=0;i<4;i++)
			{
				pid = (j<<2)+i;
				psgp = &mz1500psg[pid];
				vol = -(psgp->psgvol*200);
				pan = (pid<4) ? -10000 : 10000;
				if (psgp->dosound & DOSND_STOP)
				{
					/* stop */
					StopWaveBuffer(pid+1);

					psgp->psgfreq = 0xFFFF;
					psgp->setsound = 0;
					psgp->dosound = 0;
				}
				else
				if ((psgp->dosound & DOSND_ALL))
				{
					if (i == 3)			// Noise
					{
						/* play Noise */
						freq2 = mz1500psg[pid-1].psgfreq;
						SetRuntimeNoise(pid, psgp->psgfreq, freq2);
						StartWaveBuffer(pid+1, 0 ,
										pan ,
										vol ,
										DSBPLAY_LOOPING);
						psgp->dosound = 1;

						psgp->dosound &= ~DOSND_ALL;
					}
					else
					{
						// Tone
						psgp->dosound &= ~DOSND_ALL;
						/* Play TONE */
						a=(psgp->psgfreq & 0x3FF) * 32;
						if (!a) a++;
						freq2 = (CPU_SPEED_BASE/2) / a;
						StartWaveBuffer(pid+1, freq2*(44100/880) ,
										pan ,
										vol ,
										DSBPLAY_LOOPING);
						psgp->dosound = 1;
					}

				} //	if ((psgp->dosound & DOSND_ALL))
			}

		}


	}

}

////////////////////////////////////////////////////////////
// Memory Access
////////////////////////////////////////////////////////////
// READ
unsigned Z80_RDMEM(dword x)
{
	int page = x >> 11;
	int attr = hw700.memctrl[page].attr;

	if (!attr)
	{
		M_CSTATE(1);													/* wait */
		
	}
	if (attr & 4)
	{
//		if (hw700.retrace)												/* not V-blank? */
		{
			M_CSTATE(VRAM_ACCESS_WAIT);									/* wait */
		}
	}
	return (attr&2)?mmio_in(x):memptr[page][x&0x7FF];
}

// WRITE
void Z80_WRMEM(dword x, dword y)
{
	unsigned int page = x >> 11;
		  
	int attr = hw700.memctrl[page].attr;
		  
	if(attr&2) mmio_out(x,y);
	else
	if(attr)
	{
		memptr[page][x&0x7FF] = (BYTE) y;
		if (attr & 4)
		{
			mz_blt_screen();											/* VRAM�A�N�Z�X�������Refresh */
//			if (hw700.retrace)											/* not V-blank? */
			{
				M_CSTATE(VRAM_ACCESS_WAIT);								/* wait */
			}
		}
	}
}

////////////////////////////////////////////////////////////
// Memory-mapped I/O Access
////////////////////////////////////////////////////////////
// IN
int mmio_in(int addr)
{
	int tmp;
	T8253_STAT *st;

	switch(addr)
	{
	case 0xE000:
		return 0xff;
		
	case 0xE001:
		/* read keyboard */
		return keyports[hw700.pb_select];
		
	case 0xE002:
		/* bit 4 - motor (on=1)
		 * bit 5 - tape data
		 * bit 6 - cursor blink timer
		 * bit 7 - vertical blanking signal (retrace?)
		 */
		tmp=((hw700.cursor_cou%25>15) ? 0x40:0);						/* �J�[�\���_�Ń^�C�}�[ */
		tmp=(((hw700.retrace^1)<<7)|(hw700.motor<<4)|tmp|0x0F);						
		return tmp;
		
	case 0xE003:
		return 0xff;
		
		/* �o�h�s�֘A */
	case 0xE004:
	case 0xE005:
	case 0xE006:
		st = &_8253_stat[addr-0xE004];
		
		if (st->lat_flag)
		{
			/* �J�E���^���b�`�I�y���[�V���� */
			switch (st->rl)
			{
			case 1:
				/* ���ʂW�r�b�g�Ăяo�� */
				st->lat_flag = 0;						// counter latch opelation: off
				return (st->counter_lat & 255);
			case 2:
				/* ��ʂW�r�b�g�Ăяo�� */
				st->lat_flag = 0;						// counter latch opelation: off
				return (st->counter_lat >> 8);
			case 3:
				/* �J�E���^�E���b�`�E�I�y���[�V���� */
				if((st->bit_hl^=1)) return (st->counter_lat & 255);			/* ���� */
				else
				{
					st->lat_flag = 0;					// counter latch opelation: off
					return (st->counter_lat>>8); 	/* ��� */
				}

				break;
			default:
				return 0x7f;
			}
		}
		else
		{
			switch (st->rl)
			{
			case 1:
				/* ���ʂW�r�b�g�Ăяo�� */
				return (st->counter & 255);
			case 2:
				/* ��ʂW�r�b�g�Ăяo�� */
				return (st->counter>>8);
			case 3:
				/* ���ʁE��� */
				if((st->bit_hl^=1)) return (st->counter & 255);
				else return (st->counter>>8);
			default:
				return 0xff;
			}
		}
		break;

	case 0xE008:
		/* ����炷���߂̃^�C�~���O�r�b�g���� */
		return (0x7e | hw700.tempo_strobe);
		
	default:
		/* all unused ones seem to give 7Eh */
		return 0x7e;
	}
}

// OUT
void mmio_out(int addr,int val)
{
	T8253_STAT *st;
	int i;

	switch(addr)
	{
	case 0xE000:
		if (!(val & 0x80)) hw700.cursor_cou = 0;	// cursor blink timer reset

		hw700.pb_select = (val & 15);
		if (hw700.pb_select>9) hw700.pb_select=9;
		break;
		
	case 0xE001:
	  break;
  
	case 0xE002:
		/* bit 0 - 8253 mask
		 * bit 1 - cassete write data
		 * bit 2 - intmsk
		 * bit 3 - motor on
		 */
		_8253_dat.beep_mask = val & 0x01;
		_8253_dat.int_mask=val & 0x04;
#if _DEBUG		
		dprintf("write beep_mask=%d int_mask=%d\n",_8253_dat.beep_mask,_8253_dat.int_mask);
#endif
		play8253();
		break;
		
	case 0xE003:
		// bit0:   1=Set / 0=Reset
		// Bit1-3: PC0-7
		i = (val >> 1) & 7;
		if ((val & 1))
		{
			// SET
			switch (i)
			{
			case 0:
				_8253_dat.beep_mask = 1;
				break;

			case 1:
				// Cassete
				// 1 byte: long:stop bit/ 1=long 0=short *8
				ts700.cmt_tstates = 0;
#if _DEBUG
				dprintf("----\n");
#endif
				break;

			case 2:
				_8253_dat.int_mask = 4;
				break;
			}
		}
		else
		{
			// RESET
			switch (i)
			{
			case 0:
				_8253_dat.beep_mask = 0;
				break;

				// Cassete
				// 1 byte: long:stop bit/ 1=long 0=short *8
			case 1:
#if _DEBUG
				dprintf("cmt_tstates=%d\n",ts700.cmt_tstates);		// short=650,long=1252 ?
#endif
				break;

			case 2:
				_8253_dat.int_mask = 0;
				break;
			}
		}
		if (i==0 || i==2)
		{
#if _DEBUG		
			dprintf("E003:beep_mask=%d int_mask=%d\n",_8253_dat.beep_mask,_8253_dat.int_mask);
#endif
			play8253();
		}

		break;
		
	case 0xE004:
	case 0xE005:
	case 0xE006:
		/* �J�E���^�ɏ������� */
		st = &_8253_stat[addr-0xE004];
		if (st->mode == 0)												/* ���[�h�O��������Aout���N���A */
		{
			st->counter_out = 0;
		}
		st->lat_flag = 0;						// counter latch opelation: off

		switch(st->rl)
		{
		case 1:
			/* ���ʂW�r�b�g�������� */
			st->counter = (val&0x00FF);
			st->counter_base = st->counter;
#if PIT_DEBUG			
			dprintf("Count%d=$%04X\n",addr-0xe004,st->counter);
#endif
			st->bit_hl=0;
			break;
		case 2:
			/* ��ʂW�r�b�g�������� */
			st->counter = (val << 8)&0xFF00;
			st->counter_base = st->counter;
#if PIT_DEBUG			
			dprintf("Count%d=$%04X\n",addr-0xe004,st->counter);
#endif
			st->bit_hl=0;
			break;
			
		case 3:
			if (st->bit_hl)
			{
				st->counter = ((st->counter & 0xFF)|(val << 8))&0xFFFF;
				st->counter_base = st->counter;
#if PIT_DEBUG			
				dprintf("H:Count%d=$%04X\n",addr-0xe004,st->counter);
#endif
			}
			else
			{
				st->counter = (val&0x00FF);
				st->counter_base = st->counter;
#if PIT_DEBUG			
				dprintf("L:Count%d=$%04X\n",addr-0xe004,st->counter);
#endif
			}
			st->bit_hl^=1;
			break;
		}

		/* �T�E���h�p�̃J�E���^�̏ꍇ */
		if (addr==0xE004)
		{
			if(!st->bit_hl)
			{
//				dprintf("freqtmp=$%04x makesound=%d\n",freqtmp,_8253_dat.makesound);
				play8253();
			}
		}
		break;
		
	case 0xE007:
#if _DEBUG
		dprintf("$E007=$%02X\n",val);
#endif
		/* PIO CONTROL WORD */
		write_8253_cw(val);
		break;
		
	case 0xE008:
#if _DEBUG
		dprintf("$E008=$%02X\n",val);
#endif
		/* bit 0: sound on/off */
		_8253_dat.makesound=(val&1);
		play8253();
		break;

		/* PCG700 Control */
		/* Data */
	case 0xE010:
		hw700.pcg700_data = val;
		break;

		/* Addr-L */
	case 0xE011:
		hw700.pcg700_addr &= 0xFF00;
		hw700.pcg700_addr |= val;
		break;

		/* Addr-H / Control */
	case 0xE012:
		hw700.pcg700_addr &= 0x00FF;
		hw700.pcg700_addr |= (val<<8);
		if ((val & (16+32))==(16+32))
		{
			/* �b�f���o�b�f�R�s�[ */
			i = hw700.pcg700_addr & 2047;
			if (i & 1024) i=2048+i;
			else i=1024+i;
			
			pcg700_font[hw700.pcg700_addr & 2047]=font[i];
		}
		else
		if (val & 16)
		{
			/* �o�b�f��` */
			pcg700_font[hw700.pcg700_addr & 2047]=hw700.pcg700_data;
		}

		/* �o�b�f�I�� */
		hw700.pcg700_mode = val & 8;
		break;
		
		
	default:;
		break;
	}
}

////////////////////////////////////////////////////////////
// I/O Port Access
////////////////////////////////////////////////////////////
// IN
byte Z80_In (word Port)
{
	int r=255;

	switch (Port & 255)
	{
	case 0xea:
		/* read data from MZ-1R18, then addr auto incliment.  */
		r = mz1r18_ptr[hw1500.mz1r18_addr++];
		hw1500.mz1r18_addr &= (MZ1R18_SIZE-1);
		break;
	case 0xf4:
		/* sio A data */
		break;
	case 0xf5:
		/* sio B data */
		break;
	case 0xf6:
		/* sio A control */
		break;
	case 0xf7:
		/* sio B control */
	    r=0x80;															/* dummy */
		break;
	case 0xf8:
		if (use_cmos)
		{
			/* MZ-1R12 addr counter reset  */
			hw700.mz1r12_addr = 0x0000;
		}
		break;
	case 0xf9:
		if (use_cmos)
		{
			/* read data from MZ-1R12, then addr auto incliment.  */
			r = mz1r12_ptr[hw700.mz1r12_addr];
			hw700.mz1r12_addr = ( hw700.mz1r12_addr + 1) & (MZ1R12_SIZE-1);
		}
		break;
	case 0xfe:
		/* z80 pio Port-A DATA Reg.*/
//		r = 0x10;														/* int0����̂�肱�݁H */
//		r = 0x20;														/* int1����̂�肱�݁H */
		r = Z80PIO_stat[0].pin;
		Z80PIO_stat[0].pin = 0xC0;										/* �ǂݍ��܂��f�[�^�̏����� */
		break;
	case 0xff:
		/* z80 pio Port-B DATA Reg.*/
		r = 0xff;
		break;
	}
	
	return r;
}

// OUT
void Z80_Out(word Port,word Value)
{
	int iVal =(int) (Value & 0xFF);
	int iPort = (int) (Port & 0xFFFF);
	TMEMBANK *mp;

	switch (iPort & 0x00FF)
	{
	case 0xe0:
		/* make 0000-0FFF RAM */
		mp = &hw700.memctrl[0];
		mp->base = MB_RAM; mp->ofs = 0x000; mp++;
		mp->base = MB_RAM; mp->ofs = 0x800;
		update_membank();
		return;
		
	case 0xe1:
		/* make D000-FFFF RAM */
		mp = &hw700.memctrl[26];
		mp->base = MB_RAM; mp->ofs = 0xD000; mp++;
		mp->base = MB_RAM; mp->ofs = 0xD800; mp++;
		mp->base = MB_RAM; mp->ofs = 0xE000; mp++;
		mp->base = MB_RAM; mp->ofs = 0xE800; mp++;
		mp->base = MB_RAM; mp->ofs = 0xF000; mp++;
		mp->base = MB_RAM; mp->ofs = 0xF800;
		update_membank();
		return;
		
	case 0xe2:
		/* make 0000-0FFF ROM */
		mp = &hw700.memctrl[0];
		mp->base = MB_ROM1; mp->ofs = 0x0000; mp++;
		mp->base = MB_ROM1; mp->ofs = 0x0800;
		update_membank();
		return;
		
	case 0xe3:
		/* make D000-FFFF VRAM/MMIO */
		mp = &hw700.memctrl[26];
		mp->base = MB_VRAM; mp->ofs = 0x0000; mp++;
		mp->base = MB_VRAM; mp->ofs = 0x0800; mp++;
		mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
		/* 1500/700�Ɛ؂�ւ��ē��삳����Ƃ� */
		if (menu.machine == MACHINE_MZ1500)
		{
			mp->base = MB_ROM2; mp->ofs = 0x0000; mp++;
			mp->base = MB_ROM2; mp->ofs = 0x0800; mp++;
			mp->base = MB_ROM2; mp->ofs = 0x1000;
		}
		else
		{
			mp->base = MB_DUMMY; mp->ofs = 0x0800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800;
		}
		update_membank();
		return;
		
	case 0xe4:
		Z80_Out(0xe2,0);
		Z80_Out(0xe3,0);
		return;
		
	case 0xe5:
		if (hw1500.e5_bak < 0)
		{
			/* Backup Bank Data */
			CopyMemory(&hw1500.memctrl_bak,&hw700.memctrl[26],sizeof(TMEMBANK)*6);
			hw1500.e5_bak = iVal;
			update_membank();
		}
		/* Select PCG Block or CG */
		switch (iVal)
		{
		case 0x00:
			/* CG BANK */
			mp = &hw700.memctrl[26];
			mp->base = MB_FONT; mp->ofs = 0x0000; mp++;
			mp->base = MB_FONT; mp->ofs = 0x0800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800;
			update_membank();
			break;

		case 0x01:
			/* PCG BLUE */
			mp = &hw700.memctrl[26];
			mp->base = MB_PCGB; mp->ofs = 0x0000; mp++;
			mp->base = MB_PCGB; mp->ofs = 0x0800; mp++;
			mp->base = MB_PCGB; mp->ofs = 0x1000; mp++;
			mp->base = MB_PCGB; mp->ofs = 0x1800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800;
			update_membank();
			break;
			
		case 0x02:
			/* PCG RED */
			mp = &hw700.memctrl[26];
			mp->base = MB_PCGR; mp->ofs = 0x0000; mp++;
			mp->base = MB_PCGR; mp->ofs = 0x0800; mp++;
			mp->base = MB_PCGR; mp->ofs = 0x1000; mp++;
			mp->base = MB_PCGR; mp->ofs = 0x1800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800;
			update_membank();
			break;
			
		case 0x03:
			/* PCG GREEN */
			mp = &hw700.memctrl[26];
			mp->base = MB_PCGG; mp->ofs = 0x0000; mp++;
			mp->base = MB_PCGG; mp->ofs = 0x0800; mp++;
			mp->base = MB_PCGG; mp->ofs = 0x1000; mp++;
			mp->base = MB_PCGG; mp->ofs = 0x1800; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0000; mp++;
			mp->base = MB_DUMMY; mp->ofs = 0x0800;
			update_membank();
			break;

		}
		return;
		
	case 0xe6:
		if (hw1500.e5_bak>=0)
		{
			/* Restore Before $e5 */
			CopyMemory(&hw700.memctrl[26],&hw1500.memctrl_bak,sizeof(TMEMBANK)*6);
			hw1500.e5_bak = -1;
			update_membank();
		}
		return;

	case 0xe9:
		/* PSG 1 and 2 Out */
		mz_psg_out(0,iVal);
		mz_psg_out(1,iVal);
		playPSG();
		return;

	case 0xea:
		/* RAM FILE OUT */
		/* then addr auto incliment.  */
//		dprintf("out:MZ1R18_ADDR=%04x Out=%02x\n",(int)hw1500.mz1r18_addr, (int)Value);
		mz1r18_ptr[hw1500.mz1r18_addr++] = iVal;
		hw1500.mz1r18_addr &= (MZ1R18_SIZE-1);
		break;
		
	case 0xeb:
//		dprintf("$eb:RMFILE ADDR:Port=%04x Data=%02x\n",(int)Port, (int)Value);
		// RAM FILE
		// set MZ-1R18 addr
		hw1500.mz1r18_addr = (iPort & 0xFF00) | iVal;
//		dprintf("$eb:MZ1R18_ADDR=%04x\n",hw1500.mz1r18_addr);
		break;
		
		
	case 0xf0:
		// mz-1500 priority
		hw1500.prty=iVal;

		mz_refresh_screen(REFSC_ALL);
		break;
		
	case 0xf1:
		// mz-1500 palet
		mz_palet(iVal);
		mz_refresh_screen(REFSC_ALL);
		break;

	case 0xf2:
	case 0xf3:
		// PSG 1 or 2 Out
		mz_psg_out( (int) ( (iPort & 0x00FF) - 0xF2) ,iVal);
		playPSG();
		return;
		


	case 0xf4:
		// sio A data
		break;
	case 0xf5:
		// sio B data
		break;
	case 0xf6:
		// sio A control
		break;
	case 0xf7:
		// sio B control
		break;

	case 0xf8:
		if (use_cmos)
		{
			// set MZ-1R12 addr (high)
			hw700.mz1r12_addr = (hw700.mz1r12_addr & 0x00FF) | (iVal << 8);
		}
		break;
	case 0xf9:
		if (use_cmos)
		{
			// set MZ-1R12 addr (low) 
			hw700.mz1r12_addr = (hw700.mz1r12_addr & 0xFF00) | iVal;
		}
		break;
	case 0xfa:
		if (use_cmos)
		{
			// write data from MZ-1R12, then addr auto incliment.
			mz1r12_ptr[hw700.mz1r12_addr] = iVal;
			hw700.mz1r12_addr = ( hw700.mz1r12_addr + 1) & (MZ1R12_SIZE-1);
		}
		break;
		// z80 pio Port-A Ctrl Reg.
	case 0xfc:
	case 0xfd:
		mz_z80pio_ctrl(((iPort&0xFF)-0xfc),iVal);
		break;
	case 0xfe:
		// z80 pio Port-A DATA Reg.
		mz_z80pio_data(0,iVal);
		break;
	}
	
	return;
}

/* Called when RETN occurs */
void Z80_Reti (void)
{
}

/* Called when RETN occurs */
void Z80_Retn (void)
{
}


#define cval (CPU_SPEED_BASE / 16000)
#define pit0cou_val (CPU_SPEED_BASE / (895000 / PIO_TIMER_RESO) )			/* 895kHz */

/* Interrupt Timer */
int Z80_Interrupt(void)
{
	int ret = 0;

	// Pit Interrupt (MZ-700)
	  if ( (ts700.cpu_tstates - ts700.pit_tstates) >= cval)
	  {
		  ts700.pit_tstates += cval;
		  if (pit_count())
		  {
			  if (_8253_stat[2].counter_out)
			  {
				  if ( _8253_dat.int_mask )
				  {
					  Z80_intflag |= 1;
					  Interrupt(0);
					}
				 }
			  }
		  }

	if (menu.machine == MACHINE_MZ1500)
	{
		// Z80 PIO TIMER (MZ-1500)
		if ( (ts700.cpu_tstates - ts1500.pio_tstates) >= pit0cou_val)
		{
			ts1500.pio_tstates += pit0cou_val;
			if (pio_pitcount())
			{
				pio_intjob(0);
			}
		}
	}
  
	return ret;
}

//--------
// NO Use
//--------
void Z80_Patch (Z80_Regs *Regs)
{

}

//----------------
// CARRY flag set
//----------------
void Z80_set_carry(Z80_Regs *Regs, int sw)
{
	if (sw)
	{
		Regs->AF.B.l |= (C_FLAG);
	}
	else
	{
		Regs->AF.B.l &= (~C_FLAG);
	}
}

//----------------
// CARRY flag get
//----------------
int Z80_get_carry(Z80_Regs *Regs)
{
	return ((Regs->AF.B.l & C_FLAG) ? 1 : 0);
}

//---------------
// ZERO flag get
//---------------
void Z80_set_zero(Z80_Regs *Regs, int sw)
{
	if (sw)
	{
		Regs->AF.B.l |= (Z_FLAG);
	}
	else
	{
		Regs->AF.B.l &= (~Z_FLAG);
	}
}

//---------------
// ZERO flag get
//---------------
int Z80_get_zero(Z80_Regs *Regs)
{
	return ((Regs->AF.B.l & Z_FLAG) ? 1 : 0);
}
