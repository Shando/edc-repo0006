ENTER source
============

A Enterprise 64/128 emulation.

The program and source are (c) Copyright Kevin Thacker 1999-2001.
<URL:mailto:amstrad@aiind.upv.es>

The ROMs are (c) Copyright Intelligent software Ltd.

Information:
<URL:http://www.mumm.ac.be/~cammejpm/enterprise.html>

This source has been written in C and written to be portable to other systems.

Much of the source is shared with my Amstrad CPC emulator called "Arnold"
<URL:http://arnold.emuunlim.com/> but is not quite as advanced. At a future
time I plan to incorporate the more advanced code from Arnold into this
emulator to make it better.

This source is released under the GNU Public License. See the file "Copying"
for the full license.

License:

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


You are welcome to make changes to this source, and if you do I would appreciate
it if you would send me the changes so I can incorporate them into a new source
release.

makefile.w32 is a makefile to be compiled with MingW/GNU tools running under Win9x/WinNT/WinME
or Win2000. (Go to http://www.mame.net/ and download mingw_for_mame.zip. Unzip this folder
and setup your path to point to the bin directory. Now make -f makefile.w32!)

Background
==========

What is the Enterprise?:
-----------------------------------

The Enterprise is a 8-bit computer with the following features:
- a custom sound chip called "Dave" which can produce complex sounds using
a combination of simple features
	- simple tone
	- noise
	- interrupts based on sound waves
	- mixing of signals using filtering and ring modulation
	- accurate control of left/right audio channels
	- and more...
- a custom graphics display processor called "Nick"
	- display list processor
	- different video modes (2,4,16 and 256 colour modes)
	- 256 colour palette
	- different resolutions
	- different resolutions on the same screen
	- programmable interlace
	- scan-line interrupts

