
/********************************
DAVE SOUND CHIP FOUND IN ENTERPRISE
*********************************/
#include "dave.h"
#include "ep.h"
#include "audioevent.h"
/*static*/ DAVE dave;

static void	Dave_SetupToneChannelInterrupts(int ChannelIndex)
{
	unsigned long CounterID;
	unsigned long NopsPerToneClock; 
	unsigned long ToneValue;
	unsigned long ToneClocks;

	/* constant nops per clock */
	NopsPerToneClock = (unsigned long)(DAVE_50HZ_CLOCK_RELOAD*50)/((unsigned long)(DAVE_TONE_CLOCK<<1));
	//((unsigned long)(DAVE_50HZ_CLOCK_RELOAD*50)<<16)/(unsigned long)DAVE_TONE_CLOCK;

	/* get tone value */
	ToneValue = ((dave.RegsWrite[(ChannelIndex<<1)+1] & 0x0f)<<8) | 
						(dave.RegsWrite[(ChannelIndex<<1)] & 0x0ff);
	
	/* tone frequency is 12500/(tonevalue+1) */
	ToneValue++;

	/* calculate number of clocks for this programmed tone */
	ToneClocks = ToneValue;	//(((unsigned long)DAVE_TONE_CLOCK<<16)/ToneValue)>>16;
	
	/* get int channel ID */
	CounterID = DAVE_INT_COUNTER_TONE_CHANNEL_0 + ChannelIndex;

	/* set current count and reload value */
	dave.InterruptCounters[CounterID] =  
		dave.InterruptCounterReload[CounterID] = 
				(NopsPerToneClock*ToneClocks);

	/* set counter output - tone starts in high phase */
	dave.InterruptCounterOutputs |= (1<<CounterID);

	/* recalculate number of cycles to next interrupt */
	dave.CyclesToNextInterrupt = Dave_CalculateCyclesToNextInterrupt();
}

void Dave_Reset(void)
{
	int i;


	dave.InterruptCounters[DAVE_INT_COUNTER_1HZ] = 
		dave.InterruptCounterReload[DAVE_INT_COUNTER_1HZ] = DAVE_1HZ_CLOCK_RELOAD;	//<<5;

	dave.InterruptCounters[DAVE_INT_COUNTER_1KHZ] = 
		dave.InterruptCounterReload[DAVE_INT_COUNTER_1KHZ] = DAVE_1KHZ_CLOCK_RELOAD;	//<<5;

	dave.InterruptCounters[DAVE_INT_COUNTER_50HZ] = 
		dave.InterruptCounterReload[DAVE_INT_COUNTER_50HZ] = DAVE_50HZ_CLOCK_RELOAD;	//<<5;

	Dave_SetupToneChannelInterrupts(0);
	Dave_SetupToneChannelInterrupts(1);

	dave.ChannelOutputs[0] = dave.ChannelOutputs[1] = dave.ChannelOutputs[2] = dave.ChannelOutputs[3] = 0;


	for (i=0; i<32; i++)
	{
		Dave_Write(i,0);
	}
}



/*
Reg 4 READ:

b7 = 1: INT2 latch set
b6 = INT2 input pin
b5 = 1: INT1 latch set
b4 = INT1 input pin
b3 = 1: 1Hz latch set
b2 = 1hz input pin
b1 = 1: 1khz/50hz/TG latch set
b0 = 1khz/50hz/TG input

Reg 4 WRITE:

b7 = 1: Reset INT2 latch
b6 = 1: Enable INT2
b5 = 1: Reset INT1 latch
b4 = 1: Enable INT1
b3 = 1: Reset 1hz interrupt latch
b2 = 1: Enable 1hz interrupt
b1 = 1: Reset 1khz/50hz/TG latch
b0 = 1: Enable 1khz/50Hz/TG latch
*/

static void Dave_SetInterruptWanted(void)
{
	if ((dave.int_latch & (dave.int_enable<<1))!=0)
	{
		Z80_TriggerInterrupt();	
	}
	else
	{
		Z80_ClearInterrupt();
	}

}


static void Dave_SetInterruptWanted2(unsigned char new_latch)
{
//	if ((new_latch!=0) && ((dave.int_latch&new_latch)==0))
	{
		dave.int_latch |= new_latch;

		if ((new_latch & (dave.int_enable<<1))!=0)
		{
			Z80_TriggerInterrupt();
		}
	}

//	if ((dave.int_latch & (dave.int_enable<<1))!=0)
//	{
//		Z80_TriggerInterrupt();	
//	}
//	else
//	{
//		Z80_ClearInterrupt();
//	}
}


#if 0
static void Dave_UpdateCounter(unsigned long CounterID, unsigned long Cycles)
{
	unsigned long Counter = dave.InterruptCounter[CounterID];

	Counter-=Cycles;

	if (Counter<0)
	{
		/* counter has finished */
		unsigned long Cycles;
		unsigned long Overflow;

		/* number of cycles processed */
		Cycles = (-Counter)/dave.InterruptCounterReload[CounterID];

		/* odd number of cycles, invert output */
		if (Cycles & 1)
			dave.InterruptCounterOutputs ^= (1<<CounterID);

		Overflow = (-Counter) % dave.InterruptCounterReload[CounterID];
		Counter = dave.InterruptCounterReload[CounterID] - Overflow;
	}

	dave.InterruptCounter[CounterID] = Counter;
}

/* 1/32 of a dave clock occurs per cpu clock */

#define CPU_CLOCK		4000000
int	Dave_ClocksPerNop = CPU_CLOCK/DAVE_TONE_CLOCK;

void	Dave_UpdateCycles(unsigned long usCycles)
{
	int DaveCycles = usCycles<<5;	//*Dave_ClocksPerNop;

	dave.InterruptCounterPreviousOutputs = dave.InterruptCounterOutputs;

	Dave_UpdateCounter(DAVE_INT_COUNTER_1HZ,DaveCycles);
	Dave_UpdateCounter(DAVE_INT_COUNTER_50HZ,DaveCycles);
	Dave_UpdateCounter(DAVE_INT_COUNTER_1KHZ,DaveCycles);


		if (
			((dave.InterruptCounterPreviousOutputs^dave.InterruptCounterOutputs) & (1<<source_id))!=0)
		{
			/* changed? */
			if ((dave.InterruptCounterOutputs & (1<<source_id))==0)
			{
				/* set latch */
	            dave.int_latch |= 0x02;
				/* set int */
				Dave_SetInterruptWanted();
			}
		}


	dave.int_input &= ~0x010;
	dave.int_input |= ((State & 0x01)<<4);

    /* interrupt state changed? */
    if (((previous_state^dave.int_input) & 0x010)!=0)




	}

}
#endif
#if 0

void	Dave_UpdateCounter(int CounterID, int DaveClocksPassed)
{
	/* current count */
	unsigned long Counter = dave.InterruptCounter[CounterID];
	/* reload value */
	unsigned long CounterReload = dave.InterruptCounterReload[CounterID];
	
	/* update count */
	Counter-=DaveClocksPassed;

	/* counter finished? */
	if (Counter<0)
	{
		unsigned long CyclesOver;
		unsigned long Cycles;

		/* get cycles remaining */
		CyclesOver = -Counter;

		/* get number of complete cycles */
		Cycles = CyclesOver/CounterReload;

//		if (Cycles & 1)
//		{
//
//
//		}

		/* new counter value is 
		Counter = CyclesOver % CounterReload;

	}


	dave.InterruptCounter[CounterID] = Counter;
}


void	Dave_UpdateInterruptCounters(void)
{
	int DaveClocksPassed;
	int i;
	
	for (i=0; i<5; i++)
	{
		Dave_UpdateCounter(i, DaveClocksPassed);
	}
}
*/


/* number of cycles passed */
static void	Dave_UpdateInternalTimers(void)
{
	int i;

//	for (i=0; i<64; i++)
//	{
//		Dave
//	if (!(dave.Regs[7] & 0x01))
//	{
//		/* run tone channel 0 */
//
//	}
	
//	if (!(dave.Regs[7] & 0x02))
//	{
//		/* run tone channel 1 */
//
//	}

//	if (!(dave.Regs[7] & 0x04))
//	{
//		/* run tone channel 2 */
//
//	}

//	Dave.OneHzCounter-=




}
#endif

static int Dave_GetSelectableIntSource(void)
{
	int int_source;

	/* int source */
	int_source = (dave.Regs[7]>>5) & 3;

	switch (int_source)
	{
		/* 1khz */
		case 0:
			return DAVE_INT_COUNTER_1KHZ;

		/* 50hz */
		case 1:
			return DAVE_INT_COUNTER_50HZ;

		/* tone generator 0 */
		case 2:
			return DAVE_INT_COUNTER_TONE_CHANNEL_0;

		/* tone generator 1 */
		case 3:
			return DAVE_INT_COUNTER_TONE_CHANNEL_1;
		

		default:
			break;
	}

	return -1;
}

/* interrupts are triggered from negative edge transition */
static unsigned long Dave_CyclesToNextTrigger(int CounterID)
{
	/* get current count */
	int CurrentCount = dave.InterruptCounters[CounterID];

//	/* depending on current wave state, adjust count so that
//	it will include time before a negative edge */
//	if ((dave.InterruptCounterOutputs & (1<<CounterID))==0)
//	{
//		/* if current wave output is 0, after CurrentCount cycles
//		there will be a positive edge. This will not trigger a
//		interrupt. The counter will be reloaded, and a negative edge
//		transition will occur when this has run out again */
//
//		CurrentCount+=dave.InterruptCounterReload[CounterID];
//	}
//
	return CurrentCount;
}


static unsigned long Dave_CalculateCyclesToNextInterrupt(void)
{
	int SelectedInterrupt;
	unsigned long SelectedInterruptCount;
	unsigned long ClosestInterrupt;

	/* no interrupts are active, so no need to check
	for interrupts that have been triggered */
	dave.CyclesToNextInterrupt = 0;

	//return 0;

	/* 1hz or selectable interrupt active? */
//	if (dave.int_enable & (1|4))
//		return;

	/* 1hz is active, or selectable interrupt is active */

//	if (dave.int_enable & 4)
//	{
//		/* 1hz interrupt is active only */
//
//		return Dave_CyclesToNextTrigger(DAVE_INT_COUNTER_1HZ)>>5;
//	}

//	if (dave.int_enable & 1)
//	{
//		/* selectable int is active only */
//				
//		/* get current selected interrupt source */
//		SelectedInterrupt = Dave_GetSelectableIntSource();
//	
//		return Dave_CyclesToNextTrigger(SelectedInterrupt)>>5;
//	}

	/* both are active */
	
	/* get selected interrupt ID */
	SelectedInterrupt = Dave_GetSelectableIntSource();
	/* get count for selected interrupt */
	SelectedInterruptCount = Dave_CyclesToNextTrigger(SelectedInterrupt);

	/* get count for 1hz interrupt */
	ClosestInterrupt = Dave_CyclesToNextTrigger(DAVE_INT_COUNTER_1HZ);

	/* if selected interrupt is closer than 1hz interrupt,
	this interrupt is the closest */
	if (SelectedInterruptCount<ClosestInterrupt)
	{
		ClosestInterrupt = SelectedInterruptCount;
	}
	
	return ClosestInterrupt;
}

static void Dave_UpdateCounter(unsigned long CounterID, unsigned long Cycles)
{
	signed long Counter = dave.InterruptCounters[CounterID];

	Counter-=Cycles;

	if (Counter<=0)
	{
		/* counter has finished */
		signed long Cycles;
		signed long Overflow;

		/* number of cycles processed */
		Cycles = 1 + (-Counter)/dave.InterruptCounterReload[CounterID];

		/* odd number of cycles, invert output */
		if (Cycles & 1)
			dave.InterruptCounterOutputs ^= (1<<CounterID);

		Overflow = (-Counter) % dave.InterruptCounterReload[CounterID];
		Counter = dave.InterruptCounterReload[CounterID] - Overflow;
	}

	dave.InterruptCounters[CounterID] = Counter;
}

void	Dave_SetInterrupt(int int_input, int old_state, int new_state)
{
	dave.int_input &= ~int_input;

	if (new_state)
		dave.int_input |= int_input;

	/* state changed? */
	if ((old_state^new_state)!=0)
	{
		/* negative transition? */
		if (new_state==0)
		{
			dave.int_latch |= int_input<<1;
			Dave_SetInterruptWanted();	//((int_input<<1));
		}
	}
}


void	Dave_SetInterrupt2(int int_input, int old_state, int new_state)
{
	dave.int_input &= ~int_input;

	if (new_state)
		dave.int_input |= int_input;

	/* state changed? */
	if (((old_state^new_state))!=0)
	{
		dave.int_latch |= int_input<<1;
		Dave_SetInterruptWanted();	//((int_input<<1));
	}
}



#if 0
void	Dave_UpdateInts(void)
{
	unsigned long OldIntInputs;

	OldIntInputs = dave.int_input;

//	dave.int_input^=0x055;

//	Dave_SetInterrupt(0x01, OldIntInputs, dave.int_input);
//	Dave_SetInterrupt(0x04, OldIntInputs, dave.int_input);
//	Dave_SetInterrupt(0x10, OldIntInputs, dave.int_input);
//	Dave_SetInterrupt(0x40, OldIntInputs, dave.int_input);

	
	unsigned long OldInterruptCounterOutputs = dave.InterruptCounterOutputs;
	unsigned long SelectableInt = Dave_GetSelectableIntSource();

	Dave_UpdateCounter(DAVE_INT_COUNTER_1HZ,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_50HZ,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_1KHZ,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_TONE_CHANNEL_0,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_TONE_CHANNEL_0,dave.CyclesToNextInterrupt);

//	// set 1hz int? 
//	Dave_SetInterrupt(0x04, OldInterruptCounterOutputs&(1<<DAVE_INT_COUNTER_1HZ), dave.InterruptCounterOutputs&(1<<DAVE_INT_COUNTER_1HZ));

//	// set selectable int? 
//	Dave_SetInterrupt(0x01, OldInterruptCounterOutputs&(1<<SelectableInt), dave.InterruptCounterOutputs&(1<<SelectableInt));


	Dave_SetInterrupt(0x01, OldInterruptCounterOutputs, dave.InterruptCounterOutputs);
	Dave_SetInterrupt(0x04, OldInterruptCounterOutputs, dave.InterruptCounterOutputs);
//	Dave_SetInterrupt(0x10, );
//	Dave_SetInterrupt(0x40, );


	dave.CyclesToNextInterrupt = Dave_CalculateCyclesToNextInterrupt();

}
#endif


void	Dave_UpdateInterrupts(void)
{
	unsigned long OldInterruptCounterOutputs = dave.InterruptCounterOutputs;
	unsigned long SelectableInt = Dave_GetSelectableIntSource();

	Dave_UpdateCounter(DAVE_INT_COUNTER_1HZ,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_50HZ,dave.CyclesToNextInterrupt);
	Dave_UpdateCounter(DAVE_INT_COUNTER_1KHZ,dave.CyclesToNextInterrupt);

	
	/* sync for channel 0? 1=hold, 0=run */
	if ((dave.RegsWrite[0x07] & 0x01)==0)
	{
		Dave_UpdateCounter(DAVE_INT_COUNTER_TONE_CHANNEL_0,dave.CyclesToNextInterrupt);
	}
	
	/* sync for channel 1? 1=hold, 0=run */
	if ((dave.RegsWrite[0x07] & 0x02)==0)
	{
		Dave_UpdateCounter(DAVE_INT_COUNTER_TONE_CHANNEL_1,dave.CyclesToNextInterrupt);
	}

	Dave_SetInterrupt(0x04, OldInterruptCounterOutputs&(1<<DAVE_INT_COUNTER_1HZ), dave.InterruptCounterOutputs&(1<<DAVE_INT_COUNTER_1HZ));
	Dave_SetInterrupt(0x01, OldInterruptCounterOutputs&(1<<SelectableInt), dave.InterruptCounterOutputs&(1<<SelectableInt));

	dave.CyclesToNextInterrupt = Dave_CalculateCyclesToNextInterrupt();
}

static void Dave_IntRegWrite(unsigned char Data)
{
	unsigned char previous_enable;

	previous_enable = dave.int_enable;

	/* int enables */
	dave.int_enable = Data & 0x055;

    /* reset latch */
    dave.int_latch &= ~(Data & (0x080|0x020|0x08|0x02));

	Dave_SetInterruptWanted();

//	Z80_ClearInterrupt();

//	/* 1hz, selectable int enable changed? */
//	if (((previous_enable^dave.int_enable) & (1|4))!=0)
//	{
		/* 1hz, selectable int enables changed */
		/* recalculate closest interrupt */
		dave.CyclesToNextInterrupt = Dave_CalculateCyclesToNextInterrupt();
//	}

}


static unsigned char Dave_IntRegRead(void)
{
	return (dave.int_input & 0x055) | (dave.int_latch & 0x0aa);
}


extern int OpCount;

int Port0x016_PreviousNopCount = 0;

void	Dave_Write(int RegIndex, int Data)
{
	int Reg = RegIndex & 0x01f;

	unsigned char PreviousData = dave.RegsWrite[Reg];

	dave.Regs[Reg] = Data;
	dave.RegsWrite[Reg] = Data;

	if (Reg<=0x0f)
	{
		AudioEvent_AddEventToBuffer(AUDIO_EVENT_DAVE, Reg, Data);
	}


	switch (Reg)
	{
		case 0x00:
		case 0x01:
		{
			Dave_SetupToneChannelInterrupts(0);
		}
		break;

		case 0x02:
		case 0x03:
		{
			Dave_SetupToneChannelInterrupts(1);
		}
		break;

		case 0x07:
		{
			if (((PreviousData^dave.Regs[7]) & (3<<5))!=0)
			{
				/* int source changed, recalculate cycles to next int */
				dave.CyclesToNextInterrupt = Dave_CalculateCyclesToNextInterrupt();
			}


#if 0
			/* L.H. audio output to D/A? */
			if (dave.Regs[7] & 0x08)
			{
				/* turn L.H. audio output into D/A, outputing value in R8 */
				dave.LeftOutputs_And[0] = dave.LeftOutputs_And[1] = dave.LeftOutputs_And[2] = dave.LeftOutputs_And[3] = 0;
				dave.LeftOutputs_Or[1] = dave.LeftOutputs_Or[2] = dave.LeftOutputs_Or[3] = 0;
				dave.LeftOutputs_Or[0] = 0x0ff;


			}
			else
			{
				/* normal L.H. audio output from mixing channel output */
				dave.LeftOutputs_And[0] = dave.LeftOutputs_And[1] = dave.LeftOutputs_And[2] = dave.LeftOutputs_And[3] = 0xff;
				dave.LeftOutputs_Or[0] = dave.LeftOutputs_Or[1] = dave.LeftOutputs_Or[2] = dave.LeftOutputs_Or[3] = 0x0;
			}

			/* R.H. audio output to D/A ? */
			if (dave.Regs[7] & 0x010)
			{
				/* turn L.H. audio output into D/A, outputing value in R8 */
				dave.RightOutputs_And[0] = dave.RightOutputs_And[1] = dave.RightOutputs_And[2] = dave.RightOutputs_And[3] = 0;
				dave.RightOutputs_Or[1] = dave.RightOutputs_Or[2] = dave.RightOutputs_Or[3] = 0;
				dave.RightOutputs_Or[0] = 0x0ff;
			}
			else
			{
				/* normal L.H. audio output from mixing channel output */
				dave.RightOutputs_And[0] = dave.RightOutputs_And[1] = dave.RightOutputs_And[2] = dave.RightOutputs_And[3] = 0xff;
				dave.RightOutputs_Or[0] = dave.RightOutputs_Or[1] = dave.RightOutputs_Or[2] = dave.RightOutputs_Or[3] = 0x0;
			}
#endif

		}
		break;

		case 0x010:
		case 0x011:
		case 0x012:
		case 0x013:
		{
			Enterprise_SetMemoryPage(Reg-0x010, Data);
		}
		break;

		case 0x014:
		{
			Dave_IntRegWrite(Data);
		}
		break;

		case 0x015:
		{
			if (
				(
				(PreviousData^dave.RegsWrite[0x015])
				&
				(1<<6)
				)!=0)
			{
				if ((dave.RegsWrite[0x015] & (1<<6))!=0)
				{
					Port0x016_PreviousNopCount = OpCount;
				}
			}
		}
		break;

		default:
			break;

	}


}


int	Dave_Read(int RegIndex)
{
	int Reg = RegIndex & 0x01f;

	switch (Reg)
	{
		case 0x017:
		case 0x010:
		case 0x011:
		case 0x012:
		case 0x013:
			break;
			
		case 0x014:
		{	
            dave.Regs[Reg] = Dave_IntRegRead();		
		}
		break;

		case 0x015:
		{
			unsigned char Data;

 			Data = Enterprise_GetKeyboardLine(dave.RegsWrite[Reg]);

			dave.Regs[Reg] = Enterprise_GetKeyboardLine(dave.RegsWrite[Reg]);
		}
		break;

		case 0x016:
		{
			unsigned char ExternalJoystickData;
			unsigned char RegisterData;
			unsigned char CassetteData;

			RegisterData = 0x03f^0x01;

			/**** TAPE ****/
			/* tape motor is on? (remote 1) */
			if ((dave.RegsWrite[0x015] & (1<<6))!=0)
			{
				unsigned long CurrentNopCount;
				unsigned char CassetteReadBit;

				/* get current nop count */
				CurrentNopCount = OpCount;

				CassetteReadBit = Sample_GetDataByteTimed(Port0x016_PreviousNopCount, CurrentNopCount);
				
				CassetteData = (CassetteReadBit<<7) | (CassetteReadBit<<6);

				/* store previous port B read nop count */
				Port0x016_PreviousNopCount = CurrentNopCount;

			}
        
			ExternalJoystickData = Enterprise_ReadExternalJoystick(dave.RegsWrite[0x015]);
			
			return RegisterData | ExternalJoystickData | CassetteData;
		}
		break;

		case 0x018:
		case 0x019:
		case 0x01a:
		case 0x01b:
		case 0x01c:
		case 0x01d:
		case 0x01e:
		case 0x01f:
			return 0x0ff;

		default:
			break;
	}
	
	return dave.Regs[Reg];
	
}


/* Nick Video interrupts */
void	Dave_Int1_SetState(int State)
{
	int previous_state = dave.int_input & 0x010;

	dave.int_input &= ~0x010;
	dave.int_input |= ((State & 0x01)<<4);

    /* interrupt state changed? */
    if (((previous_state^dave.int_input) & 0x010)!=0)
	{
		/* was int previously set? */
		if ((previous_state & 0x010)!=0)
		{
			/* was previously set, therefore we have had a negative edge transition */

		//	dave.int_latch|=8;


            /* set latch */
            dave.int_latch |= 0x020;
			Dave_SetInterruptWanted();

		
		}
    }

}


static unsigned long Update;
static unsigned char DavePlay_Registers[32];

void	Enterprise_InitialiseToneUpdates(unsigned long newUpdate)
{
	Update = newUpdate;
}



typedef struct CHANNEL_PERIOD
{
	/* tone period for this channel. Period is time for 1/2
	the square wave */
	unsigned long Period;

	/* Period position - used to define where in waveform we are. */
	unsigned long PeriodPosition;
	/* state of square wave. 0x00 or 0x0ff */
//	int		WaveFormState;
	unsigned long ToneUpdate;
} CHANNEL_PERIOD;


CHANNEL_PERIOD	ChannelPeriods[4]=
{
	{0,0,0},
	{0,0,0},
	{0,0,0}
};


void	DavePlay_ReloadChannelTone(int ChannelIndex)
{
	unsigned long CurrentCount;
	unsigned long Period;
	CHANNEL_PERIOD *pChannelPeriod = &ChannelPeriods[ChannelIndex];

	Period = (
		DavePlay_Registers[(ChannelIndex<<1)] |
		((DavePlay_Registers[(ChannelIndex<<1)+1] & 0x0f)<<8)
		);

	Period++;

	/* set new period */
	pChannelPeriod->Period = Period; 

	/* set new update */
	pChannelPeriod->ToneUpdate = Update/Period;

	pChannelPeriod->PeriodPosition &= 0x0ffff;
}


void	DavePlay_UpdateState(unsigned long Reg, unsigned long Data)
{
	/* write register data */
	DavePlay_Registers[Reg & 0x1f] = Data;

	switch(Reg)
	{
		case 0:
		case 1:
		{
			DavePlay_ReloadChannelTone(0);
		}
		break;

		case 2:
		case 3:
		{
			DavePlay_ReloadChannelTone(1);

		}
		break;

		case 4:
		case 5:
		{
			DavePlay_ReloadChannelTone(2);
		}
		break;

	
		default:
			break;
	}
}


INLINE void	DavePlay_UpdateChannel(int ChannelIndex)
{
	CHANNEL_PERIOD *pChannelPeriod = &ChannelPeriods[ChannelIndex];

	int NoOfCycles;

	pChannelPeriod->PeriodPosition+=pChannelPeriod->ToneUpdate;

	/* update position in waveform */
	//pChannelPeriod->PeriodPosition.FixedPoint.L+=pUpdate->FixedPoint.L;

	/* how many cycles have occured in this update ? */
	NoOfCycles = (pChannelPeriod->PeriodPosition>>16);	//pChannelPeriod->PeriodPosition.FixedPoint.W.Int/pChannelPeriod->Period.FixedPoint.W.Int;

	/* if odd, invert state, else keep state the same */
	if (NoOfCycles & 0x01)
	{
		/* odd number of cycles - invert state*/
		dave.ChannelOutputs[ChannelIndex]^=0x0ff;
	}

	/* zeroise integer part */
	pChannelPeriod->PeriodPosition &= 0x0ffff;
}



/* call here to update Dave sound for one sample time */
void	DavePlay_Update(unsigned long *theLeftVolume, unsigned long *theRightVolume)
{
	unsigned long LeftVolume;
	unsigned long RightVolume;

	/* hold? */
	if ((DavePlay_Registers[0x07] & 0x01)==0)
	{
		/* no, update channel */
		DavePlay_UpdateChannel(0);
	}

	/* hold? */
	if ((DavePlay_Registers[0x07] & 0x02)==0)
	{
		/* no, update channel */
		DavePlay_UpdateChannel(1);

	}

	/* hold? */
	if ((DavePlay_Registers[0x07] & 0x04)==0)
	{
		/* no, update channel */
		DavePlay_UpdateChannel(2);
	}

//	DavePlay_UpdateChannel(3);

	/* generate left volume */
	if ((DavePlay_Registers[0x07] & 0x08)!=0)
	{
		/* output direct to D/A */
		LeftVolume = DavePlay_Registers[0x08] & 0x03f;

	}
	else
	{
		/* mix channels */
		unsigned long i;

		LeftVolume = 0;

		for (i=0; i<4; i++)
		{
			unsigned long ChannelVolume;

			/* general channel output */
			ChannelVolume = ((dave.ChannelOutputs[i] & DavePlay_Registers[0x08 + i]) & 0x03f);

			/* add contribution from this channel */
			LeftVolume += ChannelVolume;
		}

		/* get averaged contribution */
		LeftVolume = (LeftVolume>>2) & 0x03f;
	}

	if ((DavePlay_Registers[0x07] & 0x010)!=0)
	{
		/* output direct to D/A */
		RightVolume = DavePlay_Registers[0x0c];
	}
	else
	{
		/* mix channels */
		unsigned long i;

		RightVolume = 0;

		for (i=0; i<4; i++)
		{
			unsigned long ChannelVolume;

			/* general channel output */
			ChannelVolume = ((dave.ChannelOutputs[i] & DavePlay_Registers[0x0c + i]) & 0x03f);

			/* add contribution from this channel */
			RightVolume += ChannelVolume;
		}

		/* get averaged contribution */
		RightVolume = (RightVolume>>2) & 0x03f;
	}


	*theLeftVolume = LeftVolume;
	*theRightVolume = RightVolume;
}


