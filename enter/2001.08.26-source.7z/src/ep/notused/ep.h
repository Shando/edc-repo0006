
/* there are 64us per line, although in reality
   about 50 are visible. */
/* there are 312 lines per screen, although in reality
   about 35*8 are visible */
#define ENTERPRISE_SCREEN_WIDTH	(50*16)
#define ENTERPRISE_SCREEN_HEIGHT	(35*8)

/* Enterprise bank allocations */
#define MEM_EXOS_0		0
#define	MEM_EXOS_1		1
#define MEM_CART_0		4
#define MEM_CART_1		5
#define MEM_CART_2		6
#define MEM_CART_3		7
#define MEM_EXDOS_0		0x020
#define	MEM_EXDOS_1		0x021
/* basic 64k ram */
#define MEM_RAM_0               ((unsigned int)0x0fc)
#define MEM_RAM_1               ((unsigned int)0x0fd)
#define MEM_RAM_2               ((unsigned int)0x0fe)
#define MEM_RAM_3               ((unsigned int)0x0ff)
/* additional 64k ram */
#define MEM_RAM_4               ((unsigned int)0x0f8)
#define MEM_RAM_5               ((unsigned int)0x0f9)
#define MEM_RAM_6               ((unsigned int)0x0fa)
#define MEM_RAM_7               ((unsigned int)0x0fb)

#define MEMSIZE	0x020000

void	Enterprise_Reset(void);
void	Enterprise_SetMemoryPage(int, int);
int		Enterprise_GetKeyboardLine(int);
void	Enterprise_SetControl(int);
void	Enterprise_ClearControl(int);
unsigned char Enterprise_ReadExternalJoystick(int PortB5);
void	Enterprise_ResetControllers(void);
void	Enterprise_PatchEXOS(unsigned char *pEXOSRom);

typedef enum
{
	/* row 0, bit 0-bit 7*/
	EP_KEY_N = 0,
	EP_KEY_BACKSLASH,
	EP_KEY_B,
	EP_KEY_C,
	EP_KEY_V,
	EP_KEY_X,
	EP_KEY_Z,
	EP_KEY_LSHIFT,
	/* row 1 */
	EP_KEY_H,
	EP_KEY_LOCK,
	EP_KEY_G,
	EP_KEY_D,
	EP_KEY_F,
	EP_KEY_S,
	EP_KEY_A,
	EP_KEY_CONTROL,
	/* row 2 */
	EP_KEY_U,
	EP_KEY_Q,
	EP_KEY_Y,
	EP_KEY_R,
	EP_KEY_T,
	EP_KEY_E,
	EP_KEY_W,
	EP_KEY_TAB,
	/* row 3 */
	EP_KEY_7,
	EP_KEY_1,	
	EP_KEY_6,
	EP_KEY_4,
	EP_KEY_5,
	EP_KEY_3,
	EP_KEY_2,
	EP_KEY_ESC,
	/* row 4 */
	EP_KEY_F4,
	EP_KEY_F8,
	EP_KEY_F3,
	EP_KEY_F6,
	EP_KEY_F5,
	EP_KEY_F7,
	EP_KEY_F2,
	EP_KEY_F1,
	/* row 5 */
	EP_KEY_8,
	EP_KEY_NC3,
	EP_KEY_9,
	EP_KEY_MINUS,
	EP_KEY_0,
	EP_KEY_HAT,
	EP_KEY_ERASE,
	EP_KEY_NC4,
	/* ROW 6 */
	EP_KEY_J,
	EP_KEY_NC5,
	EP_KEY_K,
	EP_KEY_SEMICOLON,
	EP_KEY_L,
	EP_KEY_COLON,
	EP_KEY_CLOSE_SQUARE_BRACKET,
	EP_KEY_NC6,
	/* row 7 */
	EP_KEY_STOP,
	EP_KEY_JOY_DOWN,
	EP_KEY_JOY_RIGHT,
	EP_KEY_JOY_UP,
	EP_KEY_HOLD,
	EP_KEY_JOY_LEFT,
	EP_KEY_ENTER,
	EP_KEY_ALT,
	/* row 8 */
	EP_KEY_M,
	EP_KEY_DEL,
	EP_KEY_COMMA,
	EP_KEY_FORWARD_SLASH,
	EP_KEY_DOT,
	EP_KEY_RSHIFT,
	EP_KEY_SPACE,
	EP_KEY_INSERT,
	/* row 9 */
	EP_KEY_I,
	EP_KEY_NC7,
	EP_KEY_O,
	EP_KEY_AT,
	EP_KEY_P,
	EP_KEY_OPEN_SQUARE_BRACKET,
	EP_KEY_NC8,
	EP_KEY_NC9,

	EP_KEY_NULL,

	/* external joystick 1 */
	EP_KEY_EXTERNAL_JOYSTICK1_RIGHT,
	EP_KEY_EXTERNAL_JOYSTICK1_LEFT,
	EP_KEY_EXTERNAL_JOYSTICK1_DOWN,
	EP_KEY_EXTERNAL_JOYSTICK1_UP,
	EP_KEY_EXTERNAL_JOYSTICK1_FIRE,
	EP_KEY_EXTERNAL_JOYSTICK1_NC1,
	EP_KEY_EXTERNAL_JOYSTICK1_NC2,
	EP_KEY_EXTERNAL_JOYSTICK1_NC3,
	/* external joystick 2 */
	EP_KEY_EXTERNAL_JOYSTICK2_RIGHT,
	EP_KEY_EXTERNAL_JOYSTICK2_LEFT,
	EP_KEY_EXTERNAL_JOYSTICK2_DOWN,
	EP_KEY_EXTERNAL_JOYSTICK2_UP,
	EP_KEY_EXTERNAL_JOYSTICK2_FIRE,
	EP_KEY_EXTERNAL_JOYSTICK2_NC1,
	EP_KEY_EXTERNAL_JOYSTICK2_NC2,
	EP_KEY_EXTERNAL_JOYSTICK2_NC3,


}	EP_KEY_ID;
/*
enum
{
	EP_EXT1_JOY_RIGHT,
	EP_EXT1_JOY_LEFT,
	EP_EXT1_JOY_DOWN,
	EP_EXT1_JOY_UP,
	EP_EXT1_JOY_


	EP_JOY_ID;
}
*/

typedef struct KEYBOARD_MAP
{
	unsigned long	Line;					/* keyboard row */
	unsigned long	AndMask;				/* And mask to set key pressed */
} KEYBOARD_MAP;
	
typedef enum
{
	MEMORY_TYPE_NULL = 0,
	MEMORY_TYPE_VIDEO_RAM,
	MEMORY_TYPE_RAM,
	MEMORY_TYPE_ROM,
	MEMORY_TYPE_SRAM
} EP_PAGE_TYPE;