/* NICK GRAPHICS CHIP */
/* (found in Enterprise) */
/* this is a display list graphics chip, with bitmap,
character and attribute graphics modes. Each entry in the
display list defines a char line, with variable number of
scanlines. Colour modes are 2,4, 16 and 256 colour. 
Nick has 256 colours, 3 bits for R and G, with 2 bits for Blue.
It's a nice and flexible graphics processor..........
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "nick.h"

/*************************************************************/
/* MESS stuff */
static NICK_STATE Nick;

extern unsigned char *MEMORY;
extern unsigned long ConvertedColourTable[256];

//static unsigned short	Nick_LPixelLookup[256];

static unsigned char	Nick_16ColourPalette[16];
static unsigned long	Nick_16ColourConverted[16];

static void	Nick_UpdateScanLineCount(void);



// MESS specific
/* fetch a byte from "video ram" at Addr specified */
static char Nick_FetchByte(unsigned long Addr)
{
   return MEMORY[Addr & 0x0ffff];
}

extern int BytesPerPixel;

// MESS specific
/* 8-bit pixel write! */
//#define NICK_WRITE_PIXEL(ci, dest)	\
//	((unsigned long *)dest)[0] = ConvertedColourTable[ci];	\
//	dest+= BytesPerPixel;

//#define NICK_WRITE_PIXEL(ci, dest)	\
//	{								\
//		unsigned long Inc = BytesPerPixel;	\
//		((unsigned long *)dest)[0] = ci;	\
//		dest = dest + Inc;					\
//	}

#define NICK_WRITE_PIXEL_INC(ci, dest,increment)	\
		((unsigned long *)dest)[0] = ci;	\
		dest = &dest[increment]

/*****************************************************/


/* first clock visible on left hand side */
static unsigned char Nick_FirstVisibleClock;
/* first clock visible on right hand side */
static unsigned char Nick_LastVisibleClock;

/* No of highest resolution pixels per "clock" */
#define NICK_PIXELS_PER_CLOCK	16

/* "clocks" per line */
#define NICK_TOTAL_CLOCKS_PER_LINE	64

/* we align based on the clocks */
static void Nick_CalcVisibleClocks(int Width)
{
	/* number of clocks we can see */
	int NoOfVisibleClocks;
	
	if (Width>=(NICK_MAX_VISIBLE_CLOCKS<<4))
	{
		NoOfVisibleClocks = NICK_MAX_VISIBLE_CLOCKS;
	}
	else
	{
		NoOfVisibleClocks = Width/NICK_PIXELS_PER_CLOCK;
	}

	Nick_FirstVisibleClock = 
		(NICK_TOTAL_CLOCKS_PER_LINE - NoOfVisibleClocks)>>1;

	Nick_LastVisibleClock = Nick_FirstVisibleClock + NoOfVisibleClocks;
}


/* given a bit pattern, this will get the pen index */
static unsigned int	Nick_PenIndexLookup_4Colour[256];
/* given a bit pattern, this will get the pen index */
static unsigned int	Nick_PenIndexLookup_16Colour[256];

void	Nick_Init(int ScreenWidth)
{
	int i;

	for (i=0; i<256; i++)
	{
		int PenIndex;

		PenIndex = (
				(( (i & (1<<3) )>>3)<<1) |
				(( (i & (1<<7) )>>7)<<0)
		//		((i & 0x080)>>(7-1)) | 
		//		((i & 0x08)>>(3-0))
				);
		
		Nick_PenIndexLookup_4Colour[i] = PenIndex;

		PenIndex = (
				(( (i & (1<<1) )>>1)<<3) | 
				(( (i & (1<<5) )>>5)<<2) |
				(( (i & (1<<3) )>>3)<<1) |
				(( (i & (1<<7) )>>7)<<0));

			
			//	((i & 0x080)>>(7-3)) | 
			//	((i & 0x08)>>(3-2)) |
			//	((i & 0x020)>>(5-1)) |
			//	((i & 0x02)>>(1-0))
			//	);
				
		Nick_PenIndexLookup_16Colour[i] = PenIndex;
	}

/*	for (i=0; i<256; i++)
	{
		int b;
		int data = i;
		int output = 0;
		
		for (b=0; b<8;b++)
		{
			output=output<<2;
			if ((data&0x080)!=0)
			{
				output|=3;
			}

			data = data<<1;
		}

		Nick_LPixelLookup[i] = output;
	}
*/
	Nick_CalcVisibleClocks(ScreenWidth);	
}

void	Nick_Reset(void)
{
	memset(&Nick, 0, sizeof(NICK_STATE));
}


/* write border colour */
static void	Nick_WriteBorder(int Clocks)
{
	int i;
	int ColIndex = Nick.BORDER;
	unsigned long ConvertedColour = ConvertedColourTable[Nick.BORDER];

	for (i=0; i<Clocks; i++)
	{
		{
			unsigned char *dest = Nick.dest;
			unsigned long Increment = BytesPerPixel;

			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
	
			Nick.dest = dest;
		}
	}
}

static unsigned long GetColourForPen(int PenIndex)
{
	return Nick_16ColourConverted[PenIndex];

//	if (PenIndex & 0x08)
//	{
//		return = ((Nick.FIXBIAS & 0x01f)<<3) | (Pen0 & 0x07);
//	}
//	else
//	{
//		ColIndex0 = Nick.LPT.COL[Pen0];
//	}
}



static void Nick_WritePixels2Colour_Pixel(unsigned long Pen0, unsigned long Pen1, unsigned char DataByte)
{
	int i;
	int ColIndex,ColIndex0, ColIndex1;
//	int PenIndex;
	unsigned char Data;

	Data = DataByte;


	for (i=0; i<8; i++)
	{
		if (Data & 0x080)
		{
			ColIndex = Pen1;	//ColIndex1;
		}
		else
		{
			ColIndex = Pen0;	//ColIndex0;
		}

//		ColIndex = Nick.LPT.COL[PenIndex];

		{
			unsigned char *dest = Nick.dest;
			unsigned long Increment = BytesPerPixel;

			NICK_WRITE_PIXEL_INC(ColIndex, dest, Increment);

			Nick.dest = dest;
		}


//		NICK_WRITE_PIXEL(ColIndex, Nick.dest);
		
		Data = Data<<1;
	}
}

static void Nick_WritePixels2Colour_CharMode(unsigned long Pen0, unsigned long Pen1, unsigned char DataByte)
{
	int i;
	int ColIndex,ColIndex0, ColIndex1;
//	int PenIndex;
	unsigned char Data;

	Data = DataByte;


	for (i=0; i<8; i++)
	{
		if (Data & 0x080)
		{
			ColIndex = Pen1;	//ColIndex1;
		}
		else
		{
			ColIndex = Pen0;	//ColIndex0;
		}


//		ColIndex = Nick.LPT.COL[PenIndex];

		{
			unsigned char *dest = Nick.dest;
			unsigned long Increment = BytesPerPixel;

			NICK_WRITE_PIXEL_INC(ColIndex, dest, Increment);
			NICK_WRITE_PIXEL_INC(ColIndex, dest, Increment);
	
			Nick.dest = dest;
		}

		Data = Data<<1;
	}
}



static void Nick_WritePixels_PixelMode(unsigned char DataByte, unsigned char CharIndex)
{
	int i;

	/* pen index colour 2-C (0,1), 4-C (0..3) 16-C (0..16) */
	int PenIndex;
	/* Col index = EP colour value */
	int PalIndex;
	unsigned char	ColourMode = NICK_GET_COLOUR_MODE(Nick.LPT.MB);
	unsigned char Data = DataByte;

	switch (ColourMode)
	{
		case NICK_2_COLOUR_MODE:
		{
			int PenOffset = 0;
			unsigned long Pen0ConvertedColour, Pen1ConvertedColour;

			/* do before displaying byte */

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				if (Data & 0x080)
				{
					PenOffset |= 2;
				}

				Data &=~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				if (Data & 0x001)
				{
					PenOffset |= 4;
				}

				Data &=~0x01;
			}

			if (Nick.LPT.RM & NICK_RM_ALTIND1)
			{
				if (CharIndex & 0x040)
				{
					PenOffset|=0x04;
				}
			}

			if (Nick.LPT.RM & NICK_RM_ALTIND0)
			{
				if (CharIndex & 0x080)
				{
					PenOffset|=0x02;		
				}
			}


			Pen0ConvertedColour = GetColourForPen(PenOffset);
			Pen1ConvertedColour = GetColourForPen((PenOffset|0x01));
	
			Nick_WritePixels2Colour_Pixel(Pen0ConvertedColour,
				Pen1ConvertedColour, Data);
		}
		break;

		case NICK_4_COLOUR_MODE:
		{
			unsigned long ConvertedColour;

			//printf("4 colour\r\n");

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			for (i=0; i<4; i++)
			{
				PenIndex = Nick_PenIndexLookup_4Colour[Data];

				ConvertedColour = Nick_16ColourConverted[PenIndex & 0x03];

				{
					unsigned char *dest = Nick.dest;
					unsigned long Increment = BytesPerPixel;

					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			
					Nick.dest = dest;
				}

				Data = Data<<1;
 			}
		}
		break;

		case NICK_16_COLOUR_MODE:
		{
//			unsigned long ConvertedColour;

			//printf("16 colour\r\n");

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			for (i=0; i<2; i++)
			{
				unsigned long ConvertedColour;

				PenIndex = Nick_PenIndexLookup_16Colour[Data];
				ConvertedColour = Nick_16ColourConverted[PenIndex];

				{
					unsigned char *dest = Nick.dest;
					unsigned long Increment = BytesPerPixel;

					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			
					Nick.dest = dest;
				}

				Data = Data<<1;
			}
		}
		break;

		case NICK_256_COLOUR_MODE:
		{
			unsigned long ConvertedColour;

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			PalIndex = Data;

			ConvertedColour = ConvertedColourTable[PalIndex];

//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);

			{
				unsigned char *dest = Nick.dest;
				unsigned long Increment = BytesPerPixel;

				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
		
				Nick.dest = dest;
			}

		}
		break; 
	}
}
/* in char mode it shifts less! */
static void Nick_WritePixels_CharMode(unsigned char DataByte, unsigned char CharIndex)
{
	int i;

	/* pen index colour 2-C (0,1), 4-C (0..3) 16-C (0..16) */
	int PenIndex;
	/* Col index = EP colour value */
	int PalIndex;
	unsigned char	ColourMode = NICK_GET_COLOUR_MODE(Nick.LPT.MB);
	unsigned char Data = DataByte;

	switch (ColourMode)
	{
		case NICK_2_COLOUR_MODE:
		{
			int PenOffset = 0;
			unsigned long Pen0ConvertedColour, Pen1ConvertedColour;

			/* do before displaying byte */

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				if (Data & 0x080)
				{
					PenOffset |= 2;
				}

				Data &=~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				if (Data & 0x001)
				{
					PenOffset |= 4;
				}

				Data &=~0x01;
			}

//			if (Nick.LPT.RM & NICK_RM_ALTIND1)
//			{
//				if (CharIndex & 0x080)
//				{
//					PenOffset|=0x02;
//				}
//			}

			if (Nick.LPT.RM & NICK_RM_ALTIND0)
			{
				if (CharIndex & 0x080)
				{
					PenOffset|=0x02;		
				}
			}


			Pen0ConvertedColour = GetColourForPen(PenOffset);
			Pen1ConvertedColour = GetColourForPen((PenOffset|0x01));
	
			Nick_WritePixels2Colour_CharMode(Pen0ConvertedColour,
				Pen1ConvertedColour, Data);
		}
		break;

		case NICK_4_COLOUR_MODE:
		{
			unsigned long ConvertedColour;

			//printf("4 colour\r\n");

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			for (i=0; i<4; i++)
			{
				PenIndex = Nick_PenIndexLookup_4Colour[Data];

				ConvertedColour = Nick_16ColourConverted[PenIndex & 0x03];

				{
					unsigned char *dest = Nick.dest;
					unsigned long Increment = BytesPerPixel;

					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			
					Nick.dest = dest;
				}

				Data = Data<<1;
 			}
		}
		break;

		case NICK_16_COLOUR_MODE:
		{
//			unsigned long ConvertedColour;

			//printf("16 colour\r\n");

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			for (i=0; i<2; i++)
			{
				unsigned long ConvertedColour;

				PenIndex = Nick_PenIndexLookup_16Colour[Data];

//				if (PenIndex & 0x08)
//				{
//					PalIndex = ((Nick.FIXBIAS & 0x01f)<<3) | (PenIndex & 0x07);
//				}
//				else
//				{
//					PalIndex = Nick.LPT.COL[PenIndex & 0x07];
//				}

				ConvertedColour = Nick_16ColourConverted[PenIndex];

//				NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//				NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//				NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//				NICK_WRITE_PIXEL(PalIndex, Nick.dest);


				{
					unsigned char *dest = Nick.dest;
					unsigned long Increment = BytesPerPixel;

					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
				
					Nick.dest = dest;
				}

				Data = Data<<1;
			}
		}
		break;

		case NICK_256_COLOUR_MODE:
		{
			unsigned long ConvertedColour;

			/* left margin attributes */
			if (Nick.LPT.LM & NICK_LM_MSBALT)
			{
				Data &= ~0x080;
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				Data &= ~0x01;
			}


			PalIndex = Data;

			ConvertedColour = ConvertedColourTable[PalIndex];

//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);
//			NICK_WRITE_PIXEL(PalIndex, Nick.dest);

			{
				unsigned char *dest = Nick.dest;
				unsigned long Increment = BytesPerPixel;

			//	for (i=16; i>=0; i--)
			//	{
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
					NICK_WRITE_PIXEL_INC(ConvertedColour, dest, Increment);
			//	}
		
				Nick.dest = dest;
			}
		}
		break; 
	}
}



static void Nick_DoPixel(int ClocksVisible)
{
	int i;
	unsigned char Buf1, Buf2;

	Nick.LD1.L+=(Nick.Graphics_Clocks_SkipLeft<<1);

	for (i=0; i<ClocksVisible; i++)
	{
		Buf1 =  Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;
		
		Buf2 = Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;

		Nick_WritePixels_PixelMode(Buf1,Buf1);

		Nick_WritePixels_PixelMode(Buf2,Buf1);
	}

	Nick.LD1.L+=(Nick.Graphics_Clocks_SkipRight<<1);
}


static void Nick_DoLPixel(int ClocksVisible)
{
	int i;
	unsigned char Buf1;

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft;

	for (i=0; i<ClocksVisible; i++)
	{
		unsigned char Data1, Data2;
	//	unsigned short LPixelData;

		Buf1 =  Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;

	//	LPixelData = Nick_LPixelLookup[Buf1];

	//	Data1 =(LPixelData>>8);
	//	Data2 = LPixelData;

	//	Nick_WritePixels_PixelMode(Data1,0);
	//	Nick_WritePixels_PixelMode(Data2,0);
		Nick_WritePixels_CharMode(Buf1, Buf1);
	}

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipRight;
}

static void Nick_DoAttr(int ClocksVisible)
{
	int i;
	unsigned char Buf1, Buf2;

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft;
	Nick.LD2.L+=Nick.Graphics_Clocks_SkipLeft;

	for (i=0; i<ClocksVisible; i++)
	{
		Buf1 = Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;

		Buf2 = Nick_FetchByte(Nick.LD2.L);
		Nick.LD2.L++;		

		{
			unsigned long Pen0ConvertedColour, Pen1ConvertedColour;
			unsigned char BackgroundColour = ((Buf1>>4) & 0x0f);
			unsigned char ForegroundColour = (Buf1 & 0x0f);
//			unsigned short PixelData;
//			unsigned char Data1, Data2;

//			PixelData = Nick_LPixelLookup[Buf2];
//			Data1 = (PixelData>>8);
//			Data2 = PixelData;
	
			if (Nick.LPT.RM & NICK_RM_ALTIND0)
			{
				if (Buf1 & 0x080)
				{
					BackgroundColour|=0x04;		
					ForegroundColour|=0x04;
				}
			}
	

			Pen0ConvertedColour = GetColourForPen(BackgroundColour);
			Pen1ConvertedColour = GetColourForPen(ForegroundColour);


//			Nick_WritePixels2Colour(BackgroundColour, ForegroundColour, Data1);
//			Nick_WritePixels2Colour(BackgroundColour, ForegroundColour, Data2);
			Nick_WritePixels2Colour_CharMode(Pen0ConvertedColour, Pen1ConvertedColour, Buf2);
		}
	}

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipRight;
	Nick.LD2.L+=Nick.Graphics_Clocks_SkipRight;
}

static void Nick_DoCh256(int ClocksVisible)
{
	int i;
	unsigned char Buf1, Buf2;

	
	Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft;

	for (i=0; i<ClocksVisible; i++)
	{
		Buf1 = Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;
		Buf2 = Nick_FetchByte(ADDR_CH256(Nick.LD2.L, Buf1));

		Nick_WritePixels_CharMode(Buf2,Buf1);

//		if (!(Nick.LPT.MB & NICK_MB_VRES))
//		{
//			Nick_UpdateScanLineCount();
//		}

	}
	
	Nick.LD1.L+=Nick.Graphics_Clocks_SkipRight;
}

static void Nick_DoCh128(int ClocksVisible)
{
	int i;
	unsigned char Buf1, Buf2;
	
	Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft;

	for (i=0; i<ClocksVisible; i++)
	{
		Buf1 = Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;
		Buf2 = Nick_FetchByte(ADDR_CH128(Nick.LD2.L, Buf1));

		Nick_WritePixels_CharMode(Buf2,Buf1);

//		if (!(Nick.LPT.MB & NICK_MB_VRES))
//		{
//			Nick_UpdateScanLineCount();
//		}
	}

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipRight;
}

static void Nick_DoCh64(int ClocksVisible)
{
	int i;
	unsigned char Buf1, Buf2;

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft;

	for (i=0; i<ClocksVisible; i++)
	{
		Buf1 = Nick_FetchByte(Nick.LD1.L);
		Nick.LD1.L++;
		Buf2 = Nick_FetchByte(ADDR_CH64(Nick.LD2.L, Buf1));
		
		Nick_WritePixels_CharMode(Buf2,Buf1);

	}

	Nick.LD1.L+=Nick.Graphics_Clocks_SkipRight;
}


static void Nick_DoVsync(void)
{
//	unsigned char LeftMargin, RightMargin;
//
//	// get left margin
//	LeftMargin = NICK_GET_LEFT_MARGIN(Nick.LPT.LM);
//	// get right margin.
//	RightMargin = NICK_GET_RIGHT_MARGIN(Nick.LPT.RM);
//
//	/* vsync was turned on in the line */
//	if ((LeftMargin!=0) && (LeftMargin!=63))
//	{
//		Nick.VsyncState = 1;
//	}

//	/* vsync was turned off in the line */
//	if ((RightMargin!=0) && (RightMargin!=63))
//	{
//		Nick.VsyncState = 0;
//	}
}

void	Nick_UpdateLineVariables(void)
{
	unsigned char DisplayMode;

	/* get display mode */
	DisplayMode = NICK_GET_DISPLAY_MODE(Nick.LPT.MB);

	switch (DisplayMode)
	{
		case NICK_ATTR_MODE:
		{
			Nick.LD1.L = Nick.LD1_RELOAD.L;
		}
		break;

		case NICK_LPIXEL_MODE:
		case NICK_PIXEL_MODE:
		{
			if ((Nick.LPT.MB & NICK_MB_VRES)==0)
			{
				Nick.LD1.L = Nick.LD1_RELOAD.L;
				Nick.LD2.L = Nick.LD2_RELOAD.L;
			}
		}
		break;

		case NICK_CH256_MODE:
		case NICK_CH128_MODE:
		case NICK_CH64_MODE:
		{
			/* reload LD1 */
			Nick.LD1.L = Nick.LD1_RELOAD.L;
			Nick.LD2.L++;
		}
		break;

		default:
			break;
	}

	Nick_UpdateScanLineCount();
}

static void Nick_DoDisplay(LPT_ENTRY *pLPT, unsigned long ClocksVisible)
{
	if (ClocksVisible!=0)
	{
		unsigned char DisplayMode;
	
		/* get display mode */
		DisplayMode = NICK_GET_DISPLAY_MODE(pLPT->MB);

	

//		if ((pLPT->MB & NICK_MB_VRES)==0)
//		{
//		//	printf("here");
//			Nick.LD2 = (pLPT->LD2L & 0x0ff) |
//						((pLPT->LD2H & 0x0ff)<<8);
//		
//			/* reload LD1 */
//			Nick.LD1 = (pLPT->LD1L & 0x0ff) |
//					((pLPT->LD1H & 0x0ff)<<8);
//		}
		

		switch (DisplayMode)
		{
			case NICK_PIXEL_MODE:
			{
				Nick_DoPixel(ClocksVisible);
			}
			break;

			case NICK_ATTR_MODE:
			{
				//printf("attr mode\r\n");
				Nick_DoAttr(ClocksVisible);
			}
			break;

			case NICK_CH256_MODE:
			{
				//printf("ch256 mode\r\n");
				Nick_DoCh256(ClocksVisible);
			}
			break;

			case NICK_CH128_MODE:
			{	
				Nick_DoCh128(ClocksVisible);
			}
			break;

			case NICK_CH64_MODE:
			{
				//printf("ch64 mode\r\n");
				Nick_DoCh64(ClocksVisible);
			}
			break;

			case NICK_LPIXEL_MODE:
			{
				Nick_DoLPixel(ClocksVisible);
			}
			break;

		//	case NICK_VSYNC_MODE:
		//	{
		//		Nick_DoVsync(ClocksVisible);
		//	}
		//	break;

			default:
				break;
		}
	}
}

static void Nick_DoDisplay_NoGraphics(LPT_ENTRY *pLPT, unsigned long ClocksVisible)
{
	if (ClocksVisible!=0)
	{
		unsigned char DisplayMode;
	
		/* get display mode */
		DisplayMode = NICK_GET_DISPLAY_MODE(pLPT->MB);

		switch (DisplayMode)
		{
			case NICK_PIXEL_MODE:
			{
				Nick.LD1.L+=(Nick.Graphics_Clocks_SkipLeft + Nick.Graphics_Clocks_SkipRight)<<1;
				Nick.LD1.L+=ClocksVisible<<1;
			}
			break;

			case NICK_ATTR_MODE:
			{
				Nick.LD1.L+=(Nick.Graphics_Clocks_SkipLeft + Nick.Graphics_Clocks_SkipRight);
				Nick.LD2.L+=(Nick.Graphics_Clocks_SkipLeft + Nick.Graphics_Clocks_SkipRight);
				Nick.LD1.L+=ClocksVisible;
				Nick.LD2.L+=ClocksVisible;
			}
			break;

			case NICK_CH256_MODE:
			case NICK_CH128_MODE:
			case NICK_CH64_MODE:
			{
				Nick.LD1.L+=Nick.Graphics_Clocks_SkipLeft + Nick.Graphics_Clocks_SkipRight;
				Nick.LD1.L+=ClocksVisible;
			}
			break;
			
			case NICK_LPIXEL_MODE:
			{
				Nick.LD1.L+=(Nick.Graphics_Clocks_SkipLeft + Nick.Graphics_Clocks_SkipRight);
				Nick.LD1.L+=ClocksVisible;
			}
			break;

		//	case NICK_VSYNC_MODE:
		//	{
		//		Nick_DoVsync(ClocksVisible);
		//	}
		//	break;

			default:
				break;
		}
	}
}

void	Nick_UpdateLPT(void)
{
//	unsigned long CurLPT;

	Nick.LP.L++;	//CurLPT = (Nick.LPL & 0x0ff) | ((Nick.LPH & 0x0f)<<8);
	//CurLPT++;
	//Nick.LPL = CurLPT & 0x0ff;
	//Nick.LPH = (Nick.LPH & 0x0f0) | ((CurLPT>>8) & 0x0f);		
}

void	Nick_SetupRendering(void)
{
			{
			unsigned char LeftMargin,RightMargin;
			unsigned long ClocksVisible = Nick_LastVisibleClock - Nick_FirstVisibleClock;

			// get left margin
			LeftMargin = NICK_GET_LEFT_MARGIN(Nick.LPT.LM);
			// get right margin.
			RightMargin = NICK_GET_RIGHT_MARGIN(Nick.LPT.RM);


			if ((RightMargin<LeftMargin) || (LeftMargin>RightMargin))
			{
				Nick.LM_Clocks = ClocksVisible;
				Nick.RM_Clocks = 0;
				Nick.Graphics_Clocks = 0;
				return;
			}

			// left margin not visible?
			if (LeftMargin<Nick_FirstVisibleClock)
			{
				// no part of left margin is visible
				// no left margin clocks to do.
				Nick.LM_Clocks = 0;
				// number of clocks to skip before rendering graphics
				Nick.Graphics_Clocks_SkipLeft = Nick_FirstVisibleClock-LeftMargin;
			}
			else
			{
				// some of left margin is visible. don't skip graphics clocks.
				Nick.Graphics_Clocks_SkipLeft = 0;

				// calc number of clocks visible.
				Nick.LM_Clocks = LeftMargin - Nick_FirstVisibleClock;

				// does left margin cover whole screen?
				if (Nick.LM_Clocks>=ClocksVisible)
				{
					// left margin covers whole screen!
					Nick.LM_Clocks = ClocksVisible;
					Nick.Graphics_Clocks = 0;
					Nick.RM_Clocks = 0;
					return;
				}
			}

			// left margin doesn't cover whole screen!

			// is right margin not visible?
			if (RightMargin>Nick_LastVisibleClock)
			{
				// no part of right margin is visible
				// no right margin clocks required.
				Nick.RM_Clocks = 0;
				// calc number of graphics clocks to show
				Nick.Graphics_Clocks = Nick_LastVisibleClock - Nick.LM_Clocks;

				// number of graphic clocks to skip on r.h.s
				Nick.Graphics_Clocks_SkipRight = RightMargin-Nick_LastVisibleClock;
				return;
			}
			else
			{
				Nick.Graphics_Clocks_SkipRight = 0;

				// some of right margin is visible
				Nick.RM_Clocks = Nick_LastVisibleClock - RightMargin;
				
				// does right margin cover whole screen?
				if (Nick.RM_Clocks>=ClocksVisible)
				{
					// right margin covers whole screen!
					Nick.LM_Clocks = 0;
					Nick.Graphics_Clocks = 0;
					Nick.RM_Clocks = ClocksVisible;
					return;
				}

				// calc graphics clocks to show.
				Nick.Graphics_Clocks = ClocksVisible - Nick.RM_Clocks - Nick.LM_Clocks;
			}
		}
}



void	Nick_ReloadLPT(void)
{
	unsigned long LPT_Addr;
		
		/* get addr of LPT */
		LPT_Addr = ((Nick.LP.L & 0x00fff)<<4);	// ((Nick.LPL & 0x0ff)<<4) | ((Nick.LPH & 0x01f)<<(8+4));

		/* update internal LPT state */
		Nick.LPT.SC = Nick_FetchByte(LPT_Addr);
		Nick.LPT.MB = Nick_FetchByte(LPT_Addr+1);
		Nick.LPT.LM = Nick_FetchByte(LPT_Addr+2);
		Nick.LPT.RM = Nick_FetchByte(LPT_Addr+3);
		Nick.LPT.LD1L = Nick_FetchByte(LPT_Addr+4);
		Nick.LPT.LD1H = Nick_FetchByte(LPT_Addr+5);
		Nick.LPT.LD2L = Nick_FetchByte(LPT_Addr+6);
		Nick.LPT.LD2H = Nick_FetchByte(LPT_Addr+7);
		Nick.LPT.COL[0] = Nick_FetchByte(LPT_Addr+8);
		Nick.LPT.COL[1] = Nick_FetchByte(LPT_Addr+9);
		Nick.LPT.COL[2] = Nick_FetchByte(LPT_Addr+10);
		Nick.LPT.COL[3] = Nick_FetchByte(LPT_Addr+11);
		Nick.LPT.COL[4] = Nick_FetchByte(LPT_Addr+12);
		Nick.LPT.COL[5] = Nick_FetchByte(LPT_Addr+13);
		Nick.LPT.COL[6] = Nick_FetchByte(LPT_Addr+14);
		Nick.LPT.COL[7] = Nick_FetchByte(LPT_Addr+15);

		Nick.LD1_RELOAD.W.l = Nick.LPT.LD1L;
		Nick.LD1_RELOAD.W.h = Nick.LPT.LD1H;
		Nick.LD2_RELOAD.W.l = Nick.LPT.LD2L;
		Nick.LD2_RELOAD.W.h = Nick.LPT.LD2H;

		Nick_16ColourPalette[0] = Nick.LPT.COL[0];
		Nick_16ColourPalette[1] = Nick.LPT.COL[1];
		Nick_16ColourPalette[2] = Nick.LPT.COL[2];
		Nick_16ColourPalette[3] = Nick.LPT.COL[3];
		Nick_16ColourPalette[4] = Nick.LPT.COL[4];
		Nick_16ColourPalette[5] = Nick.LPT.COL[5];
		Nick_16ColourPalette[6] = Nick.LPT.COL[6];
		Nick_16ColourPalette[7] = Nick.LPT.COL[7];


		Nick_16ColourConverted[0] = ConvertedColourTable[Nick.LPT.COL[0]];
		Nick_16ColourConverted[1] = ConvertedColourTable[Nick.LPT.COL[1]];
		Nick_16ColourConverted[2] = ConvertedColourTable[Nick.LPT.COL[2]];
		Nick_16ColourConverted[3] = ConvertedColourTable[Nick.LPT.COL[3]];
		Nick_16ColourConverted[4] = ConvertedColourTable[Nick.LPT.COL[4]];
		Nick_16ColourConverted[5] = ConvertedColourTable[Nick.LPT.COL[5]];
		Nick_16ColourConverted[6] = ConvertedColourTable[Nick.LPT.COL[6]];
		Nick_16ColourConverted[7] = ConvertedColourTable[Nick.LPT.COL[7]];
			
		/* scan line count for this LPT */
		Nick.LPT_ScanLineCount = ((~Nick.LPT.SC)+1) & 0x0ff;

		Nick_SetupRendering();

	/* set VIRQ interrupt line low if VIRQ is set */
	Dave_Int1_SetState((~Nick.LPT.MB)>>7);

	{
		int DisplayMode;

		Nick.ScanLineCount = 0;

		/* doing first line */
		Nick.LD1.L = Nick.LD1_RELOAD.L;

		DisplayMode = NICK_GET_DISPLAY_MODE(Nick.LPT.MB);

		if ((DisplayMode != NICK_LPIXEL_MODE) && (DisplayMode != NICK_PIXEL_MODE))
		{
//			///* lpixel and pixel modes don't use LD2 */

			Nick.LD2.L = Nick.LD2_RELOAD.L;
		}
	
		Nick.PrevVsyncState = Nick.VsyncState;

//		if (DisplayMode!=NICK_VSYNC_MODE)
//		{
			Nick.VsyncState = (NICK_GET_DISPLAY_MODE(Nick.LPT.MB)==NICK_VSYNC_MODE);
//		}

	}

	

}

unsigned char *Nick_GetDisplayModeName(int DisplayMode)
{
		switch (DisplayMode)
		{
			case NICK_PIXEL_MODE:
				return "PIXEL";

			case NICK_ATTR_MODE:
				return "ATTR";

			case NICK_CH256_MODE:
				return "CH256";

			case NICK_CH128_MODE:
				return "CH128";

			case NICK_CH64_MODE:
				return "CH64";
			
			case NICK_LPIXEL_MODE:
				return "LPIXEL";

			case NICK_VSYNC_MODE:
				return "VSYNC";

			default:
				break;
		}

	return "Undefined";
}

unsigned char *Nick_GetColourModeName(int ColourMode)
{
		switch (ColourMode)
		{
			case NICK_2_COLOUR_MODE:
				return "2 COLOUR ";

			case NICK_4_COLOUR_MODE:
				return "4 COLOUR";

			case NICK_16_COLOUR_MODE:
				return "16 COLOUR";

			case NICK_256_COLOUR_MODE:
				return "256 COLOUR";

			default:
				break;
		}

	return "? COLOUR";
}


void	Nick_ShowLPT(FILE *logfile)
{
		unsigned short LPT_Addr;
		LPT_ENTRY	LPT;

	if (!logfile)
		return;


	/* get addr of LPT */
	LPT_Addr = ((Nick.Reg[2] & 0x0ff)<<4) | ((Nick.Reg[3] & 0x01f)<<(8+4));


	do
	{

		LPT.SC = Nick_FetchByte(LPT_Addr);
		LPT.MB = Nick_FetchByte(LPT_Addr+1);
		LPT.LM = Nick_FetchByte(LPT_Addr+2);
		LPT.RM = Nick_FetchByte(LPT_Addr+3);
		LPT.LD1L = Nick_FetchByte(LPT_Addr+4);
		LPT.LD1H = Nick_FetchByte(LPT_Addr+5);
		LPT.LD2L = Nick_FetchByte(LPT_Addr+6);
		LPT.LD2H = Nick_FetchByte(LPT_Addr+7);
		LPT.COL[0] = Nick_FetchByte(LPT_Addr+8);
		LPT.COL[1] = Nick_FetchByte(LPT_Addr+9);
		LPT.COL[2] = Nick_FetchByte(LPT_Addr+10);
		LPT.COL[3] = Nick_FetchByte(LPT_Addr+11);
		LPT.COL[4] = Nick_FetchByte(LPT_Addr+12);
		LPT.COL[5] = Nick_FetchByte(LPT_Addr+13);
		LPT.COL[6] = Nick_FetchByte(LPT_Addr+14);
		LPT.COL[7] = Nick_FetchByte(LPT_Addr+15);

		fprintf(logfile,"ScanLineCount: %d\r\n",((~LPT.SC)+1) & 0x0ff);

		{
			int DisplayMode = NICK_GET_DISPLAY_MODE(LPT.MB);
			int ColourMode = NICK_GET_COLOUR_MODE(LPT.MB);

			fprintf(logfile,"DisplayMode: %s ColourMode: %s\r\n",Nick_GetDisplayModeName(DisplayMode),
				Nick_GetColourModeName(ColourMode));

			if (LPT.MB & NICK_MB_LPT_RELOAD)
			{
				fprintf(logfile, "RELOAD ");
			}

			if (LPT.MB & NICK_MB_VIRQ)
			{
				fprintf(logfile, "VIRQ ");
			}

			if (!(LPT.MB & NICK_MB_VRES))
			{
				fprintf(logfile, "VRES ");
			}

			fprintf(logfile,"\r\n");
		
			fprintf(logfile,"LM: %d RM: %d ", NICK_GET_LEFT_MARGIN(LPT.LM), NICK_GET_RIGHT_MARGIN(LPT.RM));

			if (LPT.LM & NICK_LM_MSBALT)
			{
				fprintf(logfile, "MSBALT ");
			}

			if (Nick.LPT.LM & NICK_LM_LSBALT)
			{
				fprintf(logfile, "LSBALT ");
			}

			if (Nick.LPT.RM & NICK_RM_ALTIND1)
			{
				fprintf(logfile, "ALTIND1 ");
			}

			if (Nick.LPT.RM & NICK_RM_ALTIND0)
			{
				fprintf(logfile, "ALTIND0 ");
			}

			fprintf(logfile,"\r\n------\r\n");
		}

		LPT_Addr+=16;
	}
	while ((LPT.MB & NICK_MB_LPT_RELOAD)==0);
}

static void	Nick_UpdateScanLineCount(void)
{
	/* update count of scanlines done so far */
	Nick.ScanLineCount++;
	
	if (((unsigned char)Nick.ScanLineCount) == 
		((unsigned char)Nick.LPT_ScanLineCount))
	{
		/* done all scanlines of this Line Parameter Table, get next */
		Nick_UpdateLPT();


		if ((Nick.LPT.MB & NICK_MB_LPT_RELOAD)!=0) 
		{
			Nick.LP.L = 0;
			Nick.LP.W.l = Nick.Reg[2];
			Nick.LP.W.h = Nick.Reg[3];
		}
		
		Nick_ReloadLPT();


	}
}

/* call here to render a line of graphics */
void	Nick_DoLine(void)
{
	// do left margin clocks
	if (Nick.LM_Clocks!=0)
	{
		Nick_WriteBorder(Nick.LM_Clocks);
	}

	// do display clocks...
	if (Nick.Graphics_Clocks!=0)
	{
		Nick_DoDisplay(&Nick.LPT, Nick.Graphics_Clocks);
	}

	// do right margin clocks..
	if (Nick.RM_Clocks!=0)
	{
		Nick_WriteBorder(Nick.RM_Clocks);
	}

}

void	Nick_DoLine_NoGraphics(void)
{
	Nick_DoDisplay_NoGraphics(&Nick.LPT,Nick.Graphics_Clocks);
}


int	Nick_Read(int RegIndex)
{
  /* read from a nick register - return floating bus,
   because the registers are not readable! */
  return 0x0ff;
}

void	Nick_Write(int RegIndex, int Data)
{
	int Reg = RegIndex & 0x0f;
	int Reload = 0;
			

  switch (Reg)
  {
		case 0x03:
		{
			if (
				((Data & 0x0c0)==0x0c0) && 
				((Nick.Reg[3] & 0x0c0)==0x040)
				)
			{
				Reload = 1;
			}
		}
		break;

		case 0x01:
		{
			Nick.BORDER = Data; 
		}
		break;

		case 0x00:
		{
			Nick.FIXBIAS = Data;

			{
				unsigned char *pPalette;
				unsigned char FixBias;

				FixBias = (Data & 0x01f)<<3;

				pPalette = &Nick_16ColourPalette[8];

				pPalette[0] = FixBias++;
				pPalette[1] = FixBias++;
				pPalette[2] = FixBias++;
				pPalette[3] = FixBias++;
				pPalette[4] = FixBias++;
				pPalette[5] = FixBias++;
				pPalette[6] = FixBias++;
				pPalette[7] = FixBias;
		
				Nick_16ColourConverted[8] = ConvertedColourTable[pPalette[0]];
				Nick_16ColourConverted[9] = ConvertedColourTable[pPalette[1]];
				Nick_16ColourConverted[10] = ConvertedColourTable[pPalette[2]];
				Nick_16ColourConverted[11] = ConvertedColourTable[pPalette[3]];
				Nick_16ColourConverted[12] = ConvertedColourTable[pPalette[4]];
				Nick_16ColourConverted[13] = ConvertedColourTable[pPalette[5]];
				Nick_16ColourConverted[14] = ConvertedColourTable[pPalette[6]];
				Nick_16ColourConverted[15] = ConvertedColourTable[pPalette[7]];

			}
		}
		break;

		default:
			break;
  }

 
  /* write to a nick register */
  Nick.Reg[Reg] = Data;

  if (Reload)
  {
	  /* reload LPT base pointer */
	   Nick.LP.W.l = Nick.Reg[2];
	   Nick.LP.W.h = Nick.Reg[3];

	   Nick_ReloadLPT();
  }
}

int line = 0;

void	Nick_RenderLine(void)
{
	if (line<NICK_MAX_VISIBLE_LINES)
	{
	//	if (Render_Lock()!=0)
	//	{
			Nick.dest = Render_GetLine(line);

			Nick_DoLine();

	//		Render_Unlock();
	//	}
	//	else
	//	{
	//		Nick_DoLine_NoGraphics();
	//	}

	}
	else
	{
		Nick_DoLine_NoGraphics();
	}

	Nick_UpdateLineVariables();

	line++;

	if (
		((Nick.VsyncState) && (!Nick.PrevVsyncState)) || 
		(line>=312) 
		)
	{
		// just started VSYNC
		line = 0;
	}

	/* copy old vsync */
	Nick.PrevVsyncState = Nick.VsyncState;
}

void    Nick_DoScreen(struct osd_bitmap *bm)
{
  int line = 0;

  do
  {
	Nick.dest = Render_GetLine(line);

    /* set write address for line */
/*    Nick.dest = bm->line[line]; */
    
    /* write line */
    Nick_DoLine();

    /* next line */
    line++;
  }
  while (((Nick.LPT.MB & 0x080)==0) && (line<(35*8)));

}






















