/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
/* EP main file */

#include "ep.h"
#include "nick.h"
#include "dave.h"
#include "z80\z80.h"
#include "device.h"
#include <stdio.h>
#include <stdlib.h>
#include "diskimage\diskimg.h"
#include "audioevent.h"
#include "host.h"
#include "render.h"
#include "config.h"

/* additional h/w */
#include "rtc.h"

//#define ZOLTAN

//#define LOGFILE 1

#if LOGFILE
FILE *logfile;
#endif

void	 WD177x_Reset(void);


/**************************************************************************/
/* KEYBOARD AND EXTERNAL JOYSTICKS */

unsigned char Enterprise_KeyboardData[16];

void	Enterprise_ResetKeyboard()
{
	memset(&Enterprise_KeyboardData[0], 0x0ff, 16);
}

int		Enterprise_GetKeyboardLine(int Line)
{
	if (Line>9)
		return 0x0ff;

	return Enterprise_KeyboardData[Line & 0x0f];
}

/* 

  Thanks to Arpad Lukacs for the info. 

External Joystick Data:
b0 - RIGHT
b1 - LEFT
b2 - DOWN
b3 - UP
b4 - FIRE
b5,b6,b7 - not used=0

FIRE on line 0, UP on line 1, DOWN on line 2,
LEFT on line 3, RIGHT on line 4 */

typedef struct EXTERNAL_JOYSTICK_MAP
{
	int JoystickIndex;
	int RightShift;
} EXTERNAL_JOYSTICK_MAP;


EXTERNAL_JOYSTICK_MAP	ExternalJoystickMapping[]=
{	
	{0,4},		/* FIRE on External 1 */
	{0,3},		/* UP on External 1 */
	{0,2},		/* DOWN on External 1 */
	{0,1},		/* LEFT on External 1 */
	{0,0},		/* RIGHT on External 1 */
	{1,4},		/* FIRE on External 2 */
	{1,3},		/* UP on External 2 */
	{1,2},		/* DOWN on External 2 */
	{1,1},		/* LEFT on External 2 */
	{1,0},		/* FIRE on External 2 */
};


/* data for joysticks */
unsigned char Enterprise_ExternalJoysticks_Data[2];

/* return data bit for joysticks */
unsigned char Enterprise_ReadExternalJoystick(int PortB5)
{
	int JoystickIndex, JoystickDataShift;

	if (PortB5>9)
		return 1;

	JoystickIndex = ExternalJoystickMapping[PortB5].JoystickIndex;
	JoystickDataShift = ExternalJoystickMapping[PortB5].RightShift;

	return (Enterprise_ExternalJoysticks_Data[JoystickIndex]>>JoystickDataShift) & 0x01;
}

void	Enterprise_ResetExternalJoysticks(void)
{
	Enterprise_ExternalJoysticks_Data[0] =
		Enterprise_ExternalJoysticks_Data[1] = 0x0ff;
}


void Enterprise_SetControl(int ControlID)
{
	unsigned char AndValue;
	
	if (ControlID<=EP_KEY_NULL)
	{
		AndValue = ~(1<<(ControlID & 0x07));

		/* keyboard */
		Enterprise_KeyboardData[(ControlID>>3)] &= AndValue;
	}
	else
	{
		/* joysticks */
		int ControlIDBase = ControlID - EP_KEY_EXTERNAL_JOYSTICK1_RIGHT;

		AndValue = ~(1<<(ControlIDBase & 0x07));

		Enterprise_ExternalJoysticks_Data[(ControlIDBase>>3)] &= AndValue;
	}
}

void Enterprise_ClearControl(int ControlID)
{
	unsigned char OrValue;
	
	if (ControlID<=EP_KEY_NULL)
	{
		OrValue = (1<<(ControlID & 0x07));

		/* keyboard */
		Enterprise_KeyboardData[(ControlID>>3)] = OrValue;
	}
	else
	{

		/* joysticks */
		int ControlIDBase = ControlID - EP_KEY_EXTERNAL_JOYSTICK1_RIGHT;

		OrValue = (1<<(ControlIDBase & 0x07));

		Enterprise_ExternalJoysticks_Data[(ControlIDBase>>3)] = OrValue;
	}

}


void	Enterprise_ResetControllers(void)
{
	/* reset keyboard */
	Enterprise_ResetKeyboard();

	/* reset external joysticks */
	Enterprise_ResetExternalJoysticks();
}

/**************************************************************************/

/* currently set pages */
unsigned char *pReadRamPtr[4];
unsigned char *pWriteRamPtr[4];

/* enterprise pages setup */
/* reading */
static unsigned char *Enterprise_ReadPages[256];
/* writing */
static unsigned char *Enterprise_WritePages[256];
/* type setup */
static EP_PAGE_TYPE Enterprise_Page_Types[256];

/* null memory for unassigned areas */
static unsigned char *Enterprise_Memory_NULL = NULL;
static unsigned char *Enterprise_Memory_Read_NULL = NULL;
static unsigned char *Enterprise_Memory_Write_NULL = NULL;
/* video ram */
unsigned char *MEMORY = NULL;

unsigned short TapeVar_Buffer;
unsigned short TapeVar_BytesRead;
unsigned short TapeVar_FilenameBuffer;
unsigned short TapeVar_BlockFlag;
unsigned short TapeVar_BlockType;

void	Z80_Reti(void)
{
}

int OpCount = 0;
int OpcodeCount = 0;
int OpcodeLineCount = 0;
int IntCycles;
extern DAVE dave;

void	Z80_OpcodeFunc(int usCycles)
{
	OpCount+=usCycles;
	IntCycles+=usCycles;
	OpcodeCount+=usCycles;
	OpcodeLineCount+=usCycles;

	if (OpcodeLineCount>=64)
	{
		OpcodeLineCount = OpcodeLineCount-64;

		Nick_RenderLine();
	}

	if (OpcodeCount>=19968)
	{
		OpcodeCount = OpcodeCount - 19968;

		Render_DumpDisplay();
	
		Host_Throttle();

//		Dave_UpdateInts();
	}

	if (dave.CyclesToNextInterrupt!=0)
	{
		if (IntCycles>=dave.CyclesToNextInterrupt)
		{
			Dave_UpdateInterrupts(IntCycles);
			IntCycles = 0;
		}
	}

	//	Dave_UpdateCycles(usCycles);
}


/* read a byte from emulator memory with paging */
Z80_BYTE        Z80_RD_MEM(Z80_WORD Addr)
{
        unsigned long    MemBlock;
        unsigned char                   *pAddr;

        /* calculate 16k page */
        MemBlock = (Addr>>14);	// & 0x03;
        
        /* calculate address to read from */
        pAddr = pReadRamPtr[MemBlock] + Addr;	//MemOffset;

        /* return byte at memory address */
        return pAddr[0];
}


/* write a byte to emulator memory with paging */
void Z80_WR_MEM(Z80_WORD Addr,Z80_BYTE Data)
{
        unsigned int MemBlock;
        unsigned char           *pAddr;

        /* calculate 16k page */
        MemBlock = (Addr>>14) & 0x03;

        /* calculate address to write to */
        pAddr = pWriteRamPtr[MemBlock] + Addr;	

        /* write byte to memory address */
        pAddr[0] = Data;
}

/* Enterprise only acknowledges interrupt by clearing latches in Dave */
void	Enterprise_AckInterrupt(void)
{
}

/* reset enterprise */
void	Enterprise_Reset(void)
{
	Dave_Reset();

	Nick_Reset();

	/* reset memory config */
	Dave_Write(0x010, 0);
	Dave_Write(0x011, 0);
	Dave_Write(0x012, 0);
	Dave_Write(0x013, 0);

	/* set Z80 vector */
	Z80_SetVectorBase(0x0ff);

	Z80_Reset();

	WD177x_Reset();

	Z80_ClearInterrupt();
}


void	Enterprise_SetMemoryPage(int Z80Page, int EPPage)
{
	int EP_Page = EPPage & 0x0ff;
	int Z80_Page = Z80Page & 0x03;

	pReadRamPtr[Z80_Page] = Enterprise_ReadPages[EP_Page] - (Z80_Page<<14);
	pWriteRamPtr[Z80_Page] = Enterprise_WritePages[EP_Page] - (Z80_Page<<14);
}



/**** EXDOS *****/
static EXDOS_INTERFACE ExdosInterface;

void Exdos_InsertDisk(int Drive)
{
	ExdosInterface.DriveStates[Drive].DriveBits |= DRIVE_FLAGS_DISK_PRESENT;
}

void Exdos_RemoveDisk(int Drive)
{
	ExdosInterface.DriveStates[Drive].DriveBits &= ~DRIVE_FLAGS_DISK_PRESENT;
}


void	Exdos_Initialise()
{
	ExdosInterface.DriveStates[0].DriveBits = 0;
	ExdosInterface.DriveStates[1].DriveBits = 0;
	ExdosInterface.DriveStates[2].DriveBits = 0;
	ExdosInterface.DriveStates[3].DriveBits = 0;
}

/* get side selected */
int Exdos_GetSide(unsigned char Data)
{
	return (Data>>4) & 0x01;
}

/* get drive selected */
int Exdos_GetDrive(unsigned char Data)
{
	/* drive 0 selected */
	if (Data & 1)
		return 0;

	/* drive 1 selected */
	if (Data & 2)
		return 1;
	
	/* drive 2 selected */
	if (Data & 4)
		return 2;

	/* drive 3 selected */
	if (Data & 8)
		return 3;

	/* no drive selected */
	return -1;
}


/* PORT 0x018: */

/* WRITE */
/* bit 7 - In use */
/* bit 6 - Disk change clear */
/* bit 5 - mfm/fm */
/* bit 4 - Side */
/* Bit 3 - Select drive 3 */
/* bit 2 - Select drive 2 */
/* bit 1 - Select drive 1 */
/* bit 0 - Select drive 0 */

/* READ */
/* bit 7 - DRQ from WD177x */
/* bit 6 - Disk change */
/* bit 5 - ???? */
/* bit 4 - ???? */
/* bit 3 - ???? */
/* bit 2 - ???? */
/* bit 1 - IRQ from WD177x */
/* bit 0 - ???? 

PORT 0x020 - EXDOS Speed select etc
*/

void	ExdosCardWrite(Z80_BYTE Data)
 {
	/* store data written */
	ExdosInterface.CardData_Write = Data;	
	/* get side selected */
	ExdosInterface.CurrentSide = Exdos_GetSide(Data);
	/* get drive selected */
	ExdosInterface.CurrentDrive = Exdos_GetDrive(Data);
}

Z80_BYTE	ExdosCardRead(void)
{
	unsigned char Data;

	Data = (((ExdosInterface.wd177x.State & WD177X_STATE_INTERRUPT_REQUEST)>>1)<<1) | 
		(((ExdosInterface.wd177x.StatusRegister & WD177X_STATUS_DATA_REQUEST)>>1)<<7);

	return Data;
}

/* get track 0 state of this drive */
int	Exdos_GetDriveDiskPresentState(int DriveIndex)
{
	return ExdosInterface.DriveStates[DriveIndex].DriveBits & DRIVE_FLAGS_DISK_PRESENT;
}

/* get track 0 state of all selected drives */
int Exdos_GetCurrentDriveDiskPresentState(void)
{
	if (ExdosInterface.CurrentDrive!=-1)
	{
		return Exdos_GetDriveDiskPresentState(ExdosInterface.CurrentDrive);
	}
	
	return 0;
}


/* step a drive, ensuring it doesn't step outside limits */
void	Exdos_StepDrive(int DriveIndex, int StepDirectionAdd)
{
 	ExdosInterface.DriveStates[DriveIndex].CurrentTrack+=StepDirectionAdd;

	if (ExdosInterface.DriveStates[DriveIndex].CurrentTrack<=0)
	{
		ExdosInterface.DriveStates[DriveIndex].CurrentTrack = 0;
	}

	if (ExdosInterface.DriveStates[DriveIndex].CurrentTrack>=84)
	{
		ExdosInterface.DriveStates[DriveIndex].CurrentTrack = 84;
	}


	if (ExdosInterface.DriveStates[DriveIndex].CurrentTrack==0)
	{
		ExdosInterface.DriveStates[DriveIndex].DriveBits |= DRIVE_FLAGS_TRACK0;
	}
	else
	{
		ExdosInterface.DriveStates[DriveIndex].DriveBits &= ~DRIVE_FLAGS_TRACK0;
	}
}

/* step the selected drives */
void	Exdos_StepSelectedDrive(int StepDirectionAdd)
{
	if (ExdosInterface.CurrentDrive!=-1)
	{
		Exdos_StepDrive(ExdosInterface.CurrentDrive, StepDirectionAdd);
	}
}

/* get track 0 state of this drive */
int	Exdos_GetDriveTrack0State(int DriveIndex)
{
	return ExdosInterface.DriveStates[DriveIndex].DriveBits & DRIVE_FLAGS_TRACK0;
}

/* get track 0 state of all selected drives */
int Exdos_GetCurrentDriveTrack0State(void)
{
	if (ExdosInterface.CurrentDrive!=-1)
	{
		return Exdos_GetDriveTrack0State(ExdosInterface.CurrentDrive);
	}
	
	return 0;
}




#if 0
///////////////
/* Disk change bit is 0, if disk has been changed.
Writing a 1 to this bit will clear it */





void	Exdos_UpdateDriveFlags(unsigned char AndData, unsigned char OrData)
{
	unsigned char DriveSelection = ExdosInterface.CardData_Write;
	int i;

	for (i=0; i<4; i++)
	{
		if (DriveSelection & (1<<i))
		{
			unsigned char DriveFlags;

			DriveFlags = ExdosInterface.DriveStates[i].DriveBits;

			DriveFlags &=AndData;
			DriveFlags |=OrData;

			ExdosInterface.DriveStates[i].DriveBits = DriveFlags;
		}
	}
}

unsigned char Exdos_GetDriveFlags(void)
{
	unsigned char DriveSelection = ExdosInterface.CardData_Write;
	unsigned char DriveData = 0x0ff;
	int i;

	for (i=0; i<4; i++)
	{
		if (DriveSelection & (1<<i))
		{
			DriveData = ExdosInterface.DriveStates[i].DriveBits;
		}
	}

	return DriveData;
}
#endif



	

int	Exdos_CheckIfSectorExists(void)
{
	int Side = ExdosInterface.CurrentSide;
	int Drive = ExdosInterface.CurrentDrive;
	int Track = ExdosInterface.DriveStates[Drive].CurrentTrack;
	int SPT;
	int	i;

	SPT = DiskImage_GetSectorsPerTrack(Drive,Track,Side);

	for (i=0; i<SPT; i++)
	{
		FDC_CHRN	CHRN;
		int CurrentID;

		DiskImage_GetID(Drive,Track,Side,i,&CHRN);

		if ((CHRN.R == ExdosInterface.wd177x.SectorRegister) && (CHRN.C == ExdosInterface.wd177x.TrackRegister))
		{
			return i;
		}

	}

	return -1;
}


int		Exdos_GetSectorData(void)
{
	int SectorIndex = Exdos_CheckIfSectorExists();
	int Side = ExdosInterface.CurrentSide;
	
	if (SectorIndex!=-1)
	{
		/* got sector data */
		DiskImage_GetSector(ExdosInterface.CurrentDrive,
			ExdosInterface.DriveStates[ExdosInterface.CurrentDrive].CurrentTrack,
			Side,SectorIndex,&ExdosInterface.wd177x.DataBuffer[0]);
	}

	return SectorIndex;
}


int		Exdos_GetSectorID(void)
{
	FDC_CHRN CHRN;
	int CurrentDrive = ExdosInterface.CurrentDrive;
	int SPT;
	int Side = ExdosInterface.CurrentSide;

	/* get sectors per track */
	SPT = DiskImage_GetSectorsPerTrack(CurrentDrive,ExdosInterface.DriveStates[CurrentDrive].CurrentTrack, Side);

	if (SPT!=0)
	{
		/* id index to get */
		ExdosInterface.DriveStates[CurrentDrive].CurrentIDIndex = ExdosInterface.DriveStates[CurrentDrive].CurrentIDIndex % SPT;

		/* get the ID */
		DiskImage_GetID(CurrentDrive,ExdosInterface.DriveStates[CurrentDrive].CurrentTrack,Side,ExdosInterface.DriveStates[CurrentDrive].CurrentIDIndex,&CHRN);

		/* increment for next ID index */
		ExdosInterface.DriveStates[CurrentDrive].CurrentIDIndex++;

		ExdosInterface.wd177x.DataBuffer[0] = CHRN.C;
		ExdosInterface.wd177x.DataBuffer[1] = CHRN.H;
		ExdosInterface.wd177x.DataBuffer[2] = CHRN.R;
		ExdosInterface.wd177x.DataBuffer[3] = CHRN.N;
	
		return 0;
	}			
	else
	{
		return -1;
	}

}


/****** WD1772 ******/



void	WD177x_Reset()
{
	/* reset 177x */
	ExdosInterface.wd177x.StatusRegister = 0;
	ExdosInterface.wd177x.TrackRegister = 0;
	ExdosInterface.wd177x.SectorRegister = 0;
	ExdosInterface.wd177x.CommandRegister = 0;
	ExdosInterface.wd177x.DataBytesRemaining = 0;

}

void	WD177x_IssueStep(int StepDirection)
{
	int StepDirectionAdd;

	if ((StepDirection & WD177X_STATE_STEP_DIRECTION)!=0)
	{
		/* step in */

		StepDirectionAdd = 1;
	}
	else
	{
		/* step out */

		StepDirectionAdd = -1;

	}

	Exdos_StepSelectedDrive(StepDirectionAdd);
}



void	WD177x_StepIn(WD177X *wd177x)
{
	wd177x->State |= WD177X_STATE_STEP_DIRECTION;

	/* u flag set? */
	if (wd177x->CommandRegister & (1<<4))
	{
		/* update track register */
		wd177x->TrackRegister++;
	}

	wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;

	WD177x_IssueStep(wd177x->State & WD177X_STATE_STEP_DIRECTION);
}

void	WD177x_StepOut(WD177X *wd177x)
{
	wd177x->State &= ~WD177X_STATE_STEP_DIRECTION;

	/* u flag set? */
	if (wd177x->CommandRegister & (1<<4))
	{
		/* update track register */
		wd177x->TrackRegister--;
	}

	wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;

	WD177x_IssueStep(wd177x->State & WD177X_STATE_STEP_DIRECTION);
}

void	WD177x_Step(WD177X *wd177x)
{
	/* step */
	if (wd177x->State & WD177X_STATE_STEP_DIRECTION)
	{
		/* step in */
		WD177x_StepIn(wd177x);
	}
	else
	{
		/* step out */
		WD177x_StepOut(wd177x);
	}

	/* verification? */
	if (wd177x->CommandRegister & (1<<2))
	{
		/* disk present */
		if (Exdos_GetCurrentDriveDiskPresentState()==0)
		{
#if LOGFILE
			if (logfile) fprintf(logfile, "VERIFIED SEEK, DISK MISSING!\r\n");
#endif
			/* disk not present */

			wd177x->StatusRegister |= STA_1_SEEK_ERR;
		}
		else
		{
			/* check track index is valid */

		}
	}
}


void	WD177x_WriteCommand(WD177X *wd177x, Z80_BYTE Data)
{
	int CommandIndex = (Data>>5) & 0x07;

	wd177x->CommandRegister = Data;

#if LOGFILE
	if (logfile) fprintf(logfile,"WRITE COMMAND: %02x\r\n",Data);
#endif

//	wd177x->DataRegister = 0;

	/* clear int request */
	wd177x->State &= ~WD177X_STATE_INTERRUPT_REQUEST;

	switch (CommandIndex)
	{
		case 0:
		{
			/* Restore,Seek */

			wd177x->StatusRegister &= ~STA_1_SEEK_ERR;


			if (Data & (1<<4))
			{
				/* Seek */

#if LOGFILE
				if (logfile) fprintf(logfile,"SEEK COMMAND: %02x\r\n",wd177x->DataRegister);
#endif
				/* set step direction */
				if (wd177x->TrackRegister<wd177x->DataRegister)
				{
	
					/* step in */
					wd177x->State |= WD177X_STATE_STEP_DIRECTION;
				}
				else
				{
					/* step out */
					wd177x->State &=~WD177X_STATE_STEP_DIRECTION;
				}

			 //	// this nobbles the command register.. need to fix
			//	wd177x->CommandRegister |= (1<<4);
				
				/* DataRegister contains destination track to seek to */
				/* Track register is assumed to have a valid track index */
				while ((wd177x->TrackRegister!=wd177x->DataRegister) && ((wd177x->StatusRegister & STA_1_SEEK_ERR)==0))
				{
					WD177x_Step(wd177x);
				}
			}
			else
			{
#if LOGFILE
				if (logfile) fprintf(logfile,"RESTORE COMMAND\r\n");
#endif
	
				wd177x->State &= ~WD177X_STATE_STEP_DIRECTION;
				
				// this nobbles the data register - correct?
				wd177x->DataRegister = 0;


				// this nobbles the command register.. need to fix
				wd177x->CommandRegister |= (1<<4);

				while ((Exdos_GetCurrentDriveTrack0State()==0) && ((wd177x->StatusRegister & STA_1_SEEK_ERR)==0))
				{
					WD177x_Step(wd177x);
				}

			//	/* if drive got to track 0 */
			//	if (Exdos_GetCurrentDriveTrack0State()!=0)
			//	{
			//		/* set flag */
			//		wd177x->StatusRegister |= WD177X_STATUS_LOST_DATA_OR_TRACK_0;
			//		wd177x->TrackRegister = 0;
			//	}

			
			}

			wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON | WD177X_STATUS_RECORD_TYPE_SPIN_UP;

			wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
		}
		break;

		case 1:
		{
			wd177x->StatusRegister &= ~STA_1_SEEK_ERR;

#if LOGFILE
			if (logfile) fprintf(logfile,"STEP \r\n");
#endif

			WD177x_Step(wd177x);
		}
		break;

		case 2:
		{
			wd177x->StatusRegister &= ~STA_1_SEEK_ERR;

#if LOGFILE
			if (logfile) fprintf(logfile,"STEP IN:\r\n");
#endif

			/* step in */
			WD177x_StepIn(wd177x);
		}
		break;

		case 3:
		{
			wd177x->StatusRegister &= ~STA_1_SEEK_ERR;

#if LOGFILE
			if (logfile) fprintf(logfile,"STEP OUT: %02x\r\n");
#endif
			/* step out */
			WD177x_StepOut(wd177x);
		}
		break;

		case 4:
		{
//			wd177x->TrackRegister = 0x0ff;

#if LOGFILE
			if (logfile) fprintf(logfile,"read sector\r\n");
#endif
			/* read sector */
			wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST|WD177X_STATUS_BUSY;
			wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON;
			wd177x->StatusRegister &= ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR | WD177X_STATUS_RECORD_NOT_FOUND | WD177X_STATUS_WRITE_PROTECT);


			if ((Exdos_GetSectorData()!=-1) && (Exdos_GetCurrentDriveDiskPresentState()!=0))
			{
					wd177x->DataBytesRemaining = 512;
					wd177x->DataByteIndex = 0;
					wd177x->pData = &wd177x->DataBuffer[0];
			}
			else
			{
#if LOGFILE
				if (logfile) fprintf(logfile, "SECTOR NOT FOUND %02x\r\n",wd177x->SectorRegister);
#endif
				wd177x->StatusRegister &=~(WD177X_STATUS_DATA_REQUEST|WD177X_STATUS_BUSY);
				wd177x->StatusRegister |=WD177X_STATUS_RECORD_NOT_FOUND;
	
				if (Exdos_GetCurrentDriveDiskPresentState()==0)
				{
					wd177x->StatusRegister |= WD177X_STATUS_CRC_ERROR;
				}
				
				wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
			}

			
//			wd177x->SectorRegister++;
		
		}
		break;

		case 5:
		{
			wd177x->TrackRegister = 0x0ff;
#if LOGFILE
			if (logfile) fprintf(logfile,"write sector\r\n");
#endif
			/* write sector */
			wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST|WD177X_STATUS_BUSY;
			wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON;
			wd177x->StatusRegister &= ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR | WD177X_STATUS_RECORD_NOT_FOUND);
			

#if 0
			{
				int SectorIndex = wd177x_GetSector(0);
				int Side = (ExdosInterface.CardData_Write>>4) & 0x01;

				if (SectorIndex!=-1)
				{
					///* got sector data */
					//DiskImage_GetSector(0,ExdosInterface.DriveStates[0].CurrentTrack,Side,SectorIndex,&wd177x->DataBuffer[0]);

					wd177x->DataBytesRemaining = 512;
					wd177x->DataByteIndex = 0;
					wd177x->pData = &wd177x->DataBuffer[0];
				}
				else
				{
#if LOGFILE
					if (logfile) fprintf(logfile, "SECTOR NOT FOUND %02x\r\n",wd177x->SectorRegister);
#endif	
					wd177x->StatusRegister &=~(WD177X_STATUS_DATA_REQUEST|WD177X_STATUS_BUSY);
					wd177x->StatusRegister |=WD177X_STATUS_RECORD_NOT_FOUND;
					wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
				}
			}
#endif
		}
		break;

		case 6:
		{
			/* read address/force interrupt */
			wd177x->TrackRegister = 0x0ff;

			if ((Data & (1<<4))!=0)
			{
				int val;

				/* force int */
				
//				val = Data & 0x0f;
	
#if LOGFILE
				if (logfile) fprintf(logfile,"FORCE INTERRUPT: %02x\r\n",wd177x->CommandRegister);
#endif

				
				wd177x->StatusRegister &= ~WD177X_STATUS_BUSY;
//				wd177x->DataBytesRemaining = 0;
				wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
			}
			else
			{
#if LOGFILE
				if (logfile) fprintf(logfile,"READ ADDRESS: \r\n");
#endif
				wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST|WD177X_STATUS_BUSY;
				//wd177x->StatusRegister |= WD177X_STATUS_RECORD_TYPE_SPIN_UP;
				wd177x->StatusRegister &= ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR);

				if (Exdos_GetSectorID()==-1)
				{
#if LOGFILE
					if (logfile) fprintf(logfile, "SECTOR ID FOUND\r\n");
#endif
					wd177x->StatusRegister |= WD177X_STATUS_CRC_ERROR;
				}

				wd177x->DataBytesRemaining = 6;
				wd177x->DataByteIndex = 0;
				wd177x->pData = &wd177x->DataBuffer[0];
			}


		}
		break;

		case 7:
		{
			/* read track/write track */
		
			if (Data & (1<<4))
			{
				/* write track */
			}


		}
		break;
	}
}


void	WD177x_WriteTrack(Z80_BYTE Data)
{
#if LOGFILE
	if (logfile) fprintf(logfile,"WRITE TRACK: %02x\r\n",Data);
#endif

	ExdosInterface.wd177x.TrackRegister = Data;
}

void	WD177x_WriteSector(Z80_BYTE Data)
{

#if LOGFILE
	if (logfile) fprintf(logfile,"WRITE SECTOR: %02x\r\n",Data);
#endif


	ExdosInterface.wd177x.SectorRegister = Data;

}

void	WD177x_WriteData(WD177X *wd177x,Z80_BYTE Data)
{
	wd177x->DataRegister = Data;

	if (!(wd177x->StatusRegister & WD177X_STATUS_DATA_REQUEST))
		return;

	if (wd177x->DataBytesRemaining!=0)
	{
		wd177x->pData[wd177x->DataByteIndex] = Data;

		wd177x->DataBytesRemaining--;
		wd177x->DataByteIndex++;
		wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
		wd177x->DataRegister = Data;

		if (wd177x->DataBytesRemaining==0)
		{
			wd177x->StatusRegister &= ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY | WD177X_STATUS_MOTOR_ON); //|WD177X_STATUS_BUSY);
			wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;

//			{
//				int SectorIndex = wd177x_GetSector(0);
//				int Side = (ExdosInterface.CardData_Write>>4) & 0x01;
//
//			//	DiskImage_PutSector(0,ExdosInterface.DriveStates[0].CurrentTrack,Side,SectorIndex,&wd177x->DataBuffer[0]);
//			}
		}

//		if (logfile) fprintf(logfile,"READ DATA: %02x\r\n",Data);

//		return Data;

	}







//	ExdosInterface.wd177x.DataRegister = Data;
//	wd177x->DataBytesRemaining = 0;
//	ExdosInterface.wd177x.StatusRegister &= ~WD177X_STATUS_DATA_REQUEST;
}


Z80_BYTE WD177x_ReadStatus(WD177X *wd177x)
{
	/* clear int request */
	wd177x->StatusRegister &= ~(WD177X_STATE_INTERRUPT_REQUEST);	// | WD177X_STATUS_BUSY);
//	wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON;
	
//	if (logfile) fprintf(logfile,"READ STATUS: %02x\r\n",wd177x->StatusRegister);

	return wd177x->StatusRegister;
}

Z80_BYTE WD177x_ReadTrack(void)
{
//	if (logfile) fprintf(logfile,"READ TRACK: %02x\r\n",ExdosInterface.wd177x.TrackRegister);

	return ExdosInterface.wd177x.TrackRegister;
}

Z80_BYTE WD177x_ReadSector(void)
{
//	if (logfile) fprintf(logfile,"READ SECTOR: %02x\r\n",ExdosInterface.wd177x.SectorRegister);

	return ExdosInterface.wd177x.SectorRegister;
}

Z80_BYTE WD177x_ReadData(WD177X *wd177x)
{
	if (wd177x->DataBytesRemaining!=0)
	{
		unsigned char Data;

		Data = wd177x->pData[wd177x->DataByteIndex];

		wd177x->DataBytesRemaining--;
		wd177x->DataByteIndex++;
		wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
		wd177x->DataRegister = Data;

		if (wd177x->DataBytesRemaining==0)
		{
			wd177x->StatusRegister &= ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY | WD177X_STATUS_MOTOR_ON); //|WD177X_STATUS_BUSY);
			wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
		}

//		if (logfile) fprintf(logfile,"READ DATA: %02x\r\n",Data);

		return Data;

	}
//	else
//	{
////		wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
//
//		
//		if (logfile) fprintf(logfile,"READ DATA: %02x\r\n",wd177x->DataRegister);
//
		return wd177x->DataRegister;
//	}
}






/* I/O out */
void	Z80_DoOut(Z80_WORD Port, Z80_BYTE Data)
{
	int PortLower = Port & 0x0ff;
	
	if ((PortLower>=0x080) && (PortLower<=0x08f))
	{
		Nick_Write(PortLower-0x080, Data);
		return;
	}


	if ((PortLower>=0x0a0) && (PortLower<=0x0bf))
	{
		Dave_Write(PortLower-0x0a0, Data);
		return;
	}

	if ((PortLower>=0x010) && (PortLower<=0x017))
	{
		switch ((PortLower-0x010) & 0x03)
		{
			case 0:
			{
				WD177x_WriteCommand(&ExdosInterface.wd177x,Data);
			}
			break;

			case 1:
			{
				WD177x_WriteTrack(Data);
			}
			break;

			case 2:
			{
				WD177x_WriteSector(Data);
			}
			break;

			case 3:
			{
				WD177x_WriteData(&ExdosInterface.wd177x,Data);
			}
			break;
		}

		return;
	}

	if ((PortLower==0x018) || (PortLower==0x01c))
	{
		ExdosCardWrite(Data);
		return;
	}

	if (PortLower==0x020)
		return;
#if 0
	/* cmos/rtc clock hardware by zoltan */
	if (PortLower==0x07e)
	{
		CMOS_SelectRegister(Data);
	}

	if (PortLower==0x07f)
	{
		CMOS_WriteData(Data);
	}
#endif
}

/* I/O in */
Z80_BYTE        Z80_DoIn(Z80_WORD Port)
{
	int PortLower = Port & 0x0ff;

	if ((PortLower>=0x0a0) && (PortLower<=0x0bf))
	{
		return Dave_Read(PortLower-0x0a0);
	}

	if ((PortLower>=0x010) && (PortLower<=0x017))
	{
		switch ((PortLower-0x010) & 0x03)
		{
			case 0:
			{
				return WD177x_ReadStatus(&ExdosInterface.wd177x);
			}
			break;

			case 1:
			{
	 			return WD177x_ReadTrack();
			}
			break;

			case 2:
			{
				return WD177x_ReadSector();
			}
			break;

			case 3:
			{
				return WD177x_ReadData(&ExdosInterface.wd177x);
			}
			break;
		}
	}



	if ((PortLower==0x018) || (PortLower==0x01c))
	{
		return ExdosCardRead();
	}
#if 0
	/* cmos/rtc read register */
	if (PortLower==0x07f)
	{
		return CMOS_ReadData();
	}
#endif
	return 0x0ff;
}

typedef struct EP_ROM
{
	unsigned long MemoryType;
	// address of data
	unsigned char *pData;
	// length
	unsigned long Length;
	// starting page
	unsigned long EP_Page;
} EP_ROM;

static EP_ROM	RomsLoaded[256];
static unsigned long NumRomsLoaded;


void	ROM_Load(unsigned char *Filename, int EP_Page)
{
	unsigned char *RomAddr;
	unsigned long RomLength;

	Host_LoadFile(Filename, 	&RomAddr, &RomLength);

	if ((RomAddr!=NULL) && (RomLength!=0))
	{
		EP_ROM *pRom;
		int NumPages = (RomLength+16383)>>14;
		int RomSize = (NumPages<<14);

		pRom = &RomsLoaded[NumRomsLoaded];
		NumRomsLoaded++;

		// allocate enough space for rom - allocate in 16k sizes.
		pRom->pData = malloc(RomSize);

		if (pRom->pData!=NULL)
		{
			int i;

			// copy data into rom space...
			memcpy(pRom->pData, RomAddr, RomLength);
		
			// length of rom is size of data we allocated
			pRom->Length = RomLength;
		
			// set starting page
			pRom->EP_Page = EP_Page;

			for (i=0; i<NumPages; i++)
			{
				// setup EP read pages so rom is accessible
				Enterprise_ReadPages[EP_Page + i] = pRom->pData + (i<<14);
			}
		}

	}

	if (RomAddr!=NULL)
		free(RomAddr);
}

void	ROM_Initialise()
{
	int i;

	for (i=0; i<256; i++)
	{
		RomsLoaded[i].pData = NULL;
	}
	NumRomsLoaded = 0;
}

void	ROM_Finish()
{
	int i;

	for (i=0; i<256; i++)
	{
		if (RomsLoaded[i].pData!=NULL)
		{
			free(RomsLoaded[i].pData);
			RomsLoaded[i].pData = NULL;
		}
	}
	NumRomsLoaded = 0;
}


void	LoadRoms()
{
	//Sample_Load("e:\\mess\\roms\\ep128\\tape.voc");

#ifdef ZOLTAN
	ROM_Load("exos23.rom",0x000);
	ROM_Load("cyrus.rom",0x010);
	ROM_Load("hea.rom",0x011);
	ROM_Load("texdos.rom",0x020);
	ROM_Load("epdos17.rom",0x022);
	ROM_Load("asmen15.rom",0x024);
	ROM_Load("fenas12.rom",0x026);
	ROM_Load("pgd&pgc.rom",0x028);
	ROM_Load("pgmemo.rom",0x029);
	ROM_Load("tpt.rom",0x02a);
	ROM_Load("heass.rom",0x02c);
	ROM_Load("hun.rom",0x02e);
	ROM_Load("zt18.rom",0x030);
	ROM_Load("edcw.rom",0x026);
#else

//	ROM_Load("exos23.rom",0x000);
	ROM_Load("exos21.rom",0x000);
	ROM_Load("basic.rom",0x004);
//	ROM_Load("exdos.rom",0x020);
//	ROM_Load("hea.rom",0x011);
//	ROM_Load("epdos17.rom",0x022);
//	ROM_Load("asmen15.rom",0x024);
//	ROM_Load("fenas12.rom",0x026);
//	ROM_Load("pgd&pgc.rom",0x028);
//	ROM_Load("pgmemo.rom",0x029);
//	ROM_Load("tpt.rom",0x02a);
//	ROM_Load("heass.rom",0x02c);
//	ROM_Load("hun.rom",0x02e);
//	ROM_Load("zt18.rom",0x030);
//	ROM_Load("edcw.rom",0x026);
	//	ROM_Load("texdos.rom",0x020);
//	ROM_Load("epdos17.rom",0x022);
	//	ROM_Load("graph.rom",0x028);
//	ROM_Load("venus.rom",0x02a);
//	ROM_Load("q3.rom",0x02c);
#endif
}



BOOL    Memory_Initialise()
{
	int i;

	/* 32k of NULL memory - 16k for null reads, 16k for null writes */
	Enterprise_Memory_NULL = malloc(32768);

	if (Enterprise_Memory_NULL!=NULL)
	{
		/* setup null read */
		Enterprise_Memory_Read_NULL = Enterprise_Memory_NULL;
		memset(Enterprise_Memory_Read_NULL, 0x0ff, 16384);
		
		/* setup null write */
		Enterprise_Memory_Write_NULL = Enterprise_Memory_NULL+16384;
	}

	/* initialise all memory for null read/write */
	for (i=0; i<256; i++)
	{
		Enterprise_ReadPages[i] = Enterprise_Memory_Read_NULL;
		Enterprise_WritePages[i] = Enterprise_Memory_Write_NULL;
		Enterprise_Page_Types[i] = MEMORY_TYPE_NULL;
	}

	MEMORY = malloc(64*1024);

	if (MEMORY!=NULL)
	{
		for (i=0; i<4; i++)
		{
			int EP_Page = 0x0fc + i;

			Enterprise_ReadPages[EP_Page] = 
				Enterprise_WritePages[EP_Page] = MEMORY + (i<<14);
			Enterprise_Page_Types[EP_Page] = MEMORY_TYPE_VIDEO_RAM;
		}
	}

	return TRUE;
}

void	Enterprise_SetRamPage(int EP_Page)
{
	unsigned char *pRamPage;

	/* set to ram if not set */
	if (Enterprise_Page_Types[EP_Page] == MEMORY_TYPE_NULL)
	{
		pRamPage = malloc(16384);

		if (pRamPage!=NULL)
		{
			Enterprise_ReadPages[EP_Page] = Enterprise_WritePages[EP_Page] = pRamPage;
			Enterprise_Page_Types[EP_Page] = MEMORY_TYPE_RAM;
		}
	}
}

char	SRAMFilename[12];

void	StoreSRAM(unsigned char EP_Page)
{
	unsigned char *pSRAMData = Enterprise_ReadPages[EP_Page];

	/* generate filename - e.g. 00-SRAM.RAM */
	sprintf(SRAMFilename,"%02x-SRAM.RAM",EP_Page);
	
	/* save file */
	Host_SaveFile(SRAMFilename, pSRAMData, 16384);
}

void	RestoreSRAM(unsigned char EP_Page)
{
	unsigned char *pSRAMData;
	unsigned long SRAMLength;
	unsigned char *pSRAMMemory;

	if (Enterprise_Page_Types[EP_Page] == MEMORY_TYPE_NULL)
	{
		
		/* generate SRAM filename */
		sprintf(SRAMFilename,"%02x-SRAM.RAM",EP_Page);

		/* attempt to load SRAM data */
		Host_LoadFile(SRAMFilename, &pSRAMData, &SRAMLength);

		/* malloc space for it */
		pSRAMMemory = malloc(16384);

		if (Enterprise_ReadPages[EP_Page]!=NULL)
		{
			/* setup read/write */
			Enterprise_ReadPages[EP_Page] = Enterprise_WritePages[EP_Page] = pSRAMMemory;
			Enterprise_Page_Types[EP_Page] = MEMORY_TYPE_SRAM;		

			memset(pSRAMMemory, 0, 16384);

			if (pSRAMData!=NULL)
			{
				/* found data */

				/* check file length */
				if (SRAMLength>16384)
				{
					/* copy at most 16384 bytes */
					memcpy(pSRAMMemory, pSRAMData, 16384);
				}
				else
				{
					/* copy all data from the file */
					memcpy(pSRAMMemory, pSRAMData, SRAMLength);
				}
				
				free(pSRAMData);

			}
		}
	}
}

unsigned char *EXOS_2_0_IDENT="EXOS 2.0";


void	Enterprise_PatchEXOS(unsigned char *pEXOSRom)
{

	short TapePatchAddress = 0;
	short ChecksumAdjust = 0;

	if ((pEXOSRom==NULL) || (pEXOSRom == Enterprise_Memory_Read_NULL))
		return;

	if (memcmp(pEXOSRom+0x0177, EXOS_2_0_IDENT, 8)==0)
	{
		/* patch for 2.0 */	
		TapePatchAddress = 0x069c8;

		ChecksumAdjust = ((0x08b27^0x0ffff)+1); //-0x8b27;

		TapeVar_FilenameBuffer = 0x0b25b;
		TapeVar_Buffer = 0x0b299;
		TapeVar_BytesRead = 0x0b295;
		TapeVar_BlockFlag = 0x0b29d;
		TapeVar_BlockType = 0x0b2a1;
	}
	else if (memcmp(pEXOSRom+0x017a, EXOS_2_0_IDENT, 7)==0)
	{
		/* patch for 2.1 or better */

		TapePatchAddress = 0x06a5f;

		ChecksumAdjust = 0x01075;

		TapeVar_FilenameBuffer = 0x0b292;
		TapeVar_Buffer = 0x0b2d1;
		TapeVar_BytesRead = 0x0b2cd;
		TapeVar_BlockFlag = 0x0b2d5; 
		TapeVar_BlockType = 0x0b2d6;
	}

	if (TapePatchAddress!=0)
	{
		pEXOSRom[TapePatchAddress] = 0x0ed;
		pEXOSRom[TapePatchAddress+1] = 0x0fe;
		pEXOSRom[TapePatchAddress+2] = 0x0c9;

		{
			unsigned short Checksum;

			/* read checksum */
			Checksum = (pEXOSRom[0x3ffe] & 0x0ff) |
						(pEXOSRom[0x03fff] & 0x0ff)<<8;

			/* adjust */
			Checksum += ChecksumAdjust;

			/* write back checksum */
			pEXOSRom[0x03ffe] = Checksum & 0x0ff;
			pEXOSRom[0x03fff] = (Checksum>>8) & 0x0ff;
		}
	}
}

void    Memory_Finish()
{
	int i;

	/* free SRAM data */
	for (i=0; i<256; i++)
	{
		/* free SRAM */
		if (Enterprise_Page_Types[i] == MEMORY_TYPE_SRAM)
		{
			/* store it */
			StoreSRAM(i);

			/* free it */
			free(Enterprise_ReadPages[i]);
		}
	
		/* free Ram */
		if (Enterprise_Page_Types[i] == MEMORY_TYPE_RAM)
		{
			free(Enterprise_ReadPages[i]);
		}
	}

	if (MEMORY!=NULL)
	{
		free(MEMORY);
		MEMORY = NULL;
	}
		
	if (Enterprise_Memory_NULL!=NULL)
	{
		free(Enterprise_Memory_NULL);
		Enterprise_Memory_NULL = NULL;
		Enterprise_Memory_Read_NULL = NULL;
		Enterprise_Memory_Write_NULL = NULL;
	}
}


void	Memory_Setup()
{
	LoadConfigFile("enter.cfg");
#if 0
	LoadRoms();
#if 0
#ifdef ZOLTAN
	RestoreSRAM(0x004);
	RestoreSRAM(0x005);
	RestoreSRAM(0x006);
	RestoreSRAM(0x007);

	RestoreSRAM(0x080);
	RestoreSRAM(0x081);
	RestoreSRAM(0x082);
	RestoreSRAM(0x083);
#endif
#endif

//	Enterprise_SetRamPage(0x0ec);
//	Enterprise_SetRamPage(0x0ed);
//	Enterprise_SetRamPage(0x0ee);
//	Enterprise_SetRamPage(0x0ef);
//	Enterprise_SetRamPage(0x0f0);
//	Enterprise_SetRamPage(0x0f1);
//	Enterprise_SetRamPage(0x0f2);
//	Enterprise_SetRamPage(0x0f3);
//	Enterprise_SetRamPage(0x0f4);
//	Enterprise_SetRamPage(0x0f5);
//	Enterprise_SetRamPage(0x0f6);
//	Enterprise_SetRamPage(0x0f7);
	Enterprise_SetRamPage(0x0f8);
	Enterprise_SetRamPage(0x0f9);
	Enterprise_SetRamPage(0x0fa);
	Enterprise_SetRamPage(0x0fb);
#endif

}



extern unsigned char *pAudioBuffer;
extern unsigned int AudioBufferSize;

void	Enterprise_UpdateAudio()
{
//	if (AudioActiveFlag)
//	{
//		Digiblaster_EndFrame();
//	}

	{
		int CPCNopCount = OpCount;
		int NopsReached = OpCount;

//		if (AudioActiveFlag)
		{
			/* update sound buffer with events in audio events buffer */
			NopsReached = AudioEvent_TraverseAudioEventsAndBuildSampleData(CPCNopCount,19968);
		}

		/* restart buffer ready to fill with new data */
		AudioEvent_RestartEventBuffer(NopsReached);
	}
}


void	Enterprise_Initialise()
{
#if LOGFILE
	logfile = fopen("logfile.txt","wb");
#endif
	Memory_Initialise();

	Nick_Init(64);

	Z80_Init();

	Z80_SetUserAckInterruptFunction(Enterprise_AckInterrupt);
	
	//Dave_Init();

	Enterprise_ResetControllers();

	Render_Initialise();

	ROM_Initialise();

	Memory_Setup();

	Enterprise_PatchEXOS(Enterprise_ReadPages[0]);

	   AudioEvent_Initialise();


	if (Host_AudioPlaybackPossible())
		{
			/* yes it is */
			SOUND_PLAYBACK_FORMAT *pSoundPlaybackFormat;

			/* get playback format */
			pSoundPlaybackFormat = Host_GetSoundPlaybackFormat();

			if (pSoundPlaybackFormat!=NULL)
			{
				/* audio was previously disabled, but we want it to be enabled */
				AudioEvent_SetFormat(pSoundPlaybackFormat->Frequency, pSoundPlaybackFormat->BitsPerSample, pSoundPlaybackFormat->NumberOfChannels);
	
				/* playing audio */
//				AudioActiveFlag = TRUE;
			}
		}

	Exdos_Initialise();

	Enterprise_Reset();

}

void	Enterprise_Finish()
{
	Memory_Finish();

	Render_Finish();

#if LOGFILE
	fclose(logfile);
#endif

	ROM_Finish();

	DiskImage_Finish();

	AudioEvent_Finish();
}


void	ConvertToMSDOSFilename(char *Filename)
{
	int c;
	int f;

	// indicator for full-stop not found
	f = -1;

	// search for full-stop
	for (c=0; c<strlen(Filename); c++)
	{
		// is it  full stop?
		if (Filename[c]=='.')
		{
			f = c;
			break;
		}
	}

	if (f==-1)
	{
		// no full stop found

		// is file over 8 chars long?
		if (strlen(Filename)>8)
		{
			// cap it off at 8 chars long
			Filename[8]='\0';
		}

	}
	else
	{
		// filename has a extension starting at char
		// specified

		int CharsBeforeExtension; 
		int CharsAfterExtension;

		// get chars after extension
		CharsAfterExtension = (strlen(Filename)-1)-f;
		// get chars before extension
		CharsBeforeExtension = f;
		
		// lock them to valid values
		if (CharsBeforeExtension>8)
		{
			CharsBeforeExtension = 8;
		}

		if (CharsAfterExtension>3)
		{
			CharsAfterExtension = 3;
		}

		// copy extension back including terminating NULL
		if (f!=CharsBeforeExtension)
		{
			// copy extension back to make string. Copy terminating
			// NULL as well
			for (c=f; c<f+CharsAfterExtension+1; c++)
			{
				Filename[CharsBeforeExtension + (c-f)] = Filename[c];
			}
		}

		// put final NULL on to stop extension from exceeding 3 chars
		Filename[CharsBeforeExtension + CharsAfterExtension + 1]='\0';

	}
}




char	Filename[30];	//="START\0            ";			// default filename and header
char	Header[30];	//="\0\5START                       ";


FILE	*CasetteFile=NULL;
int		FileSize=0;

void Z80_Patch(Z80_REGISTERS *R)
{
	Z80_WORD	Buffer,i,j;

	R->AF.B.l|=Z80_CARRY_FLAG;							// set carry flag (no errors)
	Buffer=R->IX.W-1;							// address of read buffer

	Z80_WR_MEM((TapeVar_Buffer),Buffer);						// save buffer address
	Z80_WR_MEM((TapeVar_Buffer+1),Buffer>>8);

	if(CasetteFile==NULL)
	{
		Buffer=TapeVar_FilenameBuffer;	//0xB25B;							// address of filename in system

		if(Z80_RD_MEM(Buffer))
		{					// if a filename is given
			j=Z80_RD_MEM(Buffer);
			Buffer++;
			Header[0] = '\0';

			Header[1]=j;
			for(i=0; i<j; i++)
			{
				Filename[i]=Z80_RD_MEM(Buffer);
				Header[i+2]=Z80_RD_MEM(Buffer);
				Buffer++;
			}
			Filename[i]=0;						// terminate it
		}

		// convert to MSDOS
		ConvertToMSDOSFilename(&Filename[0]);

		CasetteFile=fopen(Filename,"rb");
		if(CasetteFile==NULL)
		{
			// failed load.

				R->AF.B.l&=~Z80_CARRY_FLAG;					// error, file not found!
				return;
		}
		fseek(CasetteFile,0,SEEK_END);
		FileSize=ftell(CasetteFile);			// get length of file
		fseek(CasetteFile,0,SEEK_SET);
		
		Z80_WR_MEM(TapeVar_BlockType,255);					// header block read
		Z80_WR_MEM(TapeVar_BytesRead,0);
		Z80_WR_MEM(TapeVar_BytesRead,0);
		Buffer=R->IX.W;							// address of read buffer
		for(i=0; i<30; i++)
		{
			Buffer--;
			Z80_WR_MEM(Buffer,Header[i]);
		}
		Z80_WR_MEM(TapeVar_BlockFlag,0);						// more blocks available
	}
	else
	{
		if(FileSize<=4096)
		{
			i=FileSize;
			FileSize=0;
			Z80_WR_MEM(TapeVar_BlockFlag,255);				// no more blocks available
		}
		else
		{
			i=4096;
			FileSize-=4096;
			Z80_WR_MEM(TapeVar_BlockFlag,0);					// more blocks available
		}
		Z80_WR_MEM(TapeVar_BlockType,0);						// data block read
		Z80_WR_MEM(TapeVar_BytesRead,i);						// bytes read
		Z80_WR_MEM((TapeVar_BytesRead+1),i>>8);

		do
		{
			char ch;

			ch = fgetc(CasetteFile);

			Z80_WR_MEM(Buffer,ch);
			Buffer--;
			i--;
		}
		while(i!=0);

		if(FileSize==0)
		{
			fclose(CasetteFile);
			CasetteFile=NULL;
		}
	}
}

