#ifndef __WAV_RECORDING_HEADER_INCLUDED__
#define __WAV_RECORDING_HEADER_INCLUDED__



void	WavOutput_Init(char *TempFilename);
void	WavOutput_Finish(void);
void	WavOutput_InitialiseFormat(int NoOfChannels, int SampleRate, int BitsPerSample);
void	WavOutput_StartRecording(char *Wav);
void	WavOutput_StopRecording(void);
void	WavOutput_WriteBlock(char *, unsigned long);


#include "sampload.h"

BOOL	WAV_Validate(char *);
void	WAV_Open(SAMPLE_AUDIO_STREAM *);

#endif
