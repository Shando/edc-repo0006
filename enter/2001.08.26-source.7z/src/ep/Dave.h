/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef __DAVE_SOUND_CHIP_HEADER_INCLUDED__
#define __DAVE_SOUND_CHIP_HEADER_INCLUDED__

/******************************
DAVE SOUND CHIP
*******************************/

#define DAVE_1HZ_REFERENCE	1
#define DAVE_1KHZ_REFERENCE	1000
#define DAVE_50HZ_REFERENCE 50

/* Nick master clock - 1Mhz */
#define DAVE_CHIP_CLOCK		1000000
#define DAVE_TONE_CLOCK		125000
#define DAVE_1HZ_CLOCK_RELOAD	998400	//(DAVE_TONE_CLOCK/DAVE_1HZ_REFERENCE)
#define DAVE_1KHZ_CLOCK_RELOAD	998	//(DAVE_TONE_CLOCK/DAVE_1KHZ_REFERENCE)
#define DAVE_50HZ_CLOCK_RELOAD 19968	//(DAVE_TONE_CLOCK/DAVE_50HZ_REFERENCE)

enum
{
	DAVE_INT_SELECTABLE,
	DAVE_INT_1HZ,
} DAVE_INT_ID;

enum
{
	DAVE_INT_COUNTER_1HZ = 0,
	DAVE_INT_COUNTER_50HZ,
	DAVE_INT_COUNTER_1KHZ,
	DAVE_INT_COUNTER_TONE_CHANNEL_0,
	DAVE_INT_COUNTER_TONE_CHANNEL_1
} DAVE_INT_COUNTER_ID; 

void	Dave_Reset(void);

typedef struct DAVE
{
	unsigned char Regs[32];
//	unsigned char RegsWrite[32];

	/* int latches */
	unsigned char int_latch;
	/* int enables */
	unsigned char int_enable;
	/* int inputs */
	unsigned char int_input;

	/* square wave outputs from Tone Channel 0, Tone Channel 1, Tone Channel 2 and Noise Channel */
//	unsigned char	Outputs[4];

	/* outputs are adjusted before volume mixing (left channel desribed here): 
		FinalOutput = Outputs[ChannelIndex] & LeftOutputs_And[ChannelIndex] | LeftOutputs_Or[ChannelIndex]; 
	*/
	unsigned long	ChannelOutputs[4];
//	unsigned char	LeftOutputs_And[4];
//	unsigned char	LeftOutputs_Or[4];

//	unsigned char	RightOutputs_And[4];
//	unsigned char	RightOutputs_Or[4];

	signed long	InterruptCounters[5];
	signed long	InterruptCounterReload[5];
	//unsigned long	InterruptCounterPreviousOutputs;
	unsigned long	InterruptCounterOutputs;
//	/* fixed counter for 1khz interrupt */
//	unsigned long	 OneHzCounter;
//	/* internal counters for programmable interrupt */
//	unsigned long	FiftyHzCounter;
//	unsigned long	OneKHzCounter;
//	unsigned long	ToneChannel0Counter;
//	unsigned long	ToneChannel1Counter;

	unsigned long	ChannelCounters[4];

	unsigned long	CyclesToNextInterrupt;

//	int fiftyhertz;
//	int onehz;
} DAVE;

void	Dave_Write(int RegIndex, int Data);
int		Dave_Read(int RegIndex);


void	Enterprise_InitialiseToneUpdates(unsigned long);
void	DavePlay_UpdateState(unsigned long Reg, unsigned long Data);
void	Dave_UpdateInterrupts(unsigned long CyclesPassed);
void	Dave_Int1_SetState(int State);

#endif
