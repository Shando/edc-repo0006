/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef __EP_HEADER_INCLUDED__
#define __EP_HEADER_INCLUDED__

/* there are 64us per line, although in reality
   about 50 are visible. */
/* there are 312 lines per screen, although in reality
   about 35*8 are visible */
#define ENTERPRISE_SCREEN_WIDTH	(50*16)
#define ENTERPRISE_SCREEN_HEIGHT	(35*8)

/* Enterprise bank allocations */
#define MEM_EXOS_0		0
#define	MEM_EXOS_1		1
#define MEM_CART_0		4
#define MEM_CART_1		5
#define MEM_CART_2		6
#define MEM_CART_3		7
//#define MEM_EXDOS_0		0x020
//#define	MEM_EXDOS_1		0x021
/* basic 64k ram */
#define MEM_RAM_0               ((unsigned int)0x0fc)
#define MEM_RAM_1               ((unsigned int)0x0fd)
#define MEM_RAM_2               ((unsigned int)0x0fe)
#define MEM_RAM_3               ((unsigned int)0x0ff)
/* additional 64k ram */
#define MEM_RAM_4               ((unsigned int)0x0f8)
#define MEM_RAM_5               ((unsigned int)0x0f9)
#define MEM_RAM_6               ((unsigned int)0x0fa)
#define MEM_RAM_7               ((unsigned int)0x0fb)

#define MEMSIZE	0x020000

void	Enterprise_Reset(void);
void	Enterprise_SetMemoryPage(int, int);
int		Enterprise_GetKeyboardLine(int);
void	Enterprise_SetControl(int);
void	Enterprise_ClearControl(int);
unsigned char Enterprise_ReadExternalJoystick(int PortB5);
void	Enterprise_ResetControllers(void);
void	Enterprise_PatchEXOS(unsigned char *pEXOSRom);

typedef enum
{
	/* row 0, bit 0-bit 7*/
	EP_KEY_N = 0,
	EP_KEY_BACKSLASH,
	EP_KEY_B,
	EP_KEY_C,
	EP_KEY_V,
	EP_KEY_X,
	EP_KEY_Z,
	EP_KEY_LSHIFT,
	/* row 1 */
	EP_KEY_H,
	EP_KEY_LOCK,
	EP_KEY_G,
	EP_KEY_D,
	EP_KEY_F,
	EP_KEY_S,
	EP_KEY_A,
	EP_KEY_CONTROL,
	/* row 2 */
	EP_KEY_U,
	EP_KEY_Q,
	EP_KEY_Y,
	EP_KEY_R,
	EP_KEY_T,
	EP_KEY_E,
	EP_KEY_W,
	EP_KEY_TAB,
	/* row 3 */
	EP_KEY_7,
	EP_KEY_1,	
	EP_KEY_6,
	EP_KEY_4,
	EP_KEY_5,
	EP_KEY_3,
	EP_KEY_2,
	EP_KEY_ESC,
	/* row 4 */
	EP_KEY_F4,
	EP_KEY_F8,
	EP_KEY_F3,
	EP_KEY_F6,
	EP_KEY_F5,
	EP_KEY_F7,
	EP_KEY_F2,
	EP_KEY_F1,
	/* row 5 */
	EP_KEY_8,
	EP_KEY_NC3,
	EP_KEY_9,
	EP_KEY_MINUS,
	EP_KEY_0,
	EP_KEY_HAT,
	EP_KEY_ERASE,
	EP_KEY_NC4,
	/* ROW 6 */
	EP_KEY_J,
	EP_KEY_NC5,
	EP_KEY_K,
	EP_KEY_SEMICOLON,
	EP_KEY_L,
	EP_KEY_COLON,
	EP_KEY_CLOSE_SQUARE_BRACKET,
	EP_KEY_NC6,
	/* row 7 */
	EP_KEY_STOP,
	EP_KEY_JOY_DOWN,
	EP_KEY_JOY_RIGHT,
	EP_KEY_JOY_UP,
	EP_KEY_HOLD,
	EP_KEY_JOY_LEFT,
	EP_KEY_ENTER,
	EP_KEY_ALT,
	/* row 8 */
	EP_KEY_M,
	EP_KEY_DEL,
	EP_KEY_COMMA,
	EP_KEY_FORWARD_SLASH,
	EP_KEY_DOT,
	EP_KEY_RSHIFT,
	EP_KEY_SPACE,
	EP_KEY_INSERT,
	/* row 9 */
	EP_KEY_I,
	EP_KEY_NC7,
	EP_KEY_O,
	EP_KEY_AT,
	EP_KEY_P,
	EP_KEY_OPEN_SQUARE_BRACKET,
	EP_KEY_NC8,
	EP_KEY_NC9,

	EP_KEY_NULL,

	/* external joystick 1 */
	EP_KEY_EXTERNAL_JOYSTICK1_RIGHT,
	EP_KEY_EXTERNAL_JOYSTICK1_LEFT,
	EP_KEY_EXTERNAL_JOYSTICK1_DOWN,
	EP_KEY_EXTERNAL_JOYSTICK1_UP,
	EP_KEY_EXTERNAL_JOYSTICK1_FIRE,
	EP_KEY_EXTERNAL_JOYSTICK1_NC1,
	EP_KEY_EXTERNAL_JOYSTICK1_NC2,
	EP_KEY_EXTERNAL_JOYSTICK1_NC3,
	/* external joystick 2 */
	EP_KEY_EXTERNAL_JOYSTICK2_RIGHT,
	EP_KEY_EXTERNAL_JOYSTICK2_LEFT,
	EP_KEY_EXTERNAL_JOYSTICK2_DOWN,
	EP_KEY_EXTERNAL_JOYSTICK2_UP,
	EP_KEY_EXTERNAL_JOYSTICK2_FIRE,
	EP_KEY_EXTERNAL_JOYSTICK2_NC1,
	EP_KEY_EXTERNAL_JOYSTICK2_NC2,
	EP_KEY_EXTERNAL_JOYSTICK2_NC3,


}	EP_KEY_ID;
/*
enum
{
	EP_EXT1_JOY_RIGHT,
	EP_EXT1_JOY_LEFT,
	EP_EXT1_JOY_DOWN,
	EP_EXT1_JOY_UP,
	EP_EXT1_JOY_


	EP_JOY_ID;
}
*/

typedef struct KEYBOARD_MAP
{
	unsigned long	Line;					/* keyboard row */
	unsigned long	AndMask;				/* And mask to set key pressed */
} KEYBOARD_MAP;
	
typedef enum
{
	MEMORY_TYPE_NULL = 0,
	MEMORY_TYPE_VIDEO_RAM,
	MEMORY_TYPE_RAM,
	MEMORY_TYPE_ROM,
	MEMORY_TYPE_SRAM
} EP_PAGE_TYPE;



/***** WD177x ******/
typedef struct WD177X
{
	/* internal state */
	unsigned char State;

	unsigned char StatusRegister;
	unsigned char TrackRegister;
	unsigned char SectorRegister;
	unsigned char CommandRegister;
	unsigned char DataRegister;

	unsigned long	DataBytesRemaining;
	unsigned long	DataByteIndex;
	unsigned char	*pData;

	unsigned char	DataBuffer[2048];
} WD177X;



#define DRIVE_FLAGS_IN_USE		(1<<7)
#define DRIVE_FLAGS_DISK_CHANGE (1<<6)
#define DRIVE_FLAGS_TRACK0		(1<<5)
#define DRIVE_FLAGS_DISK_PRESENT (1<<4)

typedef struct DRIVE_STATE
{
	/* bit 6 is disk change */
	unsigned char DriveBits;

	int CurrentTrack;
	unsigned char CurrentIDIndex;
} DRIVE_STATE;

typedef struct EXDOS_INTERFACE
{
	unsigned char CardData_Write;
	unsigned long CurrentDrive;
	unsigned long CurrentSide;

	DRIVE_STATE	DriveStates[4];
	WD177X	wd177x;
} EXDOS_INTERFACE;


/* set if stepping in towards track 79, clear if stepping out towards track 0 */
#define WD177X_STATE_STEP_DIRECTION (1<<0)
#define WD177X_STATE_INTERRUPT_REQUEST (1<<1)

#define WD177X_STATUS_BUSY	(1<<0)
#define WD177X_STATUS_DATA_REQUEST (1<<1)
#define WD177X_STATUS_LOST_DATA_OR_TRACK_0 (1<<2)
#define WD177X_STATUS_CRC_ERROR (1<<3)
#define WD177X_STATUS_RECORD_NOT_FOUND (1<<4)
#define WD177X_STATUS_RECORD_TYPE_SPIN_UP (1<<5)
#define WD177X_STATUS_WRITE_PROTECT	(1<<6)
#define WD177X_STATUS_MOTOR_ON (1<<7)


/* Type I commands status */
#define STA_1_BUSY      0x01    /* controller is busy */
#define STA_1_IPL       0x02    /* index pulse */
#define STA_1_TRACK0    0x04    /* track 0 detected */
#define STA_1_CRC_ERR   0x08    /* CRC error */
#define STA_1_SEEK_ERR  0x10    /* seek error */
#define STA_1_HD_LOADED 0x20    /* head loaded */
#define STA_1_WRITE_PRO 0x40    /* floppy is write protected */
#define STA_1_NOT_READY 0x80    /* controller not ready */

/* Type II commands status */
#define STA_2_BUSY      0x01    
#define STA_2_DRQ       0x02
#define STA_2_LOST_DAT  0x04
#define STA_2_CRC_ERR   0x08
#define STA_2_REC_N_FND 0x10
#define STA_2_REC_TYPE  0x20
#define STA_2_WRITE_PRO 0x40
#define STA_2_NOT_READY 0x80

void	Enterprise_SetRamPage(int EP_Page);
void	RestoreSRAM(unsigned char EP_Page);
void	ROM_Load(unsigned char *Filename, int EP_Page);
void	Enterprise_Initialise(void);
void	Enterprise_Finish(void);
void Exdos_InsertDisk(int Drive);
void Exdos_RemoveDisk(int Drive);
void	Enterprise_UpdateAudio();

#endif