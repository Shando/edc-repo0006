#ifndef __CONFIG_HEADER_FILE_INCLUDED__
#define __CONFIG_HEADER_FILE_INCLUDED__

void  LoadConfigFile(char *Filename);

#endif