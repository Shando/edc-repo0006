/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
/* Rendering Functions */

//#include "cpcdefs.h"
#include "cpcglob.h"
//#include "cpc.h"
//#include "render.h"
#include "host.h"
#include "packedimage.h"
#include "nick.h"
#include <memory.h>
#include <stdlib.h>
#include <stdio.h>
/* if true, then memory has been setup to be filled with CPC graphics data, otherwise
no, so don't attempt to render anything */
static BOOL Renderer_Active = FALSE;
int     BytesPerPixel;
static int ScanLines = 1;
int FillScanLines = 0;
static int PIXEL_STEP;
int PIXEL_STEP_SHIFT;
static int Render_CPCRenderHeight, Render_CPCRenderWidth;
static int Render_CPCXOffset, Render_CPCYOffset;


/* start of screen buffer */
static unsigned char    *pScreenBase = NULL;
/* number of bytes in screen buffer width */
static unsigned long    ScreenPitch = 0;

static unsigned char *pScreenLine;

/* current graphics format */
static GRAPHICS_FORMAT  CurrentGraphicsFormat;

static int Render_ScreenXOffset, Render_ScreenYOffset;

/* **** RGB stuff **** */

/* each element contains colours packed into destination image format */
unsigned long    ConvertedColourTable[256];


BOOL Render_IsPalettedMode(void)
{
	if (
		(CurrentGraphicsFormat.Red.Mask==0) &&
		(CurrentGraphicsFormat.Green.Mask==0) &&
		(CurrentGraphicsFormat.Blue.Mask==0))
	{
		return TRUE;
	}
	
	return FALSE;
}


void Render_InitialiseColours(void)
{
	int i;

	if (Render_IsPalettedMode())
	{
		/* paletted graphics mode */
		for (i=0; i<256; i++)
		{
			unsigned char r,g,b;

			r = (NICK_GET_RED8(i);	
			g = (NICK_GET_GREEN8(i);	
			b = (NICK_GET_BLUE8(i);	

			/* set palette entry */
			Host_SetPaletteEntry(i, r,g,b);

			ConvertedColourTable[i] = i;
		}
	}
	else
	{
		/* R,G,B graphics mode */			
		for (i=0; i<256; i++)
		{
			unsigned long r,g,b;
			unsigned long PackedColourData;

			r = (NICK_GET_RED8(i);	
			g = (NICK_GET_GREEN8(i);	
			b = (NICK_GET_BLUE8(i);	

			/* store R,G,B colour into destination format */
			PackedColourData = PackRGBIntoDestinationImageFormat(r, g, b, &CurrentGraphicsFormat);

			/* store in converted table */
			ConvertedColourTable[i] = PackedColourData;
		}
	}
}

void	Render_Initialise()
{
	pScreenBase = NULL;
	ScreenPitch = 0;
	Renderer_Active = FALSE;

}

void    Render_Finish()
{
        if (pScreenBase!=NULL)
        {
                free(pScreenBase);
        }
}

void	Render_SetBlackScanlines(BOOL	State)
{
	if (State)
	{
		if (pScreenBase!=NULL)
		{
			memset(pScreenBase, 0, ScreenPitch*Render_CPCRenderHeight);
		}

	}
	FillScanLines = !State;
}



void    Render_DumpScreen4(void)
{
        unsigned char   *pScreen;
        unsigned char   *pScr;
        unsigned char   *pSurface;
        unsigned char   *pSurf;
        int i;
        int BytesPerPixel = (CurrentGraphicsFormat.BPP>>3);
        int Pitch;
        
        /* lock surface */
     if (Host_LockGraphicsBuffer())  
        {
                GRAPHICS_BUFFER_INFO *pGraphicsBufferInfo = Host_GetGraphicsBufferInfo();
                int XOffset;
                int XLength;
                int RenderXOffset;

                Pitch = pGraphicsBufferInfo->Pitch;     //SurfaceDesc.lPitch;

                /* source address */
                pScreen = pScreenBase;
                /* dest address */
                pSurface = (unsigned char *)pGraphicsBufferInfo->pSurface;      //SurfaceDesc.lpSurface;

                // if scanlines is true, this must be done before the pitch is adjusted.
                pSurface += Render_ScreenYOffset*Pitch;

                if (ScanLines!=0)
                {
                        Pitch = Pitch<<1;
                }

                pScr = pScreen;
                pSurf = pSurface;

                pScr += Render_CPCYOffset*ScreenPitch;
                
                XOffset = Render_CPCXOffset * BytesPerPixel;
                XLength = Render_CPCRenderWidth * BytesPerPixel;
                RenderXOffset = Render_ScreenXOffset*BytesPerPixel;
                        
                for (i=0; i<Render_CPCRenderHeight; i++)
                {
                        pSurface = pSurf + RenderXOffset;
                        pScreen = pScr + XOffset;

						/*
						{
							unsigned long l;
							unsigned char *pSrcAddr = pScreen;
							unsigned char *pDestAddr = pSurface;
			
							for (l=0; l<XLength>>2; l++)
							{
								((unsigned long *)pDestAddr)[0] = ((unsigned long *)pSrcAddr)[0];
								((unsigned long *)pDestAddr)++;
								((unsigned long *)pSrcAddr)++;
							}

							for (l=0; l<(XLength&3); l++)
							{
								pDestAddr[0] = pSrcAddr[0];
								pDestAddr++;
								pSrcAddr++;
							}
						}
						*/
                        memcpy(pSurface, pScreen, XLength);

						if (FillScanLines)
						{
							pSurface+=Pitch>>1;
							memcpy(pSurface, pScreen, XLength);
						}

                        pScr+=ScreenPitch;

                        pSurf+=Pitch;
                }

                /* unlock surface */
                Host_UnlockGraphicsBuffer();    

                /* flip screen (in windowed mode performs a blit) */
                Host_SwapGraphicsBuffers();     

        }
}

void    Render_DumpDisplay()
{
       Render_DumpScreen4();

//		Host_SwapGraphicsBuffers();
}


//BOOL Render_Lock()
//{
//	return Host_LockGraphicsBuffer();
//}

//void	Render_Unlock()
//{
//	Host_UnlockGraphicsBuffer();
//}


unsigned char *Render_GetLine(int LineIndex)
{
#if 0
	int Pitch;
    unsigned char *pSurface;
	GRAPHICS_BUFFER_INFO *pGraphicsBufferInfo = Host_GetGraphicsBufferInfo();

    Pitch = (pGraphicsBufferInfo->Pitch<<1);     

    /* dest address */
    pSurface = (unsigned char *)pGraphicsBufferInfo->pSurface;      //SurfaceDesc.lpSurface;

	return pSurface + (Pitch*LineIndex);
#endif
		return pScreenBase + (ScreenPitch*LineIndex);
}


#define BITS_PER_LINE	50*16
#define LINES_PER_SCREEN 280	
#define X_CRTC_CHAR_OFFSET 0
#define Y_CRTC_LINE_OFFSET 0
#define X_CRTC_CHAR_WIDTH 50
#define Y_CRTC_LINE_HEIGHT 280


/* ScreenResX, ScreenResY define rendering window dimensions.
 In FullScreen mode these are defined by the selected screen resolution.
 In Windowed mode these can be changed to allow for full-display */
BOOL InitialiseRender(int ScreenResX, int ScreenResY, int BPP)
{
    int ScreenWidth, ScreenHeight;

	Nick_Init(ScreenResX);

    if (pScreenBase!=NULL)
    {
            free(pScreenBase);
            pScreenBase = NULL;
			ScreenPitch = 0;
	}


    ScreenWidth = BITS_PER_LINE;    //(X_CRTC_CHAR_WIDTH<<(1+3));
    ScreenHeight = LINES_PER_SCREEN+1;      //(Y_CRTC_LINE_HEIGHT);

    ScreenPitch = (unsigned long)ScreenWidth * (BPP>>3);
    ScreenPitch += ((4-(ScreenPitch & 0x03)) & 0x03);

    pScreenBase = (unsigned char *)malloc(ScreenPitch * ScreenHeight);

    BytesPerPixel = BPP>>3;

    {
        int CPCXOffset, CPCYOffset;
        int CPCScreenWidth, CPCScreenHeight;
        int ActualCPCScreenHeight;


        CPCXOffset = X_CRTC_CHAR_OFFSET<<(1+3);
        CPCYOffset = Y_CRTC_LINE_OFFSET;
        CPCScreenWidth = X_CRTC_CHAR_WIDTH<<(1+3);
        CPCScreenHeight = Y_CRTC_LINE_HEIGHT;

        CPCScreenWidth = CPCScreenWidth>>PIXEL_STEP_SHIFT;
        CPCXOffset = CPCXOffset>>PIXEL_STEP_SHIFT;

        if (ScreenResX>=CPCScreenWidth)
        {
                /* screen resolution is higher than viewable CPC screen */
                
                /* centralise screen in display area */
                Render_ScreenXOffset = (ScreenResX>>1)-(CPCScreenWidth>>1);
                Render_CPCRenderWidth = CPCScreenWidth; 
                Render_CPCXOffset = CPCXOffset;
        }
        else
        {
                /* screen resolution is lower than viewable CPC screen */
                /* clip screen display */

                /* render from left hand side */
                Render_ScreenXOffset = 0;
                /* adjust width we are going to render */
                Render_CPCRenderWidth = ScreenResX;
                /* set new offset, so that the viewable area is still central */
                Render_CPCXOffset = CPCXOffset + (CPCScreenWidth>>1) - (ScreenResX>>1);
        }

        if (ScanLines!=0)
        {
                ActualCPCScreenHeight = CPCScreenHeight<<1;
        }
        else
        {
                ActualCPCScreenHeight = CPCScreenHeight;
        }

        if (ScreenResY>=ActualCPCScreenHeight)
        {
                /* screen Y resolution is higher than viewable CPC screen */
                /* centralise screen in display area */

                Render_ScreenYOffset = (ScreenResY>>1)-(ActualCPCScreenHeight>>1);
                Render_CPCRenderHeight = CPCScreenHeight;
                Render_CPCYOffset = CPCYOffset;
        }
        else
        {
                /* screen Y resolution is less than viewable CPC screen */
                /* clip screen display */

                /* render from top */
                Render_ScreenYOffset = 0;
                /* adjust height we are going to render */
                Render_CPCRenderHeight = ScreenResY;

                if (ScanLines)
                {
                        Render_CPCRenderHeight = Render_CPCRenderHeight>>1;
                }

                /* set new offset, so that viewablew area is still central */
                Render_CPCYOffset = CPCYOffset + ((ActualCPCScreenHeight - ScreenResY)>>1);
        }
    }       

	if (pScreenBase!=NULL)
	{
		Renderer_Active = TRUE;
	}
	else
	{
		Renderer_Active = FALSE;
	}

	return Renderer_Active;
}

BOOL	Render_IsRenderActive()
{
	return Renderer_Active;
}
#if 0
BOOL Render_SetDisplayFullScreen(int Width, int Height, int Depth)
{
        
        // not recommended for any res as low as 320x240

        int ScreenResX = Width;
        int ScreenResY = Height;
        int ScreenDepth = Depth;

        Render_SetRenderingAccuracy(RENDERING_ACCURACY_HIGH);

        if (Host_SetDisplay(DISPLAY_TYPE_FULLSCREEN,ScreenResX,ScreenResY,ScreenDepth))
        {
                GRAPHICS_BUFFER_COLOUR_FORMAT   *pGraphicsBufferColourFormat = Host_GetGraphicsBufferColourFormat();

                CurrentGraphicsFormat.BPP = pGraphicsBufferColourFormat->BPP;
                
                CurrentGraphicsFormat.Red.BPP = pGraphicsBufferColourFormat->Red.BPP;
                CurrentGraphicsFormat.Red.Mask = pGraphicsBufferColourFormat->Red.Mask;
                CurrentGraphicsFormat.Red.Shift = pGraphicsBufferColourFormat->Red.Shift;
                
                CurrentGraphicsFormat.Green.BPP = pGraphicsBufferColourFormat->Green.BPP;
                CurrentGraphicsFormat.Green.Mask = pGraphicsBufferColourFormat->Green.Mask;
                CurrentGraphicsFormat.Green.Shift = pGraphicsBufferColourFormat->Green.Shift;
                
                CurrentGraphicsFormat.Blue.BPP = pGraphicsBufferColourFormat->Blue.BPP;
                CurrentGraphicsFormat.Blue.Mask = pGraphicsBufferColourFormat->Blue.Mask;
                CurrentGraphicsFormat.Blue.Shift = pGraphicsBufferColourFormat->Blue.Shift;

				if (CurrentGraphicsFormat.BPP!=8)
				{
					Render_TrueColourRGB_Setup();
				}
				else
				{
					Render_Paletted_Setup();
				}

                pRender_DumpScreen = Render_DumpScreen4;

                if (InitialiseRender(ScreenResX,ScreenResY,ScreenDepth))
				{
					return TRUE;
				}
				
				return FALSE;
        }

        return FALSE;
}
#endif

#define X_CRTC_CHAR_WIDTH	50
#define PIXEL_STEP_SHIFT	0
#define Y_CRTC_LINE_HEIGHT	280	//312

BOOL    Render_SetDisplayWindowed()
{
        int ScreenWidth, ScreenHeight;

        //Render_SetRenderingAccuracy(Render_RenderingAccuracyForWindowedMode);

        ScreenWidth = (X_CRTC_CHAR_WIDTH<<(1+3))>>PIXEL_STEP_SHIFT;     
        ScreenHeight = (Y_CRTC_LINE_HEIGHT);

        /* adjust height for scanlines */
        if (ScanLines)
        {
                ScreenHeight = ScreenHeight<<1;
        }
        
        if (Host_SetDisplay(DISPLAY_TYPE_WINDOWED,ScreenWidth, ScreenHeight,0))
        {
			int DisplayableWidth, DisplayableHeight;

			GRAPHICS_BUFFER_INFO *pGraphicsBufferInfo;
            GRAPHICS_BUFFER_COLOUR_FORMAT   *pGraphicsBufferColourFormat;
			
			pGraphicsBufferColourFormat = Host_GetGraphicsBufferColourFormat();

			pGraphicsBufferInfo = Host_GetGraphicsBufferInfo();
			
			DisplayableWidth = pGraphicsBufferInfo->Width;
			DisplayableHeight = pGraphicsBufferInfo->Height;

                CurrentGraphicsFormat.BPP = pGraphicsBufferColourFormat->BPP;
                
                CurrentGraphicsFormat.Red.BPP = pGraphicsBufferColourFormat->Red.BPP;
                CurrentGraphicsFormat.Red.Mask = pGraphicsBufferColourFormat->Red.Mask;
                CurrentGraphicsFormat.Red.Shift = pGraphicsBufferColourFormat->Red.Shift;
                
                CurrentGraphicsFormat.Green.BPP = pGraphicsBufferColourFormat->Green.BPP;
                CurrentGraphicsFormat.Green.Mask = pGraphicsBufferColourFormat->Green.Mask;
                CurrentGraphicsFormat.Green.Shift = pGraphicsBufferColourFormat->Green.Shift;
                
                CurrentGraphicsFormat.Blue.BPP = pGraphicsBufferColourFormat->Blue.BPP;
                CurrentGraphicsFormat.Blue.Mask = pGraphicsBufferColourFormat->Blue.Mask;
                CurrentGraphicsFormat.Blue.Shift = pGraphicsBufferColourFormat->Blue.Shift;

    			Render_InitialiseColours();

				if (InitialiseRender(DisplayableWidth, DisplayableHeight, CurrentGraphicsFormat.BPP))
				{
					return TRUE;
				}

				return FALSE;
        }

        return FALSE;
}

