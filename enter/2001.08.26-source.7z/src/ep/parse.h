/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef __PARSE_HEADER_INCLUDED__
#define __PARSE_HEADER_INCLUDED__



/* OK, Maybe this is overkill*/

typedef struct PARSE_STATUS
{
	/* string we are parsing */
	char *pString;
	/* offset into that string */
	int Index;
} PARSE_STATUS;


typedef enum
{
	PARSE_ITEM_EOL,
	PARSE_ITEM_IGNORE,
	PARSE_ITEM_QUOTED_STRING,
	PARSE_ITEM_NUMBER,
	PARSE_ITEM_OPEN_BRACKET,
	PARSE_ITEM_CLOSE_BRACKET,
	PARSE_ITEM_SEPERATOR,
	PARSE_ITEM_TOKEN,
	PARSE_ITEM_EQUALS,
} PARSE_ITEM_ID;


typedef struct PARSE_ITEM
{
	PARSE_ITEM_ID	ID;
	void	*pItemData;
} PARSE_ITEM;

const int CR = 13;
const int LF = 10;

#define NEWLINE(ch) ((ch==CR) || (ch==LF))


void	Parse_Get(PARSE_STATUS *pParseStatus, PARSE_ITEM *pItem);
void	Parse_Init(PARSE_STATUS *pParseStatus, char *);


typedef int BOOL;

#ifndef TRUE
#define TRUE (1==1)
#endif

#ifndef FALSE
#define FALSE (1==0)
#endif

#endif