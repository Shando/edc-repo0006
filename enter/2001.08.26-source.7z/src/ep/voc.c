/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include "cpcglob.h"
//#include "cpcdefs.h"
//#include "cpc.h"
#include "sampload.h"
#include "host.h"
#include "endian.h"
#include "voc.h"

#define CPC_LSB_FIRST

/* Voc file format:

Header					0x01a bytes	"Creative Voice File\0x01a"
Offset to first block	2 bytes		

  Block Header:

  1 byte		Block ID
  3 byte		Block Size (not including size of this block header)

  Blocks:

  type 2:

  data

  type 9:

  2 bytes		sample frequency
  2 bytes		?
  1 byte		bits per sample
  1 byte		no of channels
  6 bytes		?
  x bytes		data
*/

#define VOC_MAIN_HEADER_IDENT "Creative Voice File\x1a"

typedef struct VOC_MAIN_HEADER
{
	/* identification text */
	unsigned char	IdentText[0x014];
	/* offset to first block */
	unsigned char	FirstBlockOffsetLow;
	unsigned char	FirstBlockOffsetHigh;
	/* unencoded version */
	unsigned char	UnencodedVersionMinor;
	unsigned char	UnencodedVersionMajor;
	/* encodeded version */
	unsigned char	EncodedVersionMinor;
	unsigned char	EncodedVersionMajor;
} VOC_MAIN_HEADER;

typedef struct VOC_BLOCK_HEADER
{
	/* id of block */
	unsigned char	ID;
	/* length of block */
	unsigned char	LengthLow;
	unsigned char	LengthMid;
	unsigned char	LengthHigh;
} VOC_BLOCK_HEADER;

typedef struct VOC_BLOCK9_HEADER
{
	/* sample frequency in Hz */
	unsigned short	SampleFrequency;
	/* ?? */
	unsigned short	pad0;
	/* bits per sample */
	unsigned char	BitsPerSample;
	/* no of channels */
	unsigned char	NoOfChannels;
	/* ?? */
	unsigned char	pad1[6];
} VOC_BLOCK9_HEADER;

typedef struct VOC_BLOCK1_HEADER
{
	unsigned char	SampleRate;
	unsigned char	CompressionType;
} VOC_BLOCK1_HEADER;

typedef struct VOC_AUDIO_STREAM
{
	/* offset into block */
	unsigned long	CurrentBlockOffset;
	/* size of data in block */
	unsigned long	CurrentBlockSize;
	/* offset in voc file */
	unsigned long Flags;

//	unsigned char *FileBuffer;
//	
//	unsigned long BufferOffset;
//	unsigned long BytesInBuffer;

} VOC_AUDIO_STREAM;

static VOC_AUDIO_STREAM VocAudioStream;


int	VOC_IdentifyHeader(VOC_MAIN_HEADER *VocHeader)
{
	/* header text matches?? */
	if (memcmp(VocHeader, VOC_MAIN_HEADER_IDENT,19)==0)
	{
		/* yes */
		
		unsigned long Version;
		unsigned long EncodedVersion;

		/* get unencoded version */

		/* get version major */
		Version = VocHeader->UnencodedVersionMajor<<8;
		/* get version minor */
		Version |= VocHeader->UnencodedVersionMinor;

		/* get encoded version */
		EncodedVersion = VocHeader->EncodedVersionMajor<<8;
		EncodedVersion |= VocHeader->EncodedVersionMinor;

		EncodedVersion -= 0x01234;
		EncodedVersion ^= 0x0ffff;

		if ((EncodedVersion & 0x0ffff) == (Version & 0x0ffff))
		{
			/* header is ok */
			return 1;
		}
	}

	/* header is not ok */
	return 0;
}

int VOC_GetBlockSize(VOC_BLOCK_HEADER *pBlockHeader)
{
	return pBlockHeader->LengthLow | (pBlockHeader->LengthMid<<8) |
			(pBlockHeader->LengthHigh<<16);
}


void	VOC_GetNextDataBlock(SAMPLE_AUDIO_STREAM *pAudioStream)
{
	VOC_BLOCK_HEADER VocBlockHeader;
	VOC_AUDIO_STREAM *pVocAudioStream = &VocAudioStream;

	/* read header */
	Sample_ReadData(pAudioStream,(unsigned char *)&VocBlockHeader, sizeof(VOC_BLOCK_HEADER));

	pVocAudioStream->CurrentBlockOffset = 0;

	if (VocBlockHeader.ID!=0)
	{
		unsigned long BlockSize;

		BlockSize = VOC_GetBlockSize(&VocBlockHeader);
	
		switch (VocBlockHeader.ID)
		{
			case 9:
			{
				/* sample data */
				VOC_BLOCK9_HEADER Block9Header;
				
				Sample_ReadData(pAudioStream, (unsigned char *)&Block9Header, sizeof(VOC_BLOCK9_HEADER));

				pVocAudioStream->CurrentBlockSize = BlockSize - sizeof(VOC_BLOCK9_HEADER);

#ifdef CPC_LSB_FIRST
				pAudioStream->SampleFrequency = Block9Header.SampleFrequency;
#else
				pAudioStream->SampleFrequency = SwapEndianWord(Block9Header.SampleFrequency);
#endif

				pAudioStream->SampleBits = Block9Header.BitsPerSample;
				pAudioStream->SampleChannels = Block9Header.NoOfChannels;
			}
			break;

			case 1:
			{
				VOC_BLOCK1_HEADER Block1Header;
				
				Sample_ReadData(pAudioStream, (unsigned char *)&Block1Header, sizeof(VOC_BLOCK1_HEADER));

				pVocAudioStream->CurrentBlockSize = BlockSize - sizeof(VOC_BLOCK1_HEADER);
				
				if (Block1Header.CompressionType==0)
				{
					pAudioStream->SampleBits = 8;
					pAudioStream->SampleChannels = 1;
				}
				
				pAudioStream->SampleFrequency = 1000000L/(256 - Block1Header.SampleRate);
			}
			break;

			case 2:
			{
				pVocAudioStream->CurrentBlockSize = BlockSize;
			}
			break;

			default:
			{
			}
			break;	
		}
	}
}

void	VOC_Validate_SkipData(HOST_FILE_HANDLE FileHandle, unsigned long Size)
{
	unsigned long i;
	unsigned long DataLong;
	unsigned char DataByte;

	for (i=0; i<(Size>>2); i++)
	{
		Host_ReadData(FileHandle, (unsigned char *)&DataLong, sizeof(unsigned long));
	}

	for (i=0; i<(Size&3); i++)
	{
		Host_ReadData(FileHandle, (unsigned char *)&DataByte, sizeof(unsigned char));
	}
}



/*-------------------------*/
BOOL	VOC_Validate(char *Filename)
{	
	VOC_MAIN_HEADER VocHeader[32];

	HOST_FILE_HANDLE FileHandle;

	FileHandle = Host_OpenFile(Filename, HOST_FILE_ACCESS_READ);

	if (FileHandle!=0)
	{
		unsigned long FileSize;

		FileSize = Host_GetFileSize(FileHandle);

		/* size must be at least size of voc header */
		if (FileSize>sizeof(VOC_MAIN_HEADER))
		{
			VOC_BLOCK_HEADER VocBlockHeader;

			/* get header */
			Host_ReadData(FileHandle, (unsigned char *)&VocHeader[0], sizeof(VOC_MAIN_HEADER));

			/* check header for identification string */
			if (VOC_IdentifyHeader(&VocHeader[0]))
			{
				unsigned long OffsetOfFirstDataBlock;
				unsigned long DataToSkip;

				OffsetOfFirstDataBlock = VocHeader->FirstBlockOffsetLow | 
						(VocHeader->FirstBlockOffsetHigh<<8);
				
				DataToSkip = OffsetOfFirstDataBlock - sizeof(VOC_MAIN_HEADER);

				if (DataToSkip!=0)
				{
					VOC_Validate_SkipData(FileHandle,DataToSkip);
				}
#if 0
	VOC_AUDIO_STREAM *pVocAudioStream = &VocAudioStream;

	/* read header */
	Sample_ReadData(pAudioStream,(unsigned char *)&VocBlockHeader, sizeof(VOC_BLOCK_HEADER));

	pVocAudioStream->CurrentBlockOffset = 0;

	if (VocBlockHeader.ID!=0)
	{
		unsigned long BlockSize;

		BlockSize = VOC_GetBlockSize(&VocBlockHeader);
	
		switch (VocBlockHeader.ID)
		{
			case 9:
			{
				/* sample data */
				VOC_BLOCK9_HEADER Block9Header;
				
				Sample_ReadData(pAudioStream, (unsigned char *)&Block9Header, sizeof(VOC_BLOCK9_HEADER));

				pVocAudioStream->CurrentBlockSize = BlockSize - sizeof(VOC_BLOCK9_HEADER);

#ifdef CPC_LSB_FIRST
				pAudioStream->SampleFrequency = Block9Header.SampleFrequency;
#else
				pAudioStream->SampleFrequency = SwapEndianWord(Block9Header.SampleFrequency);
#endif

				pAudioStream->SampleBits = Block9Header.BitsPerSample;
				pAudioStream->SampleChannels = Block9Header.NoOfChannels;
			}
			break;

			case 1:
			{
				VOC_BLOCK1_HEADER Block1Header;
				
				Sample_ReadData(pAudioStream, (unsigned char *)&Block1Header, sizeof(VOC_BLOCK1_HEADER));

				pVocAudioStream->CurrentBlockSize = BlockSize - sizeof(VOC_BLOCK1_HEADER);
				
				if (Block1Header.CompressionType==0)
				{
					pAudioStream->SampleBits = 8;
					pAudioStream->SampleChannels = 1;
				}
				
				pAudioStream->SampleFrequency = 1000000L/(256 - Block1Header.SampleRate);
			}
			break;

			case 2:
			{
				pVocAudioStream->CurrentBlockSize = BlockSize;
			}
			break;

			default:
			{
			}
			break;	
		}
	}


				VOC_GetNextDataBlock(pAudioStream);
#endif
				return TRUE;
			}
		}
	}

	return FALSE;
}

void	VOC_Open(SAMPLE_AUDIO_STREAM *pAudioStream)
{	
	VOC_MAIN_HEADER VocHeader[32];


	/* get header */
	Sample_ReadData(pAudioStream, (unsigned char *)&VocHeader[0], sizeof(VOC_MAIN_HEADER));

//	if (VOC_IdentifyHeader(&VocHeader[0]))
	{
		unsigned long OffsetOfFirstDataBlock;
		unsigned long DataToSkip;

		OffsetOfFirstDataBlock = VocHeader->FirstBlockOffsetLow | 
				(VocHeader->FirstBlockOffsetHigh<<8);
		
		DataToSkip = OffsetOfFirstDataBlock - sizeof(VOC_MAIN_HEADER);

		if (DataToSkip!=0)
		{
			Sample_SkipData(pAudioStream, DataToSkip);
		}

		VOC_GetNextDataBlock(pAudioStream);

	}
}



unsigned char VOC_GetDataByte(SAMPLE_AUDIO_STREAM *pAudioStream)
{
	VOC_AUDIO_STREAM *pVocAudioStream = &VocAudioStream;
	
	if (pVocAudioStream->CurrentBlockOffset==pVocAudioStream->CurrentBlockSize)
	{
		VOC_GetNextDataBlock(pAudioStream);
	}
	else
	{
		/* increment position in stream */
		pVocAudioStream->CurrentBlockOffset+=((pAudioStream->SampleBits>>3)*(pAudioStream->SampleChannels));
	}

	if (pAudioStream->SampleChannels==1)
	{
		if (pAudioStream->SampleBits==8)
		{
			/* return byte */
			return Sample_GetByte(pAudioStream);
		}
		else
		{
			unsigned short SampleData;

			SampleData = Sample_GetByte(pAudioStream);
			SampleData |= Sample_GetByte(pAudioStream)<<8;

			return (unsigned char)(SampleData>>8);
		}
	}
	else
	{
		/* stereo */

		if (pAudioStream->SampleBits==8)
		{
			unsigned char SampleByte1, SampleByte2;
			SampleByte1 = Sample_GetByte(pAudioStream);
			SampleByte2 = Sample_GetByte(pAudioStream);

			return (unsigned char)((SampleByte1 + SampleByte2)>>1);
		}
		else
		{
			unsigned short SampleData1, SampleData2;

			SampleData1 = Sample_GetByte(pAudioStream);
			SampleData1 |= Sample_GetByte(pAudioStream)<<8;

			SampleData2 = Sample_GetByte(pAudioStream);
			SampleData2 |= Sample_GetByte(pAudioStream)<<8;

			return (unsigned char)(((SampleData1 + SampleData2)>>1)>>8);
		}
	}
}



