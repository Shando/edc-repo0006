/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "parse.h"
#include "ep.h"
#include "config.h"

static char Parse_StringBuffer[256];

/* advance a char in the string */
char Parse_GetChar(PARSE_STATUS *pParseStatus)
{
	char ch;

	/* get char */
	ch = pParseStatus->pString[pParseStatus->Index];
	/* update offset in string */
	pParseStatus->Index++;

	return ch;
}

/* go back a char in the string */
void Parse_GoBackChar(PARSE_STATUS *pParseStatus)
{
	pParseStatus->Index--;
}


/* get chars from string until a quote is encountered. */
char	*Parse_GetQuotedString(PARSE_STATUS *pParseStatus)
{
	char ch;
	char *pOutputString = &Parse_StringBuffer[0];
	int count;

	count = 0;

	/* skip initial quote */
	Parse_GetChar(pParseStatus);
	
	do
	{
		/* get char */
		ch = Parse_GetChar(pParseStatus);

		/* if it is not a quote */
		if (ch!='"')
		{
			/* store char */
			pOutputString[count] = ch;
			count++;
		}
	}
	/* quote, end of string or end of line */
	while ((ch!='"') && (ch!='\0') && (!NEWLINE(ch)));

	/* end string */
	pOutputString[count] = '\0';

	/* do not need to go back a char because last char fetched was " and we want to skip this */

	return pOutputString;
}

/* A-Z and _ */
BOOL	Parse_IsTokenChar(char ch)
{
	if ((ch=='_') || (isalpha(ch)))
	{
		return TRUE;
	}

	return FALSE;
}


/* get chars from string until a quote is encountered. */
char	*Parse_GetToken(PARSE_STATUS *pParseStatus)
{
	char ch;
	char *pOutputString = &Parse_StringBuffer[0];
	int count;
	BOOL IsToken;

	count = 0;

	do
	{
		/* get char */
		ch = Parse_GetChar(pParseStatus);


		/* if it is not a quote */
		IsToken = Parse_IsTokenChar(ch);

		if (IsToken)
		{
			/* store char */
			pOutputString[count] = ch;
			count++;
		}
	}
	/* quote, end of string or end of line */
	while (IsToken);
	
	/* end string */
	pOutputString[count] = '\0';

	/* go back a char */
	Parse_GoBackChar(pParseStatus);

	return pOutputString;
}

/* is character a digit? */
BOOL	Parse_IsDigit(char ch)
{
	if ((ch>='0') && (ch<='9'))
		return TRUE;

	return FALSE;
}

/* convert char to number representation */
int		Parse_ConvertDigitToNumber(char ch)
{
	return ch-'0';
}


int		Parse_GetDecimalNumber(PARSE_STATUS *pParseStatus)
{
	char ch;
	unsigned long OutputNumber;
	BOOL	IsDigit;
	
	OutputNumber = 0;

	do
	{
		ch = Parse_GetChar(pParseStatus);

		IsDigit = Parse_IsDigit(ch);

		if (IsDigit)
		{
			OutputNumber = OutputNumber * 10;
			OutputNumber += Parse_ConvertDigitToNumber(ch);
		}
	}
	while (IsDigit);

	Parse_GoBackChar(pParseStatus);

	return OutputNumber;
}


/* is character a digit? */
BOOL	Parse_IsHexDigit(char ch)
{
	char upper_ch;

	upper_ch = toupper(ch);

	if (((upper_ch>='A') && (upper_ch<='F')) || 
	   ((ch>='0') && (ch<='9')))
	{
		return TRUE;
	}

	return FALSE;
}

int Parse_ConvertHexDigitToNumber(char ch)
{
	int number;

	if (ch<='9')
	{
		number = ch-'0';
	}
	else
	{
		number = toupper(ch)-'A'+10;
	}

	return number;
}


int		Parse_GetHexNumber(PARSE_STATUS *pParseStatus)
{
	char ch;
	unsigned long OutputNumber;
	BOOL IsDigit;

	OutputNumber = 0;

	do
	{
		ch = Parse_GetChar(pParseStatus);

		IsDigit = Parse_IsHexDigit(ch);
		
		if (IsDigit)
		{
			OutputNumber = OutputNumber<<4;
			OutputNumber += Parse_ConvertHexDigitToNumber(ch);
		}
	}
	while (IsDigit);

	Parse_GoBackChar(pParseStatus);

	return OutputNumber;
}


void	Parse_SkipNewLine(PARSE_STATUS *pParseStatus)
{
	char ch;

	do
	{
		ch = Parse_GetChar(pParseStatus);
	}
	while (NEWLINE(ch));

	Parse_GoBackChar(pParseStatus);
}

void	Parse_SkipSpace(PARSE_STATUS *pParseStatus)
{
	char ch;

	do
	{
		ch = Parse_GetChar(pParseStatus);
	}
	while (ch==' ');
 
	Parse_GoBackChar(pParseStatus);
}


void	Parse_Init(PARSE_STATUS *pParseStatus, char *pInputString)
{
	pParseStatus->pString = pInputString;
	pParseStatus->Index = 0;
}

/* get next token, quoted string or number from line */
void	Parse_Get(PARSE_STATUS *pParseStatus, PARSE_ITEM *pItem)
{
	char ch;

	/* get char */
	ch = Parse_GetChar(pParseStatus);
	Parse_GoBackChar(pParseStatus);

	/* end of string */
	if (ch=='\0')
	{
		pItem->ID = PARSE_ITEM_EOL;
		return;
	}
	else
	if (NEWLINE(ch))
	{
		pItem->ID = PARSE_ITEM_IGNORE;
		/* new line */
		Parse_SkipNewLine(pParseStatus);
		return;
	}
	else
	if (ch==' ')
	{
		pItem->ID = PARSE_ITEM_IGNORE;

		/* empty space */
		Parse_SkipSpace(pParseStatus);
		return;
	}
	else
	if (ch=='"')
	{
		pItem->ID = PARSE_ITEM_QUOTED_STRING;

		/* quoted string */
		pItem->pItemData = (void *)Parse_GetQuotedString(pParseStatus);
		return;
	}
	else
	if (Parse_IsDigit(ch))
	{
		pItem->ID = PARSE_ITEM_NUMBER;

		/* decimal number */
		pItem->pItemData = (void *)Parse_GetDecimalNumber(pParseStatus);
		return;
	}
	else
	if (ch=='#')
	{
		pItem->ID = PARSE_ITEM_NUMBER;
		
		Parse_GetChar(pParseStatus);

		/* decimal number */
		pItem->pItemData = (void *)Parse_GetHexNumber(pParseStatus);
		return;
	}

	if (ch=='=')
	{
		pItem->ID = PARSE_ITEM_EQUALS;

		Parse_GetChar(pParseStatus);
		return;
	}
	else
	if (Parse_IsTokenChar(ch))
	{
		pItem->ID = PARSE_ITEM_TOKEN;

		pItem->pItemData = (void *)Parse_GetToken(pParseStatus);

		/* capitalise token */
		{
			int i;
			char *pString = (char *)pItem->pItemData;

			for (i=0; i<strlen(pString); i++)
			{
				char ch;

				ch = pString[i];
				pString[i] = toupper(ch);
			}
		}

		return;
	}

	/* ignore this */
	pItem->ID = PARSE_ITEM_IGNORE;
	/* go past the char */
	Parse_GetChar(pParseStatus);

}


/****************************/

#include "parse.h"

typedef struct STATES
{
	char *StateToken;
	void (*UpdateState)(PARSE_ITEM *, int);
} STATES;

static int StateHandler_State = 0;

static void (*StateHandler_UpdateStateFunction)(PARSE_ITEM *,int) = NULL;

void EPPage_UpdateState(PARSE_ITEM *,int State);
void EPPageType_UpdateState(PARSE_ITEM *,int State);
void EPPageData_UpdateState(PARSE_ITEM *,int State);

/* the handled states */
static STATES	StateHandler_States[]=
{
	{"EP_PAGE", EPPage_UpdateState},
	{"EP_PAGE_TYPE", EPPageType_UpdateState},
	{"EP_PAGE_DATA",EPPageData_UpdateState}
};

void	StateHandler_StateReset(void)
{
	StateHandler_State = 0;
	StateHandler_UpdateStateFunction = 0;
}

void	StateHandler_ExecuteHandler(PARSE_ITEM *pItem)
{
	if (StateHandler_UpdateStateFunction!=NULL)
	{
		StateHandler_UpdateStateFunction(pItem, StateHandler_State);
	}
}


/* set state from named token */
void	StateHandler_SetStateFromToken(char *Token)
{
	int i;

	StateHandler_StateReset();

	for (i=0; i<sizeof(StateHandler_States)/sizeof(STATES); i++)
	{
		STATES *pThisState = &StateHandler_States[i];

		if (strcmp(Token, pThisState->StateToken)==0)
		{
			/* found it */

			StateHandler_UpdateStateFunction = pThisState->UpdateState;

			StateHandler_ExecuteHandler(NULL);

			return;
		}
	}
}

/*****************/

int CurrentEPPage = -1;

int ExpectedID;

void	EPPage_UpdateState(PARSE_ITEM *pParseItem, int State)
{
	if (State!=0)
	{
		if (pParseItem->ID != ExpectedID)
			return;

		StateHandler_State++;
	}

	switch (State)
	{
		case 0:
		{
			ExpectedID = PARSE_ITEM_EQUALS;
			StateHandler_State++;
		}
		break;
		
		case 1:
		{
			ExpectedID = PARSE_ITEM_NUMBER;
		}
		break;

		case 2:
		{
			CurrentEPPage = (unsigned long)pParseItem->pItemData;

			StateHandler_StateReset();

		}
		break;
	}
}


/* EP PAGE TYPE */
void	EPPageType_UpdateState(PARSE_ITEM *pParseItem, int State)
{
	if (State!=0)
	{
		if (pParseItem->ID != ExpectedID)
			return;

		StateHandler_State++;
	}

	switch (State)
	{
		case 0:
		{
			ExpectedID = PARSE_ITEM_EQUALS;
			StateHandler_State++;
		}
		break;
		

		case 1:
		{
			ExpectedID = PARSE_ITEM_TOKEN;
		}
		break;

		case 2:
		{
			if (CurrentEPPage!=-1)
			{
				if (stricmp((char *)pParseItem->pItemData, "RAM")==0)
				{
					Enterprise_SetRamPage(CurrentEPPage);
					CurrentEPPage = -1;
				}
				else
				if (stricmp((char *)pParseItem->pItemData, "SRAM")==0)
				{
					RestoreSRAM(CurrentEPPage);
					CurrentEPPage = -1;
				}
			}

			StateHandler_StateReset();

		}
		break;
	}
}


void	EPPageData_UpdateState(PARSE_ITEM *pParseItem,int State)
{
	if (State!=0)
	{
		if (pParseItem->ID != ExpectedID)
			return;

		StateHandler_State++;
	}
	
	switch (State)
	{
		case 0:
		{
			ExpectedID = PARSE_ITEM_EQUALS;
			StateHandler_State++;
		}
		break;
		
		case 1:
		{
			ExpectedID = PARSE_ITEM_QUOTED_STRING;
		}
		break;

		case 2:
		{
			if (CurrentEPPage!=-1)
			{
				/* ROM */
				ROM_Load((char *)pParseItem->pItemData, CurrentEPPage);
				CurrentEPPage = -1;

			}
				StateHandler_StateReset();

		}
		break;
	}
}


static char line[256];


void  LoadConfigFile(char *Filename)
{
	FILE *fh;

	// open file
	fh = fopen(Filename,"r");

	if (fh!=NULL)
	{
		char *result;

		StateHandler_StateReset();

		do
		{
			PARSE_ITEM ParseItem;
			PARSE_STATUS ParseStatus;

			// get a line from the file
			result = fgets(line, 255, fh);

			/* initialise parser for this line */
			Parse_Init(&ParseStatus, line);


			if (result!=NULL)
			{
				do
				{
					/* get item */
					Parse_Get(&ParseStatus, &ParseItem);

					/* if a handler is not yet installed... set one up */
					if (StateHandler_UpdateStateFunction==NULL)
					{
						/* did we get a token? */
						if (ParseItem.ID == PARSE_ITEM_TOKEN)
						{
							/* yes */
							StateHandler_SetStateFromToken((char *)ParseItem.pItemData);
						}
					}
					else
					{
						StateHandler_ExecuteHandler(&ParseItem);
					}
				/* continue until end of line */
				}
				while (ParseItem.ID!=PARSE_ITEM_EOL);
			}

		}
		while (result!=0);

		// close file
		fclose(fh);
	}
}
