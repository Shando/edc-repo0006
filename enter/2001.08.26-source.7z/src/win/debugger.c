/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN
#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include "debugger.h"
#include "resource.h"
#include "../ep/render.h"

#include "../ep/z80/z80.h"
#include "mylistvw.h"
#include "../ep/debugger/gdebug.h"

void	Debugger_DebugHooks(HWND);
void	Debugger_RegisterSpriteClass(HWND hParent);
void	Debugger_RegisterShowGfxClass(HWND hParent);
void	Debugger_OpenDissassemble(HWND);
void	Debugger_OpenMemdump(HWND);
void	Debugger_OpenDebugDialog(void);
//void	Debugger_OpenCRTCDialog(HWND);
void	Debugger_ShowSprite(HWND);
void	Debugger_ShowGfx(HWND);
void	Debugger_DestroyCRTCDialog();
void	Debugger_DestroySpriteWindow();
void	ShowASICDialog();
void	Debugger_RedrawShowGfxWindow();
void Debugger_OpenCPCPlusInfo(HWND hParent);
void	Debugger_RegisterCPCInfoClass(HWND hParent);
void	Debugger_RegisterCPCPLUSInfoClass(HWND hParent);
void	Debugger_RegisterCRTCInfoClass(HWND hParent);
void	Debugger_OpenCRTCInfo(HWND hParent);

void	Debugger_UpdateCPCInfo(void);
void	Debugger_UpdateCPCPLUSInfo(void);
void	Debugger_UpdateCRTCInfo(void);
void Debugger_OpenCPCInfo(HWND hParent);


BOOL	HexDialog(HWND hwnd,int *);

extern HINSTANCE hInstCommonControls;

#define Debug_ErrorMessage(ErrorText) \
	MessageBox(GetActiveWindow(),ErrorText,"Arnold Debugger Error",MB_OK)
/////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////

void	ForceRedraw(HWND hwnd)
{
	RECT	WindowRect;

	GetClientRect(hwnd,&WindowRect);

	InvalidateRect(hwnd,&WindowRect,TRUE);
}


typedef struct WINDOW_INFO
{
	int FontWidth;
	int FontHeight;
	int WindowWidth;
	int WindowHeight;
	int NoOfCharsInWidth;
	int NoOfCharsInHeight;
	int NoOfBytes;
} WINDOW_INFO;

void	GetWindowInfo(HWND hwnd, WINDOW_INFO *pInfo)
{
HDC hDC;
HFONT hFont, hOldFont;
TEXTMETRIC FontMetric;
RECT	WindowRect;

	hDC = GetDC(hwnd);

	if (hDC!=NULL)
	{
		hFont = GetStockObject(ANSI_FIXED_FONT);

		hOldFont = SelectObject(hDC, hFont);

		GetTextMetrics(hDC,&FontMetric);

		pInfo->FontWidth = FontMetric.tmMaxCharWidth;
		pInfo->FontHeight = FontMetric.tmHeight;

		GetClientRect(hwnd,&WindowRect);

		pInfo->WindowWidth = WindowRect.right-WindowRect.left;
		pInfo->WindowHeight = WindowRect.bottom-WindowRect.top;

		pInfo->NoOfCharsInWidth = pInfo->WindowWidth/pInfo->FontWidth;
		pInfo->NoOfCharsInHeight = pInfo->WindowHeight/pInfo->FontHeight;

		pInfo->NoOfBytes = (pInfo->NoOfCharsInWidth-(6+2))/4;

		SelectObject(hDC, hOldFont);

		DeleteObject(hFont);

		ReleaseDC(hwnd,hDC);
	}
}



//////////////////////////////////////////////////////////////////////////////////////

#include "commctrl.h"

#define TOOLBAR_BUTTON_ENTRY(x,y)	{x,y,TBSTATE_ENABLED,TBSTYLE_BUTTON,0,0,0}

TBBUTTON MemDumpToolbarButtons[] =
{
    TOOLBAR_BUTTON_ENTRY(0,ID_BUTTON_SET_ADDR),
};

#define MEMDUMP_NUM_TOOLBAR_BUTTONS (sizeof(MemDumpToolbarButtons)/sizeof(TBBUTTON))

#define MEMDUMP_TOOLBAR_BUTTON_WIDTH 16
#define MEMDUMP_TOOLBAR_BUTTON_HEIGHT 15


#define MEMDUMP_TOOLBAR_CONTROL_IDENTIFIER	2

#define CPCEMU_DEBUG_MEMDUMP_CLASS "ARNOLD_DEBUG_MEMDUMP_CLASS"

HWND hMemDump = NULL;
HWND hMemDumpToolbar = NULL;

void	RedrawMemDump()
{
   RECT    ToolbarRect;

   if (hMemDump!=NULL)
   {
	   RECT ClientRect;

		// Get Dimensions of the Client Rectangle
		GetClientRect(hMemDump,&ClientRect);

		// Get client rect of toolbar
		GetWindowRect(hMemDumpToolbar,&ToolbarRect);

		// add height of toolbar to client rect of window
		ClientRect.top += ToolbarRect.bottom-ToolbarRect.top;

		InvalidateRect(hMemDump,&ClientRect,TRUE);
   }
}


//void	RedrawMemDump()
//{
//	if (hMemDump!=NULL)
//	{
//		ForceRedraw(hMemDump);
//	}
//}


void	Debugger_SetMemDumpAddress(unsigned short Addr)
{
	if (hMemDump!=NULL)
	{
		SetWindowWord(hMemDump,0,(unsigned short)Addr);
		RedrawMemDump();
	}
}

void	Debugger_CloseMemDumpWindow()
{
	if (hMemDump!=NULL)
	{
		DestroyWindow(hMemDumpToolbar);
		hMemDumpToolbar=NULL;
		DestroyWindow(hMemDump);
		hMemDump = NULL;
	}
}

long FAR PASCAL MemDumpWindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;
//	char		MemDumpString[1024];

    switch(iMsg)
    {


    case WM_CREATE:
		SetWindowWord(hwnd,0,0);

	    hMemDumpToolbar = CreateToolbarEx(
		hwnd,
        WS_CHILD | WS_BORDER | WS_VISIBLE | CCS_NOMOVEY,	// | CCS_TOP,
        MEMDUMP_TOOLBAR_CONTROL_IDENTIFIER,
        MEMDUMP_NUM_TOOLBAR_BUTTONS,
		(HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE),
        IDR_TOOLBAR2,
        &MemDumpToolbarButtons[0],
        MEMDUMP_NUM_TOOLBAR_BUTTONS,
        MEMDUMP_TOOLBAR_BUTTON_WIDTH,
        MEMDUMP_TOOLBAR_BUTTON_HEIGHT,
        MEMDUMP_TOOLBAR_BUTTON_WIDTH,
        MEMDUMP_TOOLBAR_BUTTON_HEIGHT,
        sizeof(TBBUTTON));
		
		break;

	case WM_COMMAND:
		{
			if ((long)lParam == (long)hMemDumpToolbar)
			{
				switch (LOWORD(wParam))
				{
					case ID_BUTTON_SET_ADDR:
					{
						int NewAddr;

						if (HexDialog(hwnd, &NewAddr))
						{
							Debugger_SetMemDumpAddress((Z80_WORD)NewAddr);
						}
					}
					break;
				}
			}
		}
		break;

    case WM_PAINT:
        {
			HDC hDC;
			RECT WindowRect;
			HFONT hFont,hOldFont;
			HPEN hPen, hOldPen;
			TEXTMETRIC	FontMetric;
			int	FontWidth,FontHeight;
			int WindowWidth, WindowHeight;
			int NoOfCharsInWidth, NoOfCharsInHeight;
			int NoOfBytes;
			int j;
			int BaseAddr = GetWindowWord(hwnd,0) & 0x0ffff;


			BeginPaint( hwnd, &PaintStruct);

			hDC = PaintStruct.hdc;	//GetDC(hwnd);

			hFont = GetStockObject(ANSI_FIXED_FONT);
			hPen = GetStockObject(BLACK_BRUSH);

			hOldFont = SelectObject(hDC, hFont);
			hOldPen = SelectObject(hDC, hPen);

			GetTextMetrics(hDC,&FontMetric);

			FontWidth = FontMetric.tmMaxCharWidth;
			FontHeight = FontMetric.tmHeight;
		
			GetClientRect(hwnd,&WindowRect);

			WindowWidth = WindowRect.right-WindowRect.left;
			WindowHeight = WindowRect.bottom-WindowRect.top;

			NoOfCharsInWidth = WindowWidth/FontWidth;
			NoOfCharsInHeight = WindowHeight/FontHeight;

			NoOfBytes = Debug_CalcNumberOfBytesVisibleInMemDump(NoOfCharsInWidth);

			FillRect(hDC,&WindowRect,GetStockObject(WHITE_BRUSH));

			// debug display


			for (j=0; j<NoOfCharsInHeight; j++)
			{
				char	*pMemDumpString;

				pMemDumpString = Debug_DumpFromAddress(BaseAddr + (j*NoOfBytes), NoOfBytes, Z80_RD_MEM);

				TextOut(hDC, 0, j*FontHeight, pMemDumpString,strlen(pMemDumpString));
			}
     
			SelectObject(hDC,hOldFont);
			SelectObject(hDC,hOldPen);

			DeleteObject(hFont);

			DeleteObject(hPen);

//			ReleaseDC(hwnd,hDC);

			EndPaint( hwnd, &PaintStruct );
/*
			{			
				SCROLLINFO ScrollInfo;

				ScrollInfo.cbSize = sizeof(SCROLLINFO);
				ScrollInfo.fMask = SIF_PAGE | SIF_POS;
				//ScrollInfo.nMin = 0;
				//ScrollInfo.nMax = 65536/NoOfBytes;
				ScrollInfo.nPage = 65536/NoOfCharsInHeight;
				ScrollInfo.nPos = BaseAddr/NoOfBytes;
				ScrollInfo.nTrackPos = 0; 
			
				SetScrollInfo(hwnd, SB_VERT ,&ScrollInfo,TRUE);
			}
*/
			return TRUE;
		}

	case WM_ERASEBKGND:
		return 1;


	case WM_VSCROLL:
		{
			WINDOW_INFO MemDumpInfo;
			int ScrollCode = LOWORD(wParam);
			int Pos = HIWORD(wParam);
			HWND hwndScrollBar = (HWND)lParam;
			int BaseAddr = GetWindowWord(hwnd,0);

			GetWindowInfo(hwnd, &MemDumpInfo);

			switch (ScrollCode)
			{

				case SB_TOP:
					break;

				case SB_BOTTOM:
					break;

				case SB_LINEDOWN:
					
					BaseAddr+= MemDumpInfo.NoOfBytes;
					BaseAddr &= 0x0ffff;
					break;
					
				case SB_LINEUP:
					BaseAddr-= MemDumpInfo.NoOfBytes;
					BaseAddr &= 0x0ffff;
					break;

				case SB_PAGEDOWN:
					BaseAddr += (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_PAGEUP:
					BaseAddr -= (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_THUMBPOSITION:
					break;

				case SB_THUMBTRACK:
					break;

	
			}
/*
			{			
				SCROLLINFO ScrollInfo;

				ScrollInfo.cbSize = sizeof(SCROLLINFO);
				ScrollInfo.fMask = SIF_POS;
				//ScrollInfo.nMin = 0;
				//ScrollInfo.nMax = 65536/NoOfBytes;
				//ScrollInfo.nPage = NoOfCharsInHeight;
				ScrollInfo.nPos = BaseAddr/MemDumpInfo.NoOfBytes;
				ScrollInfo.nTrackPos = 0; 
			
				SetScrollInfo(hwnd, SB_VERT ,&ScrollInfo,TRUE);
			}
*/
			Debugger_SetMemDumpAddress((unsigned short)BaseAddr);

//
//			ForceRedraw(hwnd);
		
		}
		return TRUE;

	case WM_SIZE:
		UpdateWindow(hwnd);
		
		SendMessage(hMemDumpToolbar, WM_SIZE, 0,0);
				
		return TRUE;

	case WM_CLOSE:
		{
			Debugger_CloseMemDumpWindow();
		}
		break;

    case WM_DESTROY:
        {
//			Debugger_CloseMemDumpWindow();

			DestroyWindow(hMemDumpToolbar);
		}
		break;
   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);

} 


void	Debugger_RegisterMemdumpClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);
	
	WNDCLASSEX	DebugWindowClass;

	DebugWindowClass.cbSize = sizeof(WNDCLASSEX);
	DebugWindowClass.style = CS_HREDRAW | CS_VREDRAW;	// | CS_OWNDC; 
	DebugWindowClass.lpfnWndProc = MemDumpWindowProc;
	DebugWindowClass.cbClsExtra = 0;
	DebugWindowClass.cbWndExtra = 2;
	DebugWindowClass.hInstance = hInstance;
	DebugWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	DebugWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	DebugWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	DebugWindowClass.lpszMenuName = NULL;
	DebugWindowClass.lpszClassName = CPCEMU_DEBUG_MEMDUMP_CLASS;
	DebugWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&DebugWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for memory dump window");
	}
}

void Debugger_OpenMemdump(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hMemDump==NULL)
	{
		hMemDump = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_MEMDUMP_CLASS,
			"Memory Dump",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_VSCROLL,
			CW_USEDEFAULT, 
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hMemDump, TRUE);
		UpdateWindow( hMemDump );
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hMemDump, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}

}

//--------------------------------------------------------------------//

TBBUTTON DissasmToolbarButtons[] =
{
    TOOLBAR_BUTTON_ENTRY(0,ID_BUTTON_SET_ADDR),
};

#define DISSASM_NUM_TOOLBAR_BUTTONS (sizeof(DissasmToolbarButtons)/sizeof(TBBUTTON))

#define DISSASM_TOOLBAR_BUTTON_WIDTH 16
#define DISSASM_TOOLBAR_BUTTON_HEIGHT 15


#define DISSASM_TOOLBAR_CONTROL_IDENTIFIER	2

#define CPCEMU_DEBUG_DISSASSEMBLE_CLASS "ARNOLD_DEBUG_DISSASSEMBLE_CLASS"



HWND	hDissassemble = NULL;
HWND	hDissasmToolbar = NULL;

void	RedrawDissassemble()
{
   RECT    ToolbarRect;

   if (hDissassemble!=NULL)
   {
	   RECT ClientRect;

		// Get Dimensions of the Client Rectangle
		GetClientRect(hDissassemble,&ClientRect);

		// Get client rect of toolbar
		GetWindowRect(hDissasmToolbar,&ToolbarRect);

		// add height of toolbar to client rect of window
		ClientRect.top += ToolbarRect.bottom-ToolbarRect.top;

		InvalidateRect(hDissassemble,&ClientRect,TRUE);
	}
}

void	Debugger_DestroyDissassembleWindow()
{
	if (hDissassemble!=NULL)
	{
		DestroyWindow(hDissasmToolbar);
		hDissasmToolbar = NULL;
		DestroyWindow(hDissassemble);
		hDissassemble = NULL;
	}
}

void	Debugger_SetDissassembleAddress(int Addr)
{
	if (hDissassemble!=NULL)
	{
		SetWindowWord(hDissassemble,0,(WORD)(Addr & 0x0ffff));

		RedrawDissassemble();
	}
}


long FAR PASCAL DissassembleWindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;

    switch(iMsg)
    {


    case WM_CREATE:
		//SetWindowWord(hwnd,0,0);

		
	    hDissasmToolbar = CreateToolbarEx(
		hwnd,
        WS_CHILD | WS_BORDER | WS_VISIBLE,	// | CCS_TOP,
        DISSASM_TOOLBAR_CONTROL_IDENTIFIER,
        DISSASM_NUM_TOOLBAR_BUTTONS,
		(HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE),
        IDR_TOOLBAR2,
        &DissasmToolbarButtons[0],
        DISSASM_NUM_TOOLBAR_BUTTONS,
        DISSASM_TOOLBAR_BUTTON_WIDTH,
        DISSASM_TOOLBAR_BUTTON_HEIGHT,
        DISSASM_TOOLBAR_BUTTON_WIDTH,
        DISSASM_TOOLBAR_BUTTON_HEIGHT,
        sizeof(TBBUTTON));

		break;

	case WM_COMMAND:
	{
		if ((long)lParam == (long)hDissasmToolbar)
		{
			switch (LOWORD(wParam))
			{
				case ID_BUTTON_SET_ADDR:
				{
					int NewAddr;
					
					if (HexDialog(hwnd,&NewAddr))
					{
						Debugger_SetDissassembleAddress(NewAddr);
					}
				}
				break;
			}
		}
	}
	break;

    case WM_PAINT:
        {
			HDC	hDC;
			RECT	WindowRect;
			WINDOW_INFO WindowInfo;
			HFONT hFont,hOldFont;
			HPEN hPen, hOldPen;

			int	i;
			int Addr = GetWindowWord(hwnd,0);

			GetWindowInfo(hwnd,&WindowInfo);

			GetClientRect(hwnd,&WindowRect);

			BeginPaint( hwnd, &PaintStruct);

			hDC = PaintStruct.hdc;	//GetDC(hwnd);

			hFont = GetStockObject(ANSI_FIXED_FONT);
			hPen = GetStockObject(BLACK_BRUSH);

			hOldFont = SelectObject(hDC, hFont);
			hOldPen = SelectObject(hDC, hPen);
   
			FillRect(hDC,&WindowRect,GetStockObject(WHITE_BRUSH));

			for (i=0; i<WindowInfo.NoOfCharsInHeight; i++)
			{
				int	OpcodeCount;
				char *pDebugString;

				pDebugString = Debug_DissassembleLine(Addr, &OpcodeCount);

				TextOut(hDC, 0, i*WindowInfo.FontHeight, pDebugString,strlen(pDebugString));

				Addr+= OpcodeCount;
			}

			
			SelectObject(hDC, hOldPen);
			SelectObject(hDC, hOldFont);

			DeleteObject(hPen);
			DeleteObject(hFont);

			//ReleaseDC(hwnd,hDC);

			EndPaint( hwnd, &PaintStruct );

			return TRUE;
		}

	case WM_ERASEBKGND:
		return 1;

	case WM_VSCROLL:
		{
			WINDOW_INFO MemDumpInfo;
			int ScrollCode = LOWORD(wParam);
			int Pos = HIWORD(wParam);
			HWND hwndScrollBar = (HWND)lParam;
			int BaseAddr = GetWindowWord(hwnd,0);

			GetWindowInfo(hwnd, &MemDumpInfo);

			switch (ScrollCode)
			{

				case SB_TOP:
					break;

				case SB_BOTTOM:
					break;

				case SB_LINEDOWN:
					BaseAddr+= Debug_GetOpcodeCount(BaseAddr);
					BaseAddr &= 0x0ffff;
					break;
					
				case SB_LINEUP:
					{
//						int i;

					//	for (i=6; i>0; i--)
					//	{
					//		int OpcodeCount;
//
//							OpcodeCount = GetOpcodeCount(BaseAddr-i);
//
//							if ((BaseAddr-i+OpcodeCount)==BaseAddr)
//								break;
//						}
//
//
//
//					BaseAddr-=i;
					BaseAddr-=8;
						BaseAddr &= 0x0ffff;
					break;
					}

				case SB_PAGEDOWN:
					//BaseAddr += (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_PAGEUP:
					//BaseAddr -= (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_THUMBPOSITION:
					break;

				case SB_THUMBTRACK:
					break;

	
			}
			Debugger_SetDissassembleAddress(BaseAddr);
			

//			ForceRedraw(hwnd);
		
		}
		return TRUE;

	case WM_SIZE:
		UpdateWindow(hwnd);

		SendMessage(hDissasmToolbar, WM_SIZE, 0,0);
		
		return TRUE;

	case WM_CLOSE:
		{
			Debugger_DestroyDissassembleWindow();
		}
	break;

	    case WM_DESTROY:
        {
			DestroyWindow(hDissasmToolbar);
	
			//		Debugger_DestroyDissassembleWindow();
		}
		break;

   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);

} 

void	Debugger_RegisterDissassemblerClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	WNDCLASSEX	DissassembleWindowClass;

	DissassembleWindowClass.cbSize = sizeof(WNDCLASSEX);
	DissassembleWindowClass.style = CS_HREDRAW | CS_VREDRAW;	// | CS_OWNDC; 
	DissassembleWindowClass.lpfnWndProc = DissassembleWindowProc;
	DissassembleWindowClass.cbClsExtra = 0;
	DissassembleWindowClass.cbWndExtra = 2;
	DissassembleWindowClass.hInstance = hInstance;
	DissassembleWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	DissassembleWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW );
	DissassembleWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	DissassembleWindowClass.lpszMenuName = NULL;
	DissassembleWindowClass.lpszClassName = CPCEMU_DEBUG_DISSASSEMBLE_CLASS;
	DissassembleWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&DissassembleWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for dissassembly window");
	}
}


void Debugger_OpenDissassemble(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hDissassemble==NULL)
	{
		hDissassemble = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_DISSASSEMBLE_CLASS,
			"Dissassembly",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_VSCROLL,
			CW_USEDEFAULT, 
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			NULL,
			hInstance,
			NULL );

		SetWindowWord(hDissassemble,0,0);

		ShowWindow( hDissassemble, TRUE);
		UpdateWindow( hDissassemble );
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hDissassemble, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}

}

HWND	hDebuggerDialog = NULL;
HWND	hParentHwnd;

void	Debugger_Initialise(HWND hwnd)
{
	hParentHwnd = hwnd;

	Debugger_RegisterDissassemblerClass(hwnd);
	Debugger_RegisterMemdumpClass(hwnd);
	Debugger_RegisterSpriteClass(hwnd);
	Debugger_RegisterShowGfxClass(hwnd);
	Debugger_RegisterCPCInfoClass(hwnd);
#ifdef ASIC_DEBUGGING
	Debugger_RegisterCPCPLUSInfoClass(hwnd);
#endif
	Debugger_RegisterCRTCInfoClass(hwnd);

	Debug_SetDebuggerWindowOpenCallback(Debugger_OpenDebugDialog);
}




BOOL CALLBACK  DebuggerDialogProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg)
    {
        
        case WM_CREATE:
            return TRUE;

        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
			case IDC_BUTTON_STEP_INTO:
				{
					Debug_SetState(DEBUG_STEP_INTO);
				}
				return TRUE;
            case IDC_BUTTON_RUN_TO:
				{
					int NewAddr;

					if (HexDialog(hwnd, &NewAddr))
					{
						Debug_SetRunTo(NewAddr);
					}
				}
				return TRUE;
			case IDC_BUTTON_DEBUG_GO:
				{
					Debug_SetState(DEBUG_GO);
				}
				return TRUE;
			case IDC_BUTTON_DEBUG_BREAK:
				{
					Debug_SetState(DEBUG_BREAK);
				}
				return TRUE;
			case IDC_BUTTON_MEMDUMP:
				{
					Debugger_OpenMemdump(hwnd);
				}
				return TRUE;
			case IDC_BUTTON_DEBUG_HOOKS:
			{
				Debugger_DebugHooks(hwnd);
			}
			return TRUE;

			case IDC_BUTTON_DISSASSEMBLY:
				{
					Debugger_OpenDissassemble(hwnd);
					{
						Z80_REGISTERS	*R;

						R = Z80_GetReg();
		
						Debugger_SetDissassembleAddress(R->PC.W.l);
					}

				}
				return TRUE;
			case IDC_BUTTON_WRITE_MEM:
				{
//					Debug_WriteBaseMemoryToDisk("memdump2.bin");

					//Debug_WriteMemoryToDisk("memdump.bin");				
				}
				return TRUE;
			case IDC_BUTTON_CPC_HW:
				{
					Debugger_OpenCPCInfo(hwnd);

				}
				return TRUE;
			case IDC_BUTTON_CRTC:
				{
					Debugger_OpenCRTCInfo(hwnd);
				}
				return TRUE;
			case IDC_BUTTON_PLUS_HW:
				{
					Debugger_ShowSprite(hwnd);
#ifdef ASIC_DEBUGGING
					Debugger_OpenCPCPlusInfo(hwnd);
#endif
					//ShowASICDialog(hwnd);
				}
				return TRUE;
			case IDC_DEBUGGER_SHOWGFX:
				{
					Debugger_ShowGfx(hwnd);
				}
				return TRUE;
			case IDC_REFRESH_DISPLAY:
				{

					// dump whole display to screen
				Render_DumpDisplay();

				}
				return TRUE;
			}

        }
		break;

		case WM_CLOSE:
			{	
				Debugger_CloseMemDumpWindow();
				Debugger_DestroyDissassembleWindow();
				Debugger_DestroySpriteWindow();
				//Debugger_DestroyCRTCDialog();
				DestroyWindow(hwnd);

				hDebuggerDialog = NULL;
			}
			break;

		case WM_DESTROY:
			{
				//Debugger_CloseMemDumpWindow();
				//Debugger_DestroyDissassembleWindow();
				//Debugger_DestroySpriteWindow();
				//Debugger_DestroyCRTCDialog();
				//DestroyWindow(hwnd);
//			hDebuggerDialog = NULL;
			}
		break;

/*    case WM_DESTROY:
		PostQuitMessage (0);
		return TRUE;
*/
	}
    return FALSE;
}



BOOL CALLBACK  EnterHexDialogProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

	char	HexValueText[18];

    switch (iMsg)
    {
        
	case WM_INITDIALOG:
		return TRUE;


        case WM_CREATE:
            return TRUE;

			//EndDialog(hwnd,0);

        case WM_COMMAND:
        {
			switch LOWORD(wParam)
	        {
				case IDOK:
					{
						int Number;

					GetDlgItemText(hwnd,IDC_EDIT_HEX_VALUE,HexValueText,16);

					if (Debug_ValidateNumberIsHex(HexValueText, &Number))
					{
						EndDialog(hwnd,Number & 0x0ffff);
						return TRUE;
					}
					}
					break;

				case IDCANCEL:
					{
						EndDialog(hwnd, -1);
					}
					return TRUE;

				default:
					break;
			}
		}
		break;

		case WM_CLOSE:

			break;
		case WM_DESTROY:
			break;

/*    case WM_DESTROY:
		PostQuitMessage (0);
		return TRUE;
*/
	}
    return FALSE;
}



BOOL HexDialog(HWND hwnd, int *pValue)
{
	int Result;

	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);

	Result = DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG_ENTER_HEX),hwnd,EnterHexDialogProc);

	*pValue = Result;

	if (Result==-1)
	{
		return FALSE;
	}
	
	return TRUE;
}




void	SetDlgHexWord(HWND hDialog, int Item, int Data)
{
	char	HexWord[5];
	sprintf(HexWord,"%04x",Data & 0x0ffff);

	SetDlgItemText(hDialog,Item,HexWord);
}

void	SetDlgHexByte(HWND hDialog, int Item, int Data)
{
	char	HexByte[3];
	sprintf(HexByte,"%02x",Data & 0x0ff);

	SetDlgItemText(hDialog,Item, HexByte);
}

void	SetDlgHexDigit(HWND hDialog, int Item, int Data)
{
	char	HexByte[2];
	sprintf(HexByte,"%01x",Data & 0x0f);

	SetDlgItemText(hDialog,Item, HexByte);
}

void	SetDlgBinByte(HWND hDialog, int Item, int Data)
{
	SetDlgItemText(hDialog,Item, Debug_BinaryString((unsigned char)Data));
}


void	Debugger_UpdateDebugDialog()
{
	if (hDebuggerDialog!=NULL)
	{
	char	OutputString[16];
	
	Z80_REGISTERS	*R;

	R = Z80_GetReg();

	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_AF, R->AF.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_BC, R->BC.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_DE, R->DE.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_HL, R->HL.W);
	
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_PC, R->PC.W.l);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_SP, R->SP.W);
	
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_ALTAF, R->altAF.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_ALTHL, R->altHL.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_ALTDE, R->altDE.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_ALTBC, R->altBC.W);
	
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_IX, R->IX.W);
	SetDlgHexWord(hDebuggerDialog,IDC_EDIT_REG_IY, R->IY.W);


	SetDlgHexByte(hDebuggerDialog,IDC_EDIT_REG_I, R->I);
	
	SetDlgHexByte(hDebuggerDialog,IDC_EDIT_REG_R, (R->R & 0x07f) | (R->RBit7));

	SetDlgHexDigit(hDebuggerDialog,IDC_EDIT_REG_IM, R->IM);
	
	SetDlgHexDigit(hDebuggerDialog,IDC_EDIT_REG_IFF1, R->IFF1);
	SetDlgHexDigit(hDebuggerDialog,IDC_EDIT_REG_IFF2, R->IFF2);

	SetDlgItemText(hDebuggerDialog,IDC_STATIC_FLAGS, Debug_FlagsAsString());


	memset(OutputString,0,sizeof(OutputString));
	Debug_DissassembleInstruction(R->PC.W.l, OutputString);
	SetDlgItemText(hDebuggerDialog,IDC_STATIC_DISSASSEMBLY, OutputString);
	}
}

/*
// dma channel 0
//ASIC_DebugDMACommand(int, char *);

// dma channel 1
//ASIC_DebugDMACommand(int, char *);

// dma channel 2
//ASIC_DebugDMACommand(int, char *);
*/

extern BOOL Windowed;

void	Debugger_OpenDebugDialog(void)
{
//	if (!Windowed)
//	{
//		CPCEMU_SetWindowed();
//	}
	{
		HWND hwnd = hParentHwnd;
		HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);

		if (hDebuggerDialog==NULL)
		{
			hDebuggerDialog = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_DIALOG_DEBUGGER), hwnd, DebuggerDialogProc);

			if (hDebuggerDialog!=NULL)
			{
				HMENU hMenu;

				ShowWindow(hDebuggerDialog,TRUE);

				hMenu = LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU2));

				SetMenu(hDebuggerDialog,hMenu);
			}
		}

		if (hDebuggerDialog!=NULL)
		{
			Debugger_UpdateDebugDialog();
		}
	}
}

void	Debugger_CloseDebugDialog()
{
	if (hDebuggerDialog)
	{
		DestroyWindow(hDebuggerDialog);
		hDebuggerDialog = NULL;
	}
}

/*
HWND hCRTCDialog = NULL;

void	Debugger_DestroyCRTCDialog()
{
	if (hCRTCDialog!=NULL)
	{
		DestroyWindow(hCRTCDialog);
		hCRTCDialog = NULL;
	}
}


BOOL CALLBACK  CRTCDialogProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg)
    {
		case WM_INITDIALOG:        
			return TRUE;

		case WM_CREATE:
           return TRUE;


		case WM_CLOSE:
			Debugger_DestroyCRTCDialog();
			break;

		case WM_DESTROY:
			break;

		default:
			break;

	}
    return FALSE;
}
*/
/*
void	Debugger_UpdateCRTCDialog()
{
	if (hCRTCDialog!=NULL)
	{
	CRTC_STATE	CRTC_State;

	CRTC_GetState(&CRTC_State);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG0,CRTC_GetRegisterData(0));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG1,CRTC_GetRegisterData(1));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG2,CRTC_GetRegisterData(2));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG3,CRTC_GetRegisterData(3));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG4,CRTC_GetRegisterData(4));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG5,CRTC_GetRegisterData(5));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG6,CRTC_GetRegisterData(6));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG7,CRTC_GetRegisterData(7));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG8,CRTC_GetRegisterData(8));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG9,CRTC_GetRegisterData(9));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG10,CRTC_GetRegisterData(10));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG11,CRTC_GetRegisterData(11));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG12,CRTC_GetRegisterData(12));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG13,CRTC_GetRegisterData(13));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG14,CRTC_GetRegisterData(14));
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_REG15,CRTC_GetRegisterData(15));

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_HCCOUNT, CRTC_State.HorizontalCharCount);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VCCOUNT, CRTC_State.LineCount);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_HSYNCWIDTH, CRTC_State.HSyncWidth);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VSYNCWIDTH, CRTC_State.VSyncWidth);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_HSYNCSTATE, CRTC_State.Flags & CRTC_HS_FLAG);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VSYNCSTATE, CRTC_State.Flags & CRTC_VS_FLAG);

	SetDlgHexWord(hCRTCDialog,IDC_EDIT_CRTC_MA, CRTC_State.MA_AtLineStart);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_RA, CRTC_State.RasterCount);
	SetDlgHexWord(hCRTCDialog,IDC_EDIT_CRTC_MEMORYADDR, CRTC_State.CurrentVideoMemoryAddress);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_HSYNCCOUNT, CRTC_State.HorizontalSyncWidthCount);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VSYNCCOUNT, CRTC_State.VerticalSyncWidthCount);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_ILC, CRTC_State.InterruptLineCount);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_LAV, CRTC_State.LinesAfterVsyncTaken);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VADJUSTCOUNT, CRTC_State.VerticalTotalAdjustCount);
//	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_LAV, CRTC_State.LinesAfterVsyncTaken);

	SetDlgHexByte(hCRTCDialog,IDC_EDIT_WPSTATE, WestPhaser_GetState());
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_WPSTATECNT, WestPhaser_GetStateCount());


	}


}
*/
//////////////////////////////////////////////////////////////////////////////////////////

#define CPCEMU_DEBUG_SPRITE_CLASS "ARNOLD_DEBUG_SPRITE_CLASS"

void	Debugger_RenderSprite(HWND hwnd,HDC hdc, int SpriteIndex);

HWND hSprite = NULL;

void	Debugger_DestroySpriteWindow()
{
	if (hSprite!=NULL)
	{
		/* destroy it */
		DestroyWindow(hSprite);
		hSprite = NULL;
	}

}

long FAR PASCAL SpriteWindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;
    switch(iMsg)
    {


    case WM_CREATE:
		break;
	
    case WM_PAINT:
        {
			BeginPaint( hwnd, &PaintStruct);

			Debugger_RenderSprite(hwnd,PaintStruct.hdc, 0);

			EndPaint( hwnd, &PaintStruct );
			return TRUE;
		}
		break;	

	case WM_SIZE:
		UpdateWindow(hwnd);
		return TRUE;

	case WM_CLOSE:
	{
		Debugger_DestroySpriteWindow();
	}	
	break;


    case WM_ERASEBKGND:
		return 1;

	case WM_DESTROY:
	{
	}
	break;
	
   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);

} 

void	Debugger_ShowSprite(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hSprite==NULL)
	{
		/* create window and show it */
		hSprite = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_SPRITE_CLASS,
			"ASIC Hardware Sprites",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_VSCROLL,
			0, 
			0,
			(16*8)+32,
			32+32,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hSprite, TRUE);
		UpdateWindow( hSprite );
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hSprite, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}
}


void	Debugger_RegisterSpriteClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	WNDCLASSEX	SpriteWindowClass;

	SpriteWindowClass.cbSize = sizeof(WNDCLASSEX);
	SpriteWindowClass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC; 
	SpriteWindowClass.lpfnWndProc = SpriteWindowProc;
	SpriteWindowClass.cbClsExtra = 0;
	SpriteWindowClass.cbWndExtra = 0;
	SpriteWindowClass.hInstance = hInstance;
	SpriteWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	SpriteWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	SpriteWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	SpriteWindowClass.lpszMenuName = NULL;
	SpriteWindowClass.lpszClassName = CPCEMU_DEBUG_SPRITE_CLASS;
	SpriteWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&SpriteWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for dissassembly window");
	}
}



void	Debugger_RenderSprite(HWND hwnd,HDC hDC, int SpriteIndex)
{
char	BitmapData[16*8*32];
BITMAPINFO	*pBitmapInfo;
int		i;
//HDC	hDC;
RECT	ClientRect;
//char	*pSpriteData;
int	x,y;
int	j;
	// initialise space for header
	pBitmapInfo = (BITMAPINFO *)malloc(sizeof(BITMAPINFO) + sizeof(RGBQUAD)*256);

	if (pBitmapInfo!=NULL)
	{
		// initialise bitmap info
		pBitmapInfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		pBitmapInfo->bmiHeader.biWidth = 16*8;
		pBitmapInfo->bmiHeader.biHeight = 16*2;
		pBitmapInfo->bmiHeader.biPlanes = 1;
		pBitmapInfo->bmiHeader.biBitCount = 8;
		pBitmapInfo->bmiHeader.biCompression = 0; //DI_RGB;
		pBitmapInfo->bmiHeader.biXPelsPerMeter = 640;
		pBitmapInfo->bmiHeader.biYPelsPerMeter = 480;
		pBitmapInfo->bmiHeader.biClrUsed = 32;
		pBitmapInfo->bmiHeader.biClrImportant = 32;
		pBitmapInfo->bmiHeader.biSizeImage = 16*16; 

		pBitmapInfo->bmiColors[0].rgbReserved = 0;
		pBitmapInfo->bmiColors[0].rgbRed = 0;
		pBitmapInfo->bmiColors[0].rgbGreen = 0;
		pBitmapInfo->bmiColors[0].rgbBlue = 0;

		// setup colour palette
		for (i=1; i<16; i++)
		{
			pBitmapInfo->bmiColors[i].rgbReserved = 0;
//			pBitmapInfo->bmiColors[i].rgbRed = (unsigned char)(ASIC_GetRed(i+16)<<4);
//			pBitmapInfo->bmiColors[i].rgbGreen = (unsigned char)(ASIC_GetGreen(i+16)<<4);
//			pBitmapInfo->bmiColors[i].rgbBlue = (unsigned char)(ASIC_GetBlue(i+16)<<4);
		}


		for (j=0; j<2; j++)
		{
			for (i=0; i<8; i++)
			{
	//			pSpriteData = ASIC_GetSpriteDataAddr((j<<3)+i);

				for (y=0; y<16; y++)
				{
					for (x=0; x<16; x++)
					{
						
//						BitmapData[((1-j)*(pBitmapInfo->bmiHeader.biWidth*16)) + (i*16) + (((15-y)*pBitmapInfo->bmiHeader.biWidth)+x)] = ASIC_GetSpritePixel((j<<3)+i, x, y);
					}
				}
			}
		}


		GetClientRect(hwnd, &ClientRect);

	//	hDC = GetDC(hwnd);

		StretchDIBits(hDC,ClientRect.left,ClientRect.top,ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top,0,0,pBitmapInfo->bmiHeader.biWidth,pBitmapInfo->bmiHeader.biHeight,BitmapData,pBitmapInfo,DIB_RGB_COLORS, SRCCOPY);

	//	ReleaseDC(hwnd,hDC);

		free(pBitmapInfo);
	}
}

void	Debugger_RedrawSpriteWindow()
{
	if (hSprite!=NULL)
	{
		ForceRedraw(hSprite);
	}
}

/****************************************************************************/

#define CPCEMU_DEBUG_SHOWGFX_CLASS "ARNOLD_DEBUG_SHOWGFX_CLASS"

void	Debugger_RenderShowGfx(HWND hwnd,HDC);

HWND hShowGfx = NULL;
HWND hShowGfxToolbar = NULL;

TBBUTTON ShowGfxToolbarButtons[] =
{
    TOOLBAR_BUTTON_ENTRY(0,ID_BUTTON_SET_ADDR),
    TOOLBAR_BUTTON_ENTRY(1,ID_BUTTON_DECREASE_WIDTH),
    TOOLBAR_BUTTON_ENTRY(2,ID_BUTTON_MODE0),
    TOOLBAR_BUTTON_ENTRY(3,ID_BUTTON_MODE1),
    TOOLBAR_BUTTON_ENTRY(4,ID_BUTTON_MODE2),
	TOOLBAR_BUTTON_ENTRY(5,ID_BUTTON_MODE3),
	TOOLBAR_BUTTON_ENTRY(6,ID_BUTTON_INCREASE_WIDTH),
};

#define SHOWGFX_NUM_TOOLBAR_BUTTONS (sizeof(ShowGfxToolbarButtons)/sizeof(TBBUTTON))

#define SHOWGFX_TOOLBAR_BUTTON_WIDTH 16
#define SHOWGFX_TOOLBAR_BUTTON_HEIGHT 15


#define SHOWGFX_TOOLBAR_CONTROL_IDENTIFIER	3


void	Debugger_DestroyShowGfxWindow()
{
	if (hShowGfx!=NULL)
	{
		/* destroy it */
		DestroyWindow(hShowGfx);
		DestroyWindow(hShowGfxToolbar);
		hShowGfxToolbar = NULL;
		hShowGfx = NULL;
	}

}

long FAR PASCAL ShowGfxWindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;
    switch(iMsg)
    {


    case WM_CREATE:
		
	    hShowGfxToolbar = CreateToolbarEx(
		hwnd,
        WS_CHILD | WS_BORDER | WS_VISIBLE,	// | CCS_TOP,
        SHOWGFX_TOOLBAR_CONTROL_IDENTIFIER,
        SHOWGFX_NUM_TOOLBAR_BUTTONS,
		(HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE),
        IDR_TOOLBAR3,
        &ShowGfxToolbarButtons[0],
        SHOWGFX_NUM_TOOLBAR_BUTTONS,
        SHOWGFX_TOOLBAR_BUTTON_WIDTH,
        SHOWGFX_TOOLBAR_BUTTON_HEIGHT,
        SHOWGFX_TOOLBAR_BUTTON_WIDTH,
        SHOWGFX_TOOLBAR_BUTTON_HEIGHT,
        sizeof(TBBUTTON));

		break;


	case WM_COMMAND:
	{
		if ((long)lParam == (long)hShowGfxToolbar)
		{
			switch (LOWORD(wParam))
			{
				case ID_BUTTON_SET_ADDR:
				{
					int NewAddr;
					
					if (HexDialog(hwnd,&NewAddr))
					{
						SetWindowWord(hwnd, 0, (unsigned short)NewAddr);
					}

					Debugger_RedrawShowGfxWindow();
				}
				break;

				case ID_BUTTON_DECREASE_WIDTH:
					{
						int Width = GetWindowWord(hwnd, 2);

						Width=Width-1;

						if (Width<1)
							Width = 1;

						SetWindowWord(hwnd, 2, (unsigned short)Width);

						Debugger_RedrawShowGfxWindow();
					}
					break;

				case ID_BUTTON_INCREASE_WIDTH:
				{
						int Width = GetWindowWord(hwnd, 2);

						Width=Width+1;

						SetWindowWord(hwnd, 2, (unsigned short)Width);

						Debugger_RedrawShowGfxWindow();
				}
				break;

				case ID_BUTTON_MODE0:
					{
						SetWindowWord(hwnd, 4, 0);

						Debugger_RedrawShowGfxWindow();
					}
					break;

				case ID_BUTTON_MODE1:
				{
					SetWindowWord(hwnd,4,1);
					Debugger_RedrawShowGfxWindow();
				}
				break;

				case ID_BUTTON_MODE2:
					{
						SetWindowWord(hwnd,4,2);
						Debugger_RedrawShowGfxWindow();
					}
					break;

				case ID_BUTTON_MODE3:
					{
						SetWindowWord(hwnd,4,3);
						Debugger_RedrawShowGfxWindow();
					}
					break;
			}
		}
	}
	break;

		case WM_VSCROLL:
		{
			int ScrollCode = (int)LOWORD(wParam); // scroll bar value 
			int BaseAddr = GetWindowWord(hwnd,0);
			int Width = GetWindowWord(hwnd, 2);

			switch (ScrollCode)
			{

				case SB_TOP:
					break;

				case SB_BOTTOM:
					break;

				case SB_LINEDOWN:
					BaseAddr+= Width;
					BaseAddr &= 0x0ffff;
					break;
					
				case SB_LINEUP:
					{
					BaseAddr-=Width;
					BaseAddr &= 0x0ffff;
					}
					break;

				case SB_PAGEDOWN:
					BaseAddr+=(Width*200);
					//BaseAddr += (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_PAGEUP:
					BaseAddr-=(Width*200);
					//BaseAddr -= (MemDumpInfo.NoOfBytes*MemDumpInfo.NoOfCharsInHeight);
					BaseAddr &= 0x0ffff;
					break;

				case SB_THUMBPOSITION:
					break;

				case SB_THUMBTRACK:
					break;

	
			}

			SetWindowWord(hwnd, 0, (unsigned short)BaseAddr);

			Debugger_RedrawShowGfxWindow();

		}
		return TRUE;


    case WM_PAINT:
        {
			BeginPaint( hwnd, &PaintStruct);

			Debugger_RenderShowGfx(hwnd,PaintStruct.hdc);

			EndPaint( hwnd, &PaintStruct );
			return TRUE;
		}
		break;	

	case WM_SIZE:
		UpdateWindow(hwnd);

		SendMessage(hShowGfxToolbar, WM_SIZE, 0,0);
		
		return TRUE;

	case WM_ERASEBKGND:
		return 1;

	case WM_CLOSE:
	{
		Debugger_DestroyShowGfxWindow();
	}	
	break;

    case WM_DESTROY:
	{
		//Debugger_DestroyShowGfxWindow();
		DestroyWindow(hShowGfxToolbar);
	
	}
	break;

   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);

} 

void	Debugger_ShowGfx(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hShowGfx==NULL)
	{
		/* create window and show it */
		hShowGfx = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_SHOWGFX_CLASS,
			"Memory as Graphics",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_VSCROLL,
			0, 
			0,
			320,
			200,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hShowGfx, TRUE);
		UpdateWindow( hShowGfx );

		/* set addr */
		SetWindowWord(hShowGfx,0, 0x0);
		/* set width in bytes */
		SetWindowWord(hShowGfx,2, 16);
		/* set mode */
		SetWindowWord(hShowGfx,4, 1);

	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hShowGfx, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}
}


void	Debugger_RegisterShowGfxClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	WNDCLASSEX	ShowGfxWindowClass;

	ShowGfxWindowClass.cbSize = sizeof(WNDCLASSEX);
	ShowGfxWindowClass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC; 
	ShowGfxWindowClass.lpfnWndProc = ShowGfxWindowProc;
	ShowGfxWindowClass.cbClsExtra = 0;
	ShowGfxWindowClass.cbWndExtra = 6;
	ShowGfxWindowClass.hInstance = hInstance;
	ShowGfxWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	ShowGfxWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	ShowGfxWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	ShowGfxWindowClass.lpszMenuName = NULL;
	ShowGfxWindowClass.lpszClassName = CPCEMU_DEBUG_SHOWGFX_CLASS;
	ShowGfxWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&ShowGfxWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for ShowGfx window");
	}
}


void	Debugger_RenderShowGfx(HWND hwnd, HDC hDC)
{
#if 0
	char	BitmapData[320*200];
BITMAPINFO	*pBitmapInfo;
int		i;
//HDC	hDC;
RECT	ClientRect;
//char	*pSpriteData;
int	x; //,y;
int	j;

	int BaseAddr;
	int				Width;
	int				ModeIndex;
	PIXEL_DATA *pPixelData;
	int				PlotWidth = 320;

	// get address we are rendering from
	BaseAddr = GetWindowWord(hwnd, 0);
	Width = GetWindowWord(hwnd, 2);
	ModeIndex = GetWindowWord(hwnd, 4) & 3;

	if (Width>(PlotWidth>>3))
	{
		PlotWidth = 320>>3;
	}
	else
	{
		PlotWidth = Width;
	}

	pPixelData = CPC_GetModePixelData(ModeIndex);
	
	// initialise space for header
	pBitmapInfo = (BITMAPINFO *)malloc(sizeof(BITMAPINFO) + sizeof(RGBQUAD)*256);

	if (pBitmapInfo!=NULL)
	{
		// initialise bitmap info
		pBitmapInfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		pBitmapInfo->bmiHeader.biWidth = 320;
		pBitmapInfo->bmiHeader.biHeight = 200;
		pBitmapInfo->bmiHeader.biPlanes = 1;
		pBitmapInfo->bmiHeader.biBitCount = 8;
		pBitmapInfo->bmiHeader.biCompression = 0; //DI_RGB;
		pBitmapInfo->bmiHeader.biXPelsPerMeter = 640;
		pBitmapInfo->bmiHeader.biYPelsPerMeter = 480;
		pBitmapInfo->bmiHeader.biClrUsed = 16;
		pBitmapInfo->bmiHeader.biClrImportant = 16;
		pBitmapInfo->bmiHeader.biSizeImage = 320*200; 

		// setup colour palette to render memory graphics with
		//
		for (i=0; i<16; i++)
		{
			pBitmapInfo->bmiColors[i].rgbReserved = 0;
			pBitmapInfo->bmiColors[i].rgbRed = (unsigned char)(GateArray_GetRed(i)<<4);
			pBitmapInfo->bmiColors[i].rgbGreen = (unsigned char)(GateArray_GetGreen(i)<<4);
			pBitmapInfo->bmiColors[i].rgbBlue = (unsigned char)(GateArray_GetBlue(i)<<4);
		}

		memset(BitmapData, 0, 320*200);
		
		
		// if "sprite" method
		for (j=0; j<200; j++)
		{
			for (x=0; x<PlotWidth; x++)
			{
				int p;
				
				/* calc address to get graphics from */
				Z80_WORD ByteAddr = (unsigned short)(BaseAddr + x + (j*Width));
				/* get gfx byte */
				Z80_BYTE GfxByte = Z80_RD_MEM(ByteAddr);
				/* get pixel translation for this byte for selected mode */
				PIXEL_DATA 	*pBytePixelData = &pPixelData[GfxByte & 0x0ff];
				/* pointer to bitmap data to write to */
				unsigned char *pByteBitmap = (unsigned char *)(&BitmapData[(x*8)+((199-j)*320)]);
				
				/* write pixel index's to bitmap */
				for (p=0; p<8; p++)
				{
					pByteBitmap[p] = (unsigned char)pBytePixelData->Pixel[p];
				}
			}
		}

		GetClientRect(hwnd, &ClientRect);

		//hDC = GetDC(hwnd);

		StretchDIBits(hDC,ClientRect.left,ClientRect.top,ClientRect.right-ClientRect.left,ClientRect.bottom-ClientRect.top,0,0,pBitmapInfo->bmiHeader.biWidth,pBitmapInfo->bmiHeader.biHeight,BitmapData,pBitmapInfo,DIB_RGB_COLORS, SRCCOPY);

		//ReleaseDC(hwnd,hDC);

		free(pBitmapInfo);
	}
#endif
}

void	Debugger_RedrawShowGfxWindow()
{
	if (hShowGfx!=NULL)
	{
		ForceRedraw(hShowGfx);
	}
}



/****************************************************************************/

/*
void	Debugger_OpenCRTCDialog(HWND hwnd)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
	//HWND	hwnd;

	if (hCRTCDialog==NULL)
	{
		hCRTCDialog = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_DIALOG_CRTC), hwnd, CRTCDialogProc);

		ShowWindow(hCRTCDialog,TRUE);
		Debugger_UpdateCRTCDialog();
	}
	else
	{
		// window already shown - make it visible 
		SetWindowPos(hCRTCDialog, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
		ShowWindow(hCRTCDialog,TRUE);
	}
	//RegisterDialog(hDebuggerDialog);

}
*/

void	Debugger_Enable(HWND hParent, BOOL Status)
{
	if (Status)
	{
		Debugger_OpenDebugDialog();
	}
	else
	{
		Debugger_CloseDebugDialog();
	}

}

void	Debugger_UpdateDisplay()
{
	Z80_REGISTERS *R;

	// get registers
	R = Z80_GetReg();

	// update dissassembly
	Debugger_SetDissassembleAddress(R->PC.W.l);

	Debugger_UpdateDebugDialog();
	//Debugger_UpdateCRTCDialog();

	Debugger_UpdateCRTCInfo();
	Debugger_UpdateCPCInfo();
#if 0
	Debugger_UpdateCPCPLUSInfo();
#endif

	Debugger_RedrawSpriteWindow();
}


// sub-classed edit control

WNDPROC FloatEditOldProc = NULL;

long FAR PASCAL HexEditProc(HWND hWnd, WORD wMessage,WORD wParam,LONG lParam)
{
 
    switch (wMessage)
     {
 
          case WM_GETDLGCODE:
            return (DLGC_WANTALLKEYS |
                    CallWindowProc(FloatEditOldProc, hWnd, wMessage,
                                   wParam, lParam));
 
          case WM_CHAR:
          //Process this message to avoid message beeps.
         if ((wParam == VK_RETURN) || (wParam == VK_TAB))
           return 0;
            else
           return (CallWindowProc(FloatEditOldProc, hWnd,
                                     wMessage, wParam, lParam));
 
       case WM_KEYDOWN:
            if ((wParam == VK_RETURN) || (wParam == VK_TAB)) {
              PostMessage (GetParent(hWnd), WM_NEXTDLGCTL, 0, 0L);
              return FALSE;
            }
 
         return (CallWindowProc(FloatEditOldProc, hWnd, wMessage,
                                   wParam, lParam));
         break ;
 
       default:
            break;
 
     } /* end switch */

    return CallWindowProc(FloatEditOldProc,hWnd,wMessage,wParam,lParam);
}

/*
void	Debugger_Setup()
{

	Debug_SetState(DEBUG_STEP_INTO);

	{
		Z80_REGISTERS	*R;

		R = Z80_GetReg();

		// have a "open new mem dump window"
		// have a "open new dissassemble window"
		Debugger_OpenDebugDialog();
		Debugger_OpenMemdump(ApplicationHwnd);
		Debugger_SetMemDumpAddr(R->PC.W);
		Debugger_OpenDissassemble(ApplicationHwnd);
		Debugger_SetDissassembleAddr(R->PC.W);
	}
}
*/

#define ErrorMessage(ErrorText) \
	MessageBox(GetActiveWindow(),ErrorText,"Emulator Error",MB_OK)

void	DEBUG_DisplayError(char *pMessage)
{
		ErrorMessage(pMessage);
}

//#include <commdlg.h>


HWND hASICDialog = NULL;

void	Debugger_DestroyASICDialog()
{
	if (hASICDialog!=NULL)
	{
		DestroyWindow(hASICDialog);
		hASICDialog = NULL;
	}
}


BOOL CALLBACK  ASICDialogProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg)
    {
        
        case WM_CREATE:
			{
				HWND hListView;

				hListView = GetDlgItem(hwnd, IDC_LIST1);

				MyListView_AddColumn(hListView, "Sprite No.", 0);
				MyListView_AddColumn(hListView, "X", 1);
				MyListView_AddColumn(hListView, "Y", 2);
				MyListView_AddColumn(hListView, "X Mag", 3);
				MyListView_AddColumn(hListView, "Y Mag", 4);



			}

			return TRUE;


		case WM_CLOSE:
			Debugger_DestroyASICDialog();
			break;	//return TRUE;

		case WM_DESTROY:
//			hASICDialog = NULL;
			//DestroyWindow(hwnd);
			break; //return TRUE;

		default:
			break;

	}
    return FALSE;
}


void	ShowASICDialog(HWND hwnd)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);
	//HWND	hwnd;

	if (hASICDialog==NULL)
	{
		hASICDialog = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_DIALOG_PLUS_HARDWARE), hwnd, ASICDialogProc);

		ShowWindow(hASICDialog,TRUE);
	}
}


HWND hDebugHooksDialog = NULL;

//#include "gdebug.c"

void	Debugger_UpdateDebugHooksDialog(void)
{
	if (hDebugHooksDialog)
	{
#ifdef DEBUG_HOOKS
		SetCheckButtonState(hDebugHooksDialog, IDC_CHECK_MEMORY_READ, DebugHooks_ReadMemory_GetActiveState());
		SetCheckButtonState(hDebugHooksDialog, IDC_CHECK_MEMORY_WRITE, DebugHooks_WriteMemory_GetActiveState());
		SetCheckButtonState(hDebugHooksDialog, IDC_CHECK_IO_READ, DebugHooks_ReadIO_GetActiveState());
		SetCheckButtonState(hDebugHooksDialog, IDC_CHECK_IO_WRITE, DebugHooks_WriteIO_GetActiveState());
#endif
	}
}

BOOL CALLBACK  ConditionSetDialogProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
	{
		case WM_CREATE:
			break;

		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDOK:
				{
					EndDialog(hwnd, 1);
				}
				return TRUE;

				case IDCANCEL:
				{
					EndDialog(hwnd, 0);
				}
				return TRUE;
			}
		}

		case WM_CLOSE:
			break;

		case WM_DESTROY:
			break;
	}

	return FALSE;
}




void	OpenConditionSetDialog(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	DialogBox(hInstance, 
			MAKEINTRESOURCE(IDD_DIALOG_DEBUG_CONDITION),
			hParent,
			ConditionSetDialogProc);
}

BOOL CALLBACK  DebugHooksConditionsDialogProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg)
    {
        
        case WM_CREATE:
            return TRUE;

        case WM_COMMAND:
        {
			case IDC_BUTTON_ADD:
			{
				OpenConditionSetDialog(hwnd);
			}
			break;
		}
		break;

		
		case WM_CLOSE:
			DestroyWindow(hwnd);
			break;
		case WM_DESTROY:
			break;
	}

    return FALSE;
}





HWND	OpenConditionListDialog(HWND hParent, char *DialogTitleText)
{
	HWND hDialog;

	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	hDialog = CreateDialog (hInstance, 
		MAKEINTRESOURCE(IDD_DIALOG_CONDITIONS), 0, 
		DebugHooksConditionsDialogProc);

	if (hDialog!=NULL)
	{
		ShowWindow(hDialog, TRUE);
		SetWindowText(hDialog, DialogTitleText);
	}

	return hDialog;
}
		

BOOL CALLBACK  DebugHooksDialogProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg)
    {
        
        case WM_CREATE:
            return TRUE;

        case WM_COMMAND:
        {
			if (HIWORD(wParam)==BN_CLICKED)
			{
				/* check box clicked */

				switch (LOWORD(wParam))
				{
#ifdef DEBUG_HOOKS
				case IDC_CHECK_MEMORY_READ:
					{
						/* get check state */
						int CheckState;

						CheckState = SendDlgItemMessage(hwnd,LOWORD(wParam), BM_GETCHECK,0,0);

						if (CheckState == BST_CHECKED)
						{
							/* checked */
							DebugHooks_ReadMemory_Active(TRUE);
							Debug_ReadMemory_Comparison_Enable(TRUE);
						}
						else
						{
							/* not checked */
							DebugHooks_ReadMemory_Active(FALSE);
							Debug_ReadMemory_Comparison_Enable(FALSE);
						}
					}
					break;
				

					case IDC_CHECK_MEMORY_WRITE:
					{
						/* get check state */
						int CheckState;

						CheckState = SendDlgItemMessage(hwnd,LOWORD(wParam), BM_GETCHECK,0,0);

						if (CheckState == BST_CHECKED)
						{
							/* checked */
							DebugHooks_WriteMemory_Active(TRUE);
							Debug_WriteMemory_Comparison_Enable(TRUE);
						}
						else
						{
							/* not checked */
							DebugHooks_WriteMemory_Active(FALSE);
							Debug_WriteMemory_Comparison_Enable(FALSE);
						}
					}
					break;

					case IDC_CHECK_IO_READ:
					{
						/* get check state */
						int CheckState;

						CheckState = SendDlgItemMessage(hwnd,LOWORD(wParam), BM_GETCHECK,0,0);

						if (CheckState == BST_CHECKED)
						{
							/* checked */
							DebugHooks_ReadIO_Active(TRUE);
							Debug_ReadIO_Comparison_Enable(TRUE);
						}
						else
						{
							/* not checked */
							DebugHooks_ReadIO_Active(FALSE);
							Debug_ReadIO_Comparison_Enable(FALSE);
						}
					}
					break;

					case IDC_CHECK_IO_WRITE:
					{
						/* get check state */
						int CheckState;

						CheckState = SendDlgItemMessage(hwnd,LOWORD(wParam), BM_GETCHECK,0,0);

						if (CheckState == BST_CHECKED)
						{
							/* checked */
							DebugHooks_WriteIO_Active(TRUE);
							Debug_WriteIO_Comparison_Enable(TRUE);
						}
						else
						{
							/* not checked */
							DebugHooks_WriteIO_Active(FALSE);
							Debug_WriteIO_Comparison_Enable(FALSE);
						}

					}
					break;
#endif

					case IDC_BUTTON_MEMORY_READ:
					{
						OpenConditionListDialog(hwnd,
								"Memory Read Conditions");
					}
					return TRUE;

					case IDC_BUTTON_MEMORY_WRITE:
					{
						OpenConditionListDialog(hwnd,
								"Memory Write Conditions");
					}
					return TRUE;

					case IDC_BUTTON_IO_READ:
					{
						OpenConditionListDialog(hwnd,
								"IO Read Conditions");
					}
					return TRUE;

					case IDC_BUTTON_IO_WRITE:
					{
						OpenConditionListDialog(hwnd,
								"IO Write Conditions");
					}
					return TRUE;
				}
			}
		}
		break;
		
		case WM_CLOSE:
			DestroyWindow(hwnd);
			break;
		case WM_DESTROY:
			break;
	}

    return FALSE;
}

void	Debugger_DebugHooks(HWND hwnd)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hwnd,GWL_HINSTANCE);

	hDebugHooksDialog = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_DIALOG_DEBUG_HOOKS), 0, DebugHooksDialogProc);

	if (hDebugHooksDialog!=NULL)
	{
		ShowWindow(hDebugHooksDialog,TRUE);

		Debugger_UpdateDebugHooksDialog();
	}
}

/******************** RENDERING STUFF TO WINDOW **************************/


static int RenderFontHeight;
static int RenderFontWidth;
static HDC RenderDC;
static 	HFONT hFont,hOldFont;
static  HPEN hPen, hOldPen;

POINT	TextCoordsToPixelCoords(int X, int Y)
{
	POINT	PixelCoords;

	PixelCoords.x = X*RenderFontWidth;
	PixelCoords.y = Y*RenderFontHeight;

	return PixelCoords;
} 

void	PrintString(int X, int Y, char *pString)
{
	POINT PlotPoint;

	PlotPoint = TextCoordsToPixelCoords(X,Y);

	TextOut(RenderDC, PlotPoint.x, 
		PlotPoint.y, pString,strlen(pString));
}

static char DisplayString[256];

void	TextWindow_Ready(HWND hwnd, PAINTSTRUCT *pPaintStruct)
{
	RECT WindowRect;
	TEXTMETRIC	FontMetric;

	RenderDC = BeginPaint( hwnd, pPaintStruct);

	hFont = GetStockObject(ANSI_FIXED_FONT);
	hPen = GetStockObject(BLACK_BRUSH);

	hOldFont = SelectObject(RenderDC, hFont);
	hOldPen = SelectObject(RenderDC, hPen);

	GetTextMetrics(RenderDC,&FontMetric);

	RenderFontWidth = FontMetric.tmMaxCharWidth;
	RenderFontHeight = FontMetric.tmHeight;

	GetClientRect(hwnd,&WindowRect);

	FillRect(RenderDC,&WindowRect,GetStockObject(WHITE_BRUSH));
}

void	TextWindow_Finish(HWND hwnd, PAINTSTRUCT *pPaintStruct)
{
	SelectObject(RenderDC,hOldFont);
	SelectObject(RenderDC,hOldPen);

	DeleteObject(hFont);

	DeleteObject(hPen);

	EndPaint(hwnd, pPaintStruct);
}


/******************** CPC INFO WINDOW ************************************/

void	CPC_Info_Display()
{
	int X,Y;
	int i;

	/* Dump PSG Registers */

	{
		X=0;
		Y=0;
		
		sprintf(DisplayString, "PSG");

		PrintString(X,Y, DisplayString);

		for (i=0; i<16; i++)
		{
//			sprintf(DisplayString, "%1x: %02x",i, PSG_GetRegisterData(i));

			PrintString(X, Y+2+i, DisplayString);
		}
	}

	/* GATE ARRAY PENS */
	{
		X = 10;
		Y = 0;

		sprintf(DisplayString,"GA PENS");

		PrintString(X, Y, DisplayString);
		
		for (i=0; i<17; i++)
		{
			if (i!=16)
			{
//				sprintf(DisplayString, "%1x: %02x",i, GateArray_GetPaletteColour(i));
			}
			else
			{
//				sprintf(DisplayString, "B: %02x",GateArray_GetPaletteColour(i));
			}

			PrintString(X, Y+2+i, DisplayString);
		}
	}

	/* GATE ARRAY SETTINGS */
	{
		X = 20;
		Y = 0;

		sprintf(DisplayString,"GA");
		PrintString(X,Y, DisplayString);

//		sprintf(DisplayString,"0x000: %02x PPR", GateArray_GetSelectedPen());
		PrintString(X,Y+2, DisplayString);

		//sprintf(DisplayString,"0x040: %02x PMEM", GateArray_GetSelectedPen());
		//PrintString(X,Y+3, DisplayString);

//		sprintf(DisplayString,"0x080: %02x MRER", GateArray_GetModeAndRomConfiguration());
		PrintString(X,Y+4, DisplayString);

//		sprintf(DisplayString,"0x0c0: %02x RAM", GateArray_GetRamConfiguration());
		PrintString(X,Y+5, DisplayString);

	}
}

#ifdef ASIC_DEBUGGING
/******************** CPC PLUS WINDOW ************************************/

#define DMA_OPCODES_SHOWN	4

void	CPCPLUS_Info_Display()
{
	int X,Y;
	int i;

	/* Dump DMA Registers */

	{
		{

			int dma_channel;

			X = 0;
			Y = 0;
			
			for (dma_channel=0; dma_channel<3; dma_channel++)
			{
				int BaseY = (dma_channel*(DMA_OPCODES_SHOWN+2+1));

				sprintf(DisplayString, "DMA%01x",dma_channel);

				PrintString(X,BaseY, DisplayString);

				for (i=0; i<DMA_OPCODES_SHOWN; i++)
				{
					sprintf(DisplayString, "%s",
						ASIC_DebugDMACommand(dma_channel, i));

					PrintString(X, BaseY+2+i, DisplayString);
				}
			}
		}
	}

	/* colours */
	{
		X = 20;
		Y = 0;

		sprintf(DisplayString,"PALETTE RGB444");
		PrintString(X, Y, DisplayString);
		
		for (i=0; i<16; i++)
		{
			sprintf(DisplayString, "%02d: %01x%01x%01x  %02d: %01x%01x%01x", 
				i, ASIC_GetRed(i), ASIC_GetGreen(i), ASIC_GetBlue(i),
				(i+16), ASIC_GetRed(i+16),ASIC_GetGreen(i+16), ASIC_GetBlue(i+16));

			PrintString(X, Y+2+i, DisplayString);
		}
	}

	/* regs */
	{

		X = 40;
		Y = 0;

		sprintf(DisplayString,"PRI:    %02x",ASIC_GetPRI());
		PrintString(X,Y,DisplayString);

		sprintf(DisplayString,"SPLT:   %02x",ASIC_GetSPLT());
		PrintString(X,Y+1,DisplayString);

		sprintf(DisplayString,"SSA:  %04x",ASIC_GetSSA());
		PrintString(X,Y+2,DisplayString);

		sprintf(DisplayString,"SSCR:   %02x",ASIC_GetSSCR());
		PrintString(X,Y+3,DisplayString);

		sprintf(DisplayString,"IVR:    %02x",ASIC_GetIVR());
		PrintString(X,Y+4, DisplayString);
	}
}
#endif

/************************** CRTC INFO ***********************************/


void	CRTC_Info_Display()
{
	int X,Y;
	int i;

	/* register data */
	{
		X = 0;
		Y = 0;
		
		for (i=0; i<18; i++)
		{
//			sprintf(DisplayString,"R%02d: %02x", i, CRTC_GetRegisterData(i));
			PrintString(X,Y+i, DisplayString);
		}
	}
/*
	{
		CRTC_INTERNAL_STATE *pCRTC_State;

		X = 10;
		Y = 0;

		pCRTC_State = CRTC_GetInternalState();

		sprintf(DisplayString,"HC: %02x", pCRTC_State->HCount);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"LC: %02x", pCRTC_State->LineCounter);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"RC: %02x", pCRTC_State->RasterCounter);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"HS-WIDTH: %02x", pCRTC_State->HorizontalSyncWidth);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"VS-WIDTH: %02x", pCRTC_State->VerticalSyncWidth);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"HS-C: %02x", pCRTC_State->HorizontalSyncCount);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString,"VS-C: %02x", pCRTC_State->VerticalSyncCount);
		PrintString(X,Y, DisplayString);
		Y++;
		sprintf(DisplayString, "ILC: %02x",pCRTC_State->GA_State.InterruptLineCount);
		PrintString(X,Y, DisplayString);
		Y++;
		//sprintf(DisplayString, "LAV: %0d",CRTC_State.MonitorState.LinesAfterVsync);
		//PrintString(X,Y, DisplayString);
*/
/*
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_HSYNCSTATE, CRTC_State.Flags & CRTC_HS_FLAG);
	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VSYNCSTATE, CRTC_State.Flags & CRTC_VS_FLAG);

	SetDlgHexWord(hCRTCDialog,IDC_EDIT_CRTC_MA, CRTC_State.MA_AtLineStart);
	SetDlgHexWord(hCRTCDialog,IDC_EDIT_CRTC_MEMORYADDR, CRTC_State.CurrentVideoMemoryAddress);


	SetDlgHexByte(hCRTCDialog,IDC_EDIT_CRTC_VADJUSTCOUNT, CRTC_State.VerticalTotalAdjustCount);
*/
//	}

}


long FAR PASCAL CPC_Info_WindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;

    switch(iMsg)
    {
	    case WM_CREATE:
			break;

		case WM_PAINT:
        {
			TextWindow_Ready(hwnd,&PaintStruct);

			CPC_Info_Display();

			TextWindow_Finish(hwnd, &PaintStruct);

			return TRUE;
		}

	case WM_ERASEBKGND:
		return 1;


	case WM_SIZE:
		return TRUE;

	case WM_CLOSE:
		break;

    case WM_DESTROY:
		break;
   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);
} 

#ifdef ASIC_DEBUGGING
long FAR PASCAL CPCPLUS_Info_WindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;

    switch(iMsg)
    {
	    case WM_CREATE:
			break;

		case WM_PAINT:
        {
			TextWindow_Ready(hwnd,&PaintStruct);

			CPCPLUS_Info_Display();

			TextWindow_Finish(hwnd, &PaintStruct);

			return TRUE;
		}

	case WM_ERASEBKGND:
		return 1;


	case WM_SIZE:
		return TRUE;

	case WM_CLOSE:
		break;

    case WM_DESTROY:
		break;
   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);
} 
#endif

long FAR PASCAL CRTC_Info_WindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;

    switch(iMsg)
    {
	    case WM_CREATE:
			break;

		case WM_PAINT:
        {
			TextWindow_Ready(hwnd,&PaintStruct);

			CRTC_Info_Display();

			TextWindow_Finish(hwnd, &PaintStruct);

			return TRUE;
		}

	case WM_ERASEBKGND:
		return 1;


	case WM_SIZE:
		return TRUE;

	case WM_CLOSE:
		break;

    case WM_DESTROY:
		break;
   }

    return DefWindowProc(hwnd, iMsg, wParam, lParam);
} 



HWND hCPCInfo;
#define CPCEMU_DEBUG_CPCINFO_CLASS "ARNOLD_DEBUG_CPCINFO_CLASS"

void	Debugger_UpdateCPCInfo(void)
{
	if (hCPCInfo!=NULL)
	{
		ForceRedraw(hCPCInfo);
	}
}



void	Debugger_RegisterCPCInfoClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);
	
	WNDCLASSEX	DebugWindowClass;

	DebugWindowClass.cbSize = sizeof(WNDCLASSEX);
	DebugWindowClass.style = CS_HREDRAW | CS_VREDRAW;	// | CS_OWNDC; 
	DebugWindowClass.lpfnWndProc = CPC_Info_WindowProc;
	DebugWindowClass.cbClsExtra = 0;
	DebugWindowClass.cbWndExtra = 0;
	DebugWindowClass.hInstance = hInstance;
	DebugWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	DebugWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	DebugWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	DebugWindowClass.lpszMenuName = NULL;
	DebugWindowClass.lpszClassName = CPCEMU_DEBUG_CPCINFO_CLASS;
	DebugWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&DebugWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for memory dump window");
	}
}


void Debugger_OpenCPCInfo(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hCPCInfo==NULL)
	{
		hCPCInfo = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_CPCINFO_CLASS,
			"CPC Info",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE,
			CW_USEDEFAULT, 
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hCPCInfo, TRUE);
		UpdateWindow( hCPCInfo);
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hCPCInfo, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}
}

#ifdef ASIC_DEBUGGING
HWND hCPCPLUSInfo;
#define CPCEMU_DEBUG_CPCPLUSINFO_CLASS "ARNOLD_DEBUG_CPCPLUSINFO_CLASS"


void	Debugger_UpdateCPCPLUSInfo(void)
{
	if (hCPCPLUSInfo!=NULL)
	{
		ForceRedraw(hCPCPLUSInfo);
	}
}


void	Debugger_RegisterCPCPLUSInfoClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);
	
	WNDCLASSEX	DebugWindowClass;

	DebugWindowClass.cbSize = sizeof(WNDCLASSEX);
	DebugWindowClass.style = CS_HREDRAW | CS_VREDRAW;	// | CS_OWNDC; 
	DebugWindowClass.lpfnWndProc = CPCPLUS_Info_WindowProc;
	DebugWindowClass.cbClsExtra = 0;
	DebugWindowClass.cbWndExtra = 0;
	DebugWindowClass.hInstance = hInstance;
	DebugWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	DebugWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	DebugWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	DebugWindowClass.lpszMenuName = NULL;
	DebugWindowClass.lpszClassName = CPCEMU_DEBUG_CPCPLUSINFO_CLASS;
	DebugWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&DebugWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for memory dump window");
	}
}

void Debugger_OpenCPCPlusInfo(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hCPCPLUSInfo==NULL)
	{
		hCPCPLUSInfo = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_CPCPLUSINFO_CLASS,
			"CPC PLUS Info",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE,
			CW_USEDEFAULT, 
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hCPCPLUSInfo, TRUE);
		UpdateWindow( hCPCPLUSInfo);
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hCPCInfo, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}
}
#endif


HWND hCRTCInfo;
#define CPCEMU_DEBUG_CRTCINFO_CLASS "ARNOLD_DEBUG_CRTCINFO_CLASS"


void	Debugger_UpdateCRTCInfo(void)
{
	if (hCRTCInfo!=NULL)
	{
		ForceRedraw(hCRTCInfo);
	}
}

void	Debugger_RegisterCRTCInfoClass(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);
	
	WNDCLASSEX	DebugWindowClass;

	DebugWindowClass.cbSize = sizeof(WNDCLASSEX);
	DebugWindowClass.style = CS_HREDRAW | CS_VREDRAW;	// | CS_OWNDC; 
	DebugWindowClass.lpfnWndProc = CRTC_Info_WindowProc;
	DebugWindowClass.cbClsExtra = 0;
	DebugWindowClass.cbWndExtra = 0;
	DebugWindowClass.hInstance = hInstance;
	DebugWindowClass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	DebugWindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
	DebugWindowClass.hbrBackground = GetStockObject(GRAY_BRUSH); //NULL; //GetStockObject(COLOR_APPWORKSPACE);
	DebugWindowClass.lpszMenuName = NULL;
	DebugWindowClass.lpszClassName = CPCEMU_DEBUG_CRTCINFO_CLASS;
	DebugWindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);

	if (RegisterClassEx(&DebugWindowClass)==0)
	{
		Debug_ErrorMessage("Failed to register class for memory dump window");
	}
}


void Debugger_OpenCRTCInfo(HWND hParent)
{
	HINSTANCE hInstance = (HINSTANCE)GetWindowLong(hParent,GWL_HINSTANCE);

	if (hCRTCInfo==NULL)
	{
		hCRTCInfo = CreateWindowEx(
			WS_EX_OVERLAPPEDWINDOW,
			CPCEMU_DEBUG_CRTCINFO_CLASS,
			"CRTC Info",
			WS_OVERLAPPEDWINDOW | WS_VISIBLE,
			CW_USEDEFAULT, 
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			NULL,
			hInstance,
			NULL );

		ShowWindow( hCRTCInfo, TRUE);
		UpdateWindow( hCRTCInfo);
	}
	else
	{
		/* window already shown - make it visible */
		SetWindowPos(hCRTCInfo, HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	}
}
