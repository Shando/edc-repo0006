/* 
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *  
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
//#define WIN32_LEAN_AND_MEAN
//#define WIN32_EXTRA_LEAN
#include <windows.h>
//#include <commctl.h>
//#include "comdlg.h"
#include "resource.h"
//#include <windows.h>
#include <shlobj.h>
//#define DRAGANDDROP
#include "filedlg.h"

//#define DO_DEBUG

//#define EXTERNAL2

#include <direct.h>
#include "../ep/debugger/gdebug.h"
#include "joy.h"
#include "ziphandle.h"
#include "commctrl.h"
#include "detectos.h"
#include "../ep/host.h"
#include "directx/graphlib.h"
#include "myapp.h"
#include "debugger.h"
int	WindowWidth;
int WindowHeight;
RECT WindowRectBeforeMinimize;
BOOL Minimized = FALSE;
// for drag and drop
#include <shellapi.h>
#ifdef CRT_DEBUG
#include <crtdbg.h>
#endif
#include "../ep/ep.h"
#include "../ep/render.h"
#include "../ep/z80/z80.h"

#include "directx/di.h"
#include "directx/dd.h"
#include "directx/ds.h"

#define APPLICATION_CLASS_NAME "ArnoldEmu"
#define APP_ERROR_TEXT	"Arnold Emulator Error"

HMENU hAppMenu;
BOOL ApplicationIsActive;
BOOL	ApplicationHasFocus;

HINSTANCE hCommonControls;
HWND ApplicationHwnd;
static HINSTANCE AppInstance;

#define IDSTATUSWINDOW			1

BOOL	WindowedMode = TRUE;
int ScreenResX;
int ScreenResY;

BOOL	DoNotScanKeyboard = TRUE;

extern int	Host_LockSpeed;


/*=====================================================================================*/

/********************************************************************************
 KEYBOARD 
 ********************************************************************************/

#include <dinput.h>
#include "../ep/ep.h"
int KeyboardRemapData[]=
{
	EP_KEY_NULL,			//0x00
	EP_KEY_ESC,  // DIK_ESCAPE          0x01
	EP_KEY_1, // DIK_1               0x02
	EP_KEY_2, // DIK_2               0x03
	EP_KEY_3, // DIK_3               0x04
	EP_KEY_4,	// DIK_4               0x05
	EP_KEY_5,	// DIK_5               0x06
	EP_KEY_6,	// DIK_6               0x07
	EP_KEY_7,	// DIK_7               0x08
	EP_KEY_8,	// DIK_8               0x09
	EP_KEY_9,	// DIK_9               0x0A
	EP_KEY_0,	// DIK_0               0x0B
	EP_KEY_MINUS,	// DIK_MINUS           0x0C    // - on main keyboard //
	EP_KEY_NULL,	// DIK_EQUALS          0x0D
	EP_KEY_ERASE,	// DIK_BACK            0x0E    // backspace //
	EP_KEY_TAB,	// DIK_TAB             0x0F
	EP_KEY_Q,	// DIK_Q               0x10
	EP_KEY_W,	// DIK_W               0x11
	EP_KEY_E,	// DIK_E               0x12
	EP_KEY_R,	// DIK_R               0x13
	EP_KEY_T,	// DIK_T               0x14
	EP_KEY_Y,	// DIK_Y               0x15
	EP_KEY_U,	// DIK_U               0x16
	EP_KEY_I,	// DIK_I               0x17
	EP_KEY_O,	// DIK_O               0x18
	EP_KEY_P,	// DIK_P               0x19
	EP_KEY_OPEN_SQUARE_BRACKET,	// DIK_LBRACKET        0x1A
	EP_KEY_CLOSE_SQUARE_BRACKET,	// DIK_RBRACKET        0x1B
	EP_KEY_ENTER,	// DIK_RETURN          0x1C    // Enter on main keyboard //
	EP_KEY_CONTROL,	// DIK_LCONTROL        0x1D
	EP_KEY_A,	// DIK_A               0x1E
	EP_KEY_S,	// DIK_S               0x1F
	EP_KEY_D,	// DIK_D               0x20
	EP_KEY_F,	// DIK_F               0x21
	EP_KEY_G,	// DIK_G               0x22
	EP_KEY_H,	// DIK_H               0x23
	EP_KEY_J,	// DIK_J               0x24
	EP_KEY_K,	// DIK_K               0x25
	EP_KEY_L,	// DIK_L               0x26
	EP_KEY_COLON,	// DIK_SEMICOLON       0x27
	EP_KEY_AT,	// DIK_APOSTROPHE      0x28
	EP_KEY_SEMICOLON,	// DIK_GRAVE           0x29    // accent grave //
	EP_KEY_LSHIFT,	// DIK_LSHIFT          0x2A
	EP_KEY_BACKSLASH,	// DIK_BACKSLASH       0x2B
	EP_KEY_Z,	// DIK_Z               0x2C
	EP_KEY_X,	// DIK_X               0x2D
	EP_KEY_C,	// DIK_C               0x2E
	EP_KEY_V,	// DIK_V               0x2F
	EP_KEY_B,	// DIK_B               0x30
	EP_KEY_N,	// DIK_N               0x31
	EP_KEY_M,	// DIK_M               0x32
	EP_KEY_COMMA,	// DIK_COMMA           0x33
	EP_KEY_DOT,	// DIK_PERIOD          0x34    // . on main keyboard //
	EP_KEY_FORWARD_SLASH,	// DIK_SLASH           0x35    // / on main keyboard //
	EP_KEY_RSHIFT,	// DIK_RSHIFT          0x36
	EP_KEY_NULL,		// DIK_MULTIPLY        0x37    // * on numeric keypad //
	EP_KEY_ALT,		// DIK_LMENU           0x38    // left Alt //
	EP_KEY_SPACE,	// DIK_SPACE           0x39
	EP_KEY_LOCK,	// DIK_CAPITAL         0x3A
	EP_KEY_NULL,		// DIK_F1              0x3B
	EP_KEY_NULL,		// DIK_F2              0x3C
	EP_KEY_NULL,		// DIK_F3              0x3D
	EP_KEY_NULL,		// DIK_F4              0x3E
	EP_KEY_NULL,		// DIK_F5              0x3F
	EP_KEY_NULL,		// DIK_F6              0x40
	EP_KEY_NULL,		// DIK_F7              0x41
	EP_KEY_NULL,		// DIK_F8              0x42
	EP_KEY_NULL,		// DIK_F9              0x43
	EP_KEY_NULL,		// DIK_F10             0x44
	EP_KEY_NULL,		// DIK_NUMLOCK         0x45
	EP_KEY_NULL,		// DIK_SCROLL          0x46    // Scroll Lock //
	EP_KEY_F7,	// DIK_NUMPAD7         0x47
	EP_KEY_F8,	// DIK_NUMPAD8         0x48
	EP_KEY_NULL,	// DIK_NUMPAD9         0x49
	EP_KEY_NULL,		// DIK_SUBTRACT        0x4A    // - on numeric keypad //
	EP_KEY_F4,	// DIK_NUMPAD4         0x4B
	EP_KEY_F5,	// DIK_NUMPAD5         0x4C
	EP_KEY_NULL,		// DIK_NUMPAD6         0x4D
	EP_KEY_NULL,		// DIK_ADD             0x4E    // + on numeric keypad //
	EP_KEY_F1,	// DIK_NUMPAD1         0x4F
	EP_KEY_F2,	// DIK_NUMPAD2         0x50
	EP_KEY_F3,	// DIK_NUMPAD3         0x51
	EP_KEY_NULL,	// DIK_NUMPAD0         0x52
	EP_KEY_NULL,	// DIK_DECIMAL         0x53    // . on numeric keypad //
	EP_KEY_NULL,		// DIK_F11             0x57
	EP_KEY_NULL		// DIK_F12             0x58
};

#define NUM_KEYS	(sizeof(KeyboardRemapData)/sizeof(int))

int EmulatedJoystick = 0;

void	DoEmulatedJoystick()
{
//#ifdef WESTPHASER
//	// fire
//	if (IsKeyPressed(DIK_NUMPAD5))
//	{
//		WestPhaser_SetCoordinates(0,0);
//		WestPhaser_Trigger();
//	}
//#else



	// joystick emulated using Keypad

	// left
	if (IsKeyPressed(DIK_NUMPAD4))
	{
		Enterprise_SetControl(EP_KEY_JOY_LEFT);
	}

	
	// right
	if (IsKeyPressed(DIK_NUMPAD6))
	{
		Enterprise_SetControl(EP_KEY_JOY_RIGHT);
	}

	// up
	if (IsKeyPressed(DIK_NUMPAD8))
	{
		Enterprise_SetControl(EP_KEY_JOY_UP);
	}
	
	
	// down
	if (IsKeyPressed(DIK_NUMPAD2))
	{
		Enterprise_SetControl(EP_KEY_JOY_DOWN);
	}
	
	// fire
//	if (IsKeyPressed(DIK_NUMPAD5))
//	{
//		Enterprise_SetControl(EP_KEY_JOY_FIRE1);
//	}
	
//	// fire 2
//	if (IsKeyPressed(DIK_NUMPAD0))
//	{
//		Enterprise_SetControl(EP_KEY_JOY_FIRE2);
//	}
//#endif
}

#include "joy.h"


void	ScanJoyPad()
{

	JOY_STATE_DIGITAL	JoystickState;

	Joystick_Read();
	Joystick_StateDigital(&JoystickState);

#ifndef EXTERNAL2
	if (JoystickState.Left)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK1_LEFT);
	}
	
	if (JoystickState.Right)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK1_RIGHT);
	}
	
	if (JoystickState.Up)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK1_UP);
	}

	if (JoystickState.Down)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK1_DOWN);
	}

	if (JoystickState.Buttons)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK1_FIRE);
	}
#else
	if (JoystickState.Left)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK2_LEFT);
	}
	
	if (JoystickState.Right)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK2_RIGHT);
	}
	
	if (JoystickState.Up)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK2_UP);
	}

	if (JoystickState.Down)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK2_DOWN);
	}

	if (JoystickState.Buttons)
	{
		Enterprise_SetControl(EP_KEY_EXTERNAL_JOYSTICK2_FIRE);
	}
#endif

//
//	if (JoystickState.Buttons & 0x0002)
//	{
//		Enterprise_SetControl(EP_KEY_JOY_FIRE2);
//	}

}

BOOL	ToggleKeyPressed = FALSE;

void	DoKeyboard()
{
	int	i;

	Enterprise_ResetControllers();
	
	for (i=0; i<NUM_KEYS; i++)
	{
		if (IsKeyPressed(i))
		{
			Enterprise_SetControl(KeyboardRemapData[i]);
		}
		
	}

	if (IsKeyPressed(DIK_RCONTROL))
	{
		Enterprise_SetControl(EP_KEY_CONTROL);
	}

	if (IsKeyPressed(DIK_DELETE))
	{
		Enterprise_SetControl(EP_KEY_DEL);
	}

	if (IsKeyPressed(DIK_INSERT))
	{
		Enterprise_SetControl(EP_KEY_INSERT);
	}

	if (IsKeyPressed(DIK_RMENU))
	{
		Enterprise_SetControl(EP_KEY_ALT);
	}

	if (IsKeyPressed(DIK_END))
	{
		Enterprise_SetControl(EP_KEY_STOP);
	}

	if (IsKeyPressed(DIK_CAPSLOCK))
	{
		Enterprise_SetControl(EP_KEY_LOCK);
	}


//
	// prior and next are page up, page down                                                                                                                                                                           
//	if (IsKeyPressed(DIK_NEXT))
//	{
//		Enterprise_SetControl(EP_KEY_COPY);
//	}
//
//	if (IsKeyPressed(DIK_NUMPADENTER))
//	{
//		Enterprise_SetControl(EP_KEY_SMALL_ENTER);
//	}

	if (IsKeyPressed(DIK_SCROLL))
	{
		Enterprise_SetControl(EP_KEY_HOLD);
	}

	if (IsKeyPressed(DIK_UP))
	{
		Enterprise_SetControl(EP_KEY_JOY_UP);
	}

	if (IsKeyPressed(DIK_DOWN))
	{
		Enterprise_SetControl(EP_KEY_JOY_DOWN);
	}

	if (IsKeyPressed(DIK_LEFT))
	{
		Enterprise_SetControl(EP_KEY_JOY_LEFT);
	}

	
	if (IsKeyPressed(DIK_RIGHT))
	{
		Enterprise_SetControl(EP_KEY_JOY_RIGHT);
	}

	if (IsKeyPressed(DIK_F5))
	{
		Enterprise_Reset();
	}

#if LOGFILE
	if (IsKeyPressed(DIK_F10))
	{
		Nick_ShowLPT(logfile);
	}
#endif

	
//	if (IsKeyPressed(DIK_F4))
//	{
//		if (!ToggleKeyPressed)
//		{
//			if (Windowed)
//			{
//				CPCEMU_SetFullScreen();
//			}
//			else
//			{
//				CPCEMU_SetWindowed();
//			}
//		}
//
//		ToggleKeyPressed = TRUE;
///	}
//	else
//	{
//		ToggleKeyPressed = FALSE;
//	}
//
	//DoEmul
	//	pScanJoystick();

	ScanJoyPad();
  }

int CALLBACK GetDirFunc(HWND hwnd, UINT uMsg, LPARAM lpData, LPARAM lParam)
{
	char str[MAX_PATH];

	if (uMsg == BFFM_INITIALIZED) {
		SendMessage(hwnd, BFFM_SETSELECTION, TRUE, lParam);
	} else if (uMsg == BFFM_SELCHANGED) {
		SHGetPathFromIDList((LPITEMIDLIST)lpData, str);
		if (str[0]==(char)0)
			SendMessage(hwnd, BFFM_SETSTATUSTEXT, (WPARAM)0, (LPARAM)"<None>");
		else
			SendMessage(hwnd, BFFM_SETSTATUSTEXT, (WPARAM)0, (LPARAM)str);
	}
	return 0;
}

BOOL BrowseForDirectory(HWND hwnd, LPSTR DirName, LPCSTR Prompt)
{ 
	BROWSEINFO bi;
	LPITEMIDLIST pidlDrives;	// PIDL for Drives folder
	LPITEMIDLIST pidlBrowse;	// PIDL selected by user
	LPMALLOC g_pMalloc; 

	/* Get the shell's allocator */
	if (!SUCCEEDED(SHGetMalloc(&g_pMalloc)))
		return FALSE;
 
	/* Get the PIDL for the Drives folder. */
	if (!SUCCEEDED(SHGetSpecialFolderLocation(hwnd, /*CSIDL_DRIVES*/ /*CSIDL_NETWORK*/ CSIDL_DESKTOP, &pidlDrives))) {
		g_pMalloc->lpVtbl->Release(g_pMalloc);
		return FALSE;
	}

	/* Fill in the BROWSEINFO structure. */
	bi.hwndOwner = hwnd;
	bi.pidlRoot = pidlDrives;
	bi.pszDisplayName = DirName;		// no path output
	if (Prompt == NULL)
		bi.lpszTitle = "Chosen Directory:";
	else
		bi.lpszTitle = Prompt;
	bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_STATUSTEXT;
	bi.lpfn = GetDirFunc;
	bi.lParam = (long)DirName;

	/* Browser Dialog (And Get Directories PIDL) */
	pidlBrowse = SHBrowseForFolder(&bi);
	if (pidlBrowse == NULL) {
		g_pMalloc->lpVtbl->Free(g_pMalloc, pidlDrives);
		g_pMalloc->lpVtbl->Release(g_pMalloc);
		return FALSE;
	}

	/* Get Full Path Name */
	SHGetPathFromIDList(pidlBrowse, DirName);

	/* Free the browse PIDL */
	g_pMalloc->lpVtbl->Free(g_pMalloc, pidlBrowse);

	/* Free the Drives pidl */
	g_pMalloc->lpVtbl->Free(g_pMalloc, pidlDrives);

	/* Release the shell's allocator */
	g_pMalloc->lpVtbl->Release(g_pMalloc);
  
	return TRUE;
}


#include <stdio.h>
#include <stdlib.h>

#if LOGFILE
extern FILE *logfile;
#endif

#include "../ep/diskimage/diskimg.h"

static char FilenameBuffer[MAX_PATH+1];

void	Interface_InsertDiskImage(int Drive)
{
	OPENFILENAME	DiskImageOpenFilename;
	HWND			hwnd = GetActiveWindow();

	InitFileDlg(hwnd,&DiskImageOpenFilename,"*.dsk","Disk Image (*.dsk)\0*.dsk\0All files (*.*)\0*.*\0\0",0);
	if (GetFileNameFromDlg(hwnd,&DiskImageOpenFilename,NULL,"Open Disk Image",FilenameBuffer, NULL))
	{
		DiskImage_RemoveDisk(Drive);

		DiskImage_InsertDisk(Drive, DISK_FORMATTED, FilenameBuffer);
		Exdos_InsertDisk(Drive);
	}

}

void	Interface_RemoveDiskImage(int Drive)
{
	DiskImage_RemoveDisk(Drive);
	Exdos_RemoveDisk(Drive);

}


BOOL	Interface_ToggleItemState(HMENU hMenu,int Ident)
{
	MENUITEMINFO	MenuItemInfo;

	MenuItemInfo.cbSize = sizeof(MENUITEMINFO);
	MenuItemInfo.fMask = MIIM_STATE;
		
	if (GetMenuItemInfo(hMenu,Ident,FALSE,&MenuItemInfo)!=TRUE)
		return FALSE;


	if ((MenuItemInfo.fState & MFS_CHECKED)==MFS_CHECKED)
	{
		MenuItemInfo.fState &= ~(MFS_CHECKED | MFS_UNCHECKED);
		MenuItemInfo.fState |= MFS_UNCHECKED;
	}
	else
	{
		MenuItemInfo.fState &= ~(MFS_CHECKED | MFS_UNCHECKED);
		MenuItemInfo.fState |= MFS_CHECKED;
	}

	SetMenuItemInfo(hMenu,Ident,FALSE,&MenuItemInfo);

	return ((MenuItemInfo.fState & MFS_CHECKED)==MFS_CHECKED);
}

//////////////////////////////////////////////////////////////////////////////////////
WNDPROC PreviousMessageHandler;

extern int Host_LockSpeed;
extern int FillScanLines;

LRESULT CALLBACK	Interface_MessageHandler(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
	{
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				
				case ID_FILE_DRIVE0_INSERTDISKIMAGE:
				case ID_FILE_DRIVE1_INSERTDISKIMAGE:
				case ID_FILE_DRIVE2_INSERTDISKIMAGE:
				case ID_FILE_DRIVE3_INSERTDISKIMAGE:
				{
					int Drive;

					switch (LOWORD(wParam))
					{
						case ID_FILE_DRIVE0_INSERTDISKIMAGE:
						{
							Drive = 0;
						}
						break;

						case ID_FILE_DRIVE1_INSERTDISKIMAGE:
						{
							Drive = 1;
						}
						break;

						case ID_FILE_DRIVE2_INSERTDISKIMAGE:
						{
							Drive = 2;
						}
						break;

						case ID_FILE_DRIVE3_INSERTDISKIMAGE:
						{
							Drive = 3;
						}
						break;

						default:
							Drive = 0;
							break;
					}

					Interface_InsertDiskImage(Drive);
				}
				break;

				case ID_FILE_DRIVE0_REMOVEDISKIMAGE:
				case ID_FILE_DRIVE1_REMOVEDISKIMAGE:
				case ID_FILE_DRIVE2_REMOVEDISKIMAGE:
				case ID_FILE_DRIVE3_REMOVEDISKIMAGE:
				{
					int Drive;

					switch (LOWORD(wParam))
					{
						case ID_FILE_DRIVE0_REMOVEDISKIMAGE:
						{
							Drive = 0;
						}
						break;

						case ID_FILE_DRIVE1_REMOVEDISKIMAGE:
						{
							Drive = 1;
						}
						break;

						case ID_FILE_DRIVE2_REMOVEDISKIMAGE:
						{
							Drive = 2;
						}
						break;

						case ID_FILE_DRIVE3_REMOVEDISKIMAGE:
						{
							Drive = 3;
						}
						break;

						default:
							Drive = 0;
							break;
					}

					Interface_RemoveDiskImage(Drive);
				}
				break;

				// tape files
				case ID_MENUITEM40143:
					{
						char DirectoryName[MAX_PATH+1];
						BrowseForDirectory(hwnd, &DirectoryName[0], "Select directory for tape files");
						//Interface_InsertDisk(0,FilenameAndPath_GetPath(&DiskImage),FALSE);
						SetCurrentDirectory(DirectoryName);
					}
					return 0;
				case ID_MENUITEM40144:
					Enterprise_Reset();
					return 0;


				case ID_MISC_LOCKSPEED:
				{
					Host_LockSpeed = Interface_ToggleItemState(hAppMenu, ID_MISC_LOCKSPEED);
				}
				break;
			
				case ID_MISC_BLACKSCANLINES:
				{
					DD_ClearBothSurfaces();

					Render_SetBlackScanlines(Interface_ToggleItemState(hAppMenu, ID_MISC_BLACKSCANLINES));
				}
				break;

				default:
					break;
			//	}
			}
		}
		break;
		
		default:
			break;
	}
	return CallWindowProc(PreviousMessageHandler,hwnd,iMsg, wParam,lParam);
}



void	CPCEMU_SetWindowed()
{
	int ExStyle, Style;

//	if (Windowed == FALSE)
//	{
//		DD_FullScreenToWindow();
//	}
//	else
//	{
//		DD_ShutdownWindowed();
//	}

	// enable some styles
	Style = GetWindowLong(ApplicationHwnd, GWL_STYLE);

	Style |= WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU;
//	Style &= WS_MAXIMIZEBOX;
	SetWindowLong(ApplicationHwnd, GWL_STYLE, Style);

	// remove ex-styles
	ExStyle = GetWindowLong(ApplicationHwnd, GWL_EXSTYLE);

	ExStyle &= ~WS_EX_TOPMOST;

	SetWindowLong(ApplicationHwnd, GWL_EXSTYLE, ExStyle);

 // winnt crashes here
	if (hAppMenu)
	{
		SetMenu(ApplicationHwnd, NULL);
		SetMenu(ApplicationHwnd,hAppMenu);
	}


//	Windowed = TRUE;
	
	Render_SetDisplayWindowed();

	ShowCursor(TRUE);

}

void	Debugger_UpdateDisplay(void);


void	CPCEMU_MainLoop()
{
	Enterprise_Initialise();

	Enterprise_Reset();


	Debugger_Initialise(ApplicationHwnd);

	{
		HINSTANCE	hInstance;

		PreviousMessageHandler = (WNDPROC)GetWindowLong(ApplicationHwnd, GWL_WNDPROC);

		SetWindowLong(ApplicationHwnd, GWL_WNDPROC,(LONG)Interface_MessageHandler);

		hInstance = (HINSTANCE)GetWindowLong(ApplicationHwnd,GWL_HINSTANCE);
		
		hAppMenu = LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));
	}


//	if (CPCEmulation_Initialise())
//	{
		CPCEMU_SetWindowed();
#ifdef DO_DEBUG
		Debugger_OpenDebugDialog();
	
		Debug_SetState(DEBUG_STEP_INTO);

		Debug_SetDebuggerRefreshCallback(Debugger_UpdateDisplay);
#endif

		while (!Host_ProcessSystemEvents())
		{
			int i;

			for (i=0; i<30000; i++)
			{
#ifndef DO_DEBUG
				Z80_ExecuteInstruction();	
#else
				Debugger_Execute();
#endif
			}
		}


		Enterprise_Finish();

		/* store settings */
//		GenericInterface_StoreSettings();

//		Interface_RemoveDisk(0);
//		Interface_RemoveDisk(1);

		//AudioEnable(FALSE);
		//CPC_SetAudioActive(FALSE);

		/* close CPC emulation */
//		CPCEmulation_Finish();

		/* close generic interface */
//		GenericInterface_Finish();
//	}

	/* restore state of scroll lock LED */
//	ScrollLock_RestoreState();

	/* finish handling zip archives */
//	ZipHandle_Finish();

//	DirStuff_Finish();

}



void	MyApp_SetFullScreen(int Width, int Height)
{
	WindowedMode = FALSE;
	ScreenResX = Width;
	ScreenResY = Height;
}

void	MyApp_SetWindowed(int Width, int Height)
{
	WindowedMode = TRUE;
}


void	CPCEMU_DetectFileAndLoad(char *pFilename);
	

extern	char CurrentWorkingDirectory[MAX_PATH];
void	ErrorMessage(char *ErrorText)
{
	MessageBox(GetActiveWindow(),ErrorText,APP_ERROR_TEXT,MB_OK);
}

#include "general/lnklist/lnklist.h"


LIST_HEADER *pDialogList;

void	DialogList_Initialise()
{
	LinkList_InitialiseList(&pDialogList);
}

void	DialogList_Finish()
{
	LinkList_DeleteList(&pDialogList,NULL);
}

void	DialogList_AddDialog(HWND hDialog)
{
	LinkList_AddItemToListEnd(pDialogList, hDialog);
}

int		DialogList_RemoveCallback(HWND hThisDialog, HWND hDialogWanted)
{	
	if (hThisDialog == hDialogWanted)
		return 0;

	return -1;
}


void	DialogList_RemoveDialog(HWND hDialog)
{
	LIST_NODE *pDialogListNode;

	pDialogListNode = LinkList_SearchListForwards(pDialogList, hDialog, DialogList_RemoveCallback);

	if (pDialogListNode!=NULL)
	{
		LinkList_DeleteItem(pDialogList, pDialogListNode,NULL);
	}

}

int	DialogList_IsDialogMessageCallback(MSG *pMsg, HWND hThisDialog)
{
	if (IsDialogMessage(hThisDialog, pMsg))
		return 0;

	return -1;
}


BOOL	DialogList_IsDialogMessage(MSG *msg)
{
	LIST_NODE *pDialogListNode = NULL;

	pDialogListNode = LinkList_SearchListForwards(pDialogList, msg, DialogList_IsDialogMessageCallback);
	
	if (pDialogListNode!=NULL)
		return TRUE;

	return FALSE;
}


/*----------------------------------------------------------------------*/

BOOL	MyApp_RegisterClass(WNDCLASSEX *pClass)
{
	// attempt to register the class
	if (RegisterClassEx(pClass)==0)
	{
		// register failed
		return FALSE;
	}
	
	// register succeeded
	return TRUE;
}

HWND hwndStatus;


/*----------------------------------------------------------------------*/

long FAR PASCAL WindowProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT PaintStruct;

    switch(iMsg)
    {
	case WM_CREATE:
//			hwndStatus = CreateStatusWindow(WS_CHILD | WS_VISIBLE | CCS_BOTTOM | SBARS_SIZEGRIP, "", hwnd, 101);

		return 0;

	case WM_ACTIVATE:
	{
		if (LOWORD(wParam)!=WA_INACTIVE)
		{
			// active 

			if (HIWORD(wParam)==0)
			{
				// maximized
				DI_AcquireDevices();
				DD_RestoreSurfaces();
				DD_ClearBothSurfaces();
				DoNotScanKeyboard = FALSE;
					
				return TRUE;
			}
		}

		//CPC_ReleaseKeys();

		// maximized
		DI_UnAcquireDevices();
		DoNotScanKeyboard = TRUE;
		
		// restore initial state of scroll lock
		//ScrollLock_RestoreState();
	
	}
	return 0;


	case WM_ACTIVATEAPP:
	{
		BOOL	ActiveState = (BOOL)wParam;
	
		if (ActiveState == TRUE)
		{
			DI_AcquireDevices();
			DD_RestoreSurfaces();
			DD_ClearBothSurfaces();
			DoNotScanKeyboard = FALSE;
			Minimized = FALSE;
			GetWindowRect(hwnd,&WindowRectBeforeMinimize);
		}
		else
		{

			DI_UnAcquireDevices();
			DS_ClearBuffer();
			//CPC_ReleaseKeys();
			DoNotScanKeyboard = TRUE;
			Minimized = TRUE;

			// restore state of scrolllock
			//ScrollLock_RestoreState();
		
		}

		
		ApplicationIsActive = ActiveState;

	}
	return 0;
///	case WM_NOTIFY:
//	{
//		int ControlID = (int)wParam;
//		NMHDR *pNotifyHeader = (NMHDR *)lParam;
//
//	}
//	break;

//	case WM_NCLBUTTONDOWN:
//	case WM_NCMBUTTONDOWN:
//	case WM_NCRBUTTONDOWN:
	case WM_ENTERSIZEMOVE:
	case WM_ENTERMENULOOP:
	{
		DI_UnAcquireDevices();
		DS_StopSound();
		//CPC_ReleaseKeys();
		DoNotScanKeyboard = TRUE;		
		//DS_ClearBuffer();
	}
	break;

//	case WM_NCLBUTTONUP:
//	case WM_NCMBUTTONUP:
//	case WM_NCRBUTTONUP:
	case WM_EXITSIZEMOVE:
	case WM_EXITMENULOOP:
	{
		DI_AcquireDevices();
		DS_StartSound();
		DoNotScanKeyboard = FALSE;
	}
	break;

	
	case WM_SIZING:
		{
			LPRECT	pSizingRect = (LPRECT)lParam;

			if (WindowedMode)
			{
				pSizingRect->right = pSizingRect->left + WindowWidth;
				pSizingRect->bottom = pSizingRect->top + WindowHeight;
			}
			else
			{
				pSizingRect->left = 0;
				pSizingRect->right = ScreenResX;
				pSizingRect->top = 0;
				pSizingRect->bottom = ScreenResY;
			}
		}
		return 0;

//			switch (wParam)
//			{
//				case WMSZ_BOTTOM:
//					break;
//				case WMSZ_BOTTOMLEFT:
//					break;
//				case WMSZ_BOTTOMRIGHT:
//					break;
//				case WMSZ_LEFT:
//					break;
//				case WMSZ_RIGHT:
//					break;
//				case WMSZ_TOP:
//					break;
//				case WMSZ_TOPLEFT:
//					break;
//				case WMSZ_TOPRIGHT:
//					break;
//			}
//
//		}
/*
	case WM_SIZE:
	{
		int Width = LOWORD(lParam);
		int Height= HIWORD(lParam);
		int	ResizeFlag = wParam;

		switch (ResizeFlag)
		{
			case SIZE_MAXIMIZED:
			{
				SetWindowPos(hwnd, NULL, 0,0, WindowWidth, WindowHeight, SWP_NOMOVE | SWP_NOZORDER | SWP_NOOWNERZORDER); 
			}
			return 0;
			
			default:
				break;
		}
	}
	break;
*/

		
	case WM_PARENTNOTIFY:
	{

//		int EventFlags = LOWORD(wParam);  // event flags
//		int idChild = HIWORD(wParam);  // identifier of child window 
//	
//		if (EventFlags == WM_DESTROY)
//		{
//			HWND hChild = lParam;
//
//			DestroyWindow(hChild);
//		}

	}
	break;

	
	case WM_GETMINMAXINFO:
	{
		MINMAXINFO *pMinMax = (LPMINMAXINFO) lParam;
		
		if (WindowedMode)
		{
			RECT		WindowRect;
			
			// get current x,y position.
			GetWindowRect(hwnd, &WindowRect);

			if ((WindowWidth!=0) && (WindowHeight!=0))
			{
				pMinMax->ptMaxSize.x = WindowWidth;
				pMinMax->ptMaxSize.y = WindowHeight;
				pMinMax->ptMaxPosition.x = WindowRect.left;
				pMinMax->ptMaxPosition.y = WindowRect.top;
				pMinMax->ptMinTrackSize.x = WindowWidth;
				pMinMax->ptMinTrackSize.y = WindowHeight;
				pMinMax->ptMaxTrackSize.x = WindowWidth;
				pMinMax->ptMaxTrackSize.y = WindowHeight;
				return 0;
			}
		}
		else
		{
			pMinMax->ptMaxSize.x = ScreenResX;
			pMinMax->ptMaxSize.y = ScreenResY;
			pMinMax->ptMaxPosition.x = 0;
			pMinMax->ptMaxPosition.y = 0;
			pMinMax->ptMinTrackSize.x = ScreenResX;
			pMinMax->ptMinTrackSize.y = ScreenResY;
			pMinMax->ptMaxTrackSize.x = ScreenResX;
			pMinMax->ptMaxTrackSize.y = ScreenResY;
			return 0;
		}
	}
	break;

	case WM_MOVING:
	{
		if (!WindowedMode)
		{
			LPRECT pMovingRect = (LPRECT)lParam;

			pMovingRect->left = 0;
			pMovingRect->right = ScreenResX;
			pMovingRect->top = 0;
			pMovingRect->bottom = ScreenResY;

			return TRUE;
		}
	}
	break;


	//case WM_MOVE:

	case WM_SETFOCUS:
	{
		DI_AcquireDevices();
		DoNotScanKeyboard = FALSE;
	}
	return 0;

	case WM_KILLFOCUS:
	{
		DI_UnAcquireDevices();
		DoNotScanKeyboard = TRUE;

		//CPC_ReleaseKeys();

		// restore scroll lock state
		//ScrollLock_RestoreState();

		if (!WindowedMode)
		{
			// in full-screen and focus changed.
			// something bad might have happened
		
			// go to windowed mode in an attempt
			// to force a reset
			CPCEMU_SetWindowed();
		}

	}
	return 0;

//	case WM_SETCURSOR:

	//case WM_ENTERSIZEMOVE:
	//{
	//}
	//break;

#ifdef DRAGANDDROP
	case WM_DROPFILES:
	{
		/* files dropped over it */

		/* drop handle */
		HANDLE DropHandle = (HANDLE)wParam;

		if (DropHandle!=0)
		{
			int i;

			/* get number of files dropped */
			int NoOfFilesDropped = DragQueryFile(DropHandle, -1, NULL, 0);
			
			if (NoOfFilesDropped!=0)
			{
				int MaxFilenameSize;
				char *pFilenameBuffer;

				MaxFilenameSize = 0;
				
				/* get size of largest filename */
				for (i=0; i<NoOfFilesDropped; i++)
				{
					int FilenameSize;

					/* get size of the filename for this file */
					FilenameSize = DragQueryFile(DropHandle, i, NULL, 0);

					if (FilenameSize>MaxFilenameSize)
					{
						/* update max filename size if the length of this
						filename is greater than current */
						MaxFilenameSize = FilenameSize;
					}
				}

				/* allocate memory for filenames to use */
				pFilenameBuffer = malloc(MaxFilenameSize+2);

				if (pFilenameBuffer!=NULL)
				{
					for (i=0; i<NoOfFilesDropped; i++)
					{
						/* get this filename */
						DragQueryFile(DropHandle, i, pFilenameBuffer, MaxFilenameSize+1);

						// do function to detect what this file is and
						// to load it if necessary

						CPCEMU_DetectFileAndLoad(pFilenameBuffer);
					}
				
					/* free buffer to hold filenames */
					free(pFilenameBuffer);
				}
			}

			// finish
			DragFinish(DropHandle);
		}

	}
	return 0;
#endif

	case WM_ERASEBKGND:
		return 0;

	case WM_DISPLAYCHANGE:
	{
		if (WindowedMode)
		{
			DD_ShutdownWindowed();

			CPCEMU_SetWindowed();
		}
	}
	break;

    case WM_PAINT:
        BeginPaint( hwnd, &PaintStruct);
    //    
	//	DD_FlipWindowed();
//
		EndPaint( hwnd, &PaintStruct );
      return 0;

    case WM_DESTROY:
        PostQuitMessage( 0 );
        return 0;

	default:
		break;
	}

    return DefWindowProc(hwnd, iMsg, wParam, lParam);
} 

/* This will be checked now because Arnold is currently windowed only */
/* get the bits per pixel in current display mode */
BOOL	CheckBitDepth()
{
	HWND	DesktopWindow;
	int		BitsPerPixel = 0;

	/* get desktop window */
	DesktopWindow = GetDesktopWindow();

	if (DesktopWindow!=NULL)
	{
		HDC hDC;

		/* get DC of desktop window */
		hDC = GetDC(DesktopWindow);

		if (hDC!=NULL)
		{
			/* get device caps */
			BitsPerPixel = GetDeviceCaps(hDC, BITSPIXEL);

			/* release DC */
			ReleaseDC(DesktopWindow,hDC);
		}
	}

	/* check display depth */
	if (BitsPerPixel<15)
	{
		/* show error message */
		ErrorMessage("At this time, this emulator will only run in 16, 24 or 32 bit colour!\r\n");
		/* quit */
		return FALSE;
	}

	return TRUE;
}


/*+-----------------------------------------------------------------------*/

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR pCmdLine, int iCmdShow)
{
		MSG			Message;

//	if (CheckBitDepth()==FALSE)
//	{
//		return 0;
//	}
//	else
	{
		WNDCLASSEX	WindowClass;
		BOOL		Quit=FALSE;


		
		InitCommonControls();

		AppInstance = hInstance;

		/* initialise class */
		WindowClass.cbSize = sizeof(WNDCLASSEX);
		WindowClass.style = /*CS_HREDRAW | CS_VREDRAW |*/ CS_OWNDC;	// | CS_SAVEBITS;
		WindowClass.lpfnWndProc = WindowProc;
		WindowClass.cbClsExtra = 0;
		WindowClass.cbWndExtra = 0;
		WindowClass.hInstance = hInstance;
		WindowClass.hIcon = LoadIcon( NULL, IDI_APPLICATION );
		WindowClass.hCursor = LoadCursor( NULL, IDC_ARROW );
		WindowClass.hbrBackground = GetStockObject(GRAY_BRUSH);
		WindowClass.lpszMenuName = NULL;
		WindowClass.lpszClassName = APPLICATION_CLASS_NAME;
		WindowClass.hIconSm = LoadIcon(NULL,IDI_APPLICATION);
		
		/* register class */
		if (MyApp_RegisterClass(&WindowClass))
		{
			/* create app window */
			ApplicationHwnd = CreateWindowEx(
				WS_EX_APPWINDOW,
				APPLICATION_CLASS_NAME,
				NULL,
				WS_OVERLAPPEDWINDOW,
				0,
				0,
				GetSystemMetrics( SM_CXSCREEN ),
				GetSystemMetrics( SM_CYSCREEN ), // + 30,
				NULL,
				NULL,
				hInstance,
				NULL );

							
			/* show the window */
			ShowWindow( ApplicationHwnd, iCmdShow );
			/* update window */
			UpdateWindow( ApplicationHwnd );
#ifdef DRAGANDDROP
			{
				LONG WindowLong;

				WindowLong = GetWindowLong(ApplicationHwnd, GWL_EXSTYLE);
				WindowLong |= WS_EX_ACCEPTFILES;
				SetWindowLong(ApplicationHwnd, GWL_EXSTYLE, WindowLong);
				
				/* accept dropped files */
				DragAcceptFiles(ApplicationHwnd, TRUE);
			}
#endif
			// prevent window from being resized
			{
				LONG WindowLong;

				WindowLong = GetWindowLong(ApplicationHwnd, GWL_STYLE);
				WindowLong &=~WS_THICKFRAME;
				SetWindowLong(ApplicationHwnd, GWL_STYLE, WindowLong);
			}

			ApplicationIsActive = TRUE;
			ApplicationHasFocus = TRUE;

			//DialogList_Initialise();

			/* check all required directx components are available */
			if (!DirectX_CheckComponentsArePresent())
			{
				ErrorMessage("The required DirectX components have not been found\r\nPlease re-install DirectX.");
			}
			else
			{
				{
					char		TitleText[80];
					char		*Build;

				#ifdef _DEBUG
					Build = "Debug";
				#else
					Build = "Release";
				#endif

					wsprintf(TitleText, "Enterprise Emulator");
					SetWindowText(ApplicationHwnd,TitleText);
				}
#ifdef CRT_DEBUG
				{
		
		// Get current flag
		int tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );

		// Turn on leak-checking bit
		tmpFlag |= _CRTDBG_LEAK_CHECK_DF;

		// Turn off CRT block checking bit
		//tmpFlag &= ~_CRTDBG_CHECK_CRT_DF;

		// Set flag to the new value
		_CrtSetDbgFlag( tmpFlag );
			}
#endif

				DD_Init();
				DD_SetupDD(ApplicationHwnd,NULL);

				DI_Init(hInstance);
		
				DS_Init(ApplicationHwnd);



				Joystick_Init();
			

				//_getcwd(CurrentWorkingDirectory,MAX_PATH);

				//SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);

				CPCEMU_MainLoop();
				/*
				while (Quit==FALSE)
				{
					// Is a message available?
					if (PeekMessage(&Message,NULL,0,0,PM_NOREMOVE))
					{
						//if (!(DialogList_IsDialogMessage(&Message)))
						//{
							// yes, get the message
							if (GetMessage(&Message,NULL,0,0))
							{
								// if the message is not WM_QUIT
								// Translate it and dispatch it
								TranslateMessage(&Message);
								DispatchMessage(&Message);
							}
							else
							{
								// Message was WM_QUIT. So break out of message loop
								// and quit
								Quit=TRUE;
								break;
							}
						//}
					}
					else
					{
						// No message, so idle, execute user function
						if (ApplicationHasFocus)
							DI_ScanKeyboard();

//						if (ApplicationIsActive)
							CPCEMU_MainLoop();
					}
				}
				*/

//				DestroyWindow(ApplicationHwnd);


//				CPCEMU_Exit();


				DS_Close();

				DD_CloseDD();

				DI_Close();
				DD_Close();
			}

			// Destroy Main Dialog Window

//			DestroyWindow(hwndStatus);

			return 0; //Message.wParam;
		}
	}
#ifdef CRT_DEBUG
	_CrtDumpMemoryLeaks();
#endif
	return 0;
}

void	SetStatusText(char *text)
{
	SendMessage(hwndStatus, SB_SETTEXT,0, (LPARAM)text);
}

void	SetMainTitleText(char *text)
{
	SetWindowText(ApplicationHwnd, text);
}


void	MyApp_SetWindowDimensions(int Width, int Height)
{
	WindowWidth = Width;
	WindowHeight = Height;
}

typedef struct
{
	int WindowX, WindowY;
} WINDOW_SETTINGS;


void	MyApp_GetWindowSettings(WINDOW_SETTINGS *pWindowSettings)
{
	GetWindowRect(ApplicationHwnd, 0);
}


void	MyApp_CentraliseWindow(HWND hWindow, HWND hParent)
{
	RECT WindowRect;
	RECT ParentWindowRect;
	int WindowWidth, WindowHeight;
	int ParentWindowWidth, ParentWindowHeight;
	POINT WindowPos;
	HWND hParentWindow;

	if (hParent == 0)
	{
		// no parent specified, therefore centralise in desktop window
		hParentWindow = GetDesktopWindow();
	}
	else
	{
		// use specified parent
		hParentWindow = hParent;
	}


	// get window width and height.
	GetWindowRect(hWindow, &WindowRect);

	// calc width and height of this window
	WindowWidth = WindowRect.right-WindowRect.left;
	WindowHeight = WindowRect.bottom-WindowRect.top;

	// get parent window width and height.
	GetWindowRect(hParentWindow, &ParentWindowRect);

	// calc parent width and height
	ParentWindowWidth = ParentWindowRect.right - ParentWindowRect.left;
	ParentWindowHeight = ParentWindowRect.bottom - ParentWindowRect.top;

	// calc new position
	WindowPos.x = (ParentWindowWidth>>1)-(WindowWidth>>1) + ParentWindowRect.left;
	WindowPos.y = (ParentWindowHeight>>1)-(WindowHeight>>1) + ParentWindowRect.top;

	// set new pos
	SetWindowPos(hWindow, HWND_TOPMOST, WindowPos.x, WindowPos.y, 
		WindowWidth, WindowHeight, SWP_NOSIZE | SWP_NOZORDER);
}



BOOL	WinApp_ProcessSystemEvents()
{
	MSG	Message;

	// Is a message available?
	while (PeekMessage(&Message,NULL,0,0,PM_NOREMOVE))
	{
		// yes, get the message
		if (GetMessage(&Message,NULL,0,0))
		{
			// if the message is not WM_QUIT
			// Translate it and dispatch it
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
		else
		{
			// Message was WM_QUIT. So break out of message loop
			// and quit
			return TRUE;
		}
	}

	// No message, so idle, execute user function
	if (!(DoNotScanKeyboard))
	{
		DI_ScanKeyboard();
	}

	DoKeyboard();

	return FALSE;
}


void	MyApp_GetWindowRect(RECT *pRect)
{
	int Width, Height;

	if (!Minimized)
	{
		RECT WindowRect;

		/* get client rect of window */
		GetWindowRect(ApplicationHwnd,&WindowRect);
		
		/* width of rectangle */
		Width = WindowRect.right-WindowRect.left;
		Height = WindowRect.bottom-WindowRect.top;

		MyApp_SetWindowDimensions(Width,Height);
	
		*pRect = WindowRect;
	
	}
	else
	{
		Width = WindowRectBeforeMinimize.right - WindowRectBeforeMinimize.left;
		Height = WindowRectBeforeMinimize.bottom - WindowRectBeforeMinimize.bottom;

		MyApp_SetWindowDimensions(Width, Height);
	
		*pRect = WindowRectBeforeMinimize;
	}
}

//	MyApp_CentraliseWindow(hwnd, NULL);
