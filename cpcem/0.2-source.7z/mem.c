/*CPC-em - memory emulation*/

#include "mz80.h"
#include "mem.h"
#include "ga.h"
#include <stdio.h>

/*There's not a lot in here*/
unsigned char basic[16384],amsdos[16384];

/*Current CPC model - 0=464, 1=664*/
int model;

/*ROMs*/
unsigned char low[16384],high[16384];

/*Load ROMs*/
void initmem()
{
        FILE *f;
        memset(ram,0,65536);
        if (model)
        {
                f=fopen("cpc664.rom","rb");
                if (!f)
                {
                        printf("Missing CPC664.ROM (CPC ROM)\nCPC-em can not run without it\nDid you delete it?\n");
                        exit(-1);
                }
        }
        else
        {
                f=fopen("cpc464.rom","rb");
                if (!f)
                {
                        printf("Missing CPC464.ROM (CPC ROM)\nCPC-em can not run without it\nDid you delete it?\n");
                        exit(-1);
                }
        }
        fread(low,16384,1,f);
        fread(basic,16384,1,f);
        fclose(f);
        memcpy(ram,low,16384);
        memcpy(high,basic,16384);
        f=fopen("amsdos.rom","rb");
        fread(amsdos,16384,1,f);
        fclose(f);
//        high[0xBCA1&0x3FFF]=0xED;
//        high[0xBCA2&0x3FFF]=0;
//        high[0xBCA3&0x3FFF]=0xC9;
}
