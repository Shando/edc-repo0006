#include "gfx.h"
#include <stdio.h>

PALETTE cpcpalpc;
int fdcmethod=0;
int loadthefile;
void drawvga();
int resetcpc=0;
BMP *b;
BMP *mousepoint,*mouseback;
int svga;
int model;
int changemode=0;
int guichange=1;
int focus=0;
int items;

static unsigned char mousepointer[256] =
{
        1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,1,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,1,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,
        1,2,2,2,2,2,1,1,1,0,0,0,0,0,0,0,
        1,2,2,1,2,2,1,0,0,0,0,0,0,0,0,0,
        1,2,1,0,1,2,2,1,0,0,0,0,0,0,0,0,
        0,1,0,0,1,2,2,1,0,0,0,0,0,0,0,0,
        0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0,
        0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0,
        0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0
};

void initmousepoint()
{
        int x,y;
        unsigned char mousepal[3]={0,21,12};
        mouseback=createbmp(12,16);
        mousepoint=createbmp(12,16);
        for (y=0;y<16;y++)
        {
                for (x=0;x<16;x++)
                {
                        putpixel(mousepoint,x,y,mousepal[mousepointer[x+(y<<4)]]);
                }
        }
}

void initgui()
{
        initmousepoint();
}

int readconfig()
{
        FILE *f=fopen("cpc-em.cfg","rb");
        if (!f)
           return -1;
        svga=getc(f);
        model=getc(f);
        fdcmethod=getc(f);
        fclose(f);
        return 0;
}

void writeconfig()
{
        FILE *f=fopen("cpc-em.cfg","wb");
        putc(svga,f);
        putc(model,f);
        putc(fdcmethod,f);
        fclose(f);
}

/*Mouse functions*/

int mouseinit()
{
        __dpmi_regs r;
        r.x.ax = 0x00;
        __dpmi_int(0x33, &r);
	if (r.x.ax == 0xFFFF)
           return 0;
	else
           return -1;
}

void getmouse()
{
        __dpmi_regs r;
        r.x.ax=3;
        __dpmi_int(0x33, &r);
        mouseb=r.x.bx;
        mousex=r.x.cx>>1;
        mousey=r.x.dx;
}

/*GUI functions*/
int exitui=0;

#define BUTTON 1
#define RADIO 2
#define TEXT 3

#define DISABLED 0x80

typedef struct GUI
{
        int x,y,type,misc,misc2,status;
        void (*clickproc)(int item);
        char *s;
        int sx,sy;
} GUI;

void returnbutton(int item);
void radioselect(int item);
void noaction(int item);

void modelchange(int item);
void modechange(int item);

void resetbutton(int item);
void loadbutton(int item);
void runbutton(int item);
void screenshotbutton(int item);

GUI gui[]=
{
        {0,0,0,0,0,0,returnbutton,NULL,0,0},
        {16,16,BUTTON,11,0,0,returnbutton,"Back to CPC",0,0},
        {128,16,BUTTON,11,0,0,returnbutton,"Back to DOS",0,0},
        {16,136,TEXT,11,0,0,noaction,"CPC Model  :",0,0},
        {16,152,RADIO,3,1,DISABLED,modelchange,"464",0,0},
        {16,176,RADIO,3,1,DISABLED,modelchange,"664",0,0},
        {128,136,TEXT,12,0,0,noaction,"Video mode :",0,0},
        {128,152,RADIO,3,2,0,modechange,"VGA",0,0},
        {128,176,RADIO,4,2,0,modechange,"SVGA",0,0},
        {16,56,BUTTON,9,0,0,resetbutton,"Reset CPC",0,0},
        {112,56,BUTTON,9,0,0,loadbutton,"Load file",0,0},
        {208,56,BUTTON,8,0,0,runbutton,"Run file",0,0},
        {16,96,BUTTON,9,0,0,screenshotbutton,"Screenshot",0,0},
        {NULL,NULL,NULL,NULL,0,NULL,NULL,0,0}
};

void modelchange(int item)
{
        radioselect(item);
}

void modechange(int item)
{
        if (item==7)
        {
                if (svga)
                {
                        changemode=1;
                        svga=0;
                }
        }
        else
        {
                if (!svga)
                {
                        changemode=1;
                        svga=1;
                }
        }
        radioselect(item);
}

void noaction(int item)
{
}

void resetbutton(int item)
{
        resetcpc=1;
}

void returnbutton(int item)
{
        exitui=item;
}

void loadbutton(int item)
{
        loadthefile=1;
}

void runbutton(int item)
{
        loadthefile=2;
}

void screenshotbutton(int item)
{
        drawvga();
        savepcx("cpcdump.pcx",b,cpcpalpc);
}

void radioselect(int item)
{
        int c;
        if (gui[item].status&DISABLED)
           return;
        for (c=0;c<items;c++)
        {
                if ((gui[c].type==RADIO)&&(gui[c].misc2==gui[item].misc2))
                   gui[c].status&=0xFE;
        }
        gui[item].status=1;
        guichange|=1;
}

void drawcursor()
{
        blit(mouseback,screen,0,0,mousex,mousey,12,16);
        getmouse();
        blit(screen,mouseback,mousex,mousey,0,0,12,16);
        draw_sprite(mousepoint,screen,mousex,mousey);
}

void erasecursor()
{
        blit(mouseback,screen,0,0,mousex,mousey,12,16);
}

void getcursorback()
{
        blit(screen,mouseback,mousex,mousey,0,0,12,16);
}

int entergui()
{
        int c=0;
        char s[40];
        /*Set up GUI variables*/
        exitui=0;
        guichange=1;
        /*Clear screen and set character drawing mode*/
        clearall(b,0);
        clearall(screen,1);
        charmode(MASKED);
        /*Count GUI items*/
        while (gui[++c].clickproc);
        items=c;
        /*Initialise mouse*/
        if (svga)
        {
                setlimits(0,0,627,384);
                putmouse(320,200);
        }
        else
        {
                setlimits(0,0,307,184);
                putmouse(160,100);
        }
        getmouse();
        blit(screen,mouseback,mousex,mousey,0,0,12,16);
        /*Initialise display and radio buttons*/
        if (svga)
        {
                drawvga();
                blit(b,screen,0,0,640-322,2,320,200);
                drawline(screen,640-323,1,638,1,34);
                drawline(screen,640-323,1,640-323,202,34);
                drawline(screen,640-323,202,638,202,33);
                drawline(screen,638,1,638,201,33);
                gui[8].status|=1;
        }
        else
           gui[7].status|=1;
        if (model)
           gui[5].status|=1;
        else
           gui[4].status|=1;
        while (!exitui)
        {
                if (guichange)
                {
                        erasecursor();
                        for (c=0;c<items;c++)
                        {
                                switch (gui[c].type)
                                {
                                        case BUTTON:
                                        if (!(gui[c].status&DISABLED))
                                        {
                                                drawbox(screen,gui[c].x,gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,1);
                                                drawline(screen,gui[c].x,gui[c].y,gui[c].x,gui[c].y+32,33);
                                                drawline(screen,gui[c].x,gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y,33);
                                                putpixel(screen,gui[c].x,gui[c].y,1);
                                                drawline(screen,gui[c].x+((gui[c].misc+2)*8),gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,34);
                                                drawline(screen,gui[c].x,gui[c].y+32,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,34);
                                                putpixel(screen,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,1);
                                                drawstring(screen,font,gui[c].x+8,gui[c].y+12,gui[c].s,0);
                                        }
                                        else
                                        {
                                                drawbox(screen,gui[c].x,gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,1);
                                                drawline(screen,gui[c].x,gui[c].y,gui[c].x,gui[c].y+32,33);
                                                drawline(screen,gui[c].x,gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y,33);
                                                putpixel(screen,gui[c].x,gui[c].y,1);
                                                drawline(screen,gui[c].x+((gui[c].misc+2)*8),gui[c].y,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,33);
                                                drawline(screen,gui[c].x,gui[c].y+32,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,33);
                                                putpixel(screen,gui[c].x+((gui[c].misc+2)*8),gui[c].y+32,1);
                                                drawstring(screen,font,gui[c].x+8,gui[c].y+12,gui[c].s,33);
                                        }
                                        gui[c].sx=(gui[c].misc+2)*8;
                                        gui[c].sy=32;
                                        break;
                                        case RADIO:
                                        circlefill(screen,gui[c].x+8,gui[c].y+8,6,1);
                                        circle(screen,gui[c].x+8,gui[c].y+8,6,33);
                                        if (gui[c].status&1)
                                           circlefill(screen,gui[c].x+8,gui[c].y+8,3,33);
                                        if (!(gui[c].status&DISABLED))
                                           drawstring(screen,font,gui[c].x+20,gui[c].y+5,gui[c].s,0);
                                        else
                                           drawstring(screen,font,gui[c].x+20,gui[c].y+5,gui[c].s,33);
                                        gui[c].sx=(gui[c].misc*8)+10;
                                        gui[c].sy=12;
                                        break;
                                        case TEXT:
                                        if (!(gui[c].status&DISABLED))
                                           drawstring(screen,font,gui[c].x,gui[c].y,gui[c].s,0);
                                        else
                                           drawstring(screen,font,gui[c].x,gui[c].y,gui[c].s,33);
                                        gui[c].sx=gui[c].misc*8;
                                        gui[c].sy=8;
                                        break;
                                }
                        }
                        guichange=0;
                        getcursorback();
                }
                focus=-1;
                for (c=0;c<items;c++)
                {
                        if ((mousex>gui[c].x)&&(mousey>gui[c].y)&&(mousex<(gui[c].x+gui[c].sx))&&(mousey<(gui[c].y+gui[c].sy)))
                           focus=c;
                }
                if ((focus!=-1)&&(mouseb)&&(gui[focus].clickproc))
                   gui[focus].clickproc(focus);
                vsync();
                drawcursor();
        }
        clearall(b,0);
        writeconfig();
        return exitui;
}
