/*CPC-em - main section*/

#include <stdio.h>
#include "gfx.h"
#include "mz80.h"
#include "pia.h"
#include "ga.h"
#include "crtc.h"
#include "mem.h"

int fdcmethod;
int loadthefile=0;
int runaddress=0;
PALETTE cpcpalpc;
FILE *fdclog;
int svga;
BMP *b;
int changemode;
int resetcpc;
FILE *caslog;
int screencount=0;
int mode2mode;
int filein=0;
int invsync;
int loadaddr;
/*Holds RAM at 0x0000-0x4000 and 0xC000-0xFFFF*/
unsigned char lomem[16384],himem[16384];
/*Holds ROMs*/
unsigned char low[16384],high[16384];
unsigned char basic[16384],amsdos[16384];
FILE *f;
FILE *loggo;
/*MZ80 context*/
static struct mz80context z80;

UINT16 readother(UINT16 port, struct z80PortRead *pPR)
{
        char s[80];
        sprintf(s,"Reading %04X\n",port);
        fputs(s,loggo);
}

UINT16 readfdc(UINT16 port, struct z80PortRead *pPR);
void writefdc(UINT16 port, UINT8 val, struct z80PortWrite *pPW);
void fdcmotor(UINT16 port, UINT8 val, struct z80PortWrite *pPW);
/*MZ80 structures*/
struct MemoryReadByte readmem[] =
{
	{-1, -1, NULL}
};

void changerom(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
        char s[40];
        if (val==7 && fdcmethod)
           memcpy(high,amsdos,16384);
        else
           memcpy(high,basic,16384);
        if (highrom)
           memcpy(ram+0xC000,high,16384);
}

static void writeram(UINT32 addr, UINT8 val, struct MemoryWriteByte *pMemWrite)
{
        if (addr<0x4000)
        {
                /*Writing to low RAM - could be ROM*/
                lomem[addr]=val;
                if (!lowrom)
                   ram[addr]=val;
                return;
        }
        if (addr<0xC000)
        {
                /*Writing to middle RAM - always RAM*/
                ram[addr]=val;
                return;
        }
        /*Writing to high RAM - could be ROM*/
        himem[addr&0x3FFF]=val;
        if (!highrom)
           ram[addr]=val;
}

struct MemoryWriteByte writemem[] =
{
        {0,0xFFFF,writeram},
	{-1,-1,NULL}
};

struct z80PortRead readports[] =
{
        {0x7F00,0x7FFF,readga,NULL},
        {0xBC00,0xBFFF,readcrtc,NULL},
        {0xF400,0xF7FF,readpia,NULL},
        {0xFB7E,0xFB7F,readfdc},
	{-1,-1,NULL}
};

struct z80PortWrite writeports[] =
{
        {0x7F00,0x7FFF,writega},
        {0xBC00,0xBFFF,writecrtc},
        {0xDF00,0xDFFF,changerom},
        {0xF400,0xF7FF,writepia},
        {0xFA7E,0xFA7E,fdcmotor},
        {0xFB7E,0xFB7F,writefdc},
	{-1,-1,NULL}
};

/*Snapshot loading doesn't work yet*/
/*void loadsnapshot(unsigned char *fn)
{
        FILE *f=fopen(fn,"rb");
        unsigned char temp;
        int c;
        closegfx();
        fseek(f,0x11,SEEK_SET);
//        printf("Loading registers\n");
        z80.z80af=getc(f)|(getc(f)<<8);
        z80.z80bc=getc(f)|(getc(f)<<8);
        z80.z80de=getc(f)|(getc(f)<<8);
        z80.z80hl=getc(f)|(getc(f)<<8);
        z80.z80r=getc(f);
        z80.z80i=getc(f);
        if (getc(f)&1)
           z80.z80interruptState=1;
        else
           z80.z80interruptState=0;
        getc(f);
//        if (getc(f)&1)
//           z80.z80iff2=1;
//        else
//           z80.z80iff2=0;
        z80.z80ix=getc(f)|(getc(f)<<8);
        z80.z80iy=getc(f)|(getc(f)<<8);
        z80.z80sp=getc(f)|(getc(f)<<8);
        z80.z80pc=getc(f)|(getc(f)<<8);
        z80.z80interruptMode=getc(f);
        z80.z80afprime=getc(f)|(getc(f)<<8);
        z80.z80bcprime=getc(f)|(getc(f)<<8);
        z80.z80deprime=getc(f)|(getc(f)<<8);
        z80.z80hlprime=getc(f)|(getc(f)<<8);
//        printf("Loading colours\n");
        for (c=0;c<17;c++)
        {
                writega(0,c,NULL);
                fseek(f,0x2F+c,SEEK_SET);
                writega(0,(getc(f)&0x1F)|0x40,NULL);
        }
        fseek(f,0x2E,SEEK_SET);
        writega(0,getc(f)&0x1F,NULL);
        fseek(f,0x40,SEEK_SET);
        writega(0,(getc(f)&0x3F)|0x80,NULL);
        fseek(f,0x41,SEEK_SET);
        writega(0,(getc(f)&0x3F)|0xC0,NULL);
//        printf("Loading crtc\n");
        for (c=0;c<18;c++)
        {
                writecrtc(0xBC00,c,NULL);
                fseek(f,0x43+c,SEEK_SET);
                writecrtc(0xBD00,getc(f),NULL);
        }
//        printf("Loading pia\n");
        fseek(f,0x59,SEEK_SET);
        writepia(0x300,getc(f),NULL);
        fseek(f,0x56,SEEK_SET);
        writepia(0,getc(f),NULL);
        writepia(0x100,getc(f),NULL);
        writepia(0x200,getc(f),NULL);
//        printf("Loading psg\n");
        for (c=0;c<16;c++)
        {
                writepsg(c);
                writepsgcon(0xC0);
                writepsg(getc(f));
                writepsgcon(0x80);
        }
        writepsgcon(getc(f));
//        printf("Loading memory\n");
        fseek(f,0x100,SEEK_SET);
        fread(lomem,16384,1,f);
        fread(ram+0x4000,32768,1,f);
        fread(himem,16384,1,f);
        fclose(f);
        if (lowrom)
           memcpy(ram,low,16384);
        else
           memcpy(ram,lomem,16384);
        if (highrom)
           memcpy(ram+0xC000,high,16384);
        else
           memcpy(ram+0xC000,himem,16384);
//        printf("done\n");
}*/

/*Initialise MZ80*/
void initz80()
{
        memset(&z80,0,sizeof(z80));
        z80.z80Base=ram;
        z80.z80IoRead=readports;
        z80.z80IoWrite=writeports;
	z80.z80MemRead=readmem;
	z80.z80MemWrite=writemem;
	mz80SetContext(&z80);
	mz80reset();
	mz80GetContext(&z80);
	z80.z80intAddr=0x38;
	z80.z80nmiAddr=0x66;
	mz80SetContext(&z80);
}

void loadfile(char *fn, int override)
{
        int loadaddr=0,c,length=0;
        unsigned char val;
        FILE *f=fopen(fn,"rb");
        fseek(f,21,SEEK_SET);
        loadaddr=getc(f)|(getc(f)<<8);
        getc(f);
        length=getc(f)|(getc(f)<<8);
        if (override)
           loadaddr=override;
        fseek(f,128,SEEK_SET);
        for (c=0;c<length;c++)
        {
                val=getc(f);
                if (loadaddr<0x4000)
                   lomem[loadaddr]=val;
                else if (loadaddr>0xBFFF)
                   himem[loadaddr&0x3FFF]=val;
                else
                   ram[loadaddr]=val;
                loadaddr++;
        }
        if (!lowrom)
           memcpy(ram,lomem,16384);
        if (!highrom)
           memcpy(ram+0xC000,himem,16384);
        fclose(f);
        if (loadthefile==2)
        {
                mz80GetContext(&z80);
                z80.z80pc=runaddress;
                mz80SetContext(&z80);
        }
        loadthefile=0;
}

void checkfile(unsigned char *fn)
{
        FILE *f=fopen(fn,"rb");
        if (!f)
           return;
        filein=1;
        fseek(f,26,SEEK_SET);
        runaddress=getc(f)|(getc(f)<<8);
        printf("Run address : %04X\n",runaddress);
        printf("Press a key to continue");
        getch();
        fclose(f);
}

int main(int argc, char *argv[])
{
        FILE *ff;
        char s[80];
        int intcount=0;
        int c;
        unsigned long result;
        if (argc>1)
           checkfile(argv[1]);
        if (argc>2)
           loadaddr=atoi(argv[2]);
        else
           loadaddr=0;
        tomgfxinit();
        readconfig();
        initz80();
        initmem();
        initga();
        initcrtc();
        initpia();
        initpsg();
        initkey();
        initvideo();
        initfdc();
        mouseinit();
        initgui();
        while (!keys[KEY_F10])
        {
                result=mz80exec(11000);
                if (result!=0x80000000)
                {
                        outportb(0x3F2,0x4);
                        mz80GetContext(&z80);
/*                          if (z80.z80pc==0xBC77)
                          {
                                casinopen();
                          }
                          else
                          {*/
                                closegfx();
                                printf("Illegal instruction %04X at %04X\n",result,z80.z80pc);
                                printf("Lowrom=%i hirom=%i\n",lowrom,highrom);
                                exit(-1);
//                          }
                }
                if (keys[KEY_F6])
                {
                        if (entergui()==2)
                        {
                                shutdowngfx();
                                return 0;
                        }
                        if (resetcpc)
                        {
                                initmem();
                                initz80();
                                initga();
                                initcrtc();
                                initpia();
                                initpsg();
                        }
                        resetcpc=0;
                        if (changemode)
                        {
                                free(b);
                                if (svga)
                                {
                                        initgfx(VESA2L,640,400,0,0);
                                        b=createbmp(640,400);
                                }
                                else
                                {
                                        initgfx(VGA,320,200,0,0);
                                        b=createbmp(320,200);
                                }
                                clearall(b,0);
                                setpal(cpcpalpc);
                        }
                        changemode=0;
                }
                if ((keys[KEY_F11]||loadthefile)&&filein)
                   loadfile(argv[1],loadaddr);
                if (keys[KEY_F5])
                   initz80();
                mz80int(0xFF);
                intcount++;
                if (intcount==5)
                {
                        drawscreen();
                        invsync=1;
                }
                if (intcount==6)
                {
                        invsync=0;
                        intcount=0;
                        screencount++;
                        if (screencount==25)
                        {
                                screencount=0;
                                if (keys[KEY_F12])
                                   mode2mode^=1;
                        }
                }
        }
        if (fdcmethod==2)
           outportb(0x3F2,0x4);
        shutdowngfx();
        mz80GetContext(&z80);
        return 0;
}
