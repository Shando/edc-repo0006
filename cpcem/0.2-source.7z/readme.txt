CPC-em - A freeware Amstrad CPC emulator
Version 0.2
Source code

Introduction
~~~~~~~~~~~~

CPC-em attempts to emulate an Amstrad CPC 464, which was sold in the mid to
late 80's, and was particularly popular in Europe.
Amstrad had allowed emulator authors to distribute the CPC ROMs with emulators,
and the CPC 664 ROMs are included (same as 464 ROMs but BASIC 1.1).

I've included the MZ80 files (makez80.c, mz80.h and mz80.txt) because CPC-em
relies on them, but if anyone has any problems with this, e-mail me and I'll
remove them.

Multi-Z80 CPU emulator by Neil Bradley (neil@synthcom.com)

To compile
~~~~~~~~~~

You will need DJGPP, GCC and NASM.

To compile the lot, run makeall.bat.

If you want to compile everything seperately:

You will need to link with gfx.a
The following files you just compile normally (using gcc -c) :

array.c - Gate Array emulation
cpcem.c - The main loop
fdc.c   - The FDC emulation
gui.c   - The GUI
mem.c   - Memory emulation
pia.c   - 8255 PIA emulation
psg.c   - PSG emulation
tape.c  - The tape emulation
video.c - CRTC/video emulation

To compile MZ80
~~~~~~~~~~~~~~~

The instructions are in mz80.txt, but I'll write them simplified here :

gcc -c makez80.c
gcc -o makez80.exe makez80.o
makez80 -s -16 -nt -x86 mz80.asm
nasm -f coff mz80.asm

What needs doing
~~~~~~~~~~~~~~~~

A lot needs doing, obviously, but here's some stuff to start with :

Get one of the methods of disc emulation to work.
Track down and fix the scrolling bug
Add the missing keys (and put the ones on F1 and F2 to more sensible locations)
Fix snapshot support (there is a loadsnapshot function commented out in
                      cpcem.c because it doesn't seem to work)

Tom Walker
tommowalker@hotmail.com

As I write (9th June), I'm about to go to Spain for two weeks, so I won't be
able to reply to anyone for a while.

