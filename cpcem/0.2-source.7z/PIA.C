/*CPC-em - 8255 PIA emulation*/

#include <stdio.h>
#include "mz80.h"
#include "pia.h"

/*PIA ports*/
#define PORTA      0x000
#define PORTB      0x100
#define PORTC      0x200
#define PIACONTROL 0x300

/*Bits in control register*/
#define READPA   16
#define READPB   2
#define READPCUP 8
#define READPCLO 1

int invsync;
FILE *f;
char string[80];

/*Port status and control register*/
unsigned char pa,pb,pc,con;

unsigned char bits[8]={1,2,4,8,16,32,64,128};

void initpia()
{
        /*Initialise PIA ports to defaults*/
        pa=pc=con=0;
        pb=0x1E; /*Amstrad computer, 50hz refresh, not vsync, expansion or tape*/
        invsync=0;
}

/*Writing to PIA*/
void writepia(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
//        sprintf(string,"Writing to PIA %04X %02X\n",port,val);
//        fputs(string,f);
        switch (port&0x300)
        {
                case PORTA: /*Port A - connected to PSG*/
                if (!(con&READPA))
                {
                        pa=val;
                        writepsg(val);
                }
                break;
                case PORTB: /*Port B isn't writeable so writing won't do
                              anything*/
                if (!(con&READPB))
                   pb=val;
                break;
                case PORTC: /*Port C is split into two*/
                if (!(con&READPCUP))
                {
                        pc&=0xF;
                        pc|=(val&0xF0);
                }
                if (!(con&READPCLO))
                {
                        pc&=0xF0;
                        pc|=(val&0xF);
                }
                /*Update PSG control*/
                writepsgcon(val);
                break;
                case PIACONTROL: /*PIA control register*/
                if (val&0x80)
                   con=val&0x7F;
                else
                {
                        if (con&1)
                           con|=bits[(con>>1)&7];
                        else
                           con&=~bits[(con>>1)&7];
                }
                break;
        }
}

/*Reading from PIA*/
UINT16 readpia(UINT16 port, struct z80PortRead *pPR)
{
        unsigned char val=0;
//        sprintf(string,"Reading PIA %04X\n",port);
//        fputs(string,f);
        switch (port&0x300)
        {
                case PORTA: /*Port A is connected to the PSG*/
                if (con&READPA)
                   return readpsg();
                return 0xFF;
                break;
                case PORTB: /*Port B holds `switch settings' and inputs*/
                if (con&READPB)
                {
                        if (invsync)
                           return pb|1;
                        else
                           return pb;
                }
                return 0xFF;
                break;
                case PORTC: /*Port C is split into two*/
                if (con&READPCUP)
                   val|=(pc&0xF0);
                if (con&READPCLO)
                   val|=(pc&0xF);
                return 0xFF;
                break;
                case PIACONTROL: /*Is control readable?*/
                return con;
                break;
        }
        return 0xFE;
}
