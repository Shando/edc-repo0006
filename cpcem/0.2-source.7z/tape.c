#include <stdio.h>
#include "mz80.h"

static struct mz80context z80;
FILE *caslog;
unsigned char ram[65536];

void casinopen()
{
        char s[80];
        char fn[40];
        int c;
        unsigned char b;
        mz80GetContext(&z80);
        b=z80.z80bc.half.b;
        for (c=0;c<b;c++)
            fn[c]=ram[z80.z80hl.hl+c];
        fn[c]=0;
        sprintf(s,"CAS IN OPEN - BC %04X B %02X HL %04X filename %s\n",z80.z80bc.bc,b,z80.z80hl.hl,fn);
        fputs(s,caslog);
        z80.z80af.half.f=0x40;
        z80.z80af.half.a=0xFF;
        mz80SetContext(&z80);
}

void casread()
{
        char s[40];
        mz80GetContext(&z80);
        sprintf(s,"CAS READ - DE %04X HL %04X\n",z80.z80de.de,z80.z80hl.hl);
        fputs(s,caslog);
}

void inittape()
{
        caslog=fopen("caslog.txt","wt");
}
