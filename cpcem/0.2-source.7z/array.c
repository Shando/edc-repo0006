/*CPC-em - Gate Array emulation*/

#include <stdio.h>
#include "mz80.h"
#include "ga.h"
#include "mem.h"

/*Gate Array functions*/
#define SELECTPEN 0
#define SETPEN    1
#define SETMODE   2
#define SETRAM    3

/*RAM and ROM storage*/
unsigned char low[16384],high[16384];
unsigned char lomem[16384],himem[16384];

FILE *f;
char string[80];

/*Internal Gate Array registers*/
unsigned char curpen=0;
unsigned char cpcpal[16];
unsigned char cpcmode=1;

/*Initialise Gate Array*/
void initga()
{
        lowrom=1;
        highrom=0;
        nextint=0;
}

/*Write to Gate Array*/
void writega(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
//        sprintf(string,"Writing to Gate Array %04X %02X\n",port,val);
//        fputs(string,f);
        switch ((val>>6)&3)
        {
                case SELECTPEN: /*Select pen to change*/
                curpen=val&15;
                break;
                case SETPEN:    /*Change pen colour*/
                cpcpal[curpen]=val&31;
                break;
                case SETMODE:   /*ROM banking and mode switch*/
                cpcmode=val&3;
                /*Update ROM status*/
                if (val&4)
                   lowrom=0;
                else
                   lowrom=1;
                if (val&8)
                   highrom=0;
                else
                   highrom=1;
                if (lowrom)
                   memcpy(ram,low,16384);
                else
                   memcpy(ram,lomem,16384);
                if (highrom)
                   memcpy(ram+0xC000,high,16384);
                else
                   memcpy(ram+0xC000,himem,16384);
                if (val&16)
                   nextint=0;
                else
                   nextint=1;
                break;
                case SETRAM:    /*RAM banking - not emulated*/
                break;
        }
}

UINT16 readga(UINT16 port, struct z80PortRead *pPR)
{
        /*The gate array is write-only*/
//        sprintf(string,"Reading Gate Array %04X\n",port);
//        fputs(string,f);
        return 0xFE;
}
