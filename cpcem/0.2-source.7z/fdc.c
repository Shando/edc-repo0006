#include <stdio.h>
#include "mz80.h"

int incommand=0;
int params=0;
int track=0,sector=0,byte=0;
int fdcmethod;

void fdcint()
{
//        mz80nmi();
}

FILE *fdclog;

void initfdc()
{
        if (fdcmethod==2)
           outportb(0x3F2,0x4);
}

void fdcmotor(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
        char s[40];
        if (val&1)
        {
                if (fdcmethod==2)
                   outportb(0x3F2,0x14);
        }
        else
        {
                if (fdcmethod==2)
                   outportb(0x3F2,0x4);
        }
}

void specify()
{
}

void calibrate()
{
        track=0;
        fdcint();
}

typedef struct COMMAND
{
        unsigned char ins,params;
        void (*exec)();
} COMMAND;

#define commands 2
COMMAND fdccommands[]=
{
        {3,2,specify},
        {7,2,calibrate}
};

COMMAND command;

void startcommand(unsigned char val)
{
        int c;
        for (c=0;c<commands;c++)
        {
                if ((val&31)==fdccommands[c].ins)
                {
                        break;
                }
        }
        if (c==commands)
        {
                closegfx();
                printf("Bad command %02X\n",val);
                exit(-1);
        }
        command=fdccommands[c];
        incommand=1;
        params=fdccommands[c].params;
}

void handleparam()
{
        params--;
        if (!params)
        {
                command.exec();
                incommand=0;
        }
}

void writefdc(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
        char s[40];
        if (port==0xFB7F)
        {
                if (fdcmethod==1)
                {
                        if (!incommand)
                           startcommand(val);
                        else
                           handleparam(val);
                }
                if (fdcmethod==2)
                   outportb(0x3F5,val);
        }
}

UINT16 readfdc(UINT16 port, struct z80PortRead *pPR)
{
        char s[40];
        if (port==0xFB7F)
        {
                if (fdcmethod==2)
                   return inportb(0x3F5);
                return 0;
        }
        else
        {
                if (fdcmethod==2)
                   return inportb(0x3F4);
                return 0xFF;
        }
}
