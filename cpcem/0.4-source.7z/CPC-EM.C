#include <allegro.h>
#include "cpcem.h"

int quit,soundon;
int spdc=0;

void spdcr()
{
        spdc++;
}
END_OF_FUNCTION(spdcr);
int cpuline;

int main(int argc, char *argv[])
{
        int c;
        loadconfig();
        initz80();
        loadroms();
        resetz80();
        resetcrtc();
        allegro_init();
        install_keyboard();
        initvid();
        install_mouse();
        makelookup();
        loaddsk(argv[1]);
        initpsg();
        LOCK_FUNCTION(spdcr);
        LOCK_VARIABLE(spdc);
        install_int_ex(spdcr,MSEC_TO_TIMER(20));
        while (!key[KEY_F10] && !quit)
        {
                cpuline=0;
//                while (spdc>0)
//                {
                        execz80();
//                        spdc--;
//                }
                transfersound();
                if (soundon) mixpsg();
//                while (!mixpsg())
//                {
                if (key[KEY_F5])
                {
                        while (key[KEY_F5]) yield_timeslice();
                        resetz80();
                        rebuildmem();
                        spdc=0;
                }
                if (key[KEY_F11])
                {
                        while (key[KEY_F11]) yield_timeslice();
                        entergui();
                        spdc=0;
                }
//                }
//                drawscr();
        }
        saveconfig();
//        dumpregs();
        dumpscr();
//        dumpdisc();
        /*Check RAM banking*/
/*        writega(0,0x8C);
        for (c=0;c<0x20000;c+=0x4000) ram[c]=(c>>14);
        for (c=0;c<8;c++)
        {
                writega(0,0xC0|c);
                printf("Config %i : %i %i %i %i  %i %i %i %i\n",c,readmemf(0),readmemf(0x4000),readmemf(0x8000),readmemf(0xC000),readmemf2(0),readmemf2(0x4000),readmemf2(0x8000),readmemf2(0xC000));
        }
        printf("ROMs in\n");
        for (c=0;c<8;c++)
        {
                writega(0,0x80);
                writega(0,0xC0|c);
                writega(0,0x8C);
                printf("Config %i : %i %i %i %i  %i %i %i %i\n",c,readmemf(0),readmemf(0x4000),readmemf(0x8000),readmemf(0xC000),readmemf2(0),readmemf2(0x4000),readmemf2(0x8000),readmemf2(0xC000));
        }*/
        return 0;
}
