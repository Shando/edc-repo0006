#include <allegro.h>
#include "cpcem.h"

int model;
int linessincevsync,crtcline;
int vc,sc;
int palentry;
int ramconfig=0;

int ramconfigs[8][4]=
{
        {0,1,2,3},
        {0,1,2,7},
        {4,5,6,7},
        {0,3,2,7},
        {0,4,2,3},
        {0,5,2,3},
        {0,6,2,3},
        {0,7,2,3}
};

void updaterambanking()
{
        if (!loromena) readarray[0]=ram+(ramconfigs[ramconfig&7][0]*0x4000);
        else           readarray[0]=lorom;
        writearray[0]=ram+(ramconfigs[ramconfig&7][0]*0x4000);
        readarray[1]=ram+((ramconfigs[ramconfig&7][1]*0x4000)-0x4000);
        writearray[1]=ram+((ramconfigs[ramconfig&7][1]*0x4000)-0x4000);
        readarray[2]=ram+((ramconfigs[ramconfig&7][2]*0x4000)-0x8000);
        writearray[2]=ram+((ramconfigs[ramconfig&7][2]*0x4000)-0x8000);
        if (!hiromena) readarray[3]=ram+((ramconfigs[ramconfig&7][3]*0x4000)-0xC000);
        else           readarray[3]=hirom[curhrom]-0xC000;
        writearray[3]=ram+((ramconfigs[ramconfig&7][3]*0x4000)-0xC000);
}

void writega(unsigned short a, unsigned char v)
{
        switch (v&0xC0)
        {
                case 0x00: /*Pen selection*/
                palentry=v&31;
                break;
                case 0x40: /*Pen set*/
//                printf("pal %i = %i line %i %i lines since vsync disp line %i\n",palentry,v&31,(vc<<3)|sc,linessincevsync,crtcline-16);
                if (palentry&16) gaborder=(v&31)+1;
                else             gapal[palentry]=(v&31)+1;
                palchange=1;
                break;
                case 0x80: /*Screen mode and ROM configuration*/
                loromena=!(v&4);
                hiromena=!(v&8);
                if ((v&3)!=scrmode)
                {
//                        printf("Mode set %i line %i %i %i\n",v&3,vc,linessincevsync,crtcline-16);
                        palchange=1;
                }
                scrmode=v&3;
                if (v&4)
                {
                        if (ramconfig==2) readarray[0]=ram+0x10000;
                        else              readarray[0]=ram;
                }
                else
                   readarray[0]=lorom;
                if (v&8)
                {
                        if (ramconfig && ramconfig<4) readarray[3]=ram+0x10000;
                        else                          readarray[3]=ram;
                }
                else
                   readarray[3]=hirom[curhrom]-0xC000;
                if (v&16)
                {
                        galines&=~32;
                        intreq=0;
//                        printf("gaclear %02X line %i\n",v,(vc<<3)|sc);
                }
                updaterambanking();
//                printf("Ena now %i, cur %i\n",hiromena,curhrom);
                break;
                case 0xC0: /*RAM banking*/
//                printf("RAM config %i\n",v&7);
                if (model<2) ramconfig=0;
                else         ramconfig=v&7;
                updaterambanking();
                break;
        }
}

void cleargacount()
{
        galines&=~32;
}
