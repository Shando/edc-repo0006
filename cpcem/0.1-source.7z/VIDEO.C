/*CPC-em - video emulation*/

#include "mz80.h"
#include <stdio.h>
#include "gfx.h"

FILE *f;
unsigned char cpcmode;
char string[80];
/*Memory stuff*/
unsigned char himem[16384],lomem[16384];
/*CRTC registers*/
unsigned char crtcreg[32];
unsigned char curcrtcreg;
int mode2mode=0;
/*Lookup table*/
unsigned char mode1table[256][4];
unsigned char mode0table[256][2];
unsigned char mode2table[256][8];

/*CRTC ports*/
#define CRTCREG   0xBC00
#define CRTCWRITE 0xBD00
#define CRTCREAD  0xBF00

/*Palette - from Gate Array*/
unsigned char cpcpal[16];

/*CPC palette in PC form - some entries are probably wrong*/
PALETTE cpcpalpc=
{
        {31,31,31},
        {31,31,31},
        {0,63,31},
        {63,63,31},
        {0,0,31},
        {63,0,31},
        {0,31,31},
        {63,31,31},
        {63,0,31},
        {63,63,31},
        {63,63,0},
        {63,63,63},
        {63,0,0},
        {0,63,63},
        {63,31,0},
        {63,31,63},
        {0,0,31},
        {0,63,31},
        {0,63,0},
        {63,0,63},
        {0,0,0},
        {0,0,63},
        {0,31,0},
        {0,31,63},
        {31,0,31},
        {31,63,31},
        {31,63,0},
        {31,63,63},
        {31,0,0},
        {31,0,63},
        {31,31,0},
        {31,31,63}
};

/*Back buffer*/
BMP *b;

/*Initialise CRTC - I don't know what the power-on registers are*/
void initcrtc()
{
        curcrtcreg=0;
}

/*Write to CRTC*/
void writecrtc(UINT16 port, UINT8 val, struct z80PortWrite *pPW)
{
//        sprintf(string,"Writing to CRTC %04X %02X\n",port,val);
//        fputs(string,f);
        switch (port&0xFF00)
        {
                case CRTCREG:  /*Select a register*/
                curcrtcreg=val&31;
                break;
                case CRTCWRITE:/*Write to the selected register*/
                crtcreg[curcrtcreg]=val;
                break;
        }
}

/*Read from CRTC*/
UINT16 readcrtc(UINT16 port, struct z80PortRead *pPR)
{
//        sprintf(string,"Reading CRTC %04X\n",port);
//        fputs(string,f);
        switch (port&0xFF00)
        {
                /*I assume that you can just read from these*/
                case CRTCREG:
                return curcrtcreg;
                break;
                case CRTCREAD:
                return crtcreg[curcrtcreg];
                break;
        }
        return 0xFE;
}

unsigned char bits[8];

/*Generate lookup tables*/
void maketable()
{
        int c,d;
        /*Mode 1 format - pixel 1  pixel 2  pixel 3  pixel 4
                    bits -  7,3      6,2      5,1      4,0 */
        for (c=0;c<256;c++)
        {
                for (d=0;d<4;d++)
                {
                        mode1table[c][d]=0;
                        if (c&bits[d])
                           mode1table[c][d]|=2;
                        if (c&bits[d|4])
                           mode1table[c][d]|=1;
                }
        }
        /*Mode 0 format - pixel 1  pixel 2
                   bits -  0248     1357  */
        for (c=0;c<256;c++)
        {
                for (d=0;d<2;d++)
                {
                        mode0table[c][d]=0;
                        if (c&bits[d])
                           mode0table[c][d]|=8;
                        if (c&bits[d|2])
                           mode0table[c][d]|=4;
                        if (c&bits[d|4])
                           mode0table[c][d]|=2;
                        if (c&bits[d|6])
                           mode0table[c][d]|=1;
                }
        }
        /*Mode 2 format - pixel 1 2 3 4 5 6 7 8
                   bits -       7 6 5 4 3 2 1 0*/
        for (c=0;c<256;c++)
        {
                for (d=0;d<8;d++)
                {
                        mode2table[c][d]=0;
                        if (c&bits[d])
                           mode2table[c][d]=1;
                }
        }
}

/*Initialise video*/
void initvideo()
{
        b=createbmp(320,200);
        initgfx(VGA,320,200,0,0);
        setpal(cpcpalpc);
        maketable();
}

/*Draw the screen*/
void drawscreen()
{
        int x,y,xx,cy;
        unsigned short addr=crtcreg[13]|(crtcreg[12]<<8);
        unsigned char val;
        addr<<=1;
        switch (cpcmode)
        {
                case 0:
                /*Loop through character rows*/
                for (cy=0;cy<8;cy++)
                {
                        addr=((crtcreg[13]|(crtcreg[12]<<8))<<1)&0x7FF;
                        addr|=(cy<<11);
                        /*Loop through rows*/
                        for (y=0;y<200;y+=8)
                        {
                                /*Loop through columns*/
                                for (x=0;x<crtcreg[1]<<3;x+=4)
                                {
                                        val=himem[(addr)&0x3FFF];
                                        addr++;
                                        /*Decode the byte*/
                                        b->line[y+cy][x]=cpcpal[mode0table[val][1]];
                                        b->line[y+cy][x+1]=cpcpal[mode0table[val][1]];
                                        b->line[y+cy][x+2]=cpcpal[mode0table[val][0]];
                                        b->line[y+cy][x+3]=cpcpal[mode0table[val][0]];
                                }
                        }
                }
                break;
                case 1:
                /*Loop through character rows*/
                for (cy=0;cy<8;cy++)
                {
                        addr=((crtcreg[13]|(crtcreg[12]<<8))<<1)&0x7FF;
                        addr|=(cy<<11);
                        /*Loop through rows*/
                        for (y=0;y<200;y+=8)
                        {
                                /*Loop through columns*/
                                for (x=0;x<crtcreg[1]<<3;x+=4)
                                {
                                        val=himem[(addr)&0x3FFF];
                                        addr++;
                                        /*Decode the byte*/
                                        b->line[y+cy][x]=cpcpal[mode1table[val][3]];
                                        b->line[y+cy][x+1]=cpcpal[mode1table[val][2]];
                                        b->line[y+cy][x+2]=cpcpal[mode1table[val][1]];
                                        b->line[y+cy][x+3]=cpcpal[mode1table[val][0]];
                                }
                        }
                }
                break;
                case 2:
                /*Loop through character rows*/
                for (cy=0;cy<8;cy++)
                {
                        addr=((crtcreg[13]|(crtcreg[12]<<8))<<1)&0x7FF;
                        addr|=(cy<<11);
                        /*Loop through rows*/
                        for (y=0;y<200;y+=8)
                        {
                                /*Loop through columns*/
                                for (x=0;x<crtcreg[1]<<3;x+=4)
                                {
                                        val=himem[(addr)&0x3FFF];
                                        addr++;
                                        /*Decode the byte*/
                                        if (mode2mode)
                                        {
                                                b->line[y+cy][x]=cpcpal[mode2table[val][6]];
                                                b->line[y+cy][x+1]=cpcpal[mode2table[val][4]];
                                                b->line[y+cy][x+2]=cpcpal[mode2table[val][2]];
                                                b->line[y+cy][x+3]=cpcpal[mode2table[val][0]];
                                        }
                                        else
                                        {
                                                b->line[y+cy][x]=cpcpal[mode2table[val][7]];
                                                b->line[y+cy][x+1]=cpcpal[mode2table[val][5]];
                                                b->line[y+cy][x+2]=cpcpal[mode2table[val][3]];
                                                b->line[y+cy][x+3]=cpcpal[mode2table[val][1]];
                                        }
                                }
                        }
                }
                break;
        }
        /*Copy to screen*/
        blit(b,screen,0,0,0,0,320,200);
        if (keys[KEY_F8])
           savepcx("cpcdump.pcx",b,cpcpalpc);
}

/*Shut down the graphics*/
void shutdowngfx()
{
        int c;
        closegfx();
        free(b);
}
