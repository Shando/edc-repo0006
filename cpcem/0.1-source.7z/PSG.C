/*CPC-em - PSG emulation*/

#include "gfx.h"

/*Keyboard table*/
unsigned char cpckeys[16][8]=
{
        {KEY_UP,KEY_RIGHT,KEY_DOWN,0,0,0,KEY_HOME,0},
        {KEY_LEFT,KEY_INSERT,0,0,0,0,0,0},
        {KEY_DEL,0,KEY_ENTER,0,0,KEY_RSHIFT,KEY_BSLASH,KEY_CTRL},
        {KEY_F2,KEY_MINUS,KEY_F1,KEY_P,KEY_SCOLON,KEY_QUOTA,KEY_SLASH,KEY_DOT},
        {KEY_0,KEY_9,KEY_O,KEY_I,KEY_L,KEY_K,KEY_M,KEY_COMA},
        {KEY_8,KEY_7,KEY_U,KEY_Y,KEY_H,KEY_J,KEY_N,KEY_SPACE},
        {KEY_6,KEY_5,KEY_R,KEY_T,KEY_G,KEY_F,KEY_B,KEY_V},
        {KEY_4,KEY_3,KEY_E,KEY_W,KEY_S,KEY_D,KEY_C,KEY_X},
        {KEY_1,KEY_2,KEY_ESC,KEY_Q,KEY_TAB,KEY_A,KEY_CAPS,KEY_Z},
        {0,0,0,0,0,0,0,KEY_BACKSP},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0}
};

/*PSG registers*/
unsigned char psgreg;
unsigned char psgregs[16];
unsigned char psgfunc;
unsigned char psgport;
unsigned char keyline=0;

unsigned char bitss[8]={1,2,4,8,16,32,64,128};

/*Scan the selected keyboard line*/
unsigned char scankey()
{
        int c;
        unsigned char val=0;
        for (c=0;c<8;c++)
        {
                if (keys[cpckeys[keyline][c]])
                   val|=bitss[c];
        }
        return val^0xFF;
}

/*Initialise PSG*/
void initpsg()
{
        int c;
        for (c=0;c<16;c++)
            psgregs[c]=0;
        psgfunc=psgport=psgreg=0;
}

/*Write to PSG port*/
void writepsg(unsigned char val)
{
        psgport=val;
}

/*Read from PSG port*/
unsigned char readpsg()
{
        return psgport;
}

/*Write to PSG control*/
void writepsgcon(unsigned char val)
{
        switch (val&0xC0)
        {
                case 0x00: /*No function*/
                break;
                case 0x40: /*Read register*/
                if (psgreg==14)
                   psgregs[psgreg]=scankey();
                psgport=psgregs[psgreg];
                break;
                case 0x80: /*Write register*/
                psgregs[psgreg]=psgport;
                break;
                case 0xC0: /*Select register*/
                psgreg=psgport&15;
                break;
        }
        keyline=(val&15)+1; /*Update selected keyboard line*/
}
