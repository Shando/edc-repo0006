/*CPC-em - memory emulation*/

#include "mz80.h"
#include "mem.h"
#include "ga.h"
#include <stdio.h>

/*There's not a lot in here*/
/*ROMs*/
unsigned char low[16384],high[16384];

/*Load ROMs*/
void initmem()
{
        FILE *f;
        memset(ram,0,65536);
        f=fopen("cpc664.rom","rb");
        if (!f)
        {
                printf("Missing CPC664.ROM (CPC ROM)\nCPC-em can not run without it\nDid you delete it?\n");
                exit(-1);
        }
        fread(low,16384,1,f);
        fread(high,16384,1,f);
        fclose(f);
        memcpy(ram,low,16384);
}
