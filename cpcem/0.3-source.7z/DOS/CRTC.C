#include <allegro.h>
#include "cpcem.h"

int motoron=0;
int vols[3][512];
int resolution=1;
int vc,sc,crtcline,vsyncpulse;
unsigned short ma;

unsigned char crtcregs[32];
int crtcreg;
unsigned short crtctable[8][0x8000];

PALETTE cpcpalpc=
{
        {0,0,0},
        {31,31,31},
        {31,31,31},
        {0,63,31},
        {63,63,31},
        {0,0,31},
        {63,0,31},
        {0,31,31},
        {63,31,31},
        {63,0,31},
        {63,63,31},
        {63,63,0},
        {63,63,63},
        {63,0,0},
        {0,63,63},
        {63,31,0},
        {63,31,63},
        {0,0,31},
        {0,63,31},
        {0,63,0},
        {63,0,63},
        {0,0,0},
        {0,0,63},
        {0,31,0},
        {0,31,63},
        {31,0,31},
        {31,63,31},
        {31,63,0},
        {31,63,63},
        {31,0,0},
        {31,0,63},
        {31,31,0},
        {31,31,63},
        {47,47,47},
        {15,15,15}
};

static int frames=0,fps=0;

static void framecount()
{
        fps=frames;
        frames=0;
}

END_OF_FUNCTION(framecount);

BITMAP *b;
void initvid()
{
        if (resolution) set_gfx_mode(GFX_VESA2L,800,600,0,0);
        else            set_gfx_mode(GFX_VESA2L,400,300,0,0);
        b=create_bitmap(1024,1024);
        clear(b);
        cpcpalpc[255].r=cpcpalpc[255].g=cpcpalpc[255].b=63;
        set_palette(cpcpalpc);
        install_timer();
        install_int_ex(framecount,MSEC_TO_TIMER(1000));
}

void switchres()
{
        if (resolution) set_gfx_mode(GFX_VESA2L,800,600,0,0);
        else            set_gfx_mode(GFX_VESA2L,400,300,0,0);
        remakelookup();
        set_palette(cpcpalpc);
        clear(b);
}

void writecrtc(unsigned short a, unsigned char v)
{
        switch (a&0xFF00)
        {
                case 0xBC00: crtcreg=v&31; return;
                case 0xBD00: crtcregs[crtcreg]=v; return;
        }
}

unsigned char readcrtc(unsigned short a)
{
        switch (a&0xFF00)
        {
                case 0xBF00: return crtcregs[crtcreg];
        }
}

void resetcrtc()
{
        vc=sc=crtcline=vsyncpulse=0;
}

unsigned long look2bpp[256],look2bpph[256][2];

void makelookup()
{
        int c,d;
        /*Address table*/
        for (c=0;c<0x7FFF;c++)
        {
                for (d=0;d<8;d++)
                {
                        crtctable[d][c]=(c&0x7FF)|(d<<11)|((c&0x6000)<<1);
                }
        }
}

void remakelookup()
{
        int c,d,e;
        switch (scrmode|((resolution)?4:0))
        {
                case 0:
                for (c=0;c<256;c++)
                {
                        look2bpp[c]=0;
                        d=((c&1)<<3) | ((c&4)>>1) | ((c&0x10)>>2) | ((c&0x40)>>6);
                        look2bpp[c]|=gapal[d]<<16;
                        e=c>>1;
                        d=((e&1)<<3) | ((e&4)>>1) | ((e&0x10)>>2) | ((e&0x40)>>6);
                        look2bpp[c]|=gapal[d];
                        look2bpp[c]|=(look2bpp[c]<<8);
                }
                break;
                case 1:
                for (c=0;c<256;c++)
                {
                        look2bpp[c]=0;
                        d=((c&1)<<1)|((c&0x10)>>4);
                        look2bpp[c]|=gapal[d]<<24;
                        d=(((c&2)<<1)|((c&0x20)>>4))>>1;
                        look2bpp[c]|=gapal[d]<<16;
                        d=(((c&4)<<1)|((c&0x40)>>4))>>2;
                        look2bpp[c]|=gapal[d]<<8;
                        d=(((c&8)<<1)|((c&0x80)>>4))>>3;
                        look2bpp[c]|=gapal[d];
                }
                break;
                case 2:
                for (c=0;c<256;c++)
                {
                        look2bpp[c]=gapal[c&1]<<24;
                        look2bpp[c]|=gapal[(c>>2)&1]<<16;
                        look2bpp[c]|=gapal[(c>>4)&1]<<8;
                        look2bpp[c]|=gapal[(c>>6)&1];
                }
                break;
                case 4:
                for (c=0;c<256;c++)
                {
                        d=((c&1)<<3) | ((c&4)>>1) | ((c&0x10)>>2) | ((c&0x40)>>6);
                        look2bpph[c][1]=gapal[d]|(gapal[d]<<8);
                        look2bpph[c][1]|=(look2bpph[c][1]<<16);
                        e=c>>1;
                        d=((e&1)<<3) | ((e&4)>>1) | ((e&0x10)>>2) | ((e&0x40)>>6);
                        look2bpph[c][0]=gapal[d]|(gapal[d]<<8);
                        look2bpph[c][0]|=(look2bpph[c][0]<<16);
                }
                break;
                case 5:
                for (c=0;c<256;c++)
                {
                        look2bpph[c][0]=look2bpph[c][1]=0;
                        d=((c&1)<<1)|((c&0x10)>>4);
                        look2bpph[c][1]|=gapal[d]<<24;
                        look2bpph[c][1]|=gapal[d]<<16;
                        d=(((c&2)<<1)|((c&0x20)>>4))>>1;
                        look2bpph[c][1]|=gapal[d]<<8;
                        look2bpph[c][1]|=gapal[d];
                        d=(((c&4)<<1)|((c&0x40)>>4))>>2;
                        look2bpph[c][0]|=gapal[d]<<24;
                        look2bpph[c][0]|=gapal[d]<<16;
                        d=(((c&8)<<1)|((c&0x80)>>4))>>3;
                        look2bpph[c][0]|=gapal[d]<<8;
                        look2bpph[c][0]|=gapal[d];
                }
                break;
                case 6:
                for (c=0;c<256;c++)
                {
                        look2bpph[c][0]=gapal[(c>>7)&1];
                        look2bpph[c][0]|=gapal[(c>>6)&1]<<8;
                        look2bpph[c][0]|=gapal[(c>>5)&1]<<16;
                        look2bpph[c][0]|=gapal[(c>>4)&1]<<24;
                        look2bpph[c][1]=gapal[(c>>3)&1];
                        look2bpph[c][1]|=gapal[(c>>2)&1]<<8;
                        look2bpph[c][1]|=gapal[(c>>1)&1]<<16;
                        look2bpph[c][1]|=gapal[c&1]<<24;
                }
                break;
        }
}

void pollline()
{
        int x,xoff;
        unsigned char v;
        vols[0][crtcline&511]=psgregs[8];
        vols[1][crtcline&511]=psgregs[9];
        vols[2][crtcline&511]=psgregs[10];
//        printf("Line %i : VC %i SC %i PC %04X R5 %i\n",crtcline,vc,sc,pc,crtcregs[5]);
        if (crtcline<(crtcregs[5]&31))
        {
                crtcline++;
                return;
        }
        if (vc<crtcregs[6])
        {
//                printf("Drawing line %i from %04X\n",crtcline&511,crtctable[sc][ma]);
                if (palchange)
                {
                        remakelookup();
                        palchange=0;
                }
                if (resolution)
                {
                        xoff=(50-crtcregs[1])<<1;
                        hline(b,0,((crtcline-16)&511)<<1,xoff<<2,gaborder);
                        for (x=0;x<crtcregs[1]<<1;x++)
                        {
                                v=ram[crtctable[sc][ma+x]];
                                ((unsigned long *)b->line[((crtcline-16)&511)<<1])[((x<<1)+xoff)&254]=look2bpph[v][0];
                                ((unsigned long *)b->line[((crtcline-16)&511)<<1])[(((x<<1)+xoff)&254)+1]=look2bpph[v][1];
                        }                        
                        hline(b,((x<<1)+xoff)<<2,((crtcline-16)&511)<<1,800,gaborder);
                }
                else
                {
                        xoff=50-crtcregs[1];
                        hline(b,0,(crtcline-16)&511,xoff<<2,gaborder);
                        for (x=0;x<crtcregs[1]<<1;x++)
                        {
                                v=ram[crtctable[sc][ma+x]];
                                ((unsigned long *)b->line[(crtcline-16)&511])[(x+xoff)&127]=look2bpp[v];
                        }
                        hline(b,(x+xoff)<<2,(crtcline-16)&511,400,gaborder);
                }
                if (sc==crtcregs[9]) ma+=crtcregs[1]<<1;
        }
        else
        {
                if (resolution) hline(b,0,((crtcline-16)&511)<<1,799,gaborder);
                else            hline(b,0,(crtcline-16)&511,399,gaborder);
        }
        galines++;
//        printf("galines %i %i\n",galines,intreq);
        if (galines==52)
        {
                galines=0;
                intreq=1;
//                printf("Interrupt at line %i %i vbl %i PC %04X lorom %i\n",crtcline,(vc<<3)|sc,crtcvsync,pc,loromena);
        }
        if (vsyncpulse)
        {
                vsyncpulse--;
//                printf("vsyncpulse %i\n",vsyncpulse);
                if (!vsyncpulse) crtcvsync=0;
                if (vsyncpulse==((crtcregs[3]>>4)-2))
                {
//                        printf("galines were %i at line %i\n",galines,crtcline);
                        galines=0;
                        intreq=1;
                }
        }
        if (sc==crtcregs[9])
        {
                sc=0;
                vc++;
        }
        else if (!(crtcline<(crtcregs[5]&31)))
        {
//                printf("SC=%i %i %i\n",sc,crtcline,crtcregs[5]);
                sc++;
                sc&=31;
        }
        crtcline++;
        if (vc==crtcregs[7]+1 && !sc)
        {
//                textprintf(b,font,0,0,1,"%i %i %i",fps,psgregs[7]&7,(psgregs[7]>>3)&7);
                frames++;
//                printf("Blank at line %i %i\n",crtcline,(vc<<3)|sc);
                if (motoron)
                {
                        if (resolution) rectfill(b,770,8,786,16,13);
                        else            rectfill(b,770>>1,8>>1,786>>1,16>>1,13);
                }
                if (resolution) blit(b,screen,0,0,0,0,800,600);
                else            blit(b,screen,0,0,0,0,400,300);
                if (motoron)
                {
                        if (resolution) rectfill(b,770,8,786,16,0);
                }
//                clear_to_color(b,gaborder);
                crtcline=0;
                memcpy(psgvols,vols,sizeof(vols));
//                printf("vsyncpulse %i crtcregs[3] %02X\n",vsyncpulse,crtcregs[3]);
                vsyncpulse=crtcregs[3]>>4;
                crtcvsync=1;
        }
        if (vc==crtcregs[4]+1)
        {
//                printf("Reset at line %i %i  ",crtcline,(vc<<3)|sc);
                sc=vc=0;
                ma=(crtcregs[13]|((crtcregs[12]&0x3F)<<8))<<1;
//                printf("%04X\n",crtctable[0][ma]);
        }
}
