#include <stdio.h>
#include <allegro.h>
#include "cpcem.h"

int soundavail;
AUDIOSTREAM *as;
int quit=0;
int resolution,model=0,soundon=0;
BITMAP *mousep=NULL;
MENU discmenu[];
MENU modelmenu[];
MENU soundmenu[];
MENU videomenu[];
MENU cpcemmenu[];
char discname[260]="";

void loadconfig()
{
        FILE *f=fopen("cpc-em.cfg","rb");
        resolution=getc(f);
        model=getc(f);
        soundon=getc(f);
        fread(discname,260,1,f);
        fclose(f);
}

void saveconfig()
{
        FILE *f=fopen("cpc-em.cfg","wb");
        putc(resolution,f);
        putc(model,f);
        putc(soundon,f);
        fwrite(discname,260,1,f);
        fclose(f);
}

int menuload()
{
        char tempname[260];
        int x=(resolution)?600:300,y=(resolution)?480:240;
        memcpy(tempname,discname,260);
        if (file_select_ex("Please select a disc image",tempname,"DSK",x,y))
        {
                memcpy(discname,tempname,260);
                loaddsk();
        }
        return D_EXIT;
}

int menu464()
{
        modelmenu[0].flags|=D_SELECTED;
        modelmenu[1].flags&=~D_SELECTED;
        model=0;
        return D_EXIT;
}

int menu664()
{
        modelmenu[1].flags|=D_SELECTED;
        modelmenu[0].flags&=~D_SELECTED;
        model=1;
        return D_EXIT;
}

int menusndena()
{
        soundmenu[0].flags^=D_SELECTED;
        soundon^=1;
        return D_EXIT;
}

int menuhires()
{
        videomenu[0].flags|=D_SELECTED;
        videomenu[1].flags&=~D_SELECTED;
        resolution=1;
        return D_EXIT;
}

int menulores()
{
        videomenu[1].flags|=D_SELECTED;
        videomenu[0].flags&=~D_SELECTED;
        resolution=0;
        return D_EXIT;
}

int menureturn()
{
        return D_EXIT;
}

int menuexit()
{
        return D_EXIT;
}

MENU discmenu[]=
{
        {"Load disc",menuload,NULL,0,0},
        {0,0,0,0,0}
};

MENU modelmenu[]=
{
        {"464",menu464,NULL,0,0},
        {"664",menu664,NULL,0,0},
        {0,0,0,0,0}
};

MENU soundmenu[]=
{
        {"Enable",menusndena,NULL,0,0},
        {0,0,0,0,0}
};

MENU videomenu[]=
{
        {"High resolution",menuhires,NULL,0,0},
        {"Low resolution",menulores,NULL,0,0},
        {0,0,0,0,0}
};

MENU cpcemmenu[]=
{
        {"Return",menureturn,NULL,0,NULL},
        {"Disc",NULL,discmenu,0,0},
        {"Model",NULL,modelmenu,0,0},
        {"Sound",NULL,soundmenu,0,0},
        {"Video",NULL,videomenu,0,0},
        {"Exit",menuexit,NULL,0,NULL},
        {0,0,0,0,0}
};

void entergui()
{
        int ret;
        int c;
        while (keypressed()) readkey();
        for (c=0;c<128;c++) key[c]=0;
        gui_fg_color=makecol(255,255,255);
        gui_bg_color=makecol(0,0,0);
        if (!mousep) makemousepointer();
        if (model)
        {
                modelmenu[0].flags=0;
                modelmenu[1].flags=D_SELECTED;
        }
        else
        {
                modelmenu[1].flags=0;
                modelmenu[0].flags=D_SELECTED;
        }
        if (resolution)
        {
                videomenu[1].flags=0;
                videomenu[0].flags=D_SELECTED;
        }
        else
        {
                videomenu[0].flags=0;
                videomenu[1].flags=D_SELECTED;
        }
        if (soundon) soundmenu[0].flags=D_SELECTED;
        else         soundmenu[0].flags=0;
        if (soundon) stop_audio_stream(as);
        show_mouse(screen);
        ret=do_menu(cpcemmenu,0,0);
        show_mouse(NULL);
        if (soundon)
        {
                if (!soundavail)
                {
                        if (install_sound(DIGI_AUTODETECT,MIDI_NONE,0))
                        {
                                soundavail=0;
                                soundon=0;
                        }
                        else soundavail=1;
                }
                if (soundon) as=play_audio_stream(1228,8,0,15600<<2,255,127);
        }
        if (ret==2)
        {
                loadroms();
                resetz80();
                rebuildmem();
        }
        if (ret==4) switchres();
        if (ret==5) quit=1;
}

/*Since Allegro's mouse pointer keeps coming out in PINK, here's some custom
  mouse pointer creaty code*/

unsigned char mousepointer[256] =
{
        1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,1,0,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,1,0,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,
        1,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,
        1,2,2,2,2,2,1,1,1,0,0,0,0,0,0,0,
        1,2,2,1,2,2,1,0,0,0,0,0,0,0,0,0,
        1,2,1,0,1,2,2,1,0,0,0,0,0,0,0,0,
        0,1,0,0,1,2,2,1,0,0,0,0,0,0,0,0,
        0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0,
        0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0,
        0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0
};

void makemousepointer()
{
        int x,y;
        mousep=create_bitmap(16,16);
        for (y=0;y<16;y++)
        {
                for (x=0;x<16;x++)
                {
                        switch (mousepointer[x|(y<<4)])
                        {
                                case 0: mousep->line[y][x]=0;   break;
                                case 1: mousep->line[y][x]=254; break;
                                case 2: mousep->line[y][x]=255; break;
                        }
                }
        }
        set_mouse_sprite(mousep);
}
