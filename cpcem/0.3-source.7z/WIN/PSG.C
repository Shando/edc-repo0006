#include <allegro.h>
#include <stdio.h>
#include "cpcem.h"

int soundon,soundavail;
AUDIOSTREAM *as;
int psgcount[4],psglatch[4],psgvol[4],psgstat[4];
FILE *sndf;

void initpsg()
{
        int c;
        if (install_sound(DIGI_AUTODETECT,MIDI_NONE,0)) { soundon=0; soundavail=0; }
        else soundavail=1;
        if (soundon) as=play_audio_stream(1228,8,0,15600<<2,255,127);
        for (c=0;c<4;c++)
        {
                psgstat[c]=1;
                psgcount[c]=0xFFFF;
                psglatch[c]=0xFFFF;
                psgvol[c]=0;
        }
//        sndf=fopen("sound.pcm","wb");
}

void updatepsg()
{
        switch (psgmode)
        {
                case 1:
                psgdat=psgregs[psgreg];
                break;
                case 2:
                psgregs[psgreg]=psgdat;
                break;
                case 3:
                psgreg=psgdat;
                break;
        }
}

/*Keyboard table*/
int cpckeys[16][8]=
{
        {0xFF,0xFF,0xFF,KEY_9_PAD,KEY_6_PAD,KEY_3_PAD,KEY_ENTER_PAD,KEY_DEL_PAD},
        {0xFF,0xFF,KEY_7_PAD,KEY_8_PAD,KEY_5_PAD,KEY_1_PAD,KEY_2_PAD,KEY_0_PAD},
        {KEY_DEL,KEY_OPENBRACE,KEY_ENTER,KEY_CLOSEBRACE,KEY_4_PAD,KEY_RSHIFT,KEY_BACKSLASH,KEY_RCONTROL},
        {KEY_F2,KEY_MINUS,KEY_TILDE,KEY_P,KEY_COLON,KEY_QUOTE,KEY_SLASH,KEY_STOP},
        {KEY_0,KEY_9,KEY_O,KEY_I,KEY_L,KEY_K,KEY_M,KEY_COMMA},
        {KEY_8,KEY_7,KEY_U,KEY_Y,KEY_H,KEY_J,KEY_N,KEY_SPACE},
        {KEY_6,KEY_5,KEY_R,KEY_T,KEY_G,KEY_F,KEY_B,KEY_V},
        {KEY_4,KEY_3,KEY_E,KEY_W,KEY_S,KEY_D,KEY_C,KEY_X},
        {KEY_1,KEY_2,KEY_ESC,KEY_Q,KEY_TAB,KEY_A,KEY_CAPSLOCK,KEY_Z},
        {KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,KEY_INSERT,0xFF,0xFF,KEY_BACKSPACE},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
        {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}
};

void updatekeys(int line)
{
        int c;
        psgregs[14]=0xFF;
        for (c=0;c<8;c++)
        {
                if (key[cpckeys[line][c]] && (cpckeys[line][c]!=0xFF))
                {
                        psgregs[14]&=~(1<<c);
                }
        }
}

int mixpsg()
{
        int c;
        signed char *buf;
        unsigned char *ubuf;
        buf=(signed char *)get_audio_stream_buffer(as);
        ubuf=(unsigned char *)buf;
        if (buf)
        {
                psglatch[0]=((psgregs[0]|((psgregs[1]<<8)&0xF00))>>1)+1;
                psglatch[1]=((psgregs[2]|((psgregs[3]<<8)&0xF00))>>1)+1;
                psglatch[2]=((psgregs[4]|((psgregs[5]<<8)&0xF00))>>1)+1;
                psglatch[3]=(psgregs[6]>>2)+1;
                psgvol[0]=psgregs[8]&15;
                psgvol[1]=psgregs[9]&15;
                psgvol[2]=psgregs[10]&15;
                for (c=0;c<1228;c++)
                {
                        buf[c]=0;
                        if (!(psgregs[7]&1) && !(psgregs[8]&0x10))
                        {
                                if (psglatch[0]<2) buf[c]+=psgvols[0][c>>2];
                                else               buf[c]+=((psgstat[0]*psgvols[0][c>>2]));
                        }
                        if (!(psgregs[7]&2) && !(psgregs[9]&0x10))
                        {
                                if (psglatch[1]<2) buf[c]+=psgvols[1][c>>2];
                                else               buf[c]+=((psgstat[1]*psgvols[1][c>>2]));
                        }
                        if (!(psgregs[7]&4) && !(psgregs[10]&0x10))
                        {
                                if (psglatch[2]<2) buf[c]+=psgvols[2][c>>2];
                                else               buf[c]+=((psgstat[2]*psgvols[2][c>>2]));
                        }

                        if (!(psgregs[7]&8) && !(psgregs[8]&0x10))
                        {
                                buf[c]+=((psgstat[3]*psgvols[0][c>>2]));
                        }
                        if (!(psgregs[7]&16) && !(psgregs[9]&0x10))
                        {
                                buf[c]+=((psgstat[3]*psgvols[1][c>>2]));
                        }
                        if (!(psgregs[7]&32) && !(psgregs[10]&0x10))
                        {
                                buf[c]+=((psgstat[3]*psgvols[2][c>>2]));
                        }

                        if (psgcount[0]>=psglatch[0]) { psgstat[0]=-psgstat[0]; psgcount[0]=0; }
                        if (psgcount[1]>=psglatch[1]) { psgstat[1]=-psgstat[1]; psgcount[1]=0; }
                        if (psgcount[2]>=psglatch[2]) { psgstat[2]=-psgstat[2]; psgcount[2]=0; }
                        if (psgcount[3]>=psglatch[3]) { psgstat[3]=(rand()&2)-1; psgcount[3]=0; }

                        psgcount[0]++;
                        psgcount[1]++;
                        psgcount[2]++;
                        psgcount[3]++;
                        buf[c]*=2;
                }
//                printf("%04X %04X %04X %04X  %i %i\n",psglatch[0],psglatch[1],psglatch[2],psglatch[3],psgregs[7]&7,(psgregs[7]>>3)&7);
                for (c=0;c<1228;c++) ubuf[c]^=0x80;
                free_audio_stream_buffer(as);
                return 1;
        }
        return 0;
}
