#include <allegro.h>
#include "cpcem.h"

int quit,soundon;
int spdc=0;

void spdcr()
{
        spdc++;
}
END_OF_FUNCTION(spdcr);

int main(int argc, char *argv[])
{
        char s[80];
        loadconfig();
        initz80();
        loadroms();
        resetz80();
        resetcrtc();
        allegro_init();
        install_keyboard();
        install_mouse();
        initvid();
        makelookup();
        loaddsk(argv[1]);
        initpsg();
        LOCK_FUNCTION(spdcr);
        LOCK_VARIABLE(spdc);
        install_int_ex(spdcr,MSEC_TO_TIMER(20));
        while (!key[KEY_F10] && !quit)
        {
                while (spdc>0)
                {
//                        sprintf(s,"%i fps",fps);
//                        set_window_title(s);
                        execz80();
                        spdc--;
                        if (key[KEY_F5])
                        {
                                remove_int(spdcr);
                                while (key[KEY_F5]) yield_timeslice();
                                resetz80();
                                rebuildmem();
                                install_int_ex(spdcr,MSEC_TO_TIMER(20));
                        }
                        if (key[KEY_F11])
                        {
                                remove_int(spdcr);
                                while (key[KEY_F11]) yield_timeslice();
                                entergui();
                                install_int_ex(spdcr,MSEC_TO_TIMER(20));
                        }
                }
                if (soundon) mixpsg();
//                while (!mixpsg())
//                {
        }
        saveconfig();
        return 0;
}

END_OF_MAIN();
