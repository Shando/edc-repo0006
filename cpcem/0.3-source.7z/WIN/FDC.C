/*C72B - try command*/
/*A9B0*/
#include <stdio.h>

int motoron;
char discname[260];
int discon;
int endread;

int output;
unsigned short pc;

int fdcint=0;
unsigned char fdcstatus=0x80;
int params=0,readparams=0;
unsigned char paramdat[16];
unsigned char command;
unsigned char st0,st1,st2,st3;
int fdctrack;
int starttrack,startsector,endsector;
int posinsector;
int reading=0;

int disctracks;
int discsects[40];
unsigned char discdat[42][9][512];
unsigned char discid[42][9][4];

void loaddsk()
{
        int numsect;
        int c,d;
        char head[40];
        unsigned char dskhead[256],trkhead[256];
        FILE *f=fopen(discname,"rb");
        if (!f) return;
        fread(dskhead,256,1,f);
        for (c=0;c<40;c++) head[c]=0;
        for (c=0;c<0x21;c++) head[c]=dskhead[c];
        disctracks=dskhead[0x30];
//        printf("%i tracks\n",dskhead[0x30]);
//        printf("%s\n",head);
        for (d=0;d<disctracks;d++)
        {
//                printf("Track %i ftell %05X : ",d,ftell(f));
                fread(trkhead,256,1,f);
                discsects[d]=numsect=trkhead[0x15];
//                printf("%i sectors\n",discsects[d]);
                for (c=0;c<numsect;c++)
                {
                        discid[d][c][0]=trkhead[0x18+(c<<3)];
                        discid[d][c][1]=trkhead[0x19+(c<<3)];
                        discid[d][c][2]=trkhead[0x1A+(c<<3)];
                        discid[d][c][3]=trkhead[0x1B+(c<<3)];
//                        printf("%i %i %i %i  ",discid[d][c][0],discid[d][c][1],discid[d][c][2],discid[d][c][3]);
                        fread(discdat[d][c],512,1,f);
                }
//                printf("\n");
        }
//        printf("DSK pos %i\n",ftell(f));
        fclose(f);
}

unsigned char readfdc(unsigned short addr)
{
        unsigned char temp;
//        printf("Read %04X  %04X\n",addr,pc);
        if (addr&1)
        {
                if (!readparams)
                {
                        printf("Reading but no params - last command %02X\n",command);
                        exit(-1);
                }
                switch (command)
                {
                        case 0x04: /*Sense drive status*/
                        readparams=0;
                        fdcstatus=0x80;
                        return st3;

                        case 0x06: /*Read sectors*/
                        if (reading)
                        {
                                temp=discdat[fdctrack][startsector-1][posinsector];
//                                printf("%c",temp);
                                posinsector++;
                                if (posinsector==512)
                                {
                                        if (startsector==endsector)
                                        {
                                                reading=0;
                                                readparams=7;
//                                                output=1;
                                                fdcstatus=0xD0;
//                                                if (startsector==4) output=1;
//                                                printf("Done it %04X\n",pc);
                                                endread=1;
                                                fdcint=1;
                                                discon=0;
//                                                output=1;
//                                                dumpregs();
//                                                dumpram();
//                                                exit(-1);
                                        }
                                        else
                                        {
                                                posinsector=0;
                                                startsector++;
                                                if (startsector==(discsects[fdctrack]+1))
                                                {
                                                        if (command&0x80)
                                                           fdctrack++;
                                                        startsector=1;
                                                }
                                        }
                                }
                                return temp;
                        }
                        readparams--;
                        switch (readparams)
                        {
                                case 6: st0=0x40; st1=0x80; st2=0; return st0;
                                case 5: return st1;
                                case 4: return st2;
                                case 3: return fdctrack;
                                case 2: return 0;
                                case 1: return startsector;
                                case 0: fdcstatus=0x80; return 2;
                        }
                        break;

                        case 0x08: /*Sense interrupt state*/
                        readparams--;
                        if (readparams==1)
                           return st0;
                        fdcstatus=0x80;
                        return fdctrack;

                        case 0x0A: /*Read sector ID*/
                        readparams--;
                        switch (readparams)
                        {
                                case 6: return st0;
                                case 5: return st1;
                                case 4: return st2;
                                case 3: return discid[fdctrack][startsector][0];
                                case 2: return discid[fdctrack][startsector][1];
                                case 1: return discid[fdctrack][startsector][2];
                                case 0: fdcstatus=0x80; return discid[fdctrack][startsector][3];
                        }
                        break;

                        default:
                        printf("Reading command %02X\n",command);
                        exit(-1);
                }
        }
        else
        {
//                if (reading)
//                   fdcstatus^=0x80;
                return fdcstatus;
        }
}

void writefdc(unsigned short addr, unsigned char val)
{
//        printf("Write %04X %02X  %04X\n",addr,val,pc);
        if (addr==0xFA7E)
        {
                motoron=val&1;
                return;
        }
        if (addr&1)
        {
                if (params)
                {
                        paramdat[params-1]=val;
                        params--;
                        if (!params)
                        {
                                switch (command)
                                {
                                        case 0x03: /*Specify*/
//                                        printf("Specified %02X %02X\n",paramdat[1],paramdat[0]);
                                        fdcstatus=0x80;
                                        break;

                                        case 0x04: /*Sense drive status*/
                                        st3=0x60;
                                        if (!fdctrack) st3|=0x10;
                                        fdcstatus=0xD0;
                                        readparams=1;
                                        break;

                                        case 0x06: /*Read sectors*/
//                                        printf("Read sectors %02X %02X %02X %02X %02X %02X %02X %02X\n",paramdat[7],paramdat[6],paramdat[5],paramdat[4],paramdat[3],paramdat[2],paramdat[1],paramdat[0]);
                                        starttrack=paramdat[6];
                                        startsector=paramdat[4]&15;
                                        endsector=paramdat[2]&15;
                                        posinsector=0;
                                        readparams=1;
                                        reading=1;
                                        fdcstatus=0xF0;
//                                        printf("Start - track %i sector %i\n",starttrack,startsector);
                                        break;

                                        case 0x07: /*Recalibrate*/
//                                        printf("Recalibrate %02X\n",paramdat[0]);
                                        fdcstatus=0x80;
                                        fdctrack=0;
                                        fdcint=1;
                                        break;

                                        case 0x0A: /*Read sector ID*/
                                        fdcstatus|=0x60;
                                        readparams=7;
                                        break;

                                        case 0x0F: /*Seek*/
//                                        printf("Seek %02X %02X\n",paramdat[1],paramdat[0]);
                                        fdcstatus=0x80;
                                        fdctrack=paramdat[0];
                                        fdcint=1;
//                                        output=1;
                                        break;

                                        default:
                                        printf("Executing bad command %02X\n",command);
                                        exit(-1);
                                }
                        }
                }
                else
                {
                        command=val&0x1F;
                        switch (command)
                        {
                                case 0: case 0x1F: return; /*Invalid*/
                                case 0x03: /*Specify*/
                                params=2;
                                fdcstatus|=0x10;
                                break;

                                case 0x04: /*Sense drive status*/
                                params=1;
                                fdcstatus|=0x10;
                                break;

                                case 0x06: /*Read sectors*/
//                                if (output) exit(0);
                                params=8;
                                fdcstatus|=0x10;
                                discon=1;
                                break;

                                case 0x07: /*Recalibrate*/
                                params=1;
                                fdcstatus|=0x10;
                                break;

                                case 0x08: /*Sense interrupt state*/
                                st0=0x21;
                                if (!fdcint) st0|=0x80;
                                else         fdcint=0;
                                fdcstatus|=0xD0;
                                readparams=2;
                                break;

                                case 0x0A: /*Read sector ID*/
                                params=1;
                                fdcstatus|=0x10;
                                break;

                                case 0x0F: /*Seek*/
                                params=2;
                                fdcstatus|=0x10;
                                break;

                                default:
                                printf("Starting bad command %02X\n",command);
                                exit(-1);
                        }
                }
        }
}
