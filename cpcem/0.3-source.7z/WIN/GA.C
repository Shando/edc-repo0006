#include <allegro.h>
#include "cpcem.h"

int vc,sc;
int palentry;

void writega(unsigned short a, unsigned char v)
{
        switch (v&0xC0)
        {
                case 0x00: /*Pen selection*/
                palentry=v&31;
                break;
                case 0x40: /*Pen set*/
//                printf("pal %i = %i line %i\n",palentry,v&31,(vc<<3)|sc);
                if (palentry&16) gaborder=(v&31)+1;
                else             gapal[palentry]=(v&31)+1;
                palchange=1;
                break;
                case 0x80: /*Screen mode and ROM configuration*/
                if ((v&3)!=scrmode)
                {
//                        printf("Mode set %i line %i\n",v&3,(vc<<3)|sc);
                        palchange=1;
                }
                scrmode=v&3;
                if (v&4) readarray[0]=ram;
                else     readarray[0]=lorom;
                if (v&8) readarray[3]=ram;
                else     readarray[3]=hirom[curhrom]-0xC000;
                if (v&16) galines&=~32;
                loromena=!(v&4);
                hiromena=!(v&8);
//                printf("Ena now %i, cur %i\n",hiromena,curhrom);
                break;
        }
}
