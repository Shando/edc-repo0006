/**
 * (c) 2014 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_dbg.h"
#include "nucleus/syscalls/lv2.h"

s32 sys_dbg_ppu_exception_handler()
{
    return CELL_OK;
}
