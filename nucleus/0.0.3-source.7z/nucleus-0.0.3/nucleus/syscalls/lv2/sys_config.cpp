/**
 * (c) 2015 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_config.h"
#include "nucleus/syscalls/lv2.h"

s32 sys_config_add_service_listener()
{
    // TODO: ?
    return CELL_OK;
}

s32 sys_config_close()
{
    // TODO: ?
    return CELL_OK;
}

s32 sys_config_open()
{
    // TODO: ?
    return CELL_OK;
}
