/**
 * (c) 2015 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#pragma once

#include "nucleus/common.h"

// SysCalls
s32 sys_hid_0x1FE();
s32 sys_hid_0x200();
s32 sys_hid_0x202();
