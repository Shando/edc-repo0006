/**
 * (c) 2015 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_ss.h"
#include "nucleus/syscalls/lv2.h"

s32 sys_ss_access_control_engine(u32 pid, u64 arg2, u64 arg3)
{
    return CELL_OK;
}
