/**
 * (c) 2014-2016 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "orbis_dynlib.h"

namespace sys {
namespace scei {
namespace orbis {

}  // namespace orbis
}  // namespace scei
}  // namespace sys
