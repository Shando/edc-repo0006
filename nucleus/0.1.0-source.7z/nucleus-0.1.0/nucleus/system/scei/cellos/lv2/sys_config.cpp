/**
 * (c) 2014-2016 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_config.h"
#include "nucleus/system/scei/cellos/lv2.h"

namespace sys {

S32 sys_config_add_service_listener() {
    // TODO: ?
    return CELL_OK;
}

S32 sys_config_close() {
    // TODO: ?
    return CELL_OK;
}

S32 sys_config_open() {
    // TODO: ?
    return CELL_OK;
}

}  // namespace sys
