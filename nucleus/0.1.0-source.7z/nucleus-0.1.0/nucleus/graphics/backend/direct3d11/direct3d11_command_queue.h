/**
 * (c) 2015 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#pragma once

#include "nucleus/graphics/graphics.h"
#include "nucleus/graphics/backend/direct3d11/direct3d11.h"

namespace gfx {
namespace direct3d11 {

class Direct3D11CommandQueue : public CommandQueue {
private:
    ID3D11DeviceContext* immediateContext;

public:
    Direct3D11CommandQueue();
    ~Direct3D11CommandQueue();

    bool initialize(ID3D11Device* device);

    void submit(CommandBuffer* cmdBuffer, Fence* fence) override;
    void waitIdle() override;
};

}  // namespace direct3d11
}  // namespace gfx
