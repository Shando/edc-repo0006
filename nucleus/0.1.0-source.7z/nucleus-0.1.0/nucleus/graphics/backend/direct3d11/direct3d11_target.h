/**
 * (c) 2015 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#pragma once

#include "nucleus/graphics/target.h"
#include "nucleus/graphics/backend/direct3d11/direct3d11.h"

namespace gfx {
namespace direct3d11 {

class Direct3D11ColorTarget : public ColorTarget {
public:
    ID3D11RenderTargetView* view;
};

class Direct3D11DepthStencilTarget : public DepthStencilTarget {
public:
    ID3D11DepthStencilView* view;
};

}  // namespace direct3d11
}  // namespace gfx
