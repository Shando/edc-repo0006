/**
 * (c) 2014-2016 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "texture_cache.h"
#include "nucleus/graphics/texture.h"

namespace gpu {

gfx::Texture* TextureCache::get(const Byte* addr, Size size) {
    return nullptr;
}

}  // namespace gpu
