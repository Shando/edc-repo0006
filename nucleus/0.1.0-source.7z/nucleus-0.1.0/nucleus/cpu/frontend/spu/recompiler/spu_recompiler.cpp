/**
 * (c) 2015 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "spu_recompiler.h"

namespace cpu {
namespace spu {

hir::Value* Recompiler::getGPR(int index) {
    // TODO
    return nullptr;
}

void Recompiler::setGPR(int index, hir::Value* value) {
    // TODO
}

}  // namespace spu
}  // namespace cpu
