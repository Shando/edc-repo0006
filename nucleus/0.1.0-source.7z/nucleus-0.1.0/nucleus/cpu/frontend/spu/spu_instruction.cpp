/**
 * (c) 2014-2016 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "spu_instruction.h"
#include "nucleus/cpu/frontend/spu/spu_tables.h"

namespace cpu {
namespace spu {

}  // namespace spu
}  // namespace cpu
