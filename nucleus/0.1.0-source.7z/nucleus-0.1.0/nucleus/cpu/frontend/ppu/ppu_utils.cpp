/**
 * (c) 2014-2016 Alexandro Sanchez Bach. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "ppu_utils.h"

namespace cpu {
namespace frontend {
namespace ppu {

// PowerPC rotation-masks
RotateMask rotateMask;

}  // namespace ppu
}  // namespace frontend
}  // namespace cpu
