Credits
=======

Project created by Alexandro Sánchez Bach at around `2014-08-01T00:00:00+00:00` near `+49.41248+008.67000+122/`.

### Developers

* _Alexandro Sánchez Bach_

### Acknowledgements

* _Michael Putters_: Donated many brilliant ideas. And an icon.
* _Billy Rabishaw_: Donated a PlayStation 3.
* _Picard_: Donated knowledge.
* _Zecoxao_: Donated determination.
