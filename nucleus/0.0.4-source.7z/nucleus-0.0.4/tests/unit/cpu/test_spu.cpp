/**
 * (c) 2014 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

// Visual Studio testing dependencies
#include "CppUnitTest.h"

// Target
// TODO

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

TEST_CLASS(SPUTests) {

public:
    TEST_METHOD(SPU_AnalyzerTests)
    {
        // TODO
    }

    TEST_METHOD(SPU_InterpreterTests)
    {
        // TODO
    }

    TEST_METHOD(SPU_RecompilerTests)
    {
        // TODO
    }
};
