/**
 * (c) 2014 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

// Visual Studio testing dependencies
#include "CppUnitTest.h"

// Target
// TODO

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

TEST_CLASS(PPUTests) {

public:
    TEST_METHOD(PPU_AnalyzerTests)
    {
        // TODO
    }

    TEST_METHOD(PPU_InterpreterTests)
    {
        // TODO
    }

    TEST_METHOD(PPU_RecompilerTests)
    {
        // TODO
    }
};
