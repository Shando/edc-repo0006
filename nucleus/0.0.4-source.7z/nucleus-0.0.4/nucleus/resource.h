//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nucleus.rc
//
#define IDI_NUCLEUS                     101
#define IDR_LANGUAGE_DE_DE              102
#define IDR_LANGUAGE_EN_US              103
#define IDR_LANGUAGE_ES_ES              104

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
