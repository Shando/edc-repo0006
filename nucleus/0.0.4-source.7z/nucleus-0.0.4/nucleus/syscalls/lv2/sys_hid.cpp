/**
 * (c) 2015 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_hid.h"
#include "nucleus/syscalls/lv2.h"

s32 sys_hid_0x1FE()
{
    // TODO: ?
    return CELL_OK;
}

s32 sys_hid_0x200()
{
    // TODO: ?
    return CELL_OK;
}

s32 sys_hid_0x202()
{
    // TODO: ?
    return CELL_OK;
}
