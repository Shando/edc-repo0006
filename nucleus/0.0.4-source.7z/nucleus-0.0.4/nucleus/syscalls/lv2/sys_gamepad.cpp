/**
 * (c) 2015 Nucleus project. All rights reserved.
 * Released under GPL v2 license. Read LICENSE for more details.
 */

#include "sys_gamepad.h"
#include "nucleus/syscalls/lv2.h"

s32 sys_gamepad_ycon_if()
{
    // TODO: ?
    return CELL_OK;
}
