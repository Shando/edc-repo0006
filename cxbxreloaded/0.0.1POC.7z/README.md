Cxbx-Reloaded - An Xbox Emulator

Cxbx-Reloaded is an emulator for running Microsoft Xbox (and eventually, Chihiro) games on Microsoft Windows.
The project began life as a fork of Cxbx with added 64-bit support. Work is currently underway to backport some of the improvements from Dxbx.

WARNING: Cxbx-Reloaded is still pretty unstable, don't expect it to run much at this point.

System Requirements:
  * Windows 10 64-bit (May work on other versions, but this has not been tested. 32-Bit Windows is NOT supported).
  * A graphics card that supports Direct3D 8.

Bug Reports:
This build if Cxbx-Reloaded is a proof of concept only, it is expected to be buggy.
Please do not submit any issues found in this build.

Please DO submit compatibility reports to the tracker at http://cxbx-reloaded.co.uk

Special Thanks:
All contributers to the original Cxbx and Dxbx projects, without which Cxbx-Reloaded would not exist at all