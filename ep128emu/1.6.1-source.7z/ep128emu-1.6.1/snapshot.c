
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* snapshot.c: snapshot file I/O */

#include <ep128.h>

#define SNAPFILE_VERSION    0x0102

/* list of snapshot file names */

char    *snapshot_files[32] = {
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
};

/* index of currently selected snapshot file (0 to 25) */

int     cur_snapshot = 0;

/* save snapshot file */
/* returns zero on success */

int save_snapshot(int snap_idx)
{
    char    *fname;
    FILE    *f;

    if (snap_idx < 0 || snap_idx > 25)
      return -1;
    fname = snapshot_files[snap_idx];
    if (fname == NULL || (int) strlen(fname) <= 0) {
      printMsg("save_snapshot(): no snapshot file for '%c'\n",
               ((int) 'A' + snap_idx));
      return -1;
    }
    /* open file */
    f = fopen(fname, "wb");
    if (f == NULL) {
      printMsg("save_snapshot(): error opening file '%s': %s\n",
               fname, strerror(errno));
      return -1;
    }
    /* write header */
    snapshot_write_uint32((uint32_t) 0x45313238, f);    /* 'E128' */
    /*   file version */
    snapshot_write_uint16((uint16_t) SNAPFILE_VERSION, f);
    /*   memory configuration */
    snapshot_write_uint16((uint16_t) query_current_memory_config(), f);
    /*   padding to 16 bytes */
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);

    /* save memory and I/O registers */
    if (save_memory_snapshot(f))
      goto snap_err;
    /* save CPU state */
    if (save_cpu_state(f))
      goto snap_err;
    /* save NICK internal registers */
    if (save_nick_snapshot(f))
      goto snap_err;
    /* save DAVE internal registers */
    if (save_dave_snapshot(f))
      goto snap_err;

    /* successfully saved snapshot */
    fflush(f);
    fclose(f);
    printMsg("Saved snapshot to file '%s'\n", fname);
    return 0;

 snap_err:
    fflush(f);
    fclose(f);
    printMsg("snapshot_save(): error writing to file '%s'\n", fname);
    return -1;
}

/* load snapshot file */
/* returns zero on success */

int load_snapshot(int snap_idx)
{
    char    *fname;
    FILE    *f;
    int     s_ver, memcfg, fsize, fsize_reqd;

    if (snap_idx < 0 || snap_idx > 25)
      return -1;
    fname = snapshot_files[snap_idx];
    if (fname == NULL || (int) strlen(fname) <= 0) {
      printMsg("load_snapshot(): no snapshot file for '%c'\n",
               ((int) 'A' + snap_idx));
      return -1;
    }
    /* open file */
    f = fopen(fname, "rb");
    if (f == NULL) {
      printMsg("load_snapshot(): error opening file '%s': %s\n",
               fname, strerror(errno));
      return -1;
    }
    /* check header */
    fseek(f, 0L, SEEK_END);
    fsize = (int) ftell(f);     /* file size */
    rewind(f);
    if (fsize < 16) {
      printMsg("load_snapshot(): invalid snapshot file '%s'\n", fname);
      goto snap_err;
    }
    if ((int) snapshot_read_uint32(f) != 0x45313238) {
      printMsg("load_snapshot(): invalid snapshot file '%s'\n", fname);
      goto snap_err;
    }
    s_ver = (int) snapshot_read_uint16(f);
    if (s_ver != 0x0101 && s_ver != 0x0102) {
      printMsg("load_snapshot(): snapshot file '%s' is not compatible with\n"
               "                 this version\n", fname);
      goto snap_err;
    }
    memcfg = (int) snapshot_read_uint16(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    /* check file size */
    fsize_reqd = 16;    /* with header */
    fsize_reqd += memory_snapshot_bytes(s_ver, memcfg);
    fsize_reqd += cpu_snapshot_bytes(s_ver);
    fsize_reqd += nick_snapshot_bytes(s_ver);
    fsize_reqd += dave_snapshot_bytes(s_ver);
    if (fsize != fsize_reqd) {
      printMsg("load_snapshot(): file '%s' has incorrect size\n", fname);
      goto snap_err;
    }

    tape_motor_off();
    WD177x_Reset();
    /* load memory and I/O registers */
    if (load_memory_snapshot(f, s_ver, memcfg))
      goto snap_err_msg;
    /* load CPU state */
    if (load_cpu_state(f, s_ver))
      goto snap_err_msg;
    /* load NICK internal registers */
    if (load_nick_snapshot(f, s_ver))
      goto snap_err_msg;
    /* load DAVE internal registers */
    if (load_dave_snapshot(f, s_ver))
      goto snap_err_msg;

    /* successfully loadd snapshot */
    fclose(f);
    printMsg("Loaded snapshot from file '%s'\n", fname);
    return 0;

 snap_err_msg:
    printMsg("snapshot_load(): error reading file '%s'\n", fname);
 snap_err:
    fclose(f);
    return -1;
}

/* read a signed 16-bit integer (big-endian) from file 'f' */

int16_t snapshot_read_int16(FILE *f)
{
    int n = 0;

    n |= ((int) fgetc(f) & 0xFF);
    n <<= 8;
    n |= ((int) fgetc(f) & 0xFF);

    return (int16_t) n;
}

/* read an unsigned 16-bit integer (big-endian) from file 'f' */

uint16_t snapshot_read_uint16(FILE *f)
{
    int n = 0;

    n |= ((int) fgetc(f) & 0xFF);
    n <<= 8;
    n |= ((int) fgetc(f) & 0xFF);

    return (uint16_t) n;
}

/* read a signed 32-bit integer (big-endian) from file 'f' */

int32_t snapshot_read_int32(FILE *f)
{
    uint32_t n = (uint32_t) 0;

    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);

    return (int32_t) n;
}

/* read an unsigned 32-bit integer (big-endian) from file 'f' */

uint32_t snapshot_read_uint32(FILE *f)
{
    uint32_t n = (uint32_t) 0;

    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);
    n <<= 8;
    n |= ((uint32_t) fgetc(f) & (uint32_t) 0xFF);

    return n;
}

/* write a signed 16-bit integer (big-endian) to file 'f' */

void snapshot_write_int16(int16_t c, FILE *f)
{
    int n = (int) c;

    fputc(((n & 0xFF00) >> 8), f);
    fputc((n & 0xFF), f);
}

/* write an unsigned 16-bit integer (big-endian) to file 'f' */

void snapshot_write_uint16(uint16_t c, FILE *f)
{
    int n = (int) c;

    fputc(((n & 0xFF00) >> 8), f);
    fputc((n & 0xFF), f);
}

/* write a signed 32-bit integer (big-endian) to file 'f' */

void snapshot_write_int32(int32_t c, FILE *f)
{
    uint32_t n = (uint32_t) c;

    fputc((int) ((n & (uint32_t) 0xFF000000UL) >> 24), f);
    fputc((int) ((n & (uint32_t) 0x00FF0000UL) >> 16), f);
    fputc((int) ((n & (uint32_t) 0x0000FF00UL) >> 8), f);
    fputc((int)  (n & (uint32_t) 0x000000FFUL), f);
}

/* write an unsigned 32-bit integer (big-endian) to file 'f' */

void snapshot_write_uint32(uint32_t c, FILE *f)
{
    uint32_t n = (uint32_t) c;

    fputc((int) ((n & (uint32_t) 0xFF000000UL) >> 24), f);
    fputc((int) ((n & (uint32_t) 0x00FF0000UL) >> 16), f);
    fputc((int) ((n & (uint32_t) 0x0000FF00UL) >> 8), f);
    fputc((int)  (n & (uint32_t) 0x000000FFUL), f);
}

