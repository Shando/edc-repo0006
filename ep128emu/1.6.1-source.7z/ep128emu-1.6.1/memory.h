
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_MEMORY_H
#define EP128_MEMORY_H

#include <stdio.h>
#include <stdint.h>

/* segments at pages 0, 1, 2, and 3 (I/O registers B0 - B3) */

extern  int     page_segment[4];

/* start addresses of memory pages, minus 0x4000 * (page number[0 - 3]) */
/* this table is used for faster memory access */
extern  uint8_t     *page_address_table[4];

/* the actual start addresses of memory segments */
extern  uint8_t     *page_address_real[4];

/* 0: page is RAM, 1: page is ROM */
extern  int         is_page_rom[4];

/* segment address table */
extern  uint8_t     *segment_address_table[256];

/* 0: segment is RAM, 1: segment is ROM */
extern  int         is_segment_rom[256];

/* video memory (actually, segments 0xFC to 0xFF as a single 64K area) */
extern  uint8_t     video_memory[];

/* list of ROM file names for segments 0 to 7 */

extern  char    *rom_file_0;
extern  char    *rom_file_1;
extern  char    *rom_file_2;
extern  char    *rom_file_3;
extern  char    *rom_file_4;
extern  char    *rom_file_5;
extern  char    *rom_file_6;
extern  char    *rom_file_7;

/* write a byte to memory */

void mem_write_8(uint16_t addr, uint8_t value);

/* read a byte from memory */

uint8_t mem_read_8(uint16_t addr);

/* write a byte to I/O memory */

void io_write_8(uint16_t addr, uint8_t value);

/* read a byte from I/O memory */

uint8_t io_read_8(uint16_t addr);

/* load ROM to segment 'segment' from file 'fname' */
/* returns zero on success */

int alloc_rom_segment(int segment, const char *fname);

/* initialize memory subsystem with the specified number of RAM segments */
/* (this includes video memory, so a value of 8 means a total of 128K RAM) */
/* returns zero on success */

int initialize_memory(int nr_ram_segments);

/* free all memory and reset segment tables */

void destroy_memory(void);

/* returns current memory configuration in the following format: */
/*   bits 15 to 8: number of RAM segments (4 to 248)             */
/*   bits  7 to 0: ROM segment bitmap (for example, if ROM       */
/*                 segment 4 is present, then bit 4 is 1)        */

int query_current_memory_config(void);

/* return the size of memory snapshot data (in bytes) for snapshot file */
/* version 'file_version', with memory configuration 'memory_config' */

int memory_snapshot_bytes(int file_version, int memory_config);

/* save memory data and I/O registers to file 'f' */
/* returns zero in case of success */

int save_memory_snapshot(FILE *f);

/* load memory data and I/O registers from file 'f', using file format */
/* specified by 'file_version' and memory configuration 'memory_config'. */
/* Returns zero in case of success. */

int load_memory_snapshot(FILE *f, int file_version, int memory_config);

#endif      /* EP128_MEMORY_H */

