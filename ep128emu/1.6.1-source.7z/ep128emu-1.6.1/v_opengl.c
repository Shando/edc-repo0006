
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* v_opengl.c: OpenGL video driver */

#include <ep128.h>

#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>

static  SDL_Surface *screen = NULL;

static const double event_poll_rate = 100.0;  /* event poll frequency in Hz */
static  int         event_poll_cnt;     /* process_events() polls events */
                                        /* once per 'event_poll_cnt' calls */

static  GLuint      texture_id = (GLuint) 0;

/* table to map 8 bit NICK colors to 16 bit 5/6/5 format */
static  uint16_t    colormap[256];
/* temporary buffer to store video data to be used as a texture */
static  uint16_t    *txt_buf = NULL;
/* texture height in pixels = (1 << gl_txtheight) */
/* width is always 1024 pixels */
static  int         texture_height;
/* structure to store one line of NICK data - used by 'blit_on_change_only' */
typedef struct linebuf_s {
    int         lmarg;
    int         rmarg;
    int         border_color;
    int         noupdate_cnt;
    uint8_t     data[1024];
} linebuf_t;
/* number of lines changed in most recently drawn 'texture_height' lines */
/* if this variable is zero, drawing on screen is not needed */
static  int         lines_changed = 0;
/* previous display frame saved for optimization purposes */
/* prv_display[0] to prv_display[311] is previous even frame */
/* prv_display[312] to prv_display[623] is previous odd frame */
static  linebuf_t   *prv_display = NULL;
/* in 'blit_on_change_only' mode, any line will be redrawn at least this */
/* number of times per second */
static const int    min_update_freq = 1.5625;
static  int         max_noupdate_cnt = 0;

/* create NICK palette (256 colors) */

static void colormap_init(void)
{
    int       i, r, g, b;
    uint16_t  pval;

    /* calculate all colors */
    for (i = 0; i < 256; i++) {
      NICKColorToRGB(i, &r, &g, &b);
      /* convert to 16 bit 5/6/5 format */
      /* TODO: other texture formats */
      r = (r + 4) >> 3;
      r = (r > 31 ? 31 : r);
      g = (g + 2) >> 2;
      g = (g > 63 ? 63 : g);
      b = (b + 4) >> 3;
      b = (b > 31 ? 31 : b);
      pval = (uint16_t) ((r << 11) | (g << 5) | b);
      /* store 16 bit pixel value */
      colormap[i] = pval;
    }
}

/* draw a line (line number should be in the range 0 to 623) */
/* 'data' is an array of 1024 8-bit integers */
/* borders are drawn with 'border_color', using margin positions */
/* 'lmarg' and 'rmarg' (specified in character units, 0 to 63) */

static void draw_line_(int line_number, const uint8_t *data,
                       uint8_t border_color, int lmarg, int rmarg)
{
    uint8_t   *bufp = (uint8_t*) data;
    uint16_t  *p;
    linebuf_t *prv_line;
    int       i, lmarg_npixels, disp_npixels, rmarg_npixels;

    /* check if line is visible */
    if (line_number < display_min_line || line_number >= display_max_line)
      return;

    line_number -= display_min_line;
    /* pointer to previous state of this line */
    if (display_doublebuf && (line_number & 1))
      prv_line = &(prv_display[(line_number >> 1) + 312]);
    else
      prv_line = &(prv_display[(line_number >> 1)]);
    /* OpenGL video driver does not support interlaced display */
    line_number >>= 1;
    /* pointer to texture buffer (texture width is always 1024 pixels) */
    p = (uint16_t*) txt_buf
        + (intptr_t) ((line_number & (texture_height - 1)) * 1024);

    /* calculate the number of pixels to draw */
    lmarg_npixels = (lmarg << 4) - display_left_offset;
    disp_npixels = ((rmarg - lmarg) << 4);
    /* check for the case when only border is visible */
    if (lmarg_npixels >= display_window_width || lmarg >= rmarg ||
        ((rmarg << 4) - display_left_offset) <= 0) {
      /* border only */
      lmarg = 63;
      rmarg = 0;
      lmarg_npixels = display_window_width;
      disp_npixels = 0;
      rmarg_npixels = 0;
    }
    else if (lmarg_npixels <= 0) {
      /* left border is not visible */
      bufp -= (intptr_t) lmarg_npixels;
      disp_npixels += lmarg_npixels;
      lmarg_npixels = 0;
      lmarg = 0;
      if (disp_npixels >= display_window_width) {
        /* right border is not visible, either */
        disp_npixels = display_window_width;
        rmarg_npixels = 0;
        rmarg = 63;
        /* no visible border: assume it is black for more effective */
        /* blit_on_change_only optimization */
        border_color = (uint8_t) 0;
      }
      else {
        /* right border is visible */
        rmarg_npixels = display_window_width - disp_npixels;
      }
    }
    else {
      /* left border is visible */
      if ((lmarg_npixels + disp_npixels) >= display_window_width) {
        /* right border is not visible */
        disp_npixels = display_window_width - lmarg_npixels;
        rmarg_npixels = 0;
        rmarg = 63;
      }
      else {
        /* right border is visible */
        rmarg_npixels = display_window_width - (lmarg_npixels + disp_npixels);
      }
    }
    if (display_blit_on_change) {
      /* if update on change only was requested, */
      /* check if this line was changed: */
      if (lmarg != prv_line->lmarg ||
          rmarg != prv_line->rmarg ||
          (int) border_color != prv_line->border_color ||
          prv_line->noupdate_cnt >= max_noupdate_cnt ||
          (disp_npixels != 0 &&
           memcmp((void*) &(prv_line->data[0]), (void*) bufp,
                  (size_t) disp_npixels) != 0)) {
        /* line has been changed, update */
        lines_changed++;
        prv_line->lmarg = lmarg;
        prv_line->rmarg = rmarg;
        prv_line->border_color = (int) border_color;
        prv_line->noupdate_cnt = 0;
        if (disp_npixels) {
          memcpy((void*) &(prv_line->data[0]), (void*) bufp,
                 (size_t) disp_npixels);
        }
      }
      else {
        /* force update at some interval */
        prv_display[line_number].noupdate_cnt++;
      }
    }
    /* draw left border */
    if (lmarg_npixels) {
      for (i = 0; i < lmarg_npixels; i++)
        *(p++) = colormap[(int) border_color];
    }
    /* draw text/graphics area */
    if (disp_npixels) {
      for (i = 0; i < disp_npixels; i++)
        *(p++) = colormap[(int) *(bufp++)];
    }
    /* draw right border */
    if (rmarg_npixels) {
      for (i = 0; i < rmarg_npixels; i++)
        *(p++) = colormap[(int) border_color];
    }

    /* update screen depending on video mode */
    if ((!display_blit_on_change || lines_changed) &&
        ((line_number & (texture_height - 1)) == (texture_height - 1) ||
         line_number == ((display_window_height >> 1) - 1))) {
      double  txt_x1, txt_y1, txt_x2, txt_y2;
      double  txt_x3, txt_y3, txt_x4, txt_y4;
      double  poly_x1, poly_y1, poly_x2, poly_y2;
      double  poly_x3, poly_y3, poly_x4, poly_y4;
      /* not at bottom of texture: fill one line with border color */
      if ((line_number & (texture_height - 1)) != (texture_height - 1)) {
        for (i = 0; i < 1024; i++)
        *(p++) = colormap[(int) border_color];
      }
      /* load texture (note: the texture is vertically inverted) */
      glEnable(GL_TEXTURE_2D);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 1024, texture_height, 0,
                   GL_RGB, GL_UNSIGNED_SHORT_5_6_5, (GLvoid*) txt_buf);
      /* calculate polygon and texture coordinates */
      /* upper left */
      txt_x1 = 0.0;
      txt_y1 = 0.0;
      poly_x1 = -1.0;
      poly_y1 = 1.0 - (2.0 * (double) (line_number & (~(texture_height - 1)))
                           / (double) (display_window_height >> 1));
      /* upper right */
      txt_x2 = (double) display_window_width / 1024.0;
      txt_y2 = txt_y1;
      poly_x2 = 1.0;
      poly_y2 = poly_y1;
      /* lower right */
      txt_x3 = txt_x2;
      txt_y3 = 1.0;
      poly_x3 = poly_x2;
      poly_y3 = poly_y1 - (2.0 * (double) texture_height
                               / (double) (display_window_height >> 1));
      /* lower left */
      txt_x4 = txt_x1;
      txt_y4 = txt_y3;
      poly_x4 = poly_x1;
      poly_y4 = poly_y3;
      /* draw polygon */
      glBegin(GL_QUADS);
      glTexCoord2d(txt_x1, txt_y1);
      glVertex2d(poly_x1, poly_y1);
      glTexCoord2d(txt_x2, txt_y2);
      glVertex2d(poly_x2, poly_y2);
      glTexCoord2d(txt_x3, txt_y3);
      glVertex2d(poly_x3, poly_y3);
      glTexCoord2d(txt_x4, txt_y4);
      glVertex2d(poly_x4, poly_y4);
      glEnd();
      /* display is now up to date */
      lines_changed = 0;
    }
    /* at the bottom of the window: */
    if (line_number == ((display_window_height >> 1) - 1)) {
      /* make sure that the display is actually updated */
      glFlush();
      /* render console overlay if enabled */
      if (GLconsole_is_enabled)
        GLconsole_render_frame();
      if (display_doublebuf) {
        /* in case of a double buffered display, swap buffers */
        SDL_GL_SwapBuffers();
      }
    }
}

static int mask_to_depth(uint32_t mask)
{
    int d;

    if (!mask)
      return 0;
    while (!(mask & (uint32_t) 1)) {
      mask >>= 1;
    }
    d = 1;
    while (mask > (uint32_t) 1) {
      mask >>= 1;
      d++;
    }
    return d;
}

/* initialize graphics system */

static int init_graphics_(int *argc, char ***argv)
{
    SDL_VideoInfo   *video_info;
    Uint32          sdl_flags;
    int             w, h;
    double          disp_scale;

    argc = argc;    /* unused parameters */
    argv = argv;

    /* calculate window parameters */

    display_window_width  &= (~3);
    display_window_height &= (~3);
    display_x_shift &= (~3);
    display_y_shift &= (~3);

    display_min_line = (624 - display_window_height) >> 1;
    display_max_line = 624 - display_min_line;
    display_sync_line = (590 + display_min_line) + display_y_shift;
    display_left_offset = ((992 - display_window_width) >> 1) - display_x_shift;
    if (display_sync_line < 0)          display_sync_line = 0;
    if (display_sync_line > 622)        display_sync_line = 622;
    if (display_left_offset < 0)        display_left_offset = 0;
    if (display_left_offset > 1024)     display_left_offset = 1024;

    /* zoom */
    disp_scale = gl_zoom * (display_half_size ? 0.5 : 1.0);
    if (((double) display_window_width * disp_scale) > 1200.0)
      disp_scale = 1200.0 / (double) display_window_width;
    if (((double) display_window_width * disp_scale) < 200.0)
      disp_scale = 200.0 / (double) display_window_width;
    w = (int) ((double) display_window_width * disp_scale + 0.5);
    h = (int) ((double) display_window_height * disp_scale + 0.5);

    /* texture height */
    texture_height = (1 << gl_txtheight);

    /* initialize SDL */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0 ) {
      printMsg("ep128: couldn't initialize SDL: %s\n", SDL_GetError());
      return -1;
    }
    atexit(destroy_graphics);
    /* console renderer requires double buffered display without */
    /* 'blit_on_change_only' optimization */
    if (GLconsole_is_enabled) {
      display_doublebuf = 1;
      display_blit_on_change = 0;
    }
    /* OpenGL video driver does not support hardware mode, */
    /* interlaced display, and half refresh rate */
    display_hardware_mode = 0;
    display_interlace = 0;
    display_half_refresh = 0;
    half_refresh_is_allowed = 0;

    /* calculate minimum update interval for 'blit_on_change_only' */
    /* FIXME: the vertical sync frequency is assumed to be 50 Hz */
    if (display_doublebuf)
      max_noupdate_cnt = (int) ((25.0 / min_update_freq) + 0.5) - 1;
    else
      max_noupdate_cnt = (int) ((50.0 / min_update_freq) + 0.5) - 1;

    /* if update on change only was requested, prepare buffer now */
    if (display_blit_on_change) {
      prv_display = (linebuf_t*) malloc(sizeof(linebuf_t) * (size_t) 624);
      if (prv_display == (linebuf_t*) NULL) {
        printMsg(" *** ep128: not enough memory\n");
        return -1;
      }
      /* force drawing the full display on the first time */
      memset((void*) prv_display, 0xFF, sizeof(linebuf_t) * (size_t) 624);
    }
    lines_changed = 0;
    /* ---- initialize video system ---- */
    /* find out video parameters */
    video_info = (SDL_VideoInfo*) SDL_GetVideoInfo();
    if (video_info == NULL)
      return -1;
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE,
                        mask_to_depth((uint32_t) video_info->vfmt->Rmask));
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE,
                        mask_to_depth((uint32_t) video_info->vfmt->Gmask));
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE,
                        mask_to_depth((uint32_t) video_info->vfmt->Bmask));
    SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE,
                        mask_to_depth((uint32_t) video_info->vfmt->Amask));
    if (display_doublebuf)
      SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    else
      SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 0);
    SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE,
                        (int) video_info->vfmt->BitsPerPixel);
    /* set video mode */
    sdl_flags = SDL_OPENGL;
    if (display_fullscreen)
      sdl_flags |= (Uint32) SDL_FULLSCREEN;
    screen = SDL_SetVideoMode(w, h, 0, sdl_flags);
    if (!screen) {
      printMsg(" *** ep128: couldn't set video mode: %s\n", SDL_GetError());
      return -1;
    }
    /* set window title */
    SDL_WM_SetCaption("ep128emu", "ep128emu");
    /* reset key states */
    memset(&(key_matrix[0]), 0xFF, (size_t) 16);
    key_matrix_row_select = 0;
    /* no key repeat */
    SDL_EnableKeyRepeat(0, 0);
    /* turn off mouse cursor in fullscreen mode */
    if ((int) screen->flags & (int) SDL_FULLSCREEN)
      SDL_ShowCursor(SDL_DISABLE);
    /* calculate event poll timing */
    event_poll_cnt = (int) ((master_clock_freq / event_poll_rate) + 0.5);
    /* initialize 256 color NICK palette */
    colormap_init();
    /* allocate texture buffer */
    txt_buf = (uint16_t*) malloc(sizeof(uint16_t) * (1024 * texture_height));
    if (txt_buf == NULL) {
      printMsg(" *** ep128: not enough memory\n");
      return -1;
    }
    /* clear buffer */
    memset((void*) txt_buf, 0, sizeof(uint16_t) * (1024 * texture_height));
    /* set OpenGL rendering parameters */
    glDisable(GL_ALPHA_TEST);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_DITHER);
    glDisable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    /* allocate texture */
    glGenTextures(1, &texture_id);
    glBindTexture(GL_TEXTURE_2D, texture_id);
    /* set texture parameters */
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    if (gl_antialias) {
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    }
    else {
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    /* clear screen */
    glClearColor(0.0, 0.0, 0.0, 1.0);
    if (display_doublebuf) {
      SDL_GL_SwapBuffers();
      glClearColor(0.0, 0.0, 0.0, 1.0);
    }
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT
            | GL_ACCUM_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    /* initialize console renderer */
    GLconsole_initialize();

    return 0;
}

/* de-initialize graphics (this function may not return) */

static void destroy_graphics_(void)
{
    /* de-initialize console renderer */
    GLconsole_close();
    /* restore key repeat */
    SDL_EnableKeyRepeat(500, 30);
    /* show mouse cursor */
    SDL_ShowCursor(SDL_ENABLE);
    /* free texture */
    if (texture_id != (GLuint) 0) {
      glDeleteTextures(1, &texture_id);
      texture_id = (GLuint) 0;
    }
    /* free allocated memory */
    if (txt_buf != NULL) {
      free(txt_buf);
      txt_buf = NULL;
    }
    if (prv_display != (linebuf_t*) NULL) {
      free(prv_display);
      prv_display = NULL;
    }
    /* shut down SDL */
    SDL_Quit();
}

static const int event_table[][4] = {
/*      keysym        matrix   row     bit      */
    { SDLK_n,           0,      0,      0   },      /* ROW 0 */
    { SDLK_BACKSLASH,   0,      0,      1   },
    { SDLK_b,           0,      0,      2   },
    { SDLK_c,           0,      0,      3   },
    { SDLK_v,           0,      0,      4   },
    { SDLK_x,           0,      0,      5   },
    { SDLK_z,           0,      0,      6   },
    { SDLK_LSHIFT,      0,      0,      7   },
    { SDLK_h,           0,      1,      0   },      /* ROW 1 */
    { SDLK_CAPSLOCK,    0,      1,      1   },
    { SDLK_g,           0,      1,      2   },
    { SDLK_d,           0,      1,      3   },
    { SDLK_f,           0,      1,      4   },
    { SDLK_s,           0,      1,      5   },
    { SDLK_a,           0,      1,      6   },
    { SDLK_LCTRL,       0,      1,      7   },
    { SDLK_RCTRL,       0,      1,      7   },
    { SDLK_u,           0,      2,      0   },      /* ROW 2 */
    { SDLK_q,           0,      2,      1   },
    { SDLK_y,           0,      2,      2   },
    { SDLK_r,           0,      2,      3   },
    { SDLK_t,           0,      2,      4   },
    { SDLK_e,           0,      2,      5   },
    { SDLK_w,           0,      2,      6   },
    { SDLK_TAB,         0,      2,      7   },
    { SDLK_7,           0,      3,      0   },      /* ROW 3 */
    { SDLK_1,           0,      3,      1   },
    { SDLK_6,           0,      3,      2   },
    { SDLK_4,           0,      3,      3   },
    { SDLK_5,           0,      3,      4   },
    { SDLK_3,           0,      3,      5   },
    { SDLK_2,           0,      3,      6   },
    { SDLK_ESCAPE,      0,      3,      7   },
    { SDLK_F4,          0,      4,      0   },      /* ROW 4 */
    { SDLK_F8,          0,      4,      1   },
    { SDLK_F3,          0,      4,      2   },
    { SDLK_F6,          0,      4,      3   },
    { SDLK_F5,          0,      4,      4   },
    { SDLK_F7,          0,      4,      5   },
    { SDLK_F2,          0,      4,      6   },
    { SDLK_F1,          0,      4,      7   },
    { SDLK_8,           0,      5,      0   },      /* ROW 5 */
    { SDLK_9,           0,      5,      2   },
    { SDLK_MINUS,       0,      5,      3   },
    { SDLK_0,           0,      5,      4   },
    { SDLK_BACKQUOTE,   0,      5,      5   },
    { SDLK_BACKSPACE,   0,      5,      6   },
    { SDLK_j,           0,      6,      0   },      /* ROW 6 */
    { SDLK_k,           0,      6,      2   },
    { SDLK_SEMICOLON,   0,      6,      3   },
    { SDLK_l,           0,      6,      4   },
    { SDLK_QUOTE,       0,      6,      5   },
    { SDLK_RIGHTBRACKET,0,      6,      6   },
    { SDLK_PRINT,       0,      7,      0   },      /* ROW 7 */
    { SDLK_END,         0,      7,      0   },
    { SDLK_DOWN,        0,      7,      1   },
    { SDLK_RIGHT,       0,      7,      2   },
    { SDLK_UP,          0,      7,      3   },
    { SDLK_PAUSE,       0,      7,      4   },
    { SDLK_PAGEUP,      0,      7,      4   },
    { SDLK_LEFT,        0,      7,      5   },
    { SDLK_RETURN,      0,      7,      6   },
    { SDLK_LALT,        0,      7,      7   },
    { SDLK_RALT,        0,      7,      7   },
    { SDLK_m,           0,      8,      0   },      /* ROW 8 */
    { SDLK_DELETE,      0,      8,      1   },
    { SDLK_COMMA,       0,      8,      2   },
    { SDLK_SLASH,       0,      8,      3   },
    { SDLK_PERIOD,      0,      8,      4   },
    { SDLK_RSHIFT,      0,      8,      5   },
    { SDLK_SPACE,       0,      8,      6   },
    { SDLK_INSERT,      0,      8,      7   },
    { SDLK_i,           0,      9,      0   },      /* ROW 9 */
    { SDLK_o,           0,      9,      2   },
    { SDLK_EQUALS,      0,      9,      3   },
    { SDLK_p,           0,      9,      4   },
    { SDLK_LEFTBRACKET, 0,      9,      5   },
    /* end of list */
    { -1,               -1,     -1,     -1  }
};

/* read keyboard events and update matrix values */
/* returns non-zero if the event is "close window" */

static  int     event_poll_clk = 1;

static int process_events_(void)
{
    SDL_Event   event;
    int         i, is_pressed;
    int         keysym;

    /* check events 100 times per second */
    if (--event_poll_clk)
      return 0;
    event_poll_clk = event_poll_cnt;

    /* read and process all queued events */
 next_event:

    while (SDL_PollEvent(&event)) {
      switch ((int) event.type) {
      case SDL_QUIT:
        return -1;                      /* close window */
      case SDL_KEYDOWN:
      case SDL_KEYUP:                   /* key press or release */
        is_pressed = (event.type == SDL_KEYDOWN ? 1 : 0);
        /* key number */
        keysym = (int) (event.key.keysym.sym);
        /* check for basic tape control keys (F9, F10, F11), */
        /* and keyboard mode toggle (F12) */
        if (is_pressed) {
          switch (keysym) {
          case SDLK_F9:
            handle_special_key(19);     /* <F9>:  PLAY ON */
            goto next_event;
          case SDLK_F10:
            handle_special_key(20);     /* <F10>: PLAY/RECORD OFF */
            goto next_event;
          case SDLK_F11:
            handle_special_key(21);     /* <F11>: RECORD ON */
            goto next_event;
          case SDLK_KP_MINUS:
            handle_special_key(81);     /* <KEYPAD ->: DECREASE CPU FREQ */
            goto next_event;
          case SDLK_KP_PLUS:
            handle_special_key(82);     /* <KEYPAD +>: INCREASE CPU FREQ */
            goto next_event;
          case SDLK_KP_ENTER:
          case SDLK_KP_MULTIPLY:
            handle_special_key(80);     /* <KEYPAD ENTER>: RESET CPU FREQ */
            goto next_event;
          case SDLK_KP0:
            handle_special_key(83);     /* <KEYPAD INS>: PRINT KEYBOARD USAGE */
            goto next_event;
          case SDLK_KP_PERIOD:          /* <KEYPAD DEL>: SET ALT CPU FREQ */
            handle_special_key(84);
            goto next_event;
          case SDLK_F12:
            emulator_ui_mode = (emulator_ui_mode ? 0 : 1);
            if (emulator_ui_mode)
              printMsg("Keyboard Mode: program control\n");
            else
              printMsg("Keyboard Mode: emulation\n");
            goto next_event;
          }
        }
        /* in program control mode, keyboard is handled differently */
        if (is_pressed && emulator_ui_mode) {
          switch (keysym) {
            case SDLK_0:  handle_special_key(0);  goto next_event;
            case SDLK_1:  handle_special_key(1);  goto next_event;
            case SDLK_2:  handle_special_key(2);  goto next_event;
            case SDLK_3:  handle_special_key(3);  goto next_event;
            case SDLK_4:  handle_special_key(4);  goto next_event;
            case SDLK_5:  handle_special_key(5);  goto next_event;
            case SDLK_6:  handle_special_key(6);  goto next_event;
            case SDLK_7:  handle_special_key(7);  goto next_event;
            case SDLK_8:  handle_special_key(8);  goto next_event;
            case SDLK_9:  handle_special_key(9);  goto next_event;
            case SDLK_a:  handle_special_key(40); goto next_event;
            case SDLK_b:  handle_special_key(41); goto next_event;
            case SDLK_c:  handle_special_key(42); goto next_event;
            case SDLK_d:  handle_special_key(43); goto next_event;
            case SDLK_e:  handle_special_key(44); goto next_event;
            case SDLK_f:  handle_special_key(45); goto next_event;
            case SDLK_g:  handle_special_key(46); goto next_event;
            case SDLK_h:  handle_special_key(47); goto next_event;
            case SDLK_i:  handle_special_key(48); goto next_event;
            case SDLK_j:  handle_special_key(49); goto next_event;
            case SDLK_k:  handle_special_key(50); goto next_event;
            case SDLK_l:  handle_special_key(51); goto next_event;
            case SDLK_m:  handle_special_key(52); goto next_event;
            case SDLK_n:  handle_special_key(53); goto next_event;
            case SDLK_o:  handle_special_key(54); goto next_event;
            case SDLK_p:  handle_special_key(55); goto next_event;
            case SDLK_q:  handle_special_key(56); goto next_event;
            case SDLK_r:  handle_special_key(57); goto next_event;
            case SDLK_s:  handle_special_key(58); goto next_event;
            case SDLK_t:  handle_special_key(59); goto next_event;
            case SDLK_u:  handle_special_key(60); goto next_event;
            case SDLK_v:  handle_special_key(61); goto next_event;
            case SDLK_w:  handle_special_key(62); goto next_event;
            case SDLK_x:  handle_special_key(63); goto next_event;
            case SDLK_y:  handle_special_key(64); goto next_event;
            case SDLK_z:  handle_special_key(65); goto next_event;
            case SDLK_F1: handle_special_key(11); goto next_event;
            case SDLK_F2: handle_special_key(12); goto next_event;
            case SDLK_F3: handle_special_key(13); goto next_event;
            case SDLK_F4: handle_special_key(14); goto next_event;
            case SDLK_F5: handle_special_key(15); goto next_event;
            case SDLK_F6: handle_special_key(16); goto next_event;
            case SDLK_F7: handle_special_key(17); goto next_event;
            case SDLK_F8: handle_special_key(18); goto next_event;
            case SDLK_ESCAPE:   handle_special_key(10); goto next_event;
            case SDLK_PAUSE:
            case SDLK_PAGEUP:   return -1;
            default:      goto next_event;
          }
        }
        /* normal Enterprise keyboard emulation */
        i = 0;
        while (event_table[i][1] >= 0) {
          if ((int) event_table[i][0] == keysym) {
            int matrixnum = event_table[i][1];
            int rownum = event_table[i][2];
            int bitnum = event_table[i][3];
            uint8_t *matrixptr;
            if (bitnum < 0)
              bitnum = 0xFF;
            else
              bitnum = (1 << bitnum);
            switch (matrixnum) {
            case 0:
              matrixptr = &(key_matrix[0]);     /* normal keys */
              break;
            default:                            /* unknown key type */
              goto next_event;
            }
            if (is_pressed) {
              bitnum ^= 0xFF;
              matrixptr[rownum] &= (uint8_t) bitnum;
            }
            else
              matrixptr[rownum] |= (uint8_t) bitnum;
          }
          i++;
        }
      }
    }

    return 0;
}

/* module interface */

VideoModule_t OpenGLVideoDriver = {
    "opengl",
    init_graphics_,
    draw_line_,
    process_events_,
    destroy_graphics_
};

