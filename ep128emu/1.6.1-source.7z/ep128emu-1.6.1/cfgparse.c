
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* cfgparse.c: parse configuration file and command line options */

#include <ep128.h>
#include <ctype.h>

static  char    *cfg_name = NULL;

static const char copyright_info_text[] =
    "Enterprise 128 emulator v%d.%d.%d, written by Istvan Varga, 2003, 2004, 2005\n"
    "The Z80 and WD177x emulation are (c) Copyright, Kevin Thacker 1999-2001\n";

static const char cmdline_usage_text[] =
    "Usage: ep128emu [OPTIONS...]\n"
    "\n"
    "Allowed options are:\n"
    "    -h | -help | --help\n"
    "        print this message.\n"
    "    -cfg <cfgfile>\n"
    "        load settings from configuration file 'cfgfile'. Defaults to\n"
    "        '$HOME/.ep128rc'.\n"
    "    -<option>=<value>\n"
    "        set configuration variable 'option' to 'value'\n"
    "        for a list of options see .ep128rc\n";

static const char keyboard_usage_text[] =
    "Keyboard usage:\n"
    "    <F9>    Tape PLAY on\n"
    "    <F10>   Tape PLAY/RECORD off\n"
    "    <F11>   Tape RECORD on\n"
    "    <Keypad +/->    Increase/decrease CPU frequency by 5 percent\n"
    "    <Keypad Enter>, <Keypad *>  Reset CPU frequency to 4 MHz\n"
    "    <Keypad Del>    Set alternate CPU frequency\n"
    "    <Keypad Ins>    Print keyboard usage\n"
    "    <F12>   Toggle UI mode (emulation / program control)\n"
    "If UI mode is program control, the following keys may be used in\n"
    "addition to the above:\n"
    "    0 - 9   Select tape file 0 to 9 (file names can be set in the\n"
    "            configuration file).\n"
    "    A - Z   Select snapshot file A to Z (file names can be set in the\n"
    "            configuration file).\n"
    "    <F1>    Tape seek backward 60 seconds.\n"
    "    <F2>    Tape seek backward 5 seconds.\n"
    "    <F3>    Tape seek forward 5 seconds.\n"
    "    <F4>    Tape seek forward 60 seconds.\n"
    "    <F5>    Tape rewind to time zero.\n"
    "    <F7>    Save snapshot.\n"
    "    <F8>    Load snapshot.\n"
    "    <Esc>   Reset emulated machine.\n"
    "    <Pause>, <PageUp>  Quit emulator.\n";

/* argument types:                                                           */
/*   0: none (in this case, argptr is a pointer to a void(*)(void) function) */
/*   1: string                                                               */
/*   2: int                                                                  */
/*   3: double                                                               */

typedef struct cfg_opt_s {
    char    *optname;                   /* option name                  */
    int     argtyp;                     /* argument type (see above)    */
    void    *argptr;                    /* pointer to store parameter   */
} cfg_opt_t;

/* list of available configuration file options */

static const cfg_opt_t opt_list[] = {
    {   "sync_freq",        3,      (void*) (&master_clock_freq)        },
    {   "sound_driver",     1,      (void*) (&sound_driver)             },
    {   "video_driver",     1,      (void*) (&video_driver)             },
    {   "srate",            3,      (void*) (&sound_sample_rate)        },
    {   "oversample",       2,      (void*) (&sound_oversample)         },
    {   "snd_device",       1,      (void*) (&sound_device)             },
    {   "sndbuf_hw",        2,      (void*) (&buffer_size)              },
    {   "sndbuf_sw",        2,      (void*) (&period_size)              },
    {   "no_sound",         2,      (void*) (&disable_sound)            },
    {   "dcblock_1",        3,      (void*) (&DC_block_1_frq)           },
    {   "dcblock_2",        3,      (void*) (&DC_block_2_frq)           },
    {   "volume",           3,      (void*) (&amplitude_scale)          },
    {   "cpu_freq",         3,      (void*) (&cpu_frequency)            },
    {   "cpu_altfrq",       3,      (void*) (&cpu_alternate_frequency)  },
    {   "vram_clock",       3,      (void*) (&vram_clock_ratio)         },
    {   "vram_latency",     3,      (void*) (&vram_latency_f)           },
    {   "nowait_freq",      3,      (void*) (&no_memory_wait_frequency) },
    {   "ram_kb",           2,      (void*) (&ram_kilobytes)            },
    {   "rom0",             1,      (void*) (&rom_file_0)               },
    {   "rom1",             1,      (void*) (&rom_file_1)               },
    {   "rom2",             1,      (void*) (&rom_file_2)               },
    {   "rom3",             1,      (void*) (&rom_file_3)               },
    {   "rom4",             1,      (void*) (&rom_file_4)               },
    {   "rom5",             1,      (void*) (&rom_file_5)               },
    {   "rom6",             1,      (void*) (&rom_file_6)               },
    {   "rom7",             1,      (void*) (&rom_file_7)               },
    {   "tape_sr",          3,      (void*) (&tape_sample_rate)         },
    {   "tape_fb",          2,      (void*) (&tape_feedback_enable)     },
    {   "fast_tape_mode",   2,      (void*) (&fast_tape_mode)           },
    {   "tape0",            1,      (void*) (&tape_file_name_0)         },
    {   "tape1",            1,      (void*) (&tape_file_name_1)         },
    {   "tape2",            1,      (void*) (&tape_file_name_2)         },
    {   "tape3",            1,      (void*) (&tape_file_name_3)         },
    {   "tape4",            1,      (void*) (&tape_file_name_4)         },
    {   "tape5",            1,      (void*) (&tape_file_name_5)         },
    {   "tape6",            1,      (void*) (&tape_file_name_6)         },
    {   "tape7",            1,      (void*) (&tape_file_name_7)         },
    {   "tape8",            1,      (void*) (&tape_file_name_8)         },
    {   "tape9",            1,      (void*) (&tape_file_name_9)         },
    {   "disk_a",           1,      (void*) (&wd177x_diskimage_a)       },
    {   "disk_b",           1,      (void*) (&wd177x_diskimage_b)       },
    {   "disk_c",           1,      (void*) (&wd177x_diskimage_c)       },
    {   "disk_d",           1,      (void*) (&wd177x_diskimage_d)       },
    {   "gamma",            3,      (void*) (&color_gamma)              },
    {   "min_intensity",    3,      (void*) (&min_intensity)            },
    {   "max_intensity",    3,      (void*) (&max_intensity)            },
    {   "gamma_r",          3,      (void*) (&color_gamma_R)            },
    {   "min_intensity_r",  3,      (void*) (&min_intensity_R)          },
    {   "max_intensity_r",  3,      (void*) (&max_intensity_R)          },
    {   "gamma_g",          3,      (void*) (&color_gamma_G)            },
    {   "min_intensity_g",  3,      (void*) (&min_intensity_G)          },
    {   "max_intensity_g",  3,      (void*) (&max_intensity_G)          },
    {   "gamma_b",          3,      (void*) (&color_gamma_B)            },
    {   "min_intensity_b",  3,      (void*) (&min_intensity_B)          },
    {   "max_intensity_b",  3,      (void*) (&max_intensity_B)          },
    {   "window_width",     2,      (void*) (&display_window_width)     },
    {   "window_height",    2,      (void*) (&display_window_height)    },
    {   "x_shift",          2,      (void*) (&display_x_shift)          },
    {   "y_shift",          2,      (void*) (&display_y_shift)          },
    {   "fullscreen",       2,      (void*) (&display_fullscreen)       },
    {   "video_hw",         2,      (void*) (&display_hardware_mode)    },
    {   "video_doublebuf",  2,      (void*) (&display_doublebuf)        },
    {   "half_size",        2,      (void*) (&display_half_size)        },
    {   "interlace",        2,      (void*) (&display_interlace)        },
    {   "blit_on_change_only",  2,  (void*) (&display_blit_on_change)   },
    {   "half_refresh",     2,      (void*) (&display_half_refresh)     },
    {   "gl_antialias",     2,      (void*) (&gl_antialias)             },
    {   "gl_txtheight",     2,      (void*) (&gl_txtheight)             },
    {   "gl_zoom",          3,      (void*) (&gl_zoom)                  },
    {   "gl_console",       2,      (void*) (&GLconsole_is_enabled)     },
    {   "console_bg_r",     3,      (void*) (&console_bg_R)             },
    {   "console_bg_g",     3,      (void*) (&console_bg_G)             },
    {   "console_bg_b",     3,      (void*) (&console_bg_B)             },
    {   "console_bg_a",     3,      (void*) (&console_bg_A)             },
    {   "console_fg_r",     3,      (void*) (&console_fg_R)             },
    {   "console_fg_g",     3,      (void*) (&console_fg_G)             },
    {   "console_fg_b",     3,      (void*) (&console_fg_B)             },
    {   "console_fg_a",     3,      (void*) (&console_fg_A)             },
    {   "msg_stderr",       2,      (void*) (&console_to_stderr)        },
    {   "logfile",          1,      (void*) (&logfile_name)             },
    {   "snapshot_a",       1,      (void*) (&(snapshot_files[0]))      },
    {   "snapshot_b",       1,      (void*) (&(snapshot_files[1]))      },
    {   "snapshot_c",       1,      (void*) (&(snapshot_files[2]))      },
    {   "snapshot_d",       1,      (void*) (&(snapshot_files[3]))      },
    {   "snapshot_e",       1,      (void*) (&(snapshot_files[4]))      },
    {   "snapshot_f",       1,      (void*) (&(snapshot_files[5]))      },
    {   "snapshot_g",       1,      (void*) (&(snapshot_files[6]))      },
    {   "snapshot_h",       1,      (void*) (&(snapshot_files[7]))      },
    {   "snapshot_i",       1,      (void*) (&(snapshot_files[8]))      },
    {   "snapshot_j",       1,      (void*) (&(snapshot_files[9]))      },
    {   "snapshot_k",       1,      (void*) (&(snapshot_files[10]))     },
    {   "snapshot_l",       1,      (void*) (&(snapshot_files[11]))     },
    {   "snapshot_m",       1,      (void*) (&(snapshot_files[12]))     },
    {   "snapshot_n",       1,      (void*) (&(snapshot_files[13]))     },
    {   "snapshot_o",       1,      (void*) (&(snapshot_files[14]))     },
    {   "snapshot_p",       1,      (void*) (&(snapshot_files[15]))     },
    {   "snapshot_q",       1,      (void*) (&(snapshot_files[16]))     },
    {   "snapshot_r",       1,      (void*) (&(snapshot_files[17]))     },
    {   "snapshot_s",       1,      (void*) (&(snapshot_files[18]))     },
    {   "snapshot_t",       1,      (void*) (&(snapshot_files[19]))     },
    {   "snapshot_u",       1,      (void*) (&(snapshot_files[20]))     },
    {   "snapshot_v",       1,      (void*) (&(snapshot_files[21]))     },
    {   "snapshot_w",       1,      (void*) (&(snapshot_files[22]))     },
    {   "snapshot_x",       1,      (void*) (&(snapshot_files[23]))     },
    {   "snapshot_y",       1,      (void*) (&(snapshot_files[24]))     },
    {   "snapshot_z",       1,      (void*) (&(snapshot_files[25]))     },
    {   NULL,               0,      NULL                                }
};

/* read a single line from configuration file, storing option name and value */
/* in 'optname' and 'value'. */
/* returns non-zero on end of file. */

static int read_cfg_line(FILE *f, char *optname, char *value)
{
    int i;

    /* default: both option name and value are empty */
    *optname = (char) '\0';
    *value = (char) '\0';

    if (feof(f))
      return -1;        /* end of file */

    /* skip any whitespace or blank lines */
    do {
      i = getc(f);
      /* check for EOF */
      if (i == EOF) return -1;
      /* and comment */
      if (i == ';' || i == '#') {
        do {
          i = getc(f);
          /* skip rest of line */
          if (i == EOF) return -1;
        } while (i != '\r' && i != '\n');
      }
    } while (i == ' ' || i == '\t' || i == '\r' || i == '\n');
    /* i now contains the first character of option name */

    /* read option name */
    do {
      /* option names are not case sensitive */
      if (isupper(i))
        i = tolower(i);
      *(optname++) = (char) i;
      i = getc(f);
      /* check for EOF, end of line, and comment */
      if (i == EOF || i == '\r' || i == '\n')
        goto return_eof;
      if (i == ';' || i == '#')
        goto return_comment;
    } while (i != '=' && i != ' ' && i != '\t');
    *optname = (char) '\0';     /* terminate */

    /* find '=' character */
    while (i != '=') {
      i = getc(f);
      if (i == ';' || i == '#')
        goto return_comment;
      if (i != '=' && i != ' ' && i != '\t')
        goto return_eof;
    }
    /* skip whitespace */
    do {
      i = getc(f);
      /* check for EOF, end of line, and comment */
      if (i == EOF || i == '\r' || i == '\n')
        goto return_eof;
      if (i == ';' || i == '#')
        goto return_comment;
    } while (i == ' ' || i == '\t');
    /* i now contains the first character of option value */

    /* read option name */
    do {
      /* option values are case sensitive */
      *(value++) = (char) i;
      i = getc(f);
      /* check for EOF and comment */
      if (i == EOF)
        goto return_eof;
      if (i == ';' || i == '#' || i == ' ' || i == '\t')
        goto return_comment;
    } while (i != '\r' && i != '\n');
    *value = (char) '\0';     /* terminate */

    return 0;   /* successfully read option/value pair */

 return_comment:
    do {
      i = getc(f);
      /* skip rest of line */
    } while (i != EOF && i != '\r' && i != '\n');

 return_eof:
    *optname = (char) '\0';
    *value = (char) '\0';

    return 0;
}

/* set configuration variable 'optname' to 'value' */
/* returns zero on success */

static int set_configuration_variable(char *optname, char *value)
{
    cfg_opt_t   *optptr;

    /* find option in database */
    optptr = (cfg_opt_t*) &(opt_list[0]);
    while (optptr->optname != NULL) {
      if (!strcmp(optname, optptr->optname))
        break;
      optptr++;
    }
    /* not found */
    if (optptr->optname == NULL) {
      printMsg("ep128: invalid option name: %s\n", optname);
      return -1;
    }
    /* check argument */
    if (optptr->argtyp && (int) value[0] == '\0') {
      printMsg("ep128: missing argument for '%s'\n", optname);
      return -1;
    }
    switch (optptr->argtyp) {
    case 1:                         /* string */
      {
        char *p = malloc((size_t) strlen(value) + (size_t) 1);
        if (p == NULL) {
          printMsg("ep128: not enough memory\n");
          return -1;
        }
        strcpy(p, value);
        *((char**) optptr->argptr) = p;
      }
      break;
    case 2:                         /* int */
      *((int*) optptr->argptr) = (int) atoi(value);
      break;
    case 3:                         /* double */
      *((double*) optptr->argptr) = (double) atof(value);
      break;
    default:                        /* no argument: call function */
      ((void(*)(void)) optptr->argptr)();
    }
    /* report success */
    return 0;
}

/* print copyright information */

void print_copyright_info(void)
{
    printMsg(copyright_info_text,
             EP128EMU_VERSION_MAJOR,
             EP128EMU_VERSION_MINOR,
             EP128EMU_VERSION_PATCHLEVEL);
    printMsg("\n");
}

/* print keyboard usage */

void print_keyboard_usage(void)
{
    printMsg("%s", keyboard_usage_text);
}

/* parse command line options and configuration file */
/* returns zero on success */

int parse_config_file(int argc, char **argv)
{
    char    optname[1024], value[1024], *dirnam, **saved_argv;
    FILE    *f;
    int     saved_argc;

    saved_argc = argc;
    saved_argv = argv;
    /* parse command line options */
    while (--argc) {
      argv++;
      if (!strcmp(*argv, "-h") ||
          !strcmp(*argv, "-help") ||
          !strcmp(*argv, "--help")) {
        /* print usage and exit */
        printMsg(copyright_info_text,
                 EP128EMU_VERSION_MAJOR,
                 EP128EMU_VERSION_MINOR,
                 EP128EMU_VERSION_PATCHLEVEL);
        printMsg("\n");
        printMsg("%s", cmdline_usage_text);
        printMsg("\n");
        printMsg("%s", keyboard_usage_text);
        printMsg("\n");
        exit(0);
      }
      else if (!strcmp(*argv, "-cfg")) {
        /* configuration file name */
        if (!(--argc)) {
          printMsg("ep128: missing filename for '-cfg'\n");
          return -1;
        }
        argv++;
        cfg_name = *argv;
      }
      else if ((int) (*argv)[0] == '-' && strchr((*argv), '=') != NULL) {
        /* 'optname' is the option name and 'dirnam' is the value */
        strcpy(&(optname[0]), &((*argv)[1]));
        dirnam = strchr(&(optname[0]), '=');
        *(dirnam++) = '\0';
        if (set_configuration_variable(&(optname[0]), dirnam) != 0)
          return -1;
      }
      else {
        /* invalid option */
        printMsg("ep128: invalid option: '%s'\n", *argv);
        return -1;
      }
    }
    /* open configuration file */
    if (cfg_name == NULL) {
      /* no file name was specified, try the default '.ep128rc' */
      dirnam = getenv("HOME");
      if (dirnam != NULL) {
        strcpy(value, dirnam);
        /* remove any trailing slash from directory name */
        dirnam = value + strlen(value);
        do {
          dirnam--;
        } while (((uintptr_t) dirnam >= (uintptr_t) value) && *dirnam == '/');
        /* and then add exactly one */
        *(++dirnam) = '/';
        *(++dirnam) = '\0';
      }
      else
        value[0] = '\0';
      /* we already have the directory name, now add the file name */
      strcat(value, ".ep128rc");
    }
    else
      strcpy(value, cfg_name);  /* user specified file name */
    /* attempt to open file */
    f = fopen(value, "rb");
    if (f == NULL) {
      if (cfg_name == NULL)
        return 0;   /* it is not an error if the default file is not found */
      /* however, it is an error if the user specified file cannot be opened */
      printMsg("ep128: error opening configuration file '%s': %s\n",
               value, strerror(errno));
      return -1;
    }
    /* read and parse all options */
    while (!read_cfg_line(f, &(optname[0]), &(value[0]))) {
      if (set_configuration_variable(&(optname[0]), &(value[0])) != 0) {
        fclose(f);
        return -1;
      }
    }
    fclose(f);
    /* need to do this again to make sure that command line options */
    /* override those that were specified in the file */
    argc = saved_argc;
    argv = saved_argv;
    while (--argc) {
      argv++;
      if ((int) (*argv)[0] == '-' && strchr((*argv), '=') != NULL) {
        /* 'optname' is the option name and 'dirnam' is the value */
        strcpy(&(optname[0]), &((*argv)[1]));
        dirnam = strchr(&(optname[0]), '=');
        *(dirnam++) = '\0';
        if (set_configuration_variable(&(optname[0]), dirnam) != 0)
          return -1;
      }
    }

    return 0;
}

/* limit integer value pointed to by 'x' to the range 'minval' to 'maxval' */
/* return value is zero if 'x' was in the range, -1 if 'x' was less than */
/* 'minval', and 1 if 'x' was greater than 'maxval' */

int limit_int_to_range(int *x, int minval, int maxval)
{
    cfg_opt_t   *p;
    int         prv;

    if (*x >= minval && *x <= maxval)
      return 0;
    prv = *x;
    if (*x < minval)
      *x = minval;
    else if (*x > maxval)
      *x = maxval;
    p = (cfg_opt_t*) &(opt_list[0]);
    while (p->optname != NULL) {
      if (p->argptr == (void*) x)
        break;
      p++;
    }
    if (p->optname != NULL) {
      printMsg("ep128: warning: option '%s' is out of range, set to %d\n",
               p->optname, *x);
    }
    return (*x < prv ? 1 : -1);
}

/* limit double value pointed to by 'x' to the range 'minval' to 'maxval' */
/* return value is zero if 'x' was in the range, -1 if 'x' was less than */
/* 'minval', and 1 if 'x' was greater than 'maxval' */

int limit_double_to_range(double *x, double minval, double maxval)
{
    cfg_opt_t   *p;
    double      prv;

    if (*x >= minval && *x <= maxval)
      return 0;
    prv = *x;
    if (*x < minval)
      *x = minval;
    else if (*x > maxval)
      *x = maxval;
    p = (cfg_opt_t*) &(opt_list[0]);
    while (p->optname != NULL) {
      if (p->argptr == (void*) x)
        break;
      p++;
    }
    if (p->optname != NULL) {
      printMsg("ep128: warning: option '%s' is out of range, set to %f\n",
               p->optname, *x);
    }
    return (*x < prv ? 1 : -1);
}

/* set integer value pointed to by 'x' to 1 if it is not zero */

void fix_boolean_value(int *x)
{
    if (*x != 0)
      *x = 1;
}

