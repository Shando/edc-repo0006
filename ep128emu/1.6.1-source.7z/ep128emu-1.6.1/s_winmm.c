
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* s_winmm.c: Windows sound output */

#include <ep128.h>
#include <ctype.h>

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <mmsystem.h>

#define MIN_BUFFER_SIZE 128
#define MAX_BUFFER_SIZE 65536
#define MIN_PERIOD_SIZE 16
#define MAX_PERIOD_SIZE 8192

/* sleep time in ms - should be added to configuration options, */
/* but this value seems to be OK */
static  const   int     snd_sleep_ms = 1;

static volatile int     samples_ahead, buffer_state;
static volatile int     read_buf, write_buf;
static  int             n_buffers, period_cnt;

/* buffer thresholds */
static  int     bufthreshold_1, bufthreshold_2, bufthreshold_3;
static  int     bufthreshold_4, bufthreshold_5;

static  int     device_is_open  = 0;
static  int     playback_on     = 0;

static  HWAVEOUT        wave_device = (HWAVEOUT) 0;

static  WAVEFORMATEX    wave_format = {
    (WORD) WAVE_FORMAT_PCM,     /* wFormatTag                               */
    (WORD) 2,                   /* nChannels                                */
    (DWORD) 48000,              /* nSamplesPerSec (will be set at run-time) */
    (DWORD) 192000,             /* nAvgBytesPerSec (also set at run-time)   */
    (WORD) 4,                   /* nBlockAlign                              */
    (WORD) 16,                  /* wBitsPerSample                           */
    (WORD) 0                    /* cbSize                                   */
};

static  LPSTR           *wave_buffers = (LPSTR*) NULL;
static  WAVEHDR         *wave_headers = (WAVEHDR*) NULL;

/* free all allocated memory and close wave device if it is open */

static void do_cleanup(void)
{
    int i;

    /* close wave out device */
    if (wave_device != (HWAVEOUT) 0) {
      if (playback_on) {
        /* wait for any remaining buffers to be played */
        while (samples_ahead >= period_size)
          Sleep(1);
        /* no longer playing */
        playback_on = 0;
      }
      waveOutReset(wave_device);
      waveOutClose(wave_device);
      wave_device = (HWAVEOUT) 0;
    }

    /* free all buffers and headers */
    if (wave_headers != (WAVEHDR*) NULL) {
      free((void*) wave_headers);
      wave_headers = (WAVEHDR*) NULL;
    }
    if (wave_buffers != (LPSTR*) NULL) {
      /* one additional buffer contains silence for underruns */
      for (i = 0; i <= n_buffers; i++) {
        if (wave_buffers[i] == (LPSTR) NULL) {
          free((void*) wave_buffers[i]);
          wave_buffers[i] = (LPSTR) NULL;
        }
      }
      free((void*) wave_buffers);
      wave_buffers = (LPSTR*) NULL;
    }
}

/* allocate and prepare wave out buffers; returns zero on success */

static int allocate_buffers(void)
{
    int     i;

    /* allocate memory */
    /* note: one additional buffer contains silence for underruns */
    wave_buffers = (LPSTR*) malloc(sizeof(LPSTR) * (size_t) (n_buffers + 1));
    if (wave_buffers == (LPSTR*) NULL)
      goto mem_err;
    for (i = 0; i <= n_buffers; i++)
      wave_buffers[i] = (LPSTR) NULL;
    wave_headers = (WAVEHDR*)
                   malloc(sizeof(WAVEHDR) * (size_t) (n_buffers + 1));
    if (wave_headers == (WAVEHDR*) NULL)
      goto mem_err;
    for (i = 0; i <= n_buffers; i++) {
      /* sample frame size is 4 bytes for stereo 16 bit format */
      wave_buffers[i] = (LPSTR)
                        GlobalLock(GlobalAlloc((UINT)
                                               (GMEM_MOVEABLE | GMEM_SHARE),
                                               (SIZE_T) (period_size * 4)));
      if (wave_buffers[i] == (LPSTR) NULL)
        goto mem_err;
      /* clear buffer */
      memset((void*) wave_buffers[i], 0, (size_t) (period_size * 4));
      /* set up wave header structure, clear first so that any */
      /* unspecified parameters will default to zero */
      memset((void*) &(wave_headers[i]), 0, sizeof(WAVEHDR));
      wave_headers[i].lpData = wave_buffers[i];
      wave_headers[i].dwBufferLength = (DWORD) (period_size * 4);
      wave_headers[i].dwFlags = (DWORD) WHDR_DONE;
      wave_headers[i].dwLoops = (DWORD) 1;
    }
    /* buffers have been allocated, now prepare all */
    for (i = 0; i < n_buffers; i++) {
      if (waveOutPrepareHeader(wave_device, &(wave_headers[i]),
                               (UINT) sizeof(WAVEHDR))
                               != (UINT) MMSYSERR_NOERROR) {
        do_cleanup();
        printMsg(" *** ep128emu: error preparing wave out header\n");
        return -1;
      }
    }
    /* successfully finished */
    return 0;

 mem_err:
    /* could not allocate memory, clean up and report error */
    do_cleanup();
    printMsg(" *** ep128emu: error allocating memory for sound buffers\n");
    return -1;
}

static int play_next_buffer(void)
{
    if (samples_ahead >= period_size) {
      waveOutWrite(wave_device, &(wave_headers[read_buf]),
                   (UINT) sizeof(WAVEHDR));
      /* assume power of two number of buffers */
      read_buf = (read_buf + 1) & (n_buffers - 1);
      /* successfully played 'period_size' samples */
      samples_ahead -= period_size;
      return 0;
    }
    else {
      /* there is not enough data available, play dummy buffer */
      waveOutPrepareHeader(wave_device, &(wave_headers[n_buffers]),
                           (UINT) sizeof(WAVEHDR));
      waveOutWrite(wave_device, &(wave_headers[n_buffers]),
                   (UINT) sizeof(WAVEHDR));
      waveOutUnprepareHeader(wave_device, &(wave_headers[n_buffers]),
                             (UINT) sizeof(WAVEHDR));
      /* underrun */
      return -1;
    }
}

/* initialize sound card (returns zero on success) */

static void CALLBACK sound_callback(HDRVR hWave, UINT wMsg, DWORD dwInstance,
                                    DWORD dwParam1, DWORD dwParam2);

static int soundcard_initialize_(void)
{
    int           i, ndevs, devnum = 0;
    WAVEOUTCAPS   dev_caps;

    /* there is nothing to do if sound is disabled */
    if (disable_sound & 1) {
      device_is_open = 1;
      return 0;
    }

    /* make sure that buffer sizes are valid */
    if (buffer_size < MIN_BUFFER_SIZE)
      buffer_size = MIN_BUFFER_SIZE;
    if (buffer_size > MAX_BUFFER_SIZE)
      buffer_size = MAX_BUFFER_SIZE;
    if (period_size < MIN_PERIOD_SIZE)
      period_size = MIN_PERIOD_SIZE;
    if (period_size > MAX_PERIOD_SIZE)
      period_size = MAX_PERIOD_SIZE;
    /* round up to power of two buffer size */
    /* could be done better, but speed does not really matter here */
    while (buffer_size & (buffer_size - 1))
      buffer_size++;
    while (period_size & (period_size - 1))
      period_size++;
    /* must have at least two buffer fragments, but four is better */
    if (period_size > (buffer_size >> 2))
      period_size = buffer_size >> 2;
    n_buffers = buffer_size / period_size;
    /* initialize playback state variables */
    period_cnt = 0;
    read_buf = 0;
    write_buf = (n_buffers >> 1);
    samples_ahead = period_size * (n_buffers >> 1);
    /* 0: underrun, 1: very low, 2: low, 3: normal, 4: high, 5: full */
    buffer_state = 3;
    /* not opened yet */
    device_is_open = 0;
    /* set playback parameters - only the sample rate is variable */
    wave_format.nSamplesPerSec = (DWORD) (sound_sample_rate + 0.5);
    wave_format.nAvgBytesPerSec = wave_format.nSamplesPerSec
                                  * (DWORD) wave_format.nBlockAlign;
    /* query the number of available sound output devices */
    ndevs = (int) waveOutGetNumDevs();
    if (ndevs < 1) {
      printMsg(" *** ep128emu: winmm: no available waveOut devices\n");
      return -1;
    }
    /* check the device specified by user */
    if (sound_device == NULL || sound_device[0] == '\0' ||
        strcmp(sound_device, "default") == 0) {
      /* default: use device #0 */
      devnum = 0;
    }
    else {
      if (!isdigit(sound_device[0])) {
        printMsg(" *** ep128emu: invalid waveOut device number: '%s'\n",
                 sound_device);
        return -1;
      }
      devnum = (int) atoi(sound_device);
      if (devnum < 0 || devnum >= ndevs) {
        printMsg(" *** ep128emu: invalid waveOut device number: '%s'\n",
                 sound_device);
        return -1;
      }
    }
    if (waveOutGetDevCaps(devnum, &dev_caps, (UINT) sizeof(WAVEOUTCAPS))
        != (UINT) MMSYSERR_NOERROR) {
      printMsg(" *** ep128emu: cannot determine capabilities of "
               "waveOut device #%d\n", devnum);
      return -1;
    }
    printMsg("winmm: using waveOut device #%d: '%s'\n",
             devnum, dev_caps.szPname);
    /* open the device for playback */
    if (waveOutOpen(&wave_device, (UINT) devnum, &wave_format,
                    (DWORD) sound_callback, (DWORD) 0,
                    (DWORD) CALLBACK_FUNCTION)
                    != (UINT) MMSYSERR_NOERROR) {
      printMsg(" *** ep128emu: error opening waveOut device #%d ('%s')\n",
               devnum, dev_caps.szPname);
      do_cleanup();
      return -1;
    }
    /* set up buffers */
    if (allocate_buffers() != 0) {
      do_cleanup();
      return -1;
    }
    /* set buffer thresholds */
    bufthreshold_1 = 0;
    bufthreshold_2 = (int) (0.1 * (double) buffer_size + 0.5);
    bufthreshold_3 = (int) (0.4 * (double) buffer_size + 0.5);
    bufthreshold_4 = (int) (0.6 * (double) buffer_size + 0.5);
    bufthreshold_5 = (int) (0.9 * (double) buffer_size + 0.5);
    /* mark as open, */
    device_is_open = 1;
    /* start playback, */
    for (i = 0; i < (n_buffers >> 1); i++)
      play_next_buffer();
    playback_on = 1;
    /* and report success */
    return 0;
}

/* sound callback function */

static void CALLBACK sound_callback(HDRVR hWave, UINT wMsg, DWORD dwInstance,
                                    DWORD dwParam1, DWORD dwParam2)
{
    if (!playback_on || wMsg != (UINT) WOM_DONE)
      return;

    /* avoid compiler warnings */
    hWave = hWave;
    dwInstance = dwInstance;
    dwParam1 = dwParam1;
    dwParam2 = dwParam2;
    /* play one buffer of audio */
    if (play_next_buffer() != 0) {
      /* underrun */
      buffer_state = 0;
      return;
    }
    /* update buffer state information */
    if (samples_ahead <= bufthreshold_3) {
      if (samples_ahead <= bufthreshold_2) {
        buffer_state = 1;                       /* very low */
      }
      else {
        buffer_state = 2;                       /* low */
      }
    }
    else if (samples_ahead <= bufthreshold_4) {
      buffer_state = 3;                         /* normal */
    }
    else if (samples_ahead <= bufthreshold_5) {
      buffer_state = 4;                         /* high */
    }
    else {
      buffer_state = 5;                         /* full */
    }
    printMsg("ST: %d, RB: %d, WB: %d, SA: %d\n",
             buffer_state, read_buf, write_buf, samples_ahead);
}

/* send a sample to DAC */

static void soundcard_write_data_(int16_t sample_left, int16_t sample_right)
{
    int16_t   *p;

    /* there is nothing to do if sound is disabled */
    if (disable_sound || !device_is_open)
      return;

    /* may need to wait if all buffers are full */
    while (samples_ahead >= buffer_size) {
      buffer_state = 5;
      if (snd_sleep_ms > 0)
        Sleep((DWORD) snd_sleep_ms);
    }
    /* store sample in buffer */
    p = &(((int16_t*) (wave_buffers[write_buf]))[period_cnt << 1]);
    p[0] = sample_left;
    p[1] = sample_right;
    period_cnt++;
    samples_ahead++;

    if (period_cnt >= period_size) {
      /* current buffer is full, advance to next one */
      period_cnt = 0;
      /* assume power of two number of buffers */
      write_buf = (write_buf + 1) & (n_buffers - 1);
    }

    /* check buffer state */
    switch (buffer_state) {
      case 5:                           /* full */
      case 4:                           /* high */
        if (half_refresh_is_allowed)
          display_half_refresh &= ~2;
        break;
      case 0:                           /* underrun */
      case 1:                           /* very low */
        if (half_refresh_is_allowed)
          display_half_refresh |= 2;
    }
    /* reset buffer state until callback function sets it again */
    buffer_state = 3;
}

/* close sound output */

static void soundcard_close_(void)
{
    if (!device_is_open)
      return;
    do_cleanup();
    device_is_open = 0;
}

/* module interface */

SoundModule_t   WinMMSoundDriver = {
    "winmm",
    soundcard_initialize_,
    soundcard_write_data_,
    soundcard_close_
};

