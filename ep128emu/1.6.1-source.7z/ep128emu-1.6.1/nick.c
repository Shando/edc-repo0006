
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* nick.c: NICK chip emulation */

#include <ep128.h>

/* static const int screen_width = 1024; */
static const int    screen_height = 624;    /* (with interlace) */
static const double refresh_rate = 50.0;

static  uint8_t     fixbias = (uint8_t) 0;      /* FIXBIAS << 3      */
static  uint8_t     border_color = (uint8_t) 0; /* border color      */
static  uint16_t    lpt_addr = (uint16_t) 0;    /* LPT base address  */
static  uint16_t    lpt_ptr = (uint16_t) 0;     /* current LPT addr. */
static  uint16_t    ld1_addr = (uint16_t) 0;    /* 1st video address */
static  uint16_t    ld1_ptr = (uint16_t) 0;     /* and current value */
static  uint16_t    ld2_addr = (uint16_t) 0;    /* 2nd video address */
static  uint16_t    ld2_ptr = (uint16_t) 0;     /* and current value */

static  int     lmarg = 63;                 /* left margin       */
static  int     rmarg = 0;                  /* right margin      */
static  int     altind0 = 0, altind1 = 0;
static  int     lsbalt = 0, msbalt = 0;
static  int     lpt_clk_enabled = 1;        /* LPT clock enabled */
static  int     lpt_lines_rem = 1;          /* LPT line counter  */
static  int     cur_line = 0;               /* curr. screen line */

static  int     reload_flag = 0;

static  int     vres = 0;
static  int     video_mode = 0;
static  uint8_t palette[16] = { 0, 0, 0, 0, 0, 0, 0, 0,
                                0, 0, 0, 0, 0, 0, 0, 0 };

static  uint32_t pixel_buf_data[256];       /* line buffer (1024 bytes) */
static  uint8_t  *pixel_buf = (uint8_t*) &(pixel_buf_data[0]);

/* table of render functions */

typedef void (*RenderFunc_t)(uint8_t**, int);

static  void    draw_line_pixel_2_colors(uint8_t **bufp, int nchars);
static  void    draw_line_pixel_4_colors(uint8_t **bufp, int nchars);
static  void    draw_line_pixel_16_colors(uint8_t **bufp, int nchars);
static  void    draw_line_pixel_256_colors(uint8_t **bufp, int nchars);
static  void    draw_line_lpixel_2_colors(uint8_t **bufp, int nchars);
static  void    draw_line_lpixel_4_colors(uint8_t **bufp, int nchars);
static  void    draw_line_lpixel_16_colors(uint8_t **bufp, int nchars);
static  void    draw_line_lpixel_256_colors(uint8_t **bufp, int nchars);
static  void    draw_line_char_2_colors(uint8_t **bufp, int nchars);
static  void    draw_line_char_4_colors(uint8_t **bufp, int nchars);
static  void    draw_line_char_16_colors(uint8_t **bufp, int nchars);
static  void    draw_line_char_256_colors(uint8_t **bufp, int nchars);
static  void    draw_line_attribute_16_colors(uint8_t **bufp, int nchars);

static RenderFunc_t renderer_functions[32] = {
    (RenderFunc_t) NULL,                /* 00 000: VSYNC                  */
    draw_line_pixel_2_colors,           /* 00 001: PIXEL        2 colors  */
    draw_line_attribute_16_colors,      /* 00 010: ATTRIBUTE   16 colors  */
    draw_line_char_2_colors,            /* 00 011: CH256        2 colors  */
    draw_line_char_2_colors,            /* 00 100: CH128        2 colors  */
    draw_line_char_2_colors,            /* 00 101: CH64         2 colors  */
    (RenderFunc_t) NULL,                /* 00 110: INVALID                */
    draw_line_lpixel_2_colors,          /* 00 111: LPIXEL       2 colors  */
    (RenderFunc_t) NULL,                /* 01 000: VSYNC                  */
    draw_line_pixel_4_colors,           /* 01 001: PIXEL        4 colors  */
    draw_line_attribute_16_colors,      /* 01 010: ATTRIBUTE / INVALID    */
    draw_line_char_4_colors,            /* 01 011: CH256        4 colors  */
    draw_line_char_4_colors,            /* 01 100: CH128        4 colors  */
    draw_line_char_4_colors,            /* 01 101: CH64         4 colors  */
    (RenderFunc_t) NULL,                /* 01 110: INVALID                */
    draw_line_lpixel_4_colors,          /* 01 111: LPIXEL       4 colors  */
    (RenderFunc_t) NULL,                /* 10 000: VSYNC                  */
    draw_line_pixel_16_colors,          /* 10 001: PIXEL       16 colors  */
    draw_line_attribute_16_colors,      /* 10 010: ATTRIBUTE / INVALID    */
    draw_line_char_16_colors,           /* 10 011: CH256       16 colors  */
    draw_line_char_16_colors,           /* 10 100: CH128       16 colors  */
    draw_line_char_16_colors,           /* 10 101: CH64        16 colors  */
    (RenderFunc_t) NULL,                /* 10 110: INVALID                */
    draw_line_lpixel_16_colors,         /* 10 111: LPIXEL      16 colors  */
    (RenderFunc_t) NULL,                /* 11 000: VSYNC                  */
    draw_line_pixel_256_colors,         /* 11 001: PIXEL      256 colors  */
    draw_line_attribute_16_colors,      /* 11 010: ATTRIBUTE / INVALID    */
    draw_line_char_256_colors,          /* 11 011: CH256      256 colors  */
    draw_line_char_256_colors,          /* 11 100: CH128      256 colors  */
    draw_line_char_256_colors,          /* 11 101: CH64       256 colors  */
    (RenderFunc_t) NULL,                /* 11 110: INVALID                */
    draw_line_lpixel_256_colors         /* 11 111: LPIXEL     256 colors  */
};

/* currently active renderer function (may be NULL for blank screen) */

static  RenderFunc_t    current_renderer_function = (RenderFunc_t) NULL;

static inline void reload_lpt_ptr(void)
{
    lpt_ptr = lpt_addr;
    lpt_lines_rem = 1;
    reload_flag = 0;
}

/* write video register */

void nick_register_write(uint16_t address, uint8_t value)
{
    switch ((int) address) {
    case 0x80:                              /* FIXBIAS */
      fixbias = (value & 0x1F) << 3;
      /* update palette */
      palette[8]  = fixbias | (uint8_t) 0;
      palette[9]  = fixbias | (uint8_t) 1;
      palette[10] = fixbias | (uint8_t) 2;
      palette[11] = fixbias | (uint8_t) 3;
      palette[12] = fixbias | (uint8_t) 4;
      palette[13] = fixbias | (uint8_t) 5;
      palette[14] = fixbias | (uint8_t) 6;
      palette[15] = fixbias | (uint8_t) 7;
      break;
    case 0x81:                              /* BORDER */
      border_color = value;
      break;
    case 0x82:                              /* LPL */
      lpt_addr = (lpt_addr & (uint16_t) 0xF000)
                 | ((uint16_t) value << 4);
      break;
    case 0x83:                              /* LPH */
      lpt_addr = (lpt_addr & (uint16_t) 0x0FF0)
                 | ((uint16_t) (value & (uint8_t) 0x0F) << 12);
      /* enable / disable LPT clock */
      lpt_clk_enabled = (value & (uint8_t) 0x40 ? 1 : 0);
      /* force LPT reload */
      if (!(value & (uint8_t) 0x80)) reload_lpt_ptr();
      break;
    }
}

/* reset video subsystem */

void    nick_reset(void)
{
    /* reset all registers */
    nick_register_write((uint16_t) 0x80, (uint8_t) 0x00);
    nick_register_write((uint16_t) 0x81, (uint8_t) 0x00);
    nick_register_write((uint16_t) 0x82, (uint8_t) 0x00);
    nick_register_write((uint16_t) 0x83, (uint8_t) 0x00);
    reload_lpt_ptr();
    /* set default values */
    ld1_addr = (uint16_t) 0;        /* 1st video address */
    ld1_ptr = (uint16_t) 0;         /* and current value */
    ld2_addr = (uint16_t) 0;        /* 2nd video address */
    ld2_ptr = (uint16_t) 0;         /* and current value */
    lmarg = 63;                     /* left margin       */
    rmarg = 0;                      /* right margin      */
    altind0 = 0, altind1 = 0;
    lsbalt = 0, msbalt = 0;
    lpt_clk_enabled = 1;            /* LPT clock enabled */
    cur_line = 0;                   /* curr. screen line */
    vres = 0;
    video_mode = 0;
    memset(palette, 0, 16);
    current_renderer_function = (RenderFunc_t) NULL;
}

/* read next line of LPT, set video mode, and trigger video interrupt */

static void nick_read_lpt(void)
{
    static  int vid_modes[8] = {
      0x00000000,           /* VSYNC        */
      0x00000001,           /* PIXEL        */
      0x00000100,           /* ATTRIBUTE    */
      0x00030000,           /* CH256        */
      0x00020000,           /* CH128        */
      0x00010000,           /* CH64         */
      0x00000000,           /* invalid      */
      0x00000002            /* LPIXEL       */
    };
    uint8_t *p;

    if (!lpt_clk_enabled) return;
    if (--lpt_lines_rem) return;
    if (reload_flag) reload_lpt_ptr();
    /* -- read next LPB -- */
    p = video_memory + (size_t) lpt_ptr;
    /* byte 0: count of lines */
    lpt_lines_rem = 256 - (int) (*p++);
    /* byte 1: mode */
    dave_set_int_1_state(*p & (uint8_t) 0x80 ? 1 : 0);
    if (!video_mode && ((int) *p & 0x0E)) {     /* at end of VSYNC: */
      int prv_line = cur_line;
      cur_line = (cur_line & 1) ^ 1;    /* switch odd / even lines */
      cur_line |= display_sync_line;    /* synchronize             */
      if (((cur_line & (~1)) - (prv_line & (~1))) < (screen_height - 32)) {
        /* the above test is needed to correctly deal with bogus LPTs */
        /* that have more than 312 lines */
        while ((prv_line & (~1)) < (cur_line & (~1))) {
          /* fill any remaining lines with blank */
          draw_line(prv_line, pixel_buf, (uint8_t) 0, 63, 0);
          prv_line += 2;
        }
      }
    }
    vres = ((int) (*p & 0x10)) >> 4;
    video_mode = vid_modes[((int) (*p & 0x0E)) >> 1];
    reload_flag = (int) (*p & 0x01);
    /* select renderer function */
    current_renderer_function =
      renderer_functions[(((int) *p & 0x60) >> 2) | (((int) *p & 0x0E) >> 1)];
    /* byte 2: left margin */
    lmarg = (int) (*++p) & 0x3F;
    lsbalt = ((int) *p & 0x40 ? 1 : 0);
    msbalt = ((int) *p & 0x80 ? 1 : 0);
    /* byte 3: right margin */
    rmarg = (int) (*++p) & 0x3F;
    altind0 = ((int) *p & 0x80 ? 1 : 0);
    altind1 = ((int) *p & 0x40 ? 1 : 0);
    /* byte 4, 5: 1st video address */
    ld1_addr = (uint16_t) (*++p);
    ld1_addr |= (uint16_t) (*++p) << 8;
    ld1_ptr = ld1_addr;
    /* byte 6, 7: 2nd video address */
    ld2_addr = (uint16_t) (*++p);
    ld2_addr |= (uint16_t) (*++p) << 8;
    switch (video_mode) {   /* ignore lowest bits in character modes */
      case 0x00010000:  ld2_addr <<= 6; break;
      case 0x00020000:  ld2_addr <<= 7; break;
      case 0x00030000:  ld2_addr <<= 8; break;
    }
    ld2_ptr = ld2_addr;
    /* palette colors */
    palette[0] = *++p;
    palette[1] = *++p;
    palette[2] = *++p;
    palette[3] = *++p;
    palette[4] = *++p;
    palette[5] = *++p;
    palette[6] = *++p;
    palette[7] = *++p;
    /* next LPB */
    lpt_ptr += (uint16_t) 16;
}

/* conversion table for 4 colors */

static  const   uint8_t tabl1[144] = {
    0, 2, 2, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0,
    1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0
};

/* conversion table for 16 colors */

static  const   uint8_t tabl2[176] = {
     0,  8,  8,  0,  2, 10,  0,  0,  2,  0, 10,  0,  0,  0,  0,  0,
     4, 12,  0,  0,  6, 14,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     4,  0, 12,  0,  0,  0,  0,  0,  6,  0, 14,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     1,  9,  0,  0,  3, 11,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     5, 13,  0,  0,  7, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     1,  0,  9,  0,  0,  0,  0,  0,  3,  0, 11,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     5,  0, 13,  0,  0,  0,  0,  0,  7,  0, 15,  0,  0,  0,  0,  0
};

/* ---------------- render functions ---------------- */

/* draw a line of 'nchars' characters in PIXEL modes ('nchars' must be > 0) */

static void draw_line_pixel_2_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    uint8_t pixel_value, c0, c1;

    nchars <<= 1;
    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- two colors ---- */
      c0 = (uint8_t) 0;
      if (msbalt) {
        if (pixel_value & (uint8_t) 0x80) c0 |= 2;
        pixel_value &= (uint8_t) 0x7F;
      }
      if (lsbalt) {
        if (pixel_value & (uint8_t) 0x01) c0 |= 4;
        pixel_value &= (uint8_t) 0xFE;
      }
      c1 = palette[c0 + (uint8_t) 1];
      c0 = palette[c0];
      *(p++) = (pixel_value & (uint8_t) 0x80 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x40 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x20 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x10 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x08 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x04 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x02 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x01 ? c1 : c0);
    } while (--nchars);
    (*bufp) = p;
}

static void draw_line_pixel_4_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    uint8_t pixel_value;

    nchars <<= 1;
    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- four colors ---- */
      p[0] = p[1] = palette[tabl1[pixel_value & (uint8_t) 0x88]];
      p += 2;
      p[0] = p[1] = palette[tabl1[pixel_value & (uint8_t) 0x44]];
      p += 2;
      p[0] = p[1] = palette[tabl1[pixel_value & (uint8_t) 0x22]];
      p += 2;
      p[0] = p[1] = palette[tabl1[pixel_value & (uint8_t) 0x11]];
      p += 2;
    } while (--nchars);
    (*bufp) = p;
}

static void draw_line_pixel_16_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    uint8_t pixel_value;

    nchars <<= 1;
    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- 16 colors ---- */
      p[0] = p[1] = p[2] = p[3] = palette[tabl2[pixel_value & (uint8_t) 0xAA]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl2[pixel_value & (uint8_t) 0x55]];
      p += 4;
    } while (--nchars);
    (*bufp) = p;
}

static void draw_line_pixel_256_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     i;
    uint8_t pixel_value;

    nchars <<= 1;
    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- 256 colors (simple!) ---- */
      for (i = 0; i < 8; i++)
        p[i] = pixel_value;
      p += 8;
    } while (--nchars);
    (*bufp) = p;
}

/* draw a line of 'nchars' characters in LPIXEL modes ('nchars' must be > 0) */

static void draw_line_lpixel_2_colors(uint8_t **bufp, int nchars)
{
    uint16_t    *p, c0, c1;
    uint8_t     pixel_value;

    /* *bufp should be aligned to 2 bytes */
    p = (uint16_t*) (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- two colors ---- */
      c0 = (uint16_t) 0;
      if (msbalt) {
        if (pixel_value & (uint8_t) 0x80) c0 |= (uint16_t) 2;
        pixel_value &= (uint8_t) 0x7F;
      }
      if (lsbalt) {
        if (pixel_value & (uint8_t) 0x01) c0 |= (uint16_t) 4;
        pixel_value &= (uint8_t) 0xFE;
      }
      c1 = (uint16_t) palette[(int) c0 + 1];
      c0 = (uint16_t) palette[(int) c0];
      c1 = (c1 << 8) | c1;
      c0 = (c0 << 8) | c0;
      *(p++) = (pixel_value & (uint8_t) 0x80 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x40 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x20 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x10 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x08 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x04 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x02 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x01 ? c1 : c0);
    } while (--nchars);
    (*bufp) = (uint8_t*) p;
}

static void draw_line_lpixel_4_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    uint8_t pixel_value;

    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- four colors ---- */
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x88]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x44]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x22]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x11]];
      p += 4;
    } while (--nchars);
    (*bufp) = p;
}

static void draw_line_lpixel_16_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     i;
    uint8_t pixel_value;

    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- 16 colors ---- */
      for (i = 0; i < 8; i++)
        p[i] = palette[tabl2[pixel_value & (uint8_t) 0xAA]];
      p += 8;
      for (i = 0; i < 8; i++)
        p[i] = palette[tabl2[pixel_value & (uint8_t) 0x55]];
      p += 8;
    } while (--nchars);
    (*bufp) = p;
}

static void draw_line_lpixel_256_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     i;
    uint8_t pixel_value;

    p = (*bufp);
    do {
      pixel_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      /* ---- 256 colors (simple!) ---- */
      for (i = 0; i < 16; i++)
        p[i] = pixel_value;
      p += 16;
    } while (--nchars);
    (*bufp) = p;
}

/* draw a line of 'nchars' (must be > 0) characters in CHARACTER modes */

static void draw_line_char_2_colors(uint8_t **bufp, int nchars)
{
    uint16_t *p, c0, c1;
    int     mask = 0;
    uint8_t char_value, pixel_value;

    switch (video_mode) {
      case 0x00010000:  mask = 0x3F; break;     /* CH64 */
      case 0x00020000:  mask = 0x7F; break;     /* CH128 */
      case 0x00030000:  mask = 0xFF; break;     /* CH256 */
    }
    /* *bufp should be aligned to 2 bytes */
    p = (uint16_t*) (*bufp);
    do {
      char_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      pixel_value =
        video_memory[ld2_ptr | (uint16_t) ((int) char_value & mask)];
      /* ---- two colors ---- */
      c0 = (uint16_t) 0;
      if (altind1 && (char_value & (uint8_t) 0x80)) c0 |= (uint16_t) 2;
      if (altind0 && (char_value & (uint8_t) 0x40)) c0 |= (uint16_t) 4;
      c1 = (uint16_t) palette[(int) c0 + 1];
      c0 = (uint16_t) palette[(int) c0];
      c1 = (c1 << 8) | c1;
      c0 = (c0 << 8) | c0;
      *(p++) = (pixel_value & (uint8_t) 0x80 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x40 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x20 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x10 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x08 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x04 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x02 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x01 ? c1 : c0);
    } while (--nchars);
    ld2_ptr += (uint16_t) (mask + 1);
    (*bufp) = (uint8_t*) p;
}

static void draw_line_char_4_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     mask = 0;
    uint8_t char_value, pixel_value;

    switch (video_mode) {
      case 0x00010000:  mask = 0x3F; break;     /* CH64 */
      case 0x00020000:  mask = 0x7F; break;     /* CH128 */
      case 0x00030000:  mask = 0xFF; break;     /* CH256 */
    }
    p = (*bufp);
    do {
      char_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      pixel_value =
        video_memory[ld2_ptr | (uint16_t) ((int) char_value & mask)];
      /* ---- four colors ---- */
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x88]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x44]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x22]];
      p += 4;
      p[0] = p[1] = p[2] = p[3] = palette[tabl1[pixel_value & (uint8_t) 0x11]];
      p += 4;
    } while (--nchars);
    ld2_ptr += (uint16_t) (mask + 1);
    (*bufp) = p;
}

static void draw_line_char_16_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     i, mask = 0;
    uint8_t char_value, pixel_value;

    switch (video_mode) {
      case 0x00010000:  mask = 0x3F; break;     /* CH64 */
      case 0x00020000:  mask = 0x7F; break;     /* CH128 */
      case 0x00030000:  mask = 0xFF; break;     /* CH256 */
    }
    p = (*bufp);
    do {
      char_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      pixel_value =
        video_memory[ld2_ptr | (uint16_t) ((int) char_value & mask)];
      /* ---- 16 colors ---- */
      for (i = 0; i < 8; i++)
        p[i] = palette[tabl2[pixel_value & (uint8_t) 0xAA]];
      p += 8;
      for (i = 0; i < 8; i++)
        p[i] = palette[tabl2[pixel_value & (uint8_t) 0x55]];
      p += 8;
    } while (--nchars);
    ld2_ptr += (uint16_t) (mask + 1);
    (*bufp) = p;
}

static void draw_line_char_256_colors(uint8_t **bufp, int nchars)
{
    uint8_t *p;
    int     i, mask = 0;
    uint8_t char_value, pixel_value;

    switch (video_mode) {
      case 0x00010000:  mask = 0x3F; break;     /* CH64 */
      case 0x00020000:  mask = 0x7F; break;     /* CH128 */
      case 0x00030000:  mask = 0xFF; break;     /* CH256 */
    }
    p = (*bufp);
    do {
      char_value = (uint8_t) video_memory[ld1_ptr];
      ld1_ptr++;
      pixel_value =
        video_memory[ld2_ptr | (uint16_t) ((int) char_value & mask)];
      /* ---- 256 colors (simple!) ---- */
      for (i = 0; i < 16; i++)
        p[i] = pixel_value;
      p += 16;
    } while (--nchars);
    ld2_ptr += (uint16_t) (mask + 1);
    (*bufp) = p;
}

/* draw a line of 'nchars' (must be > 0) characters in ATTRIBUTE mode */

static void draw_line_attribute_16_colors(uint8_t **bufp, int nchars)
{
    uint16_t    *p, c0, c1;
    uint8_t     pixel_value;

    /* *bufp should be aligned to 2 bytes */
    p = (uint16_t*) (*bufp);
    do {
      c0 = (uint16_t) palette[((int) video_memory[ld1_ptr] & 0xF0) >> 4];
      c1 = (uint16_t) palette[(int) video_memory[ld1_ptr] & 0x0F];
      c0 = (c0 << 8) | c0;
      c1 = (c1 << 8) | c1;
      ld1_ptr++;
      pixel_value = video_memory[ld2_ptr];
      ld2_ptr++;
      *(p++) = (pixel_value & (uint8_t) 0x80 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x40 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x20 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x10 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x08 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x04 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x02 ? c1 : c0);
      *(p++) = (pixel_value & (uint8_t) 0x01 ? c1 : c0);
    } while (--nchars);
    (*bufp) = (uint8_t*) p;
}

/* convert time value (in seconds) to number of lines * 16777216 */

int time_to_nlines(double timeval)
{
    /* multiplied by 0.5 because of interlaced display */
    return (int) (16777216.0 * (timeval * refresh_rate)
                  * ((double) screen_height * 0.5) + 0.5);
}

/* draw the specified number of lines / 16777216 */

static  int     lin_rem = 0;

void nick_draw_lines(int nlines)
{
    uint8_t   *bufp;
    int       i, nchars;

    /* calculate the actual number of lines to draw */
    i = nlines + lin_rem;
    nlines = (i & 0x7F000000) >> 24;
    lin_rem = (i - (nlines << 24));

    while (nlines--) {
      if (!video_mode || current_renderer_function == (RenderFunc_t) NULL) {
        /* VSYNC or invalid mode: fill with blank */
        draw_line((int) cur_line, pixel_buf, (uint8_t) 0, 63, 0);
        goto next_line;
      }
      else if (lmarg >= rmarg) {
        /* border only */
        draw_line((int) cur_line, pixel_buf, border_color, 63, 0);
        goto next_line;
      }
      /* the active display area (text/graphics) */
      bufp = (uint8_t*) pixel_buf;
      nchars = rmarg - lmarg;
      /* render line */
      current_renderer_function(&bufp, nchars);
      /* finished drawing this line, copy to screen */
      draw_line((int) cur_line, pixel_buf, border_color, lmarg, rmarg);

 next_line:
      /* check VRES mode */
      if (!vres)
        ld1_ptr = ld1_addr;
      /* update LPT */
      nick_read_lpt();
      /* new line */
      cur_line += 2;
      if (cur_line >= 624)
        cur_line -= 624;        /* wrap around */
    }
}

/* return the size of video snapshot data (in bytes) for snapshot file */
/* version 'file_version' */

int nick_snapshot_bytes(int file_version)
{
    switch (file_version) {
    case 0x0101:
    case 0x0102:
      return 32;
    default:
      return -1;
    }
}

/* save video snapshot to file 'f' */
/* returns zero in case of success */

int save_nick_snapshot(FILE *f)
{
    snapshot_write_uint16((uint16_t) lpt_addr, f);
    snapshot_write_uint16((uint16_t) lpt_ptr, f);
    snapshot_write_uint16((uint16_t) ld1_addr, f);
    snapshot_write_uint16((uint16_t) ld2_addr, f);

    snapshot_write_uint32((uint32_t) lpt_lines_rem, f);
    snapshot_write_uint32((uint32_t) cur_line, f);
    snapshot_write_uint32((uint32_t) reload_flag, f);

    /* padding */
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);

    return 0;           /* TODO: error handling */
}

/* load video snapshot from file 'f', using file format */
/* specified by 'file_version'. Returns zero in case of success. */

int load_nick_snapshot(FILE *f, int file_version)
{
    /* check file version */
    if (file_version != 0x0101 && file_version != 0x0102)
      return -1;

    lpt_addr = (uint16_t) snapshot_read_uint16(f);
    lpt_ptr  = (uint16_t) snapshot_read_uint16(f);
    ld1_addr = (uint16_t) snapshot_read_uint16(f);
    ld2_addr = (uint16_t) snapshot_read_uint16(f);

    lpt_lines_rem = (int) snapshot_read_uint32(f);
    cur_line      = (int) snapshot_read_uint32(f);
    reload_flag   = (int) snapshot_read_uint32(f);

    /* padding */
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);

    /* temporarily switch to blank mode */
    lmarg = 63;
    rmarg = 0;
    video_mode = 0;
    current_renderer_function = (RenderFunc_t) NULL;

    return 0;           /* TODO: error handling */
}

