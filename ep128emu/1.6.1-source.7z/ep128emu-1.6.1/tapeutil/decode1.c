
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* decode1.c: extract files from 1-bit mono 24 kHz tape file */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

static	double	esr = 24000.0;		/* sample rate of input file */

static	FILE	*infile = NULL;		/* input file */

static	char	outflname[256];		/* output file name */
static	FILE	*outfl = NULL;		/* output file */

static	unsigned char	buf[4096];

static	int	byte_val = 0, bit_cnt = 0;
static	int	cursamp = 0, prvsamp1 = 0;
static	int	time_smp = 0;
static	double	time_sec = 0.0;
static	int	cur_edge = 0, prv_edge_1 = 0, prv_edge_2 = 0;
static	double	cur_edge_time = 0.0;
static	double	prv_edge_time_1 = 0.0, prv_edge_time_2 = 0.0;
static	double	ref_period_time = 0.0;
static	int	crc_val = 0;

/* print current time (for debugging) */

void	print_time(void)
{
	fprintf(stderr, "at time %f: ", time_sec);
}

void	store_sample(unsigned char samp)
{
	/* update time */
	time_smp++;
	time_sec += (1.0 / esr);
	/* shift old samples */
	prvsamp1 = cursamp;
	/* store new sample */
	cursamp = (int) samp;
}

/* return value is -1 for edge down, 1 for edge up, and 0 for no edge */

int	detect_edge(void)
{
	if (cursamp > prvsamp1) {
		/* edge up */
		return 1;
	} else if (cursamp < prvsamp1) {
		/* edge down */
		return -1;
	}
	/* no edge */
	return 0;
}

/* open input file */

void	open_file(char *name)
{
	infile = fopen(name, "rb");
	if (infile == NULL) {
		fprintf(stderr, "cannot open input file\n");
		exit(-1);
	}
}

/* open file for writing (name is specified in outflname) */

FILE	*open_output_file(void)
{
	struct stat	tmp;
	char		s[256];
	int		outflcnt = 0;
	FILE		*f = NULL;

	strcpy(s, outflname);
	do {
		/* check if the file already exists */
		if (stat(s, &tmp) != 0) {
			if (errno != ENOENT) return (FILE*) NULL;
		} else {
			/* try a new name */
			outflcnt++;
			sprintf(s, "%s-%04d", outflname, outflcnt);
			continue;
		}
		/* does not exist yet */
		strcpy(outflname, s);
		f = fopen(outflname, "wb");
	} while (!f);
	return f;
}

/* read a sample from input file, and store in buffer */
/* return value is zero if end of file is reached */
/* (in this case, the input file is closed) */

int	read_next_sample(void)
{
	int	c;

	if (bit_cnt) {
		store_sample((unsigned char) (byte_val & 0x80 ? 0xFC : 0x04));
		byte_val = (byte_val & 0x7F) << 1;
		bit_cnt--;
		return 1;
	}
	/* need to read next byte from input file */
	if (infile == NULL) {
		store_sample((unsigned char) 0);	/* end of file */
		return 0;
	}
	c = getc(infile);
	if (c == EOF) {
		fclose(infile); infile = NULL; return read_next_sample();
	}
	byte_val = c & 0xFF;
	bit_cnt = 8;
	return read_next_sample();
}

/* read input file until an edge is found, and update edge times */
/* return value is zero at end of file, 1 otherwise */

int	scan_for_edge(void)
{
	int	e;
	do {
		if (!read_next_sample()) return 0;	/* end of file */
		e = detect_edge();
	} while (!e);
	/* shift old edges */
	prv_edge_2 = prv_edge_1;
	prv_edge_1 = cur_edge;
	cur_edge = e;
	/* and edge times */
	prv_edge_time_2 = prv_edge_time_1;
	prv_edge_time_1 = cur_edge_time;
	cur_edge_time = time_sec;
	return 1;
}

/* read a single bit, and update CRC */
/* returns zero on error or end of file, -1 for bit=0, and 1 for bit=1 */

int	read_bit(void)
{
	double	x;
	int	n = 0;

	if (!scan_for_edge()) return 0;
	if (!scan_for_edge()) return 0;
	x = (cur_edge_time - prv_edge_time_2) / ref_period_time;
	/* check if we have found a valid bit */
	if (x > 0.500 && x < 0.950) {
		/* found bit 1 */
		n = 0x8000;
	} else if (x > 1.050 && x < 1.400) {
		/* found bit 0 */
		n = 0x0000;
	} else {
		/* invalid period time */
		print_time();
		fprintf(stderr, "invalid period time for bit: %f\n", x);
		return 0;
	}
	/* update CRC */
	crc_val ^= n;
	if (crc_val & 0x8000) crc_val ^= 0x0810;
	crc_val <<= 1;
	crc_val = (crc_val & 0xFFFE) + ((crc_val & 0x10000) >> 16);
	/* return -1 for bit=0 and 1 for bit=1 */
	n = (n ? 1 : -1);
	return n;
}

/* read a byte from input file */
/* returns the byte read, or -1 in case of error or end of file */

int	read_byte(void)
{
	int	n = 0, m, i = 8;
	do {
		m = read_bit();
		if (!m) return -1;	/* error or end of file */
		n >>= 1;
		if (m > 0) n |= 0x80;
	} while (--i);
	return n;
}

/* scan input file until a data chunk is found */
/* a return value of 1 means success, and zero is returned on error or EOF */

int	scan_for_sync(void)
{
	int	i;
	double	avg_period_time = 0.0, x, cnt;

restart:
	/* search for lead-in signal */
	do {
		if (!scan_for_edge()) return 0;
		if (!scan_for_edge()) return 0;
		/* set initial period time */
		avg_period_time = cur_edge_time - prv_edge_time_2;
		cnt = 1.0; i = 64;
		do {
			if (!scan_for_edge()) return 0;
			if (!scan_for_edge()) return 0;
			/* check for a constant period time */
			x = cur_edge_time - prv_edge_time_2;
			if ((x / avg_period_time) < 0.85
			    || (x / avg_period_time) > 1.15) break;
			/* average period times for better accuracy */
			avg_period_time = (avg_period_time * cnt + x)
					  / (cnt + 1.0);
			cnt += 1.0;
		} while (--i);
	} while (i);
	/* check for standard period times (424 us and 1000 us) */
	if (!((avg_period_time > 3.84e-4 && avg_period_time < 4.64e-4)
	      || (avg_period_time > 9.2e-4 && avg_period_time < 1.08e-3)))
		goto restart;
	ref_period_time = avg_period_time;
#ifdef DEBUGMSG
	print_time();
	fprintf(stderr, "attempting to synchronize to period time %f ...\n",
			ref_period_time);
#endif

resync:
	/* skip rest of lead-in signal, and search for sync bit */
	do {
		if (!scan_for_edge()) return 0;
		x = (cur_edge_time - prv_edge_time_2) / ref_period_time;
	} while (x < 1.5);
	if (x > 2.0) goto resync;		/* failed to find sync bit */
	/* sync bit found, now check for dummy byte and 0x6A */
#ifdef DEBUGMSG
	print_time();
	fprintf(stderr, "found sync bit (period = %f)\n", x);
#endif
	for (i = 0; i < 8; i++) {
		/* skip dummy byte */
		if (!scan_for_edge()) return 0;
		if (!scan_for_edge()) return 0;
	}
	i = read_byte();
	if (i < 0) {
		if (!infile) return 0;		/* end of file */
		else goto resync;
	}
#ifdef DEBUGMSG
	print_time();
	fprintf(stderr, "byte 0x6A ... ");
#endif
	if (i == 0x6A) {
#ifdef DEBUGMSG
		fprintf(stderr, "OK\n");
#endif
		return 1;
	} else {
#ifdef DEBUGMSG
		fprintf(stderr, "error: found %d instead\n", i);
#endif
		goto restart;
	}
}

int	do_read_chunk(void)
{
	int	i, hdrblk = 0, nblks, nbytes, nread = 0, crc, crc_reqd;

	/* determine chunk type */
	i = read_byte(); if (i < 0) return -1;
#ifdef DEBUGMSG
	print_time();
	fprintf(stderr, "block number: %d\n", i);
#endif
	if (i == 0xFF) {
		hdrblk = 1;	/* header */
		nblks = 1;
	} else if (!i) {
		return 0;	/* no data */
	} else if (i <= 16) {
		nblks = i;
	} else {
#ifndef DEBUGMSG
		print_time();
		fprintf(stderr, "block number: %d\n", i);
#endif
		fprintf(stderr, " *** invalid block number\n");
		return -1;
	}
	do {
		/* number of bytes to read */
		nbytes = read_byte();
		if (nbytes < 0) return -1;
		if (!nbytes) nbytes = 0x100;
		/* reset CRC */
		crc_val = 0;
		do {
			i = read_byte(); if (i < 0) return -1;
			buf[nread++] = (unsigned char) i;
		} while (--nbytes);
		/* check crc */
		crc = crc_val;
		i = read_byte(); if (i < 0) return -1;
		crc_reqd = i;
		i = read_byte(); if (i < 0) return -1;
		crc_reqd |= (i << 8);
		crc_val = 0;
#ifdef DEBUGMSG
		fprintf(stderr, "CRC: stored: %d, calculated: %d\n",
				crc_reqd, crc);
#endif
		if (crc_reqd != crc) {
			/* detected CRC error */
			fprintf(stderr, " *** ");
			print_time();
			fprintf(stderr, "CRC error\n");
			return -1;
		}
	} while (--nblks);
	/* return the number of bytes read */
#ifdef DEBUGMSG
	print_time();
	fprintf(stderr, "read data chunk (size = %d bytes)\n", nread);
#endif
	if (hdrblk) nread = -nread;
	return nread;
}

/* read a chunk of data (max 4096 bytes) to buffer */
/* return value is the number of bytes read (negative for header block), */
/* or -1 for error or EOF */

int	read_chunk(void)
{
	int	i;

	/* find sync signal */
	if (!scan_for_sync())
		return -1;	/* not found */

	/* read data */
	i = do_read_chunk();

	return i;
}

/* read and decode a single file */
/* returns zero on error or end of file */

int	read_file(void)
{
	int	i, nread = 0;
	int	retval = 0;

#ifdef DEBUGMSG
	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "new output file\n");
#endif
	/* read header or first chunk */
	i = read_chunk();
	if (i == -1) goto endwrt;
	if (i < 0) {
		char	*c = (char*) outflname, *s = (char*) buf + 2;
		/* found header */
		i = -(i + 2);
		if (i < 1 || i > 28 || i != (int) buf[1]) {
			fprintf(stderr, " *** incorrect file name length ");
			fprintf(stderr, "(read: %d, stored: %d)\n",
					i, (int) buf[1]);
			goto endwrt;
		}
		/* store file name */
		do *c++ = *s++; while (--i);
		*c++ = '\0';
	} else {
		/* no header (possibly truncated file) */
		strcpy(outflname, "FILE");
		if (!i) goto endwrt;	/* empty file ? */
	}
	/* open output file */
	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "new output file: %s\n", outflname);
	outfl = open_output_file();
	if (!outfl) {
		fprintf(stderr, " *** error opening %s\n", outflname);
		goto endwrt;
	}
	/* store any remaining bytes */
	while (i--) {
		int	c = (int) buf[nread++];
		putc(c, outfl);
	}
	if (nread && nread < 4096) goto scwrt;	/* no more data */
	/* read all data chunks */
	do {
		i = read_chunk();
		if (i < 0) goto endwrt;		/* error */
		if (!i) goto scwrt;	/* end of data */
		do {
			int	c = (int) buf[nread++ & 0x0FFF];
			putc(c, outfl);
		} while (--i);
	} while (!(nread & 0x0FFF));
scwrt:
	retval = 1;
	/* report success */
	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "file %s has been successfully decoded\n", outflname);
endwrt:
	if (outfl) {
		/* report number of bytes written */
		fflush(outfl); fclose(outfl);
		outfl = NULL;
		fprintf(stderr, " === wrote %d bytes to %s ",
				nread, outflname);
		if (!retval) fprintf(stderr, "(with errors)");
		fprintf(stderr, "\n");
	}
	return retval;
}

int	main(int argc, char **argv)
{
	char	*fname = NULL;

	/* parse command line args */
	if (argc > 2 ||
	    (argc == 2 &&
	     (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-help") == 0 ||
	      strcmp(argv[1], "--help") == 0))) {
		fprintf(stderr, "Usage: decode1 <infile>\n");
		fprintf(stderr, "Extracts files from 1-bit 24 kHz mono ");
		fprintf(stderr, "tape file.\n");
		return (argc == 2 ? 0 : -1);
	}
	if (argc > 1)
		fname = argv[1];
	if (!fname) {
		infile = stdin;
	} else {
		open_file(fname);
	}
	do {
		read_file();
	} while (infile);
	return 0;
}

