
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* conv1to8.c: convert 1-bit mono 24 kHz sound file to 8-bit stereo 48 kHz */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
    int i, c;

    /* there are no recognized options */
    if (argc != 1) {
      fprintf(stderr, "Usage: conv1to8 < infile > outfile\n");
      fprintf(stderr, "Converts 1-bit mono 24 kHz soundfile to 8-bit stereo ");
      fprintf(stderr, "48 kHz format.\n");
      return -1;
    }
    argv = argv;    /* compiler only */

    while ((c = fgetc(stdin)) != EOF) {
      c &= 0xFF;
      for (i = 0; i < 8; i++) {
        if (c & 0x80) {
          fputc(0xFC, stdout);
          fputc(0xFC, stdout);
          fputc(0xFC, stdout);
          fputc(0xFC, stdout);
        }
        else {
          fputc(0x04, stdout);
          fputc(0x04, stdout);
          fputc(0x04, stdout);
          fputc(0x04, stdout);
        }
        c <<= 1;
      }
    }

    return 0;
}

