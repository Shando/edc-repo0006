#!/bin/bash

for i in *.[ch] ; do
	rm -f __tmp1 __tmp2 __tmp3
	cat $i | tr -d '\r' | sed 's/[[:space:]]\+$//' | expand | sed 's/^    /  /' > __tmp1
	indent -kr -i2 -nce -sob -l79 -lc79 -st __tmp1 | expand | sed 's/^  /    /' > __tmp2
	cat __tmp2 | sed 's/^\(.*\)[[:space:]]\+\\$/\1                                                                        \\/' | sed 's/^\(.\{71\}\)[[:space:]]\+\\$/\1 \\/' > __tmp3
	rm $i
	cat __tmp3 | sed 's/^\(.\{71,\}[^[:space:]]\)[[:space:]]\+\\$/\1 \\/' > $i
	rm -f __tmp1 __tmp2 __tmp3 ;
done

