
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_CFGPARSE_H
#define EP128_CFGPARSE_H

#include <ep128.h>
#include <ctype.h>

/* parse command line options and configuration file */
/* returns zero on success */

int parse_config_file(int argc, char **argv);

/* print copyright information */

void print_copyright_info(void);

/* print keyboard usage */

void print_keyboard_usage(void);

/* limit integer value pointed to by 'x' to the range 'minval' to 'maxval' */
/* return value is zero if 'x' was in the range, -1 if 'x' was less than */
/* 'minval', and 1 if 'x' was greater than 'maxval' */

int limit_int_to_range(int *x, int minval, int maxval);

/* limit double value pointed to by 'x' to the range 'minval' to 'maxval' */
/* return value is zero if 'x' was in the range, -1 if 'x' was less than */
/* 'minval', and 1 if 'x' was greater than 'maxval' */

int limit_double_to_range(double *x, double minval, double maxval);

/* set integer value pointed to by 'x' to 1 if it is not zero */

void fix_boolean_value(int *x);

#endif      /* EP128_CFGPARSE_H */

