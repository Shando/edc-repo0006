
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_CONSOLE_H
#define EP128_CONSOLE_H

/* console.h -- message printing to stderr, log file, and OpenGL display */

#include <ep128.h>
#include <stdarg.h>

/* enable printing of messages to stderr (0: no) */
/* this is always 1 by default, so that start-up and */
/* error messages can be printed */
extern  int     console_to_stderr;
/* console log file name */
extern  char    *logfile_name;

/* is the OpenGL console enabled (0: no) ? */
/* turning this on requires a double buffered */
/* display and disabling 'blit_on_change_only' */
extern  int     GLconsole_is_enabled;

extern  double  console_bg_R;   /* console background color     */
extern  double  console_bg_G;   /*   (red, green, blue, and     */
extern  double  console_bg_B;   /*   alpha, in the range        */
extern  double  console_bg_A;   /*   0.0 to 1.0)                */

extern  double  console_fg_R;   /* console foreground (text)    */
extern  double  console_fg_G;   /*   color (red, green, blue,   */
extern  double  console_fg_B;   /*   and alpha, in the range    */
extern  double  console_fg_A;   /*   0.0 to 1.0)                */

#ifdef HAVE_OPENGL

/* initialize the OpenGL based console renderer */
/* returns zero on success */

int GLconsole_initialize(void);

/* render one frame of console display if UI mode is program control */
/* should be called after rendering normal emulator display */
/* for the console to work correctly, enable double buffering and */
/* disable 'blit_on_change_only' optimization */

void GLconsole_render_frame(void);

/* de-initialize the OpenGL based console renderer */

void GLconsole_close(void);

#endif  /* HAVE_OPENGL */

/* Print a message to stderr, log file, and OpenGL console, depending */
/* on configuration settings. The parameters and return value are the */
/* same as in the case of printf(). */

int printMsg(const char *fmt, ...);

/* initialize message printing system */
/* return value is zero on success */

int msg_initialize(void);

/* de-initialize message printing system */

void msg_close(void);

#endif          /* EP128_CONSOLE_H */

