
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* COPYRIGHT NOTE: this file is based on code that has been written by, */
/* and is copyright by Kevin Thacker and Vincze Bela Gyorgy (also under */
/* the terms of the GNU General Public License) */

#ifndef EP128_WD177X_H
#define EP128_WD177X_H

#include <stdint.h>

/* disk image file names in the format 'filename@C,H,S' or 'filename' */

extern  char    *wd177x_diskimage_a;
extern  char    *wd177x_diskimage_b;
extern  char    *wd177x_diskimage_c;
extern  char    *wd177x_diskimage_d;

typedef struct wd177x_drive_s {
    /* ---- device parameters ---- */
    char    fname[4096];        /* file name                                */
    FILE    *f;                 /* file pointer (NULL if there is no disk)  */
    int     readOnly;           /* is the image read-only ? (non-zero: yes) */
    int     fileSize;           /* image file size in bytes                 */
    int     Cylinders;          /* number of cylinders                      */
    int     Heads;              /* number of heads                          */
    int     Sectors;            /* number of sectors per track              */
    int     totalSectors;       /* total number of sectors (fileSize / 512) */
    /* ---- internal state ---- */
    int     State;
    int     StatusRegister;
    int     TrackRegister;
    int     SectorRegister;
    int     CommandRegister;
    int     DataRegister;
    int     DataBytesRemaining;
    int     DataByteIndex;
    int     CurrentTrack;
    int     CurrentIDIndex;
    int     CurrentSide;
    uint8_t DataBuffer[1024];
} wd177x_drive_t;

/* reset the internal variables of all drives */

void WD177x_Reset(void);

/* initialize all disks                                 */
/* return value:                                        */
/*   -1: a fatal error has occured                      */
/*   -2: some of the disk images were not available     */
/*    0: all disk images have been opened successfully  */

int wd177x_initialize(void);

/* close all disks */

void wd177x_close(void);

/* ---- port I/O implementation ---- */

/* write to port 0x18 */
void    ExdosCardWrite(uint8_t Data);
/* read from port 0x18 */
uint8_t ExdosCardRead(void);
/* write to port 0x10 */
void    WD177x_WriteCommand(uint8_t Data);
/* set track register */
void    WD177x_WriteTrack(uint8_t Data);
/* set sector register */
void    WD177x_WriteSector(uint8_t Data);
/* write a byte of data */
void    WD177x_WriteData(uint8_t Data);
/* read status register */
uint8_t WD177x_ReadStatus(void);
/* read track register */
uint8_t WD177x_ReadTrack(void);
/* read sector register */
uint8_t WD177x_ReadSector(void);
/* read a byte of data */
uint8_t WD177x_ReadData(void);

#endif          /* EP128_WD177X_H */

