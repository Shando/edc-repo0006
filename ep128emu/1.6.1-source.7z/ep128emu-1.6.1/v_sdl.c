
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* v_sdl.c: SDL video driver */

#include <ep128.h>

#include <SDL/SDL.h>

static  SDL_Surface *screen = NULL;

static const double event_poll_rate = 100.0;  /* event poll frequency in Hz */
static  int         event_poll_cnt;     /* process_events() polls events */
                                        /* once per 'event_poll_cnt' calls */

static  uint8_t     **colormap = NULL;

static void colormap_init(void)
{
    int i, j, c_index, r, g, b;

    if (colormap || !screen) return;
    /* allocate space */
    colormap = (uint8_t**)
               malloc(sizeof(uint8_t*) * (int) screen->format->BytesPerPixel);
    for (i = 0; i < (int) screen->format->BytesPerPixel; i++)
      colormap[i] = (uint8_t*) malloc(sizeof(uint8_t) * 256);
    /* now calculate all colors */
    for (i = 0; i < 256; i++) {
      NICKColorToRGB(i, &r, &g, &b);
      /* convert according to visual */
      c_index = ((r >> (int) screen->format->Rloss)
                 << (int) screen->format->Rshift)
                | ((g >> (int) screen->format->Gloss)
                   << (int) screen->format->Gshift)
                | ((b >> (int) screen->format->Bloss)
                   << (int) screen->format->Bshift);
      /* store value */
      if (SDL_BYTEORDER == SDL_LIL_ENDIAN) {
        /* little-endian */
        j = 0;
        do {
          colormap[j][i] = (uint8_t) (c_index & 0xFF);
          c_index >>= 8;
        } while (++j < (int) screen->format->BytesPerPixel);
      }
      else {
        /* big-endian */
        j = (int) screen->format->BytesPerPixel;
        while (--j >= 0) {
          colormap[j][i] = (uint8_t) (c_index & 0xFF);
          c_index >>= 8;
        }
      }
    }
}

static void draw_pixels(uint8_t **dst, uint8_t *src, int npixels, int bpp)
{
    uint8_t *p = *dst;
    uint8_t *cp0, *cp1, *cp2, *cp3;

    if (display_half_size) {
      /* half resolution */
      npixels >>= 1;
      switch (bpp) {
      case 1:                     /* 8 bpp */
        cp0 = &(colormap[0][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
        } while (--npixels);
        break;
      case 2:                     /* 16 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c]; src++;
        } while (--npixels);
        break;
      case 3:                     /* 24 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        cp2 = &(colormap[2][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c]; src++;
          *p++ = cp2[c];
        } while (--npixels);
        break;
      case 4:                     /* 32 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        cp2 = &(colormap[2][0]);
        cp3 = &(colormap[3][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c];
          *p++ = cp2[c]; src++;
          *p++ = cp3[c];
        } while (--npixels);
        break;
      }
    }
    else {
      /* full resolution */
      switch (bpp) {
      case 1:                     /* 8 bpp */
        cp0 = &(colormap[0][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
        } while (--npixels);
        break;
      case 2:                     /* 16 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c];
        } while (--npixels);
        break;
      case 3:                     /* 24 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        cp2 = &(colormap[2][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c];
          *p++ = cp2[c];
        } while (--npixels);
        break;
      case 4:                     /* 32 bpp */
        cp0 = &(colormap[0][0]);
        cp1 = &(colormap[1][0]);
        cp2 = &(colormap[2][0]);
        cp3 = &(colormap[3][0]);
        do {
          int  c = (int) *src;
          *p++ = cp0[c]; src++;
          *p++ = cp1[c];
          *p++ = cp2[c];
          *p++ = cp3[c];
        } while (--npixels);
        break;
      }
    }
    *dst = p;
}

static void fill_pixels(uint8_t **dst, uint8_t color, int npixels, int bpp)
{
    uint8_t *p = *dst;
    uint8_t c0, c1, c2, c3;

    if (display_half_size) {
      /* half resolution */
      npixels >>= 1;
    }
    switch (bpp) {
    case 1:                   /* 8 bpp */
      c0 = colormap[0][(int) color];
      do {
        *p++ = c0;
      } while (--npixels);
      break;
    case 2:                   /* 16 bpp */
      c0 = colormap[0][(int) color];
      c1 = colormap[1][(int) color];
      do {
        *p++ = c0;
        *p++ = c1;
      } while (--npixels);
      break;
    case 3:                   /* 24 bpp */
      c0 = colormap[0][(int) color];
      c1 = colormap[1][(int) color];
      c2 = colormap[2][(int) color];
      do {
        *p++ = c0;
        *p++ = c1;
        *p++ = c2;
      } while (--npixels);
      break;
    case 4:                   /* 32 bpp */
      c0 = colormap[0][(int) color];
      c1 = colormap[1][(int) color];
      c2 = colormap[2][(int) color];
      c3 = colormap[3][(int) color];
      do {
        *p++ = c0;
        *p++ = c1;
        *p++ = c2;
        *p++ = c3;
      } while (--npixels);
      break;
    }
    *dst = p;
}

/* draw a line (line number should be in the range 0 to 623) */
/* 'data' is an array of 1024 8-bit integers */
/* borders are drawn with 'border_color', using margin positions */
/* 'lmarg' and 'rmarg' (specified in character units, 0 to 63) */

typedef struct linebuf_s {
    int         lmarg;
    int         rmarg;
    int         border_color;
    uint8_t     data[1024];
} linebuf_t;

static  int         lines_changed = 0;
static  linebuf_t   *prv_display = NULL;

static void draw_line_(int line_number, const uint8_t *data,
                       uint8_t border_color, int lmarg, int rmarg)
{
    uint8_t *p, *bufp = (uint8_t*) data;
    int     lmarg_npixels, disp_npixels, rmarg_npixels, odd_frame;

    /* check if line is visible */
    if (line_number < display_min_line || line_number >= display_max_line)
      return;

    odd_frame = line_number & 1;
    line_number -= display_min_line;
    if (!display_interlace)
      line_number &= (~1);      /* doublescan */
    if (display_half_size)
      line_number >>= 1;        /* half size */
    /* half refresh rate: only draw frames with even line numbers */
    if (display_half_refresh != 0 && odd_frame)
      goto do_blit;

    p = (uint8_t*) screen->pixels + (line_number * (int) screen->pitch);
    /* calculate the number of pixels to draw */
    lmarg_npixels = (lmarg << 4) - display_left_offset;
    disp_npixels = ((rmarg - lmarg) << 4);
    /* check for the case when only border is visible */
    if (lmarg_npixels >= display_window_width || lmarg >= rmarg ||
        ((rmarg << 4) - display_left_offset) <= 0) {
      /* border only */
      lmarg = 63;
      rmarg = 0;
      lmarg_npixels = display_window_width;
      disp_npixels = 0;
      rmarg_npixels = 0;
    }
    else if (lmarg_npixels <= 0) {
      /* left border is not visible */
      bufp -= (intptr_t) lmarg_npixels;
      disp_npixels += lmarg_npixels;
      lmarg_npixels = 0;
      lmarg = 0;
      if (disp_npixels >= display_window_width) {
        /* right border is not visible, either */
        disp_npixels = display_window_width;
        rmarg_npixels = 0;
        rmarg = 63;
        /* no visible border: assume it is black for more effective */
        /* blit_on_change_only optimization */
        border_color = (uint8_t) 0;
      }
      else {
        /* right border is visible */
        rmarg_npixels = display_window_width - disp_npixels;
      }
    }
    else {
      /* left border is visible */
      if ((lmarg_npixels + disp_npixels) >= display_window_width) {
        /* right border is not visible */
        disp_npixels = display_window_width - lmarg_npixels;
        rmarg_npixels = 0;
        rmarg = 63;
      }
      else {
        /* right border is visible */
        rmarg_npixels = display_window_width - (lmarg_npixels + disp_npixels);
      }
    }
    if (display_blit_on_change) {
      /* if update on change only was requested, */
      /* check if this line was changed: */
      if (lmarg == prv_display[line_number].lmarg &&
          rmarg == prv_display[line_number].rmarg &&
          (int) border_color == prv_display[line_number].border_color &&
          memcmp((void*) &(prv_display[line_number].data[0]), (void*) bufp,
                 (size_t) disp_npixels) == 0) {
        /* unchanged, do not need to redraw */
        goto do_blit;
      }
      else {
        /* line has been changed, update */
        lines_changed++;
        prv_display[line_number].lmarg = lmarg;
        prv_display[line_number].rmarg = rmarg;
        prv_display[line_number].border_color = (int) border_color;
        memcpy((void*) &(prv_display[line_number].data[0]), (void*) bufp,
               (size_t) disp_npixels);
      }
    }
    /* lock display */
    if (SDL_MUSTLOCK(screen)) {
      if (SDL_LockSurface(screen) < 0) {
        printMsg("Cannot lock screen: %s\n", SDL_GetError());
        return;
      }
    }
    /* draw left border */
    if (lmarg_npixels)
      fill_pixels(&p, border_color, lmarg_npixels,
                  (int) screen->format->BytesPerPixel);
    /* draw text/graphics area */
    if (disp_npixels)
      draw_pixels(&p, bufp, disp_npixels,
                  (int) screen->format->BytesPerPixel);
    /* draw right border */
    if (rmarg_npixels)
      fill_pixels(&p, border_color, rmarg_npixels,
                  (int) screen->format->BytesPerPixel);
    if (!(display_half_size | display_interlace)) {
      /* full size with doublescan */
      p = (uint8_t*) screen->pixels + ((line_number + 1) * (int) screen->pitch);
      /* draw left border */
      if (lmarg_npixels)
        fill_pixels(&p, border_color, lmarg_npixels,
                    (int) screen->format->BytesPerPixel);
      /* draw text/graphics area */
      if (disp_npixels)
        draw_pixels(&p, bufp, disp_npixels,
                    (int) screen->format->BytesPerPixel);
      /* draw right border */
      if (rmarg_npixels)
        fill_pixels(&p, border_color, rmarg_npixels,
                    (int) screen->format->BytesPerPixel);
    }
    /* unlock display */
    if (SDL_MUSTLOCK(screen)) {
      SDL_UnlockSurface(screen);
    }

do_blit:
    /* update screen depending on video mode */
    if (display_half_size)
      line_number <<= 1;
    else
      line_number &= (~1);
    if (display_hardware_mode) {
      /* hardware mode: do not need to blit as we draw directly to the */
      /* frame buffer */
      if (display_doublebuf && (line_number == (display_window_height - 2))) {
        /* double-buffered mode with vertical sync */
        SDL_Flip(screen);
      }
      return;
    }
    if (display_blit_on_change && !lines_changed) {
      /* only need to update on change, but no lines have been changed, */
      /* so there is nothing to do */
      return;
    }
    if ((line_number & 31) == 30) {
      lines_changed = 0;
      /* blit 32 lines at once for improved performance */
      if (!display_half_size)
        SDL_UpdateRect(screen,
                       0, (line_number & 0xFFE0),
                       display_window_width, 32);
      else
        /* or 16 lines with half resolution */
        SDL_UpdateRect(screen,
                       0, ((line_number & 0xFFE0) >> 1),
                       (display_window_width >> 1), 16);
    }
    else if (line_number == (display_window_height - 2)) {
      lines_changed = 0;
      /* special case: at bottom of window */
      if (!display_half_size)
        /* with full, */
        SDL_UpdateRect(screen,
                       0, (line_number & 0xFFE0), display_window_width,
                       (display_window_height - (line_number & 0xFFE0)));
      else
        /* and half resolution */
        SDL_UpdateRect(screen,
                       0, ((line_number & 0xFFE0) >> 1),
                       (display_window_width >> 1),
                       ((display_window_height - (line_number & 0xFFE0)) >> 1));
    }
}

/* initialize graphics system */

static int init_graphics_(int *argc, char ***argv)
{
    Uint32  sdl_flags;
    int     w, h;

    argc = argc;    /* unused parameters */
    argv = argv;

    /* calculate window parameters */

    display_window_width  &= (~3);
    display_window_height &= (~3);
    display_x_shift &= (~3);
    display_y_shift &= (~3);

    display_min_line = (624 - display_window_height) >> 1;
    display_max_line = 624 - display_min_line;
    display_sync_line = (590 + display_min_line) + display_y_shift;
    display_left_offset = ((992 - display_window_width) >> 1) - display_x_shift;
    if (display_sync_line < 0)          display_sync_line = 0;
    if (display_sync_line > 622)        display_sync_line = 622;
    if (display_left_offset < 0)        display_left_offset = 0;
    if (display_left_offset > 1024)     display_left_offset = 1024;

    w = display_window_width;
    h = display_window_height;
    if (display_half_size) {
      w >>= 1;
      h >>= 1;
    }

    /* reset key states */

    memset(&(key_matrix[0]), 0xFF, (size_t) 16);
    key_matrix_row_select = 0;

    /* initialize display */

    if (SDL_Init(SDL_INIT_VIDEO) < 0 ) {
      printMsg("ep128: couldn't initialize SDL: %s\n", SDL_GetError());
      return -1;
    }
    atexit(destroy_graphics);
    if (display_hardware_mode) {
      Uint32  mreqd, mgot;
      /* hardware mode */
      sdl_flags = (Uint32) SDL_ANYFORMAT;
      sdl_flags |= (Uint32) SDL_HWSURFACE;
      sdl_flags |= (Uint32) SDL_FULLSCREEN;
      if (display_doublebuf)
        sdl_flags |= (Uint32) SDL_DOUBLEBUF;
      /* check if mode is available */
      screen = SDL_SetVideoMode(w, h, 0, sdl_flags);
      mreqd = sdl_flags & (~((Uint32) SDL_ANYFORMAT));
      mgot = (Uint32) screen->flags & (~((Uint32) SDL_ANYFORMAT));
      if (!screen || (mreqd & mgot) != mreqd) {
        printMsg(" *** ep128: cannot use hardware mode\n");
        display_hardware_mode = 0;
        display_fullscreen = 0;
      }
    }
    if (!display_hardware_mode) {
      /* software mode */
      sdl_flags = (Uint32) SDL_ANYFORMAT;
      sdl_flags |= (Uint32) SDL_SWSURFACE;
      if (display_fullscreen)
        sdl_flags |= (Uint32) SDL_FULLSCREEN;
      screen = SDL_SetVideoMode(w, h, 0, sdl_flags);
    }
    if (!screen) {
      printMsg(" *** ep128: couldn't set video mode: %s\n", SDL_GetError());
      return -1;
    }
    if (screen->format->BytesPerPixel < 2) {
      printMsg(" *** ep128: 8-bit visuals are not supported\n");
      return -1;
    }
    colormap_init();
    /* check display optimization options */
    half_refresh_is_allowed = 0;
    /* half refresh rate implies blit_on_change_only and no interlace */
    if (display_half_refresh & 1) {
      display_blit_on_change = 1;
      display_interlace = 0;
    }
    else if (!(display_interlace || display_doublebuf)) {
      /* no interlacing or double buffered display is requested: */
      /* sound driver may set half refresh mode */
      half_refresh_is_allowed = 1;
    }
    /* this is not really useful in hardware mode */
    if (display_hardware_mode)
      display_blit_on_change = 0;
    /* if update on change only was requested, prepare buffer now */
    if (display_blit_on_change) {
      prv_display = (linebuf_t*) malloc(sizeof(linebuf_t) * (size_t) 624);
      if (prv_display == (linebuf_t*) NULL) {
        printMsg(" *** ep128: not enough memory\n");
        return -1;
      }
      /* force drawing the full display on the first time */
      memset((void*) prv_display, 0xFF, sizeof(linebuf_t) * (size_t) 624);
    }
    lines_changed = 0;
    /* no key repeat */
    SDL_EnableKeyRepeat(0, 0);
    /* turn off mouse cursor in fullscreen mode */
    if ((int) screen->flags & (int) SDL_FULLSCREEN)
      SDL_ShowCursor(SDL_DISABLE);
    /* calculate event poll timing */
    event_poll_cnt = (int) ((master_clock_freq / event_poll_rate) + 0.5);

    return 0;
}

/* de-initialize graphics (this function may not return) */

static void destroy_graphics_(void)
{
    /* restore key repeat */
    SDL_EnableKeyRepeat(500, 30);
    /* show mouse cursor */
    SDL_ShowCursor(SDL_ENABLE);
    /* free memory used by cache of most recently drawn lines */
    if (prv_display != (linebuf_t*) NULL) {
      free(prv_display);
      prv_display = NULL;
    }
    /* shut down SDL */
    SDL_Quit();
}

static const int event_table[][4] = {
/*      keysym        matrix   row     bit      */
    { SDLK_n,           0,      0,      0   },      /* ROW 0 */
    { SDLK_BACKSLASH,   0,      0,      1   },
    { SDLK_b,           0,      0,      2   },
    { SDLK_c,           0,      0,      3   },
    { SDLK_v,           0,      0,      4   },
    { SDLK_x,           0,      0,      5   },
    { SDLK_z,           0,      0,      6   },
    { SDLK_LSHIFT,      0,      0,      7   },
    { SDLK_h,           0,      1,      0   },      /* ROW 1 */
    { SDLK_CAPSLOCK,    0,      1,      1   },
    { SDLK_g,           0,      1,      2   },
    { SDLK_d,           0,      1,      3   },
    { SDLK_f,           0,      1,      4   },
    { SDLK_s,           0,      1,      5   },
    { SDLK_a,           0,      1,      6   },
    { SDLK_LCTRL,       0,      1,      7   },
    { SDLK_RCTRL,       0,      1,      7   },
    { SDLK_u,           0,      2,      0   },      /* ROW 2 */
    { SDLK_q,           0,      2,      1   },
    { SDLK_y,           0,      2,      2   },
    { SDLK_r,           0,      2,      3   },
    { SDLK_t,           0,      2,      4   },
    { SDLK_e,           0,      2,      5   },
    { SDLK_w,           0,      2,      6   },
    { SDLK_TAB,         0,      2,      7   },
    { SDLK_7,           0,      3,      0   },      /* ROW 3 */
    { SDLK_1,           0,      3,      1   },
    { SDLK_6,           0,      3,      2   },
    { SDLK_4,           0,      3,      3   },
    { SDLK_5,           0,      3,      4   },
    { SDLK_3,           0,      3,      5   },
    { SDLK_2,           0,      3,      6   },
    { SDLK_ESCAPE,      0,      3,      7   },
    { SDLK_F4,          0,      4,      0   },      /* ROW 4 */
    { SDLK_F8,          0,      4,      1   },
    { SDLK_F3,          0,      4,      2   },
    { SDLK_F6,          0,      4,      3   },
    { SDLK_F5,          0,      4,      4   },
    { SDLK_F7,          0,      4,      5   },
    { SDLK_F2,          0,      4,      6   },
    { SDLK_F1,          0,      4,      7   },
    { SDLK_8,           0,      5,      0   },      /* ROW 5 */
    { SDLK_9,           0,      5,      2   },
    { SDLK_MINUS,       0,      5,      3   },
    { SDLK_0,           0,      5,      4   },
    { SDLK_BACKQUOTE,   0,      5,      5   },
    { SDLK_BACKSPACE,   0,      5,      6   },
    { SDLK_j,           0,      6,      0   },      /* ROW 6 */
    { SDLK_k,           0,      6,      2   },
    { SDLK_SEMICOLON,   0,      6,      3   },
    { SDLK_l,           0,      6,      4   },
    { SDLK_QUOTE,       0,      6,      5   },
    { SDLK_RIGHTBRACKET,0,      6,      6   },
    { SDLK_PRINT,       0,      7,      0   },      /* ROW 7 */
    { SDLK_END,         0,      7,      0   },
    { SDLK_DOWN,        0,      7,      1   },
    { SDLK_RIGHT,       0,      7,      2   },
    { SDLK_UP,          0,      7,      3   },
    { SDLK_PAUSE,       0,      7,      4   },
    { SDLK_PAGEUP,      0,      7,      4   },
    { SDLK_LEFT,        0,      7,      5   },
    { SDLK_RETURN,      0,      7,      6   },
    { SDLK_LALT,        0,      7,      7   },
    { SDLK_RALT,        0,      7,      7   },
    { SDLK_m,           0,      8,      0   },      /* ROW 8 */
    { SDLK_DELETE,      0,      8,      1   },
    { SDLK_COMMA,       0,      8,      2   },
    { SDLK_SLASH,       0,      8,      3   },
    { SDLK_PERIOD,      0,      8,      4   },
    { SDLK_RSHIFT,      0,      8,      5   },
    { SDLK_SPACE,       0,      8,      6   },
    { SDLK_INSERT,      0,      8,      7   },
    { SDLK_i,           0,      9,      0   },      /* ROW 9 */
    { SDLK_o,           0,      9,      2   },
    { SDLK_EQUALS,      0,      9,      3   },
    { SDLK_p,           0,      9,      4   },
    { SDLK_LEFTBRACKET, 0,      9,      5   },

#if 0
    { SDLK_F9,          2,      4,      -1  },
    { SDLK_F10,         2,      5,      -1  },
    { SDLK_F11,         2,      6,      -1  },
    { SDLK_F12,         2,      7,      -1  },
    { SDLK_KP8,         1,      2,      0   },      /* joy 1 */
    { SDLK_KP2,         1,      2,      1   },
    { SDLK_KP4,         1,      2,      2   },
    { SDLK_KP6,         1,      2,      3   },
    { SDLK_KP0,         1,      2,      6   },
    { SDLK_KP_ENTER,    1,      2,      6   },
    { SDLK_KP8,         1,      1,      0   },      /* joy 2 */
    { SDLK_KP2,         1,      1,      1   },
    { SDLK_KP4,         1,      1,      2   },
    { SDLK_KP6,         1,      1,      3   },
    { SDLK_KP0,         1,      1,      7   },
    { SDLK_KP_ENTER,    1,      1,      7   },
#endif
    { -1,               -1,     -1,     -1  }
};

/* read keyboard events and update matrix values */
/* returns non-zero if the event is "close window" */

static  int     event_poll_clk = 1;

static int process_events_(void)
{
    SDL_Event   event;
    int         i, is_pressed;
    int         keysym;

    /* check events 100 times per second */
    if (--event_poll_clk)
      return 0;
    event_poll_clk = event_poll_cnt;

    /* read and process all queued events */
 next_event:

    while (SDL_PollEvent(&event)) {
      switch ((int) event.type) {
      case SDL_QUIT:
        return -1;                      /* close window */
      case SDL_KEYDOWN:
      case SDL_KEYUP:                   /* key press or release */
        is_pressed = (event.type == SDL_KEYDOWN ? 1 : 0);
        /* key number */
        keysym = (int) (event.key.keysym.sym);
        /* check for basic tape control keys (F9, F10, F11), */
        /* and keyboard mode toggle (F12) */
        if (is_pressed) {
          switch (keysym) {
          case SDLK_F9:
            handle_special_key(19);     /* <F9>:  PLAY ON */
            goto next_event;
          case SDLK_F10:
            handle_special_key(20);     /* <F10>: PLAY/RECORD OFF */
            goto next_event;
          case SDLK_F11:
            handle_special_key(21);     /* <F11>: RECORD ON */
            goto next_event;
          case SDLK_KP_MINUS:
            handle_special_key(81);     /* <KEYPAD ->: DECREASE CPU FREQ */
            goto next_event;
          case SDLK_KP_PLUS:
            handle_special_key(82);     /* <KEYPAD +>: INCREASE CPU FREQ */
            goto next_event;
          case SDLK_KP_ENTER:
          case SDLK_KP_MULTIPLY:
            handle_special_key(80);     /* <KEYPAD ENTER>: RESET CPU FREQ */
            goto next_event;
          case SDLK_KP0:
            handle_special_key(83);     /* <KEYPAD INS>: PRINT KEYBOARD USAGE */
            goto next_event;
          case SDLK_KP_PERIOD:          /* <KEYPAD DEL>: SET ALT CPU FREQ */
            handle_special_key(84);
            goto next_event;
          case SDLK_F12:
            emulator_ui_mode = (emulator_ui_mode ? 0 : 1);
            if (emulator_ui_mode)
              printMsg("Keyboard Mode: program control\n");
            else
              printMsg("Keyboard Mode: emulation\n");
            goto next_event;
          }
        }
        /* in program control mode, keyboard is handled differently */
        if (is_pressed && emulator_ui_mode) {
          switch (keysym) {
            case SDLK_0:  handle_special_key(0);  goto next_event;
            case SDLK_1:  handle_special_key(1);  goto next_event;
            case SDLK_2:  handle_special_key(2);  goto next_event;
            case SDLK_3:  handle_special_key(3);  goto next_event;
            case SDLK_4:  handle_special_key(4);  goto next_event;
            case SDLK_5:  handle_special_key(5);  goto next_event;
            case SDLK_6:  handle_special_key(6);  goto next_event;
            case SDLK_7:  handle_special_key(7);  goto next_event;
            case SDLK_8:  handle_special_key(8);  goto next_event;
            case SDLK_9:  handle_special_key(9);  goto next_event;
            case SDLK_a:  handle_special_key(40); goto next_event;
            case SDLK_b:  handle_special_key(41); goto next_event;
            case SDLK_c:  handle_special_key(42); goto next_event;
            case SDLK_d:  handle_special_key(43); goto next_event;
            case SDLK_e:  handle_special_key(44); goto next_event;
            case SDLK_f:  handle_special_key(45); goto next_event;
            case SDLK_g:  handle_special_key(46); goto next_event;
            case SDLK_h:  handle_special_key(47); goto next_event;
            case SDLK_i:  handle_special_key(48); goto next_event;
            case SDLK_j:  handle_special_key(49); goto next_event;
            case SDLK_k:  handle_special_key(50); goto next_event;
            case SDLK_l:  handle_special_key(51); goto next_event;
            case SDLK_m:  handle_special_key(52); goto next_event;
            case SDLK_n:  handle_special_key(53); goto next_event;
            case SDLK_o:  handle_special_key(54); goto next_event;
            case SDLK_p:  handle_special_key(55); goto next_event;
            case SDLK_q:  handle_special_key(56); goto next_event;
            case SDLK_r:  handle_special_key(57); goto next_event;
            case SDLK_s:  handle_special_key(58); goto next_event;
            case SDLK_t:  handle_special_key(59); goto next_event;
            case SDLK_u:  handle_special_key(60); goto next_event;
            case SDLK_v:  handle_special_key(61); goto next_event;
            case SDLK_w:  handle_special_key(62); goto next_event;
            case SDLK_x:  handle_special_key(63); goto next_event;
            case SDLK_y:  handle_special_key(64); goto next_event;
            case SDLK_z:  handle_special_key(65); goto next_event;
            case SDLK_F1: handle_special_key(11); goto next_event;
            case SDLK_F2: handle_special_key(12); goto next_event;
            case SDLK_F3: handle_special_key(13); goto next_event;
            case SDLK_F4: handle_special_key(14); goto next_event;
            case SDLK_F5: handle_special_key(15); goto next_event;
            case SDLK_F6: handle_special_key(16); goto next_event;
            case SDLK_F7: handle_special_key(17); goto next_event;
            case SDLK_F8: handle_special_key(18); goto next_event;
            case SDLK_ESCAPE:   handle_special_key(10); goto next_event;
            case SDLK_PAUSE:
            case SDLK_PAGEUP:   return -1;
            default:      goto next_event;
          }
        }
        /* normal Enterprise keyboard emulation */
        i = 0;
        while (event_table[i][1] >= 0) {
          if ((int) event_table[i][0] == keysym) {
            int matrixnum = event_table[i][1];
            int rownum = event_table[i][2];
            int bitnum = event_table[i][3];
            uint8_t *matrixptr;
            if (bitnum < 0)
              bitnum = 0xFF;
            else
              bitnum = (1 << bitnum);
            switch (matrixnum) {
            case 0:
              matrixptr = &(key_matrix[0]);     /* normal keys */
              break;
#if 0
            case 1:
              matrixptr = &(joy_matrix[0]);     /* TODO: joystick emulation */
              break;
#endif
            default:                            /* unknown key type */
              goto next_event;
            }
            if (is_pressed) {
              bitnum ^= 0xFF;
              matrixptr[rownum] &= (uint8_t) bitnum;
            }
            else
              matrixptr[rownum] |= (uint8_t) bitnum;
          }
          i++;
        }
      }
    }

    return 0;
}

/* module interface */

VideoModule_t SDLVideoDriver = {
    "sdl",
    init_graphics_,
    draw_line_,
    process_events_,
    destroy_graphics_
};

