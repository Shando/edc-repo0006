
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* v_dummy.c: dummy video driver */

#include <ep128.h>

/* initialize graphics system */

static int init_graphics_(int *argc, char ***argv)
{
    /* avoid compiler warnings */
    argc = argc;
    argv = argv;
    /* reset key states */
    memset(&(key_matrix[0]), 0xFF, (size_t) 16);
    key_matrix_row_select = 0;

    return 0;
}

/* draw a line (line number should be in the range 0 to 623) */
/* 'data' is an array of 1024 8-bit integers */
/* borders are drawn with 'border_color', using margin positions */
/* 'lmarg' and 'rmarg' (specified in character units, 0 to 63) */

static void draw_line_(int line_number, const uint8_t *data,
                       uint8_t border_color, int lmarg, int rmarg)
{
    /* avoid compiler warnings */
    line_number = line_number;
/*  data = data;    */
    border_color = border_color;
    lmarg = lmarg;
    rmarg = rmarg;
}

/* de-initialize graphics (this function may not return) */

static void destroy_graphics_(void)
{
    /* nothing to do */
}

/* read keyboard events and update matrix values */
/* returns non-zero if the event is "close window" */

static int process_events_(void)
{
    /* nothing to do */
    return 0;
}

/* module interface */

VideoModule_t DummyVideoDriver = {
    "null",
    init_graphics_,
    draw_line_,
    process_events_,
    destroy_graphics_
};

