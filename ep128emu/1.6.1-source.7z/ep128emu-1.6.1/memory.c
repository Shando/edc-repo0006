
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* memory.c: memory and I/O port emulation */

#include <ep128.h>

/* segments at pages 0, 1, 2, and 3 (I/O registers B0 - B3) */

int     page_segment[4] = { 0, 0, 0, 0 };

/* start addresses of memory pages, minus 0x4000 * (page number[0 - 3]) */
/* this table is used for faster memory access */
uint8_t     *page_address_table[4] = { NULL, NULL, NULL, NULL };

/* the actual start addresses of memory segments */
uint8_t     *page_address_real[4] = { NULL, NULL, NULL, NULL };

/* 0: page is RAM, 1: page is ROM */
int         is_page_rom[4] = { 1, 1, 1, 1 };

/* segment address table */
uint8_t     *segment_address_table[256];

/* 0: segment is RAM, 1: segment is ROM */
int         is_segment_rom[256];

/* video memory (actually, segments 0xFC to 0xFF as a single 64K area) */
uint8_t     video_memory[65536];

/* stores data written to I/O registers */
static  uint8_t io_shadow_memory[256];

/* list of ROM file names for segments 0 to 7 */

char    *rom_file_0 = "exos0.rom";
char    *rom_file_1 = "exos1.rom";
char    *rom_file_2 = NULL;
char    *rom_file_3 = NULL;
char    *rom_file_4 = NULL;
char    *rom_file_5 = NULL;
char    *rom_file_6 = NULL;
char    *rom_file_7 = NULL;

static  uint8_t dummy_seg[16384];
static  int     is_memory_initialized = 0;

/* some I/O registers appear at multiple ports */
/* this table maps them to the standard location */

static const uint8_t io_map_table[256] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x10, 0x11, 0x12, 0x13,     /* disk controller */
    0x18, 0x19, 0x1A, 0x1B, 0x18, 0x19, 0x1A, 0x1B,     /* (0x10 - 0x1F) */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
    0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
    0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
    0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
    0x80, 0x81, 0x82, 0x83, 0x80, 0x81, 0x82, 0x83,     /* NICK registers */
    0x80, 0x81, 0x82, 0x83, 0x80, 0x81, 0x82, 0x83,     /* (0x80 - 0x8F) */
    0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
    0x98, 0x99, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E, 0x9F,
    0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7,     /* DAVE registers */
    0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,     /* (0xA0 - 0xBF) */
    0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
    0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF,
    0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
    0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF,
    0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
    0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
    0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
    0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED, 0xEE, 0xEF,
    0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
    0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF
};

/* write a byte to memory */

void mem_write_8(uint16_t addr, uint8_t value)
{
    if (is_page_rom[(int) addr >> 14])
      return;                   /* cannot write ROM */
    *((uint8_t*) (page_address_table[(int) addr >> 14]) + (int) addr) = value;
}

/* read a byte from memory */

uint8_t mem_read_8(uint16_t addr)
{
    return *((uint8_t*) (page_address_table[(int) addr >> 14]) + (int) addr);
}

/* write a byte to I/O memory */

void io_write_8(uint16_t addr, uint8_t value)
{
    int i;

    /* map address */
    addr = (uint16_t) io_map_table[(int) addr & 0xFF];
    /* save data in shadow memory */
    io_shadow_memory[(int) addr] = value;

    switch ((int) addr) {
    case 0x10:                          /* 0x10 - 0x1F: disk controller */
      WD177x_WriteCommand(value);
      break;
    case 0x11:
      WD177x_WriteTrack(value);
      break;
    case 0x12:
      WD177x_WriteSector(value);
      break;
    case 0x13:
      WD177x_WriteData(value);
      break;
    case 0x18:
      ExdosCardWrite(value);
      break;
    case 0x80:                          /* video registers (write only) */
    case 0x81:
    case 0x82:
    case 0x83:
      nick_register_write(addr, value);
      break;
    case 0xB0:                          /* memory paging */
    case 0xB1:
    case 0xB2:
    case 0xB3:
      i = (int) addr - 0xB0;    /* page number */
      page_segment[i] = (int) value;
      page_address_table[i] = (uint8_t*) (segment_address_table[(int) value])
                              - (int) (i << 14);
      page_address_real[i] = (uint8_t*) (segment_address_table[(int) value]);
      is_page_rom[i] = is_segment_rom[(int) value];
      break;
    case 0xB5:                          /* key matrix row select */
      key_matrix_row_select = (int) value & 0x0F;
      if ((int) value & 0x20)           /* tape control */
        tape_feedback = (tape_feedback_enable ? ((tape_feedback & 1) ^ 1) : 0);
      if ((int) value & 0xC0)
        tape_motor_on();
      else
        tape_motor_off();
      break;
    case 0xA0:                          /* DAVE registers */
    case 0xA1:
    case 0xA2:
    case 0xA3:
    case 0xA4:
    case 0xA5:
    case 0xA6:
    case 0xA7:
    case 0xA8:
    case 0xA9:
    case 0xAA:
    case 0xAB:
    case 0xAC:
    case 0xAD:
    case 0xAE:
    case 0xAF:
    case 0xB4:
    case 0xB6:
    case 0xB7:
    case 0xB8:
    case 0xB9:
    case 0xBA:
    case 0xBB:
    case 0xBC:
    case 0xBD:
    case 0xBE:
    case 0xBF:
      dave_register_write(addr, value);
      break;
    }
}

/* read a byte from I/O memory */

uint8_t io_read_8(uint16_t addr)
{
    int i;

    /* map address */
    addr = (uint16_t) io_map_table[(int) addr & 0xFF];

    switch ((int) addr) {
    case 0x10:                          /* 0x10 - 0x1F: disk controller */
      return (uint8_t) WD177x_ReadStatus();
      break;
    case 0x11:
      return (uint8_t) WD177x_ReadTrack();
      break;
    case 0x12:
      return (uint8_t) WD177x_ReadSector();
      break;
    case 0x13:
      return (uint8_t) WD177x_ReadData();
      break;
    case 0x18:
      return (uint8_t) ExdosCardRead();
      break;
    case 0x19:
    case 0x1A:
    case 0x1B:
      return (uint8_t) 0;
      break;
    case 0xB0:                          /* memory paging */
    case 0xB1:
    case 0xB2:
    case 0xB3:
      i = (int) addr - 0xB0;    /* page number */
      return (uint8_t) (page_segment[i]);
      break;
    case 0xB5:                          /* key matrix read */
      return (uint8_t) (key_matrix[key_matrix_row_select & 0x0F]);
      break;
    case 0xB6:                          /* tape read */
      return (uint8_t) (tape_output ? 0xFF : 0x3F);
      break;
    case 0xA0:                          /* DAVE registers */
    case 0xA1:
    case 0xA2:
    case 0xA3:
    case 0xA4:
    case 0xA5:
    case 0xA6:
    case 0xA7:
    case 0xA8:
    case 0xA9:
    case 0xAA:
    case 0xAB:
    case 0xAC:
    case 0xAD:
    case 0xAE:
    case 0xAF:
    case 0xB4:
    case 0xB7:
    case 0xB8:
    case 0xB9:
    case 0xBA:
    case 0xBB:
    case 0xBC:
    case 0xBD:
    case 0xBE:
    case 0xBF:
      return (uint8_t) dave_register_read(addr);
      break;
    }
    /* no readable register at this address */
    return (uint8_t) 0xFF;
}

/* load ROM to segment 'segment' from file 'fname' */
/* returns zero on success */

int alloc_rom_segment(int segment, const char *fname)
{
    FILE    *f;

    if (segment_address_table[segment] != (uint8_t*) (&dummy_seg[0])) {
      printMsg("ep128: alloc_rom_segment(): segment %02X is already in use\n",
               segment);
      return -1;
    }
    /* open file */
    f = fopen(fname, "rb");
    if (f == NULL) {
      printMsg("ep128: cannot open ROM file '%s'\n", fname);
      return -1;
    }
    /* allocate segment and load file */
    segment_address_table[segment] =
      (uint8_t*) calloc((size_t) 16384, (size_t) 1);
    if (segment_address_table[segment] == NULL) {
      printMsg("ep128: not enough memory\n");
      return -1;
    }
    is_segment_rom[segment] = 1;
    fread((void*) (segment_address_table[segment]), (size_t) 1,
          (size_t) 16384, f);
    fclose(f);
    /* report success */
    return 0;
}

/* initialize memory subsystem with the specified number of RAM segments */
/* (this includes video memory, so a value of 8 means a total of 128K RAM) */
/* returns zero on success */

int initialize_memory(int nr_ram_segments)
{
    int i;

    if (is_memory_initialized)
      return 0;
    memset(&(io_shadow_memory[0]), 0x00, 256);
    /* clear dummy segment */
    memset(&(dummy_seg[0]), 0xFF, 16384);
    /* clear video memory */
    memset(&(video_memory[0]), 0x00, 65536);
    /* by default, all segments are dummy */
    for (i = 0; i < 256; i++) {
      segment_address_table[i] = (uint8_t*) (&dummy_seg[0]);
      is_segment_rom[i] = 1;    /* cannot write dummy segment */
    }
    /* now add video memory (mapped to segments 0xFC to 0xFF), */
    i = 255;
    segment_address_table[i] = (uint8_t*) (&video_memory[0xC000]);
    is_segment_rom[i] = 0; i--;
    segment_address_table[i] = (uint8_t*) (&video_memory[0x8000]);
    is_segment_rom[i] = 0; i--;
    segment_address_table[i] = (uint8_t*) (&video_memory[0x4000]);
    is_segment_rom[i] = 0; i--;
    segment_address_table[i] = (uint8_t*) (&video_memory[0x0000]);
    is_segment_rom[i] = 0; i--;
    nr_ram_segments -= 4;
    /* and the requested amount of RAM extension */
    while (--nr_ram_segments >= 0) {
      segment_address_table[i] = (uint8_t*) calloc((size_t) 16384, (size_t) 1);
      if (segment_address_table[i] == NULL) {
        printMsg("ep128: not enough memory\n");
        return -1;
      }
      is_segment_rom[i] = 0; i--;
    }
    /* load ROM modules */
    if (rom_file_0 != NULL && rom_file_0[0] != '\0' &&
        alloc_rom_segment(0x00, rom_file_0))
      return -1;
    if (rom_file_1 != NULL && rom_file_1[0] != '\0' &&
        alloc_rom_segment(0x01, rom_file_1))
      return -1;
    if (rom_file_2 != NULL && rom_file_2[0] != '\0' &&
        alloc_rom_segment(0x02, rom_file_2))
      return -1;
    if (rom_file_3 != NULL && rom_file_3[0] != '\0' &&
        alloc_rom_segment(0x03, rom_file_3))
      return -1;
    if (rom_file_4 != NULL && rom_file_4[0] != '\0' &&
        alloc_rom_segment(0x04, rom_file_4))
      return -1;
    if (rom_file_5 != NULL && rom_file_5[0] != '\0' &&
        alloc_rom_segment(0x05, rom_file_5))
      return -1;
    if (rom_file_6 != NULL && rom_file_6[0] != '\0' &&
        alloc_rom_segment(0x06, rom_file_6))
      return -1;
    if (rom_file_7 != NULL && rom_file_7[0] != '\0' &&
        alloc_rom_segment(0x07, rom_file_7))
      return -1;
    /* set up initial page table */
    io_write_8((uint16_t) 0x00B0, (uint8_t) 0x00);
    io_write_8((uint16_t) 0x00B1, (uint8_t) 0x00);
    io_write_8((uint16_t) 0x00B2, (uint8_t) 0x00);
    io_write_8((uint16_t) 0x00B3, (uint8_t) 0x00);
    /* successfully initialized */
    is_memory_initialized = 1;
    return 0;
}

/* free all memory and reset segment tables */

void destroy_memory(void)
{
    int i;

    /* ROM files are no longer loaded */
    rom_file_0 = NULL;
    rom_file_1 = NULL;
    rom_file_2 = NULL;
    rom_file_3 = NULL;
    rom_file_4 = NULL;
    rom_file_5 = NULL;
    rom_file_6 = NULL;
    rom_file_7 = NULL;
    /* free all allocated segments */
    for (i = 0; i < 252; i++) {
      if ((uint8_t*) segment_address_table[i] != (uint8_t*) &(dummy_seg[0])) {
        free((void*) segment_address_table[i]);
        /* now dummy */
        segment_address_table[i] = (uint8_t*) &(dummy_seg[0]);
        /* and ROM */
        is_segment_rom[i] = 1;
      }
    }
    /* clear video memory */
    memset(&(video_memory[0]), 0, (size_t) 0x10000);
    /* reset all pages */
    io_write_8((uint16_t) 0xB0, (uint8_t) 0x00);
    io_write_8((uint16_t) 0xB1, (uint8_t) 0x00);
    io_write_8((uint16_t) 0xB2, (uint8_t) 0x00);
    io_write_8((uint16_t) 0xB3, (uint8_t) 0x00);
    /* no longer initialized */
    is_memory_initialized = 0;
}

/* returns current memory configuration in the following format: */
/*   bits 15 to 8: number of RAM segments (4 to 248)             */
/*   bits  7 to 0: ROM segment bitmap (for example, if ROM       */
/*                 segment 4 is present, then bit 4 is 1)        */

int query_current_memory_config(void)
{
    int rom_bitmap = 0, nr_ram_segments = 0, i;

    for (i = 0; i < 8; i++) {
      if ((uint8_t*) segment_address_table[i] != (uint8_t*) &(dummy_seg[0]))
        rom_bitmap |= 0x0100;
      rom_bitmap >>= 1;
    }
    for (i = 8; i < 256; i++) {
      if ((uint8_t*) segment_address_table[i] != (uint8_t*) &(dummy_seg[0]))
        nr_ram_segments++;
    }
    return ((nr_ram_segments << 8) | rom_bitmap);
}

/* return the size of memory snapshot data (in bytes) for snapshot file */
/* version 'file_version', with memory configuration 'memory_config' */

int memory_snapshot_bytes(int file_version, int memory_config)
{
    int nbytes = 256, i;

    switch (file_version) {
    case 0x0101:
    case 0x0102:
      nbytes += ((memory_config & 0xFF00) << 6);
      for (i = 0; i < 8; i++) {
        if (memory_config & 1)
          nbytes += 0x4000;
        memory_config >>= 1;
      }
      return nbytes;
    default:
      return -1;
    }
}

/* save memory data and I/O registers to file 'f' */
/* returns zero in case of success */

int save_memory_snapshot(FILE *f)
{
    int i;

    /* save all RAM segments, */
    for (i = 8; i < 256; i++) {
      if ((uint8_t*) segment_address_table[i] != (uint8_t*) &(dummy_seg[0]))
        fwrite((void*) segment_address_table[i], (size_t) 1, (size_t) 16384, f);
    }
    /* ROM segments, */
    for (i = 0; i < 8; i++) {
      if ((uint8_t*) segment_address_table[i] != (uint8_t*) &(dummy_seg[0]))
        fwrite((void*) segment_address_table[i], (size_t) 1, (size_t) 16384, f);
    }
    /* and I/O registers */
    for (i = 0; i < 256; i++) {
      fputc((int) io_shadow_memory[(int) io_map_table[i]], f);
    }

    return 0;           /* TODO: error handling */
}

/* load memory data and I/O registers from file 'f', using file format */
/* specified by 'file_version' and memory configuration 'memory_config'. */
/* Returns zero in case of success. */

int load_memory_snapshot(FILE *f, int file_version, int memory_config)
{
    int i;

    /* check file version */
    if (file_version != 0x0101 && file_version != 0x0102)
      return -1;
    /* may need to reallocate memory */
    if (memory_config != query_current_memory_config()) {
      destroy_memory();
      if (initialize_memory((memory_config & 0xFF00) >> 8))
        return -1;
      /* allocate new ROM segments */
      for (i = 0; i < 8; i++) {
        if (memory_config & 1) {
          segment_address_table[i] = (uint8_t*) malloc((size_t) 16384);
          if (segment_address_table[i] == (uint8_t*) NULL) {
            printMsg(" *** ep128: not enough memory\n");
            return -1;
          }
          is_segment_rom[i] = 1;
        }
        memory_config >>= 1;
      }
    }
    memory_config = query_current_memory_config();
    /* load RAM segments, */
    for (i = (256 - ((memory_config & 0xFF00) >> 8)); i < 256; i++)
      fread((void*) segment_address_table[i], (size_t) 1, (size_t) 16384, f);
    /* ROM segments, */
    for (i = 0; i < 8; i++) {
      if (memory_config & 1) {
        fread((void*) segment_address_table[i], (size_t) 1, (size_t) 16384, f);
      }
      memory_config >>= 1;
    }
    /* and I/O registers */
    fread((void*) &(io_shadow_memory[0]), (size_t) 1, (size_t) 256, f);
    for (i = 0x00; i < 0x10; i++) {
      io_write_8((uint16_t) i, io_shadow_memory[(int) io_map_table[i]]);
    }
    /* skip WD177x registers as loading these from a snapshot */
    /* seems to cause problems */
    for (i = 0x18; i < 0x100; i++) {
      io_write_8((uint16_t) i, io_shadow_memory[(int) io_map_table[i]]);
    }

    return 0;           /* TODO: error handling */
}

