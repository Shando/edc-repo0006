
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* console.c -- message printing to stderr, log file, and OpenGL display */

#include <ep128.h>
#include <stdarg.h>

#ifdef HAVE_OPENGL

#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>

/* load PC VGA font (256 8x16 characters) */
#include "fontdata.h"

typedef struct FontTexture_s {
     /* the font data is stored in a 256x256 16-bit (4/4/4/4) RGBA texture, */
     /* starting from ASCII code 0x20 (space), with 12x20 pixels for one */
     /* character; in one row, there are 21 characters */
     uint16_t   txtdata[65536];
     /* texture coordinate look-up table, indexed by the ASCII code of the */
     /* character, and coordinate number (0: upper left X, 1: upper left Y, */
     /* 2: lower left X, 3: lower left Y, 4: lower right X, 5: lower right Y, */
     /* 6: upper right X, 7: upper right Y) */
     GLfloat    coord[256][8];
} FontTexture_t;

/* texture ID allocated for font texture */
static  GLuint          font_texture_id = (GLuint) 0;
/* structure holding font data in format described above */
static  FontTexture_t   font_texture;

/* width of console in characters */
static  int     console_width;
/* console height in characters */
/* (note: there are two extra lines for scrolling) */
static  int     console_height;

/* console line number of upper line */
static  int     frame_start_ypos = 0;
/* cursor X coordinate */
static  int     console_xpos = 0;
/* cursor Y coordinate */
static  int     console_ypos = 0;
/* max. console size is 128x64 characters */
static  uint8_t console_buf[8192];

/* non-zero: the console has been initialized */
static  int     GLconsole_is_initialized = 0;
/* non-zero: console cannot print more characters at this time (e.g. because */
/* of scrolling or not being initialized), need to store in message buffer */
static  int     GLconsole_is_busy = 1;
/* scroll down by this number of pixels (0 to 15); used for smooth scrolling */
static  int     scroll_lines = 0;

#endif  /* HAVE_OPENGL */

/* enable printing of messages to stderr (0: no) */
/* this is always 1 by default, so that start-up and */
/* error messages can be printed */
int     console_to_stderr = 1;
/* non-zero if messages should be written to a file */
static  int     console_to_file = 0;
/* console log file name and pointer */
char    *logfile_name = NULL;
static  FILE    *console_logfile = NULL;
/* non-zero if the message printing system is initialized */
static  int     printmsg_is_initialized = 0;

/* is the OpenGL console enabled (0: no) ? */
/* turning this on requires a double buffered */
/* display and disabling 'blit_on_change_only' */
int     GLconsole_is_enabled = 0;

double  console_bg_R = 0.0;             /* console background color     */
double  console_bg_G = 0.0;             /*   (red, green, blue, and     */
double  console_bg_B = 0.0;             /*   alpha, in the range        */
double  console_bg_A = 0.7;             /*   0.0 to 1.0)                */

double  console_fg_R = 0.0;             /* console foreground (text)    */
double  console_fg_G = 1.0;             /*   color (red, green, blue,   */
double  console_fg_B = 0.0;             /*   and alpha, in the range    */
double  console_fg_A = 1.0;             /*   0.0 to 1.0)                */

#define MSG_LEN 65536                   /* max. number of characters in */
                                        /*   message buffer             */

static  char    linebuf[MSG_LEN];       /* message buffer               */
static  int     linebuf_pos = 0;        /* buffer write position        */
static  int     read_pos = 0;           /* buffer read position         */

#ifdef HAVE_OPENGL

/* put one character to OpenGL console; the 'GLconsole_is_busy' variable */
/* should be checked before calling this function */

static void GLconsole_write_character(const char c)
{
    int i;

    if (GLconsole_is_busy)
      return;
    if (c == '\r') {
      /* CR */
      console_xpos = 0;
    }
    else if (c == '\n') {
      /* new line */
      console_xpos = 0;
      console_ypos = (console_ypos + 1) % console_height;
      frame_start_ypos = (console_ypos + 1) % console_height;
      for (i = 0; i < 128; i++)
        console_buf[(console_ypos << 7) + i] = (uint8_t) ' ';
      /* scroll if console is visible */
      if (emulator_ui_mode != 0) {
        GLconsole_is_busy = 1;
        scroll_lines = 16;
      }
      else {
        GLconsole_is_busy = 0;
        scroll_lines = 0;
      }
    }
    else if (c == '\b') {
      /* backspace */
      if (console_xpos > 0)
        console_xpos--;
    }
    else if (c == '\t') {
      /* tabulator */
      do {
        GLconsole_write_character((char) ' ');
      } while (!GLconsole_is_busy && (console_xpos & 7) != 0);
    }
    else {
      /* any other character is assumed to be printable */
      console_buf[(console_ypos << 7) + console_xpos] = (uint8_t) c;
      if (++console_xpos >= console_width) {
        /* line is full, start new line */
        console_xpos = 0;
        GLconsole_write_character((char) '\n');
      }
    }
}

/* load and bind font texture; returns the texture ID of the previously */
/* bound texture so that it can be restored later */

static GLuint GLconsole_load_texture(void)
{
    GLuint      prv_txt = (GLuint) 0;
    GLboolean   is_resident = GL_FALSE;

    /* save previous texture */
    glGetIntegerv(GL_TEXTURE_BINDING_2D, (GLint*) &prv_txt);
    /* on first call, allocate new texture */
    if (font_texture_id == (GLuint) 0) {
      glGenTextures((GLsizei) 1, &font_texture_id);
      glBindTexture(GL_TEXTURE_2D, font_texture_id);
      /* anti-aliased fonts */
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA,
                   GL_UNSIGNED_SHORT_4_4_4_4,
                   (GLvoid*) &(font_texture.txtdata[0]));
    }
    else {
      glBindTexture(GL_TEXTURE_2D, font_texture_id);
      /* check if texture is resident */
      glAreTexturesResident((GLsizei) 1, &font_texture_id, &is_resident);
      if (is_resident != GL_TRUE) {
        /* no, need to load */
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA,
                     GL_UNSIGNED_SHORT_4_4_4_4,
                     (GLvoid*) &(font_texture.txtdata[0]));
      }
    }
    /* return saved original texture, so that it can be restored later */
    return prv_txt;
}

/* initialize the OpenGL based console renderer */
/* returns zero on success */

int GLconsole_initialize(void)
{
    double      fx, fy, fw, fh;
    uint8_t     *fp;
    uint16_t    *tp;
    int         i, j, x, y;
    GLuint      prv_txt;
    uint16_t    bg, fg;

    /* clear console */
    memset(&(console_buf[0]), 0x20, (size_t) 8192);
    /* window dimensions */
    console_width = (int) display_window_width / 9;
    console_height = ((int) display_window_height / 16) + 2;
    /* calculate colors */
    bg = (uint16_t)
         (((int) (console_bg_R * 15.0 + 0.5) << 12)
          | ((int) (console_bg_G * 15.0 + 0.5) << 8)
          | ((int) (console_bg_B * 15.0 + 0.5) << 4)
          | (int) (console_bg_A * 15.0 + 0.5));
    fg = (uint16_t)
         (((int) (console_fg_R * 15.0 + 0.5) << 12)
          | ((int) (console_fg_G * 15.0 + 0.5) << 8)
          | ((int) (console_fg_B * 15.0 + 0.5) << 4)
          | (int) (console_fg_A * 15.0 + 0.5));
    /* create font texture (256x256) */
    for (i = 0; i < 65536; i++)
      font_texture.txtdata[i] = bg;
    for (i = 32; i < 256; i++) {
      fp = (uint8_t*) &(font_data[i << 4]);
      x = ((i - 32) % 21) * 12 + 2;
      y = ((i - 32) / 21) * 20 + 2;
      tp = &(font_texture.txtdata[(y << 8) + x]);
      /* calculate texture coordinates */
      fx = (double) x / 256.0;
      fy = (double) y / 256.0;
      fw = 9.0 / 256.0;
      fh = 16.0 / 256.0;
      /* upper left */
      font_texture.coord[i][0] = (GLfloat) fx;
      font_texture.coord[i][1] = (GLfloat) fy;
      /* lower left */
      font_texture.coord[i][2] = (GLfloat) fx;
      font_texture.coord[i][3] = (GLfloat) (fy + fh);
      /* lower right */
      font_texture.coord[i][4] = (GLfloat) (fx + fw);
      font_texture.coord[i][5] = (GLfloat) (fy + fh);
      /* upper right */
      font_texture.coord[i][6] = (GLfloat) (fx + fw);
      font_texture.coord[i][7] = (GLfloat) fy;
      /* convert font data */
      for (j = 0; j < 16; j++) {
        tp[(j << 8) + 0] = (uint16_t) ((int) fp[j] & 0x80 ? fg : bg);
        tp[(j << 8) + 1] = (uint16_t) ((int) fp[j] & 0x40 ? fg : bg);
        tp[(j << 8) + 2] = (uint16_t) ((int) fp[j] & 0x20 ? fg : bg);
        tp[(j << 8) + 3] = (uint16_t) ((int) fp[j] & 0x10 ? fg : bg);
        tp[(j << 8) + 4] = (uint16_t) ((int) fp[j] & 0x08 ? fg : bg);
        tp[(j << 8) + 5] = (uint16_t) ((int) fp[j] & 0x04 ? fg : bg);
        tp[(j << 8) + 6] = (uint16_t) ((int) fp[j] & 0x02 ? fg : bg);
        tp[(j << 8) + 7] = (uint16_t) ((int) fp[j] & 0x01 ? fg : bg);
      }
    }
    /* non-printable characters are rendered as spaces */
    x = 2;
    y = 2;
    fx = (double) x / 256.0;
    fy = (double) y / 256.0;
    fw = 9.0 / 256.0;
    fh = 16.0 / 256.0;
    for (i = 0; i < 32; i++) {
      /* upper left */
      font_texture.coord[i][0] = (GLfloat) fx;
      font_texture.coord[i][1] = (GLfloat) fy;
      /* lower left */
      font_texture.coord[i][2] = (GLfloat) fx;
      font_texture.coord[i][3] = (GLfloat) (fy + fh);
      /* lower right */
      font_texture.coord[i][4] = (GLfloat) (fx + fw);
      font_texture.coord[i][5] = (GLfloat) (fy + fh);
      /* upper right */
      font_texture.coord[i][6] = (GLfloat) (fx + fw);
      font_texture.coord[i][7] = (GLfloat) fy;
    }
    /* load texture */
    prv_txt = GLconsole_load_texture();
    glBindTexture(GL_TEXTURE_2D, prv_txt);

    /* now initialized */
    GLconsole_is_initialized = 1;
    return 0;   /* TODO: error handling */
}

/* render one frame of console display if UI mode is program control */
/* should be called after rendering normal emulator display */
/* for the console to work correctly, enable double buffering and */
/* disable 'blit_on_change_only' optimization */

void GLconsole_render_frame(void)
{
    double  x, y, w, h;
    int     cur_line, i, j, k;
    GLuint  prv_txt;

    /* initialize if not done so already */
    if (!GLconsole_is_initialized) {
      GLconsole_initialize();
    }

    /* print message to OpenGL console */
    while (!GLconsole_is_busy && read_pos < linebuf_pos) {
      GLconsole_write_character(linebuf[read_pos]);
      read_pos++;
    }
    if (read_pos >= linebuf_pos) {
      /* successfully printed all characters */
      linebuf_pos = 0;
      read_pos = 0;
    }
    else if (read_pos >= (MSG_LEN >> 2)) {
      /* move buffer contents to beginning of buffer */
      for (i = 0; i < (linebuf_pos - read_pos); i++) {
        linebuf[i] = linebuf[read_pos + i];
      }
      linebuf_pos -= read_pos;
      read_pos = 0;
    }

    /* there is nothing more to do if console is not visible */
    if (emulator_ui_mode == 0) {
      GLconsole_is_busy = 0;
      scroll_lines = 0;
      return;
    }

    /* load texture */
    prv_txt = GLconsole_load_texture();

    /* scroll */
    if (scroll_lines > 0) {
      i = linebuf_pos - read_pos;
      if (i < 128)      scroll_lines -= 2;
      else if (i < 256) scroll_lines -= 4;
      else if (i < 512) scroll_lines -= 8;
      else              scroll_lines -= 16;
    }
    if (scroll_lines <= 0) {
      /* finished scroll, ready to draw next line */
      GLconsole_is_busy = 0;
      scroll_lines = 0;
    }

    /* render console */
    cur_line = frame_start_ypos;
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    w = 2.0 * (9.0 / (double) display_window_width);
    h = 2.0 * (16.0 / (double) display_window_height);
    y = 1.0 + (h * (double) (16 - scroll_lines) / 16.0);
    for (i = 0; i < (console_height - 1); i++) {
      x = -1.0;
      glBegin(GL_QUADS);
      for (j = 0; j < console_width; j++) {
        k = (int) console_buf[(cur_line << 7) + j];
        glTexCoord2f(font_texture.coord[k][0], font_texture.coord[k][1]);
        glVertex2d(x, y);
        glTexCoord2f(font_texture.coord[k][2], font_texture.coord[k][3]);
        glVertex2d(x, y - h);
        glTexCoord2f(font_texture.coord[k][4], font_texture.coord[k][5]);
        glVertex2d(x + w, y - h);
        glTexCoord2f(font_texture.coord[k][6], font_texture.coord[k][7]);
        glVertex2d(x + w, y);
        x += w;
      }
      glEnd();
      y -= h;
      cur_line = (cur_line + 1) % console_height;
    }
    glDisable(GL_BLEND);
    /* fill any remaining lines at the bottom with blank */
    y = 1.0 - (h * (double) (console_height - 2));
    if (y > -1.0) {
      glColor4d(0.0, 0.0, 0.0, 1.0);
      glRectd(-1.0, y, 1.0, y - h);
    }
    /* restore original texture */
    glBindTexture(GL_TEXTURE_2D, prv_txt);
    /* make sure that the display is actually updated */
    glFlush();
}

/* de-initialize the OpenGL based console renderer */

void GLconsole_close(void)
{
    /* free allocated texture */
    if (font_texture_id != (GLuint) 0) {
      glDeleteTextures((GLsizei) 1, &font_texture_id);
      font_texture_id = (GLuint) 0;
    }
    /* reset state */
    frame_start_ypos = 0;
    console_xpos = 0;
    console_ypos = 0;
    /* no longer initialized */
    GLconsole_is_busy = 1;
    GLconsole_is_initialized = 0;
}

#endif  /* HAVE_OPENGL */

/* Print a message to stderr, log file, and OpenGL console, depending */
/* on configuration settings. The parameters and return value are the */
/* same as in the case of printf(). */

int printMsg(const char *fmt, ...)
{
    int     retval;
    va_list arglst;

    /* check if there is any space left in the buffer */
    if (linebuf_pos >= MSG_LEN)
      return 0;
    /* convert string */
    va_start(arglst, fmt);
    retval = vsnprintf(&(linebuf[linebuf_pos]),
                       (size_t) (MSG_LEN - linebuf_pos), fmt, arglst);
    va_end(arglst);
    /* if nothing was written, can return now */
    if (retval < 1)
      return retval;
    /* cannot write more characters than the free space in the buffer */
    if ((linebuf_pos + retval) > MSG_LEN)
      retval = (MSG_LEN - linebuf_pos);

    /* print message to stderr if requested */
    if (console_to_stderr) {
      fwrite(&(linebuf[linebuf_pos]), sizeof(char), (size_t) retval, stderr);
    }
    /* write message to log file if requested */
    if (console_to_file && console_logfile != NULL) {
      fwrite(&(linebuf[linebuf_pos]), sizeof(char), (size_t) retval,
             console_logfile);
    }
#ifdef HAVE_OPENGL
    if (GLconsole_is_enabled) {
      if (retval > 0)
        linebuf_pos += retval;
      return retval;
    }
#endif
    /* no OpenGL support, or console is disabled */
    if (printmsg_is_initialized) {
      linebuf_pos = 0;
    }
    else if (retval > 0) {
      /* log file has not been opened yet, save characters in buffer */
      linebuf_pos += retval;
    }
    read_pos = 0;

    return retval;
}

/* initialize message printing system */
/* return value is zero on success */

int msg_initialize(void)
{
    int retval = 0;

    /* open log file */
    console_to_file = 0;
    if (logfile_name != NULL &&
        logfile_name[0] != '\0' &&
        strcmp(logfile_name, "stderr") != 0) {
      console_logfile = fopen(logfile_name, "w");
      if (console_logfile == NULL) {
        printMsg(" *** ep128emu: error opening log file '%s': %s\n",
                 logfile_name, strerror(errno));
        retval = -1;
      }
      else {
        /* log file is line buffered */
        setvbuf(console_logfile, (char*) NULL, _IOLBF, (size_t) 0);
        console_to_file = 1;
        /* write any characters already in the buffer */
        if (linebuf_pos > 0) {
          fwrite(&(linebuf[0]), sizeof(char), (size_t) linebuf_pos,
                 console_logfile);
        }
      }
    }
    else {
      console_logfile = NULL;
    }
    /* initialization done */
    printmsg_is_initialized = 1;

    return retval;
}

/* de-initialize message printing system */

void msg_close(void)
{
    /* close log file */
    if (console_logfile != NULL) {
      fflush(console_logfile);
      fclose(console_logfile);
    }
    /* reset state */
    console_to_stderr = 1;
    console_to_file = 0;
    logfile_name = NULL;
    console_logfile = NULL;
    linebuf_pos = 0;
    read_pos = 0;
    /* no longer initialized */
    printmsg_is_initialized = 0;
}

