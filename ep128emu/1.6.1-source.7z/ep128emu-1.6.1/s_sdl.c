
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* s_sdl.c: SDL sound output */

#include <ep128.h>
#include <SDL/SDL.h>

#define MIN_BUFFER_SIZE 128
#define MAX_BUFFER_SIZE 16384
#define MIN_PERIOD_SIZE 16
#define MAX_PERIOD_SIZE 8192

static  int16_t         snd_buf[MAX_BUFFER_SIZE << 2];
static  int16_t         period_buf[MAX_PERIOD_SIZE << 1];
static volatile int     bufpos, read_pos, samples_ahead, buffer_state;
static  int             bufpos_mask, period_cnt;

/* the following variables are in 1/65536 ms units */
static  int64_t next_wait_time  = (int64_t) 0;
static  int     wait_timeslice  = 0;            /* period time */
static  int     min_timeslice   = 0;            /* period time * 0.94 */
static  int     max_timeslice   = 0;            /* period time * 1.06 */
/* buffer thresholds */
static  int     bufthreshold_1, bufthreshold_2, bufthreshold_3;
static  int     bufthreshold_4, bufthreshold_5;

static  int     device_is_open  = 0;

/* initialize sound card (returns zero on success) */

static void sound_callback(void *userdata, Uint8 *stream, int len);

static int soundcard_initialize_(void)
{
    SDL_AudioSpec       snd_spec;

    /* there is nothing to do if sound is disabled */
    if (disable_sound & 1) {
      device_is_open = 1;
      return 0;
    }

    /* make sure that buffer sizes are valid */
    if (buffer_size < MIN_BUFFER_SIZE)
      buffer_size = MIN_BUFFER_SIZE;
    if (buffer_size > MAX_BUFFER_SIZE)
      buffer_size = MAX_BUFFER_SIZE;
    if (period_size < MIN_PERIOD_SIZE)
      period_size = MIN_PERIOD_SIZE;
    if (period_size > MAX_PERIOD_SIZE)
      period_size = MAX_PERIOD_SIZE;
    /* round up to power of two buffer size */
    /* could be done better, but speed does not really matter here */
    while (buffer_size & (buffer_size - 1))
      buffer_size++;
    while (period_size & (period_size - 1))
      period_size++;
    /* must have at least two buffer fragments, but four is better */
    if (period_size > (buffer_size >> 2))
      period_size = buffer_size >> 2;
    /* correct buffer size for double buffering */
    buffer_size >>= 1;
    /* not opened yet */
    device_is_open = 0;
    /* set playback parameters */
    memset((void*) (&snd_spec), 0, sizeof(SDL_AudioSpec));
    snd_spec.freq = (int) (sound_sample_rate + 0.5);
    snd_spec.format = (Uint16) AUDIO_S16SYS;
    snd_spec.channels = (Uint8) 2;
    snd_spec.samples = (Uint16) buffer_size;
    snd_spec.callback = sound_callback;
    /* open the device for playback */
    if ((int) SDL_OpenAudio(&snd_spec, (SDL_AudioSpec*) NULL) != 0) {
      printMsg(" *** error opening audio device: %s\n", SDL_GetError());
      return -1;
    }
    if ((int) snd_spec.size != (buffer_size << 2))
      return -1;
    memset((void*) &(snd_buf[0]), 0,
           sizeof(int16_t) * (size_t) (MAX_BUFFER_SIZE << 2));
    bufpos = (buffer_size << 1);
    bufpos_mask = (MAX_BUFFER_SIZE << 1) - 1;
    read_pos = 0;
    samples_ahead = (buffer_size << 1);
    period_cnt = 0;
    /* 0: underrun, 1: very low, 2: low, 3: normal, 4: high, 5: full */
    buffer_state = 3;
    /* set buffer thresholds */
    bufthreshold_1 = 0;
    bufthreshold_2 = (int) (0.1 * (double) buffer_size + 0.5);
    bufthreshold_3 = (int) (0.4 * (double) buffer_size + 0.5);
    bufthreshold_4 = (int) (0.6 * (double) buffer_size + 0.5);
    bufthreshold_5 = (int) (0.9 * (double) buffer_size + 0.5);
    /* calculate timing parameters */
    wait_timeslice = (int) (65536000.0
                            * ((double) period_size / sound_sample_rate)
                            + 0.5);
    min_timeslice = wait_timeslice - (wait_timeslice >> 4);
    max_timeslice = wait_timeslice + (wait_timeslice >> 4);
    next_wait_time = ((int64_t) SDL_GetTicks * (int64_t) 65536)
                     + (int64_t) wait_timeslice;
    /* mark as open, */
    device_is_open = 1;
    /* start playback, */
    SDL_PauseAudio(0);
    /* and report success */
    return 0;
}

/* sound callback function */

static void sound_callback(void *userdata, Uint8 *stream, int len)
{
    int16_t     *buf;
    int         nsmps, i;

    /* avoid compiler warnings */
    userdata = userdata;
    /* calculate the number of samples to copy */
    nsmps = (int) len >> 2;
    /* copy the requested number of samples */
    buf = (int16_t*) stream;
    for (i = 0; i < nsmps; i++) {
      if (samples_ahead > 0) {
        *(buf++) = snd_buf[read_pos << 1];
        *(buf++) = snd_buf[(read_pos << 1) + 1];
        read_pos = (read_pos + 1) & bufpos_mask;
        samples_ahead--;
      }
      else {
        /* buffer underrun, fill with zero samples */
        *(buf++) = (int16_t) 0;
        *(buf++) = (int16_t) 0;
      }
    }
    /* update buffer state information */
    if (samples_ahead <= bufthreshold_3) {
      if (samples_ahead <= bufthreshold_1) {
        buffer_state = 0;                       /* underrun */
      }
      else if (samples_ahead <= bufthreshold_2) {
        buffer_state = 1;                       /* very low */
      }
      else {
        buffer_state = 2;                       /* low */
      }
    }
    else if (samples_ahead <= bufthreshold_4) {
      buffer_state = 3;                         /* normal */
    }
    else if (samples_ahead <= bufthreshold_5) {
      buffer_state = 4;                         /* high */
    }
    else {
      buffer_state = 5;                         /* full */
    }
}

/* send a sample to DAC */

static void soundcard_write_data_(int16_t sample_left, int16_t sample_right)
{
    int64_t curr_time;
    int     nsmps, wait_ms;

    /* there is nothing to do if sound is disabled */
    if (disable_sound || !device_is_open)
      return;

    /* store sample in temporary buffer */
    period_buf[period_cnt << 1] = sample_left;
    period_buf[(period_cnt << 1) + 1] = sample_right;
    if (++period_cnt < period_size)
      return;

    /* temporary buffer is now full */
    period_cnt = 0;

    /* copy data to circular buffer */
    SDL_LockAudio();
    for (nsmps = 0; nsmps < period_size; nsmps++) {
      snd_buf[bufpos << 1] = period_buf[nsmps << 1];
      snd_buf[(bufpos << 1) + 1] = period_buf[(nsmps << 1) + 1];
      bufpos = (bufpos + 1) & bufpos_mask;
    }
    samples_ahead += period_size;
    SDL_UnlockAudio();
    /* get system time */
    curr_time = (int64_t) SDL_GetTicks() * (int64_t) 65536;
    if ((next_wait_time - curr_time) > (int64_t) 0x10000000) {
      /* a wrap-around may have occured */
      next_wait_time = (int64_t) 0;
    }
    /* check buffer state and adjust timeslice */
    switch (buffer_state) {
      case 5:                           /* full */
        wait_timeslice += (wait_timeslice >> 5);
      case 4:                           /* high */
        wait_timeslice += (wait_timeslice >> 6);
        if (wait_timeslice > max_timeslice)
          wait_timeslice = max_timeslice;
        if (half_refresh_is_allowed)
          display_half_refresh &= ~2;
        break;
      case 0:                           /* underrun */
      case 1:                           /* very low */
        wait_timeslice -= (wait_timeslice >> 5);
        /* do not wait */
        next_wait_time = (int64_t) 0;
        if (half_refresh_is_allowed)
          display_half_refresh |= 2;
      case 2:                           /* low */
        wait_timeslice -= (wait_timeslice >> 6);
        if (wait_timeslice < min_timeslice)
          wait_timeslice = min_timeslice;
    }
    /* reset buffer state until callback function sets it again */
    buffer_state = 3;
    /* calculate the amount of time to wait */
    if (next_wait_time > curr_time) {
      wait_ms = (int) (next_wait_time - curr_time) >> 16;
      next_wait_time += (int64_t) wait_timeslice;
      if (wait_ms > 0)
        SDL_Delay((Uint32) wait_ms);
    }
    else {
      int64_t time1, time2;
      /* do not need to wait */
      time1 = next_wait_time + (int64_t) wait_timeslice;
      time2 = curr_time + (int64_t) (wait_timeslice >> 1);
      /* resynchronize */
      next_wait_time = (time1 > time2 ? time1 : time2);
    }
}

/* close sound output */

static void soundcard_close_(void)
{
    if (!device_is_open)
      return;
    if (!(disable_sound & 1))
      SDL_CloseAudio();
    device_is_open = 0;
}

/* module interface */

SoundModule_t   SDLSoundDriver = {
    "sdl",
    soundcard_initialize_,
    soundcard_write_data_,
    soundcard_close_
};

