
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* wd177x.c: WD177x disk controller implementation */

/* COPYRIGHT NOTE: this file is based on code that has been written by, */
/* and is copyright by Kevin Thacker and Vincze Bela Gyorgy (also under */
/* the terms of the GNU General Public License) */

#include <ep128.h>

/* disk image file names in the format 'filename@C,H,S' or 'filename' */

char    *wd177x_diskimage_a = NULL;
char    *wd177x_diskimage_b = NULL;
char    *wd177x_diskimage_c = NULL;
char    *wd177x_diskimage_d = NULL;

static  wd177x_drive_t  wd177x_drive_a;
static  wd177x_drive_t  wd177x_drive_b;
static  wd177x_drive_t  wd177x_drive_c;
static  wd177x_drive_t  wd177x_drive_d;

/* pointer to currently selected drive */

static  wd177x_drive_t  *wd177x_current_drive = NULL;

/****** WD177x ******/

/* set if stepping in towards track 79, clear if stepping out towards track 0 */
#define WD177X_STATE_STEP_DIRECTION     0x01
#define WD177X_STATE_INTERRUPT_REQUEST  0x02

#define WD177X_STATUS_BUSY                      0x01
#define WD177X_STATUS_DATA_REQUEST              0x02
#define WD177X_STATUS_LOST_DATA_OR_TRACK_0      0x04
#define WD177X_STATUS_CRC_ERROR                 0x08
#define WD177X_STATUS_RECORD_NOT_FOUND          0x10
#define WD177X_STATUS_RECORD_TYPE_SPIN_UP       0x20
#define WD177X_STATUS_WRITE_PROTECT             0x40
#define WD177X_STATUS_MOTOR_ON                  0x80

/* Type I commands status */
#define STA_1_BUSY      0x01    /* controller is busy */
#define STA_1_IPL       0x02    /* index pulse */
#define STA_1_TRACK0    0x04    /* track 0 detected */
#define STA_1_CRC_ERR   0x08    /* CRC error */
#define STA_1_SEEK_ERR  0x10    /* seek error */
#define STA_1_HD_LOADED 0x20    /* head loaded */
#define STA_1_WRITE_PRO 0x40    /* floppy is write protected */
#define STA_1_NOT_READY 0x80    /* controller not ready */

/* Type II commands status */
#define STA_2_BUSY      0x01
#define STA_2_DRQ       0x02
#define STA_2_LOST_DAT  0x04
#define STA_2_CRC_ERR   0x08
#define STA_2_REC_N_FND 0x10
#define STA_2_REC_TYPE  0x20
#define STA_2_WRITE_PRO 0x40
#define STA_2_NOT_READY 0x80

/***** EXDOS *****/

/* PORT 0x018: */

/* WRITE */
/* bit 7 - In use */
/* bit 6 - Disk change clear */
/* bit 5 - mfm/fm */
/* bit 4 - Side */
/* bit 3 - Select drive 3 */
/* bit 2 - Select drive 2 */
/* bit 1 - Select drive 1 */
/* bit 0 - Select drive 0 */

/* READ */
/* bit 7 - DRQ from WD177x */
/* bit 6 - Disk change */
/* bit 5 - ???? */
/* bit 4 - ???? */
/* bit 3 - ???? */
/* bit 2 - ???? */
/* bit 1 - IRQ from WD177x */
/* bit 0 - ???? */

/* PORT 0x020 - EXDOS Speed select etc. */

/* open disk image file specified by 's' in the format 'filename@C,H,S' or */
/* 'filename', and set up parameters in structure pointed to by 'p' */
/* return value is zero in case of success, -1 if a fatal error has occured, */
/* and -2 if a disk image is not available */

static int wd177x_open_diskimage(const char *s, wd177x_drive_t *p)
{
    int n;

    /* set defaults for missing or invalid disk image */
    memset((void*) p, 0, sizeof(wd177x_drive_t));
    p->f = NULL;
    p->readOnly = 1;
    /* check the name specified */
    if (s == NULL || *s == '\0') {
      n = -2; goto errorReturn;
    }
    /* determine number of cylinders, heads, and sectors, if specified */
    n = sscanf(s, "%[^@]@%d,%d,%d", &(p->fname[0]), &(p->Cylinders),
                                    &(p->Heads), &(p->Sectors));
    if (n == 4) {
      /* number of cylinders, heads, and sectors is available */
      /* check if format is valid */
      sscanf(s, "%[^@]@%d,%d,%d%n", &(p->fname[0]), &(p->Cylinders),
                                    &(p->Heads), &(p->Sectors), &n);
      if (n != (int) strlen(s)) {
        /* trailing garbage */
        printMsg("ep128: invalid disk image file name: '%s'\n", s);
        n = -1; goto errorReturn;
      }
      /* check for valid parameters */
      n = 0;
      if (p->Cylinders < 40 || p->Cylinders > 240) {
        printMsg("ep128: invalid number of cylinders: %d\n", p->Cylinders);
        n = -1;
      }
      if (p->Heads != 2) {
        printMsg("ep128: invalid number of heads: %d\n", p->Heads);
        n = -1;
      }
      if (p->Sectors != 9) {
        printMsg("ep128: invalid number of sectors: %d\n", p->Sectors);
        n = -1;
      }
      if (n)
        goto errorReturn;
      /* calculate expected file size */
      p->totalSectors = p->Cylinders * p->Heads * p->Sectors;
      p->fileSize = p->totalSectors * 512;
    }
    else if (n != 1) {
      printMsg("ep128: invalid disk image file name: '%s'\n", s);
      n = -1; goto errorReturn;
    }
    if (p->fname[0] == '\0') {
      printMsg("ep128: invalid disk image file name: '%s'\n", s);
      n = -1; goto errorReturn;
    }
    /* attempt to open file, first try read-write */
    p->f = fopen(&(p->fname[0]), "r+b");
    if (p->f == NULL) {
      /* try again in read-only mode */
      p->f = fopen(&(p->fname[0]), "rb");
      if (p->f == NULL) {
        printMsg("ep128: could not open disk image file '%s': %s\n",
                 &(p->fname[0]), strerror(errno));
        n = -2; goto errorReturn;
      }
      p->readOnly = 1;
    }
    else {
      /* image is not read-only */
      p->readOnly = 0;
    }
    /* check file size */
    fseek(p->f, 0L, SEEK_END);
    n = (int) ftell(p->f);
    fseek(p->f, 0L, SEEK_SET);
#ifdef WIN32
    if (strncmp(s, "\\\\.\\A:@", 7) == 0 || strncmp(s, "\\\\.\\B:@", 7) == 0 ||
        strncmp(s, "\\\\.\\a:@", 7) == 0 || strncmp(s, "\\\\.\\b:@", 7) == 0) {
      /* direct floppy access on Windows 2000 */
      printMsg("WARNING: cannot check disk geometry of '%c:', make sure\n",
               s[4]);
      printMsg("         that the correct C, H, S values are specified\n");
      n = p->fileSize;
    }
#endif
    if (p->fileSize > 0) {
      /* if the user has specified a geometry, check if it is consistent */
      /* with the actual file size */
      if (n != p->fileSize) {
        printMsg("ep128: size of disk image '%s' is inconsistent "
                 "with specified geometry\n", &(p->fname[0]));
        n = -1; goto errorReturn;
      }
    }
    else {
      /* otherwise, check for standard disk geometries */
      if (n >= 368640 && n <= 2211840 && ((n / 9216) * 9216) == n) {
        p->Cylinders = (n / 9216); p->Heads = 2; p->Sectors = 9;
      }
      else {
        printMsg("ep128: could not determine geometry of disk image '%s'\n",
                 &(p->fname[0]));
        n = -1; goto errorReturn;
      }
      /* store file size */
      p->totalSectors = p->Cylinders * p->Heads * p->Sectors;
      p->fileSize = p->totalSectors * 512;
    }
    /* report success */
    printMsg("ep128: opened disk image '%s' (", &(p->fname[0]));
    if (p->readOnly)
      printMsg("RO, ");
    else
      printMsg("RW, ");
    printMsg("C: %d, H: %d, S: %d)\n", p->Cylinders, p->Heads, p->Sectors);
    return 0;

 errorReturn:
    /* reset parameters and report error */
    if (p->f != NULL) {
      fclose(p->f);
    }
    memset((void*) p, 0, sizeof(wd177x_drive_t));
    p->f = NULL;
    p->readOnly = 1;
    return n;
}

/* close disk image 'p' */

static void wd177x_close_diskimage(wd177x_drive_t *p)
{
    if (p->f != NULL) {
      fflush(p->f);
      fclose(p->f);
    }
    memset((void*) p, 0, sizeof(wd177x_drive_t));
    p->f = NULL;
    p->readOnly = 1;
}

/* reset the internal variables of a drive */

static void WD177x_ResetDrive(wd177x_drive_t *d)
{
    if (d->f != NULL)
      fflush(d->f);
    d->State = 0;
    d->StatusRegister = 0;
    d->TrackRegister = 0;
    d->SectorRegister = 0;
    d->CommandRegister = 0;
    d->DataRegister = 0;
    d->DataBytesRemaining = 0;
    d->DataByteIndex = 0;
    d->CurrentTrack = 0;
    d->CurrentSide = 0;
}

/* reset the internal variables of all drives */

void WD177x_Reset(void)
{
    /* reset 177x */
    WD177x_ResetDrive(&wd177x_drive_a);
    WD177x_ResetDrive(&wd177x_drive_b);
    WD177x_ResetDrive(&wd177x_drive_c);
    WD177x_ResetDrive(&wd177x_drive_d);
}

/* initialize all disks                                 */
/* return value:                                        */
/*   -1: a fatal error has occured                      */
/*   -2: some of the disk images were not available     */
/*    0: all disk images have been opened successfully  */

int wd177x_initialize(void)
{
    int n, retval = 0;

    /* drive A */
    n = wd177x_open_diskimage(wd177x_diskimage_a, &wd177x_drive_a);
    if (n == -1)
      retval = n;
    else if (n == -2 && retval == 0)
      retval = n;
    /* drive B */
    n = wd177x_open_diskimage(wd177x_diskimage_b, &wd177x_drive_b);
    if (n == -1)
      retval = n;
    else if (n == -2 && retval == 0)
      retval = n;
    /* drive C */
    n = wd177x_open_diskimage(wd177x_diskimage_c, &wd177x_drive_c);
    if (n == -1)
      retval = n;
    else if (n == -2 && retval == 0)
      retval = n;
    /* drive D */
    n = wd177x_open_diskimage(wd177x_diskimage_d, &wd177x_drive_d);
    if (n == -1)
      retval = n;
    else if (n == -2 && retval == 0)
      retval = n;

    WD177x_Reset();

    return retval;
}

/* close all disks */

void wd177x_close(void)
{
    wd177x_close_diskimage(&wd177x_drive_a);
    wd177x_close_diskimage(&wd177x_drive_b);
    wd177x_close_diskimage(&wd177x_drive_c);
    wd177x_close_diskimage(&wd177x_drive_d);
}

/* look-up table to find out the current drive based on lower 4 bits of */
/* value written to port 0x18; it is not clear what to do if multiple */
/* bits are set */

static const int DriveCodeToIndex[16] =
    { -1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };

/* write to port 0x18 */

void ExdosCardWrite(uint8_t Data)
{
    /* get drive selected */
    switch (DriveCodeToIndex[(int) Data & 0x0F]) {
      case 0:   wd177x_current_drive = &wd177x_drive_a; break;
      case 1:   wd177x_current_drive = &wd177x_drive_b; break;
      case 2:   wd177x_current_drive = &wd177x_drive_c; break;
      case 3:   wd177x_current_drive = &wd177x_drive_d; break;
      default:  wd177x_current_drive = NULL;
    }
    /* if no drive has been selected, there is nothing more to do */
    if (wd177x_current_drive == NULL)
      return;
    /* get side selected */
    wd177x_current_drive->CurrentSide = ((int) Data & 0x10 ? 1 : 0);
}

/* read from port 0x18 */

uint8_t ExdosCardRead(void)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;
    int             Data = 0;

    if (wd177x != NULL) {
      if (wd177x->State & WD177X_STATE_INTERRUPT_REQUEST)       Data |= 0x02;
      if (wd177x->StatusRegister & WD177X_STATUS_DATA_REQUEST)  Data |= 0x80;
    }

    return (uint8_t) Data;
}

static int Exdos_GetSectorData(void)
{
    int Pos;

    if (wd177x_current_drive == NULL || wd177x_current_drive->f == NULL)
      return -1;
    /* calculate file position */
    Pos = (wd177x_current_drive->Sectors
           * (wd177x_current_drive->CurrentTrack * wd177x_current_drive->Heads
              + wd177x_current_drive->CurrentSide)
           + (wd177x_current_drive->SectorRegister - 1));
    Pos *= 512;
    if (Pos < 0 || Pos >= wd177x_current_drive->fileSize)
      return -1;
    /* read 512 bytes of data */
    fseek(wd177x_current_drive->f, (long) Pos, SEEK_SET);
    fread((void*) &(wd177x_current_drive->DataBuffer[0]), (size_t) 1,
          (size_t) 512, wd177x_current_drive->f);

    return 0;
}

static int Exdos_GetSectorID(void)
{
    if (wd177x_current_drive == NULL)
      return -1;

    wd177x_current_drive->CurrentIDIndex++;
    wd177x_current_drive->DataBuffer[0] =
      (uint8_t) wd177x_current_drive->CurrentTrack;
    wd177x_current_drive->DataBuffer[1] =
      (uint8_t) wd177x_current_drive->CurrentSide;
    wd177x_current_drive->DataBuffer[2] =
      (uint8_t) wd177x_current_drive->CurrentIDIndex;
    wd177x_current_drive->DataBuffer[3] = (uint8_t) 2;
    wd177x_current_drive->DataBuffer[4] = (uint8_t) 0;
    wd177x_current_drive->DataBuffer[5] = (uint8_t) 0;
    /* 6 bytes to read */
    wd177x_current_drive->DataBytesRemaining = 6;
    wd177x_current_drive->DataByteIndex = 0;

    return 0;
}

/****** WD1772 ******/

static void WD177x_StepIn(void)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;

    if (wd177x == NULL)
      return;

    wd177x->State |= WD177X_STATE_STEP_DIRECTION;
    wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
    wd177x->StatusRegister &= ~(STA_1_SEEK_ERR | STA_1_TRACK0);

    if (((wd177x->CommandRegister & 0x04) != 0 && wd177x->f == NULL) ||
        wd177x->CurrentTrack >= (wd177x->Cylinders - 1)) {
      wd177x->StatusRegister |= STA_1_SEEK_ERR;
      return;
    }
    wd177x->CurrentTrack++;
    /* u flag set? */
    if (wd177x->CommandRegister & 0x10) {
      /* update track register */
      wd177x->TrackRegister++;
    }
}

static void WD177x_StepOut(void)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;

    if (wd177x == NULL)
      return;

    wd177x->State &= ~WD177X_STATE_STEP_DIRECTION;
    wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
    wd177x->StatusRegister &= ~(STA_1_SEEK_ERR | STA_1_TRACK0);

    if (((wd177x->CommandRegister & 0x04) != 0 && wd177x->f == NULL) ||
        wd177x->CurrentTrack <= 0) {
      wd177x->StatusRegister |= STA_1_SEEK_ERR;
      wd177x->StatusRegister |= STA_1_TRACK0;
      return;
    }
    wd177x->CurrentTrack--;
    /* u flag set? */
    if (wd177x->CommandRegister & 0x10) {
      /* update track register */
      wd177x->TrackRegister--;
    }
    /* check for track 0 */
    if (wd177x->CurrentTrack == 0)
      wd177x->StatusRegister |= STA_1_TRACK0;
}

static void WD177x_Step(void)
{
    if (wd177x_current_drive == NULL)
      return;

    /* step */
    if (wd177x_current_drive->State & WD177X_STATE_STEP_DIRECTION) {
      /* step in */
      WD177x_StepIn();
    }
    else {
      /* step out */
      WD177x_StepOut();
    }
}

static void WD177x_ReadSectorCommand(void)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;

    /* read sector */
    wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY;
    wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON;
    wd177x->StatusRegister &=
      ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR
        | WD177X_STATUS_RECORD_NOT_FOUND | WD177X_STATUS_WRITE_PROTECT);
    if (wd177x->f != NULL && Exdos_GetSectorData() == 0) {
      wd177x->DataBytesRemaining = 512;
      wd177x->DataByteIndex = 0;
    }
    else {
      /* no disk is present or read error */
      wd177x->StatusRegister &=
        ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY);
      wd177x->StatusRegister |= WD177X_STATUS_RECORD_NOT_FOUND;
      if (wd177x->f == NULL) {
        wd177x->StatusRegister |= WD177X_STATUS_CRC_ERROR;
      }
      wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
    }
}

static void WD177x_WriteSectorCommand(void)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;

    wd177x->TrackRegister = -1;
    /* write sector */
    wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY;
    wd177x->StatusRegister |= WD177X_STATUS_MOTOR_ON;
    wd177x->StatusRegister &=
      ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR
        | WD177X_STATUS_RECORD_NOT_FOUND);

    if (wd177x->f != NULL) {
      if (wd177x->readOnly) {
        /* disk is read-only */
        wd177x->StatusRegister &=
          ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY);
        wd177x->StatusRegister |= WD177X_STATUS_WRITE_PROTECT;
        wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
      }
      else {
        wd177x->DataBytesRemaining = 512;
        wd177x->DataByteIndex = 0;
      }
    }
    else {
      /* no disk is present */
      wd177x->StatusRegister &=
        ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY);
      wd177x->StatusRegister |= WD177X_STATUS_RECORD_NOT_FOUND;
      wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
    }
}

void WD177x_WriteCommand(uint8_t Data)
{
    wd177x_drive_t  *wd177x = wd177x_current_drive;
    int             CommandIndex = ((int) Data >> 5) & 0x07;

    if (wd177x == NULL)
      return;

    wd177x->CommandRegister = (int) Data;
    /* clear int request */
    wd177x->State &= ~WD177X_STATE_INTERRUPT_REQUEST;

    switch (CommandIndex) {
    case 0:
      {
        /* Restore, Seek */
        wd177x->StatusRegister &= ~STA_1_SEEK_ERR;
        if ((int) Data & 0x10) {
          /* Seek */
          /* set step direction */
          if (wd177x->TrackRegister < wd177x->DataRegister) {
            /* step in */
            wd177x->State |= WD177X_STATE_STEP_DIRECTION;
          }
          else {
            /* step out */
            wd177x->State &= ~WD177X_STATE_STEP_DIRECTION;
          }
          /* DataRegister contains destination track to seek to */
          /* Track register is assumed to have a valid track index */
          while (wd177x->TrackRegister != wd177x->DataRegister &&
                 (wd177x->StatusRegister & STA_1_SEEK_ERR) == 0)
            WD177x_Step();
        }
        else {
          /* Restore */
          /* this nobbles the data register - correct? */
          wd177x->DataRegister = 0;
          /* this nobbles the command register.. need to fix */
          wd177x->CommandRegister |= 0x10;
          while (wd177x->CurrentTrack > 0 &&
                 (wd177x->StatusRegister & STA_1_SEEK_ERR) == 0)
            WD177x_StepOut();
        }
        wd177x->StatusRegister |=
          WD177X_STATUS_MOTOR_ON | WD177X_STATUS_RECORD_TYPE_SPIN_UP;
        wd177x->State |= WD177X_STATE_INTERRUPT_REQUEST;
      }
      break;

    case 1:
      /* step */
      WD177x_Step();
      break;

    case 2:
      /* step in */
      WD177x_StepIn();
      break;

    case 3:
      /* step out */
      WD177x_StepOut();
      break;

    case 4:
      /* read sector */
      WD177x_ReadSectorCommand();
      break;

    case 5:
      /* write sector */
      WD177x_WriteSectorCommand();
      break;

    case 6:
      {
        /* read address/force interrupt */
        wd177x->TrackRegister = -1;
        if (((int) Data & 0x10) != 0) {
          /* force interrupt */
          wd177x->StatusRegister &= ~WD177X_STATUS_BUSY;
          wd177x->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
        }
        else {
          /* read address */
          wd177x->StatusRegister |=
            WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY;
          wd177x->StatusRegister &=
            ~(WD177X_STATUS_LOST_DATA_OR_TRACK_0 | WD177X_STATUS_CRC_ERROR);
          if (Exdos_GetSectorID() != 0)
            wd177x->StatusRegister |= WD177X_STATUS_CRC_ERROR;
        }
      }
      break;

    case 7:
      /* TODO: read track/write track depending on bit 4 */
      break;
    }
}

/* set track register */

void WD177x_WriteTrack(uint8_t Data)
{
    if (wd177x_current_drive == NULL)
      return;
    wd177x_current_drive->TrackRegister = (int) Data;
}

/* set sector register */

void WD177x_WriteSector(uint8_t Data)
{
    if (wd177x_current_drive == NULL)
      return;
    wd177x_current_drive->SectorRegister = (int) Data;
}

/* write a byte of data */

void WD177x_WriteData(uint8_t Data)
{
    int Pos;

    if (wd177x_current_drive == NULL)
      return;

    wd177x_current_drive->DataRegister = (int) Data;

    if (!(wd177x_current_drive->StatusRegister & WD177X_STATUS_DATA_REQUEST))
      return;
    if (wd177x_current_drive->DataBytesRemaining == 0)
      return;

    wd177x_current_drive->DataBuffer[wd177x_current_drive->DataByteIndex] =
      wd177x_current_drive->DataRegister;
    wd177x_current_drive->DataBytesRemaining--;
    wd177x_current_drive->DataByteIndex++;
    wd177x_current_drive->StatusRegister |= WD177X_STATUS_DATA_REQUEST;

    if (wd177x_current_drive->DataBytesRemaining != 0)
      return;
    /* buffer is full */
    wd177x_current_drive->StatusRegister &=
      ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY
        | WD177X_STATUS_MOTOR_ON);
    wd177x_current_drive->State |= WD177X_STATE_INTERRUPT_REQUEST;
    /* write to disk */
    if (wd177x_current_drive->f == NULL)
      return;
    /* calculate file position */
    Pos = (wd177x_current_drive->Sectors
           * (wd177x_current_drive->CurrentTrack * wd177x_current_drive->Heads
              + wd177x_current_drive->CurrentSide)
           + (wd177x_current_drive->SectorRegister - 1));
    Pos *= 512;
    if (Pos < 0 || Pos >= wd177x_current_drive->fileSize)
      return;
    /* write 512 bytes of data */
    if (wd177x_current_drive->readOnly == 0) {
      fseek(wd177x_current_drive->f, (long) Pos, SEEK_SET);
      fwrite((void*) &(wd177x_current_drive->DataBuffer[0]), (size_t) 1,
             (size_t) 512, wd177x_current_drive->f);
      wd177x_current_drive->StatusRegister &= ~WD177X_STATUS_WRITE_PROTECT;
    }
    else
      wd177x_current_drive->StatusRegister |= WD177X_STATUS_WRITE_PROTECT;
}

/* read status register */

uint8_t WD177x_ReadStatus(void)
{
    if (wd177x_current_drive != NULL) {
      /* clear int request */
      wd177x_current_drive->StatusRegister &= ~(WD177X_STATE_INTERRUPT_REQUEST);
      return (uint8_t) wd177x_current_drive->StatusRegister;
    }
    else
      return (uint8_t) 0;
}

/* read track register */

uint8_t WD177x_ReadTrack(void)
{
    if (wd177x_current_drive != NULL)
      return (uint8_t) wd177x_current_drive->TrackRegister;
    else
      return (uint8_t) 0;
}

/* read sector register */

uint8_t WD177x_ReadSector(void)
{
    if (wd177x_current_drive != NULL)
      return (uint8_t) wd177x_current_drive->SectorRegister;
    else
      return (uint8_t) 0;
}

/* read a byte of data */

uint8_t WD177x_ReadData(void)
{
    if (wd177x_current_drive == NULL)
      return (uint8_t) 0;
    if (wd177x_current_drive->DataBytesRemaining == 0)
      return (uint8_t) wd177x_current_drive->DataRegister;

    wd177x_current_drive->DataBytesRemaining--;
    wd177x_current_drive->StatusRegister |= WD177X_STATUS_DATA_REQUEST;
    wd177x_current_drive->DataRegister =
      wd177x_current_drive->DataBuffer[wd177x_current_drive->DataByteIndex];
    wd177x_current_drive->DataByteIndex++;

    if (wd177x_current_drive->DataBytesRemaining == 0) {
      wd177x_current_drive->StatusRegister &=
        ~(WD177X_STATUS_DATA_REQUEST | WD177X_STATUS_BUSY
          | WD177X_STATUS_MOTOR_ON);
      wd177x_current_drive->State |= WD177X_STATE_INTERRUPT_REQUEST;
    }

    return (uint8_t) wd177x_current_drive->DataRegister;
}

