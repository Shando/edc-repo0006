
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_UI_H
#define EP128_UI_H

/* handle program control keys */
/* keynum is 0 to 9 for keys '0' to '9', 11 to 22 for keys 'F1' to 'F12', */
/* 40 to 65 for 'A' - 'Z', and 10 for 'Escape' */
/* 'Keypad Enter' is 80, 'Keypad -' is 81, 'Keypad +' is 82, */
/* 'Keypad Ins' is 83, and 'Keypad Del' is 84 */

void handle_special_key(int keynum);

#endif      /* EP128_UI_H */

