
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* modules.c -- interface to audio and video driver modules */

#include <ep128.h>
#include <ctype.h>

#define DEFAULT_SOUND_DRIVER    "sdl"
#define DEFAULT_VIDEO_DRIVER    "sdl"

/* ======== list of available sound and video modules ======== */

extern  SoundModule_t   DummySoundDriver;
extern  SoundModule_t   SDLSoundDriver;
#if defined(LINUX) && !(defined(NO_ALSA))
extern  SoundModule_t   ALSASoundDriver;
#endif
#if defined(WIN32) && !(defined(NO_WINMM))
extern  SoundModule_t   WinMMSoundDriver;
#endif

static SoundModule_t *sound_drivers[] = {
    &(DummySoundDriver),
    &(SDLSoundDriver),
#if defined(LINUX) && !(defined(NO_ALSA))
    &(ALSASoundDriver),
#endif
#if defined(WIN32) && !(defined(NO_WINMM))
    &(WinMMSoundDriver),
#endif
    (SoundModule_t*) NULL       /* terminate list */
};

extern  VideoModule_t   DummyVideoDriver;
extern  VideoModule_t   SDLVideoDriver;
#ifdef HAVE_OPENGL
extern  VideoModule_t   OpenGLVideoDriver;
#endif

static VideoModule_t *video_drivers[] = {
    &(DummyVideoDriver),
    &(SDLVideoDriver),
#ifdef HAVE_OPENGL
    &(OpenGLVideoDriver),
#endif
    (VideoModule_t*) NULL       /* terminate list */
};

/* ======== global configuration variables ======== */

/* ---- sound ---- */

char    *sound_driver = NULL;       /* sound output module name             */

int     buffer_size = 1024;         /* total buffer size in samples         */
int     period_size = 128;          /* buffer fragment size in samples      */
int     disable_sound = 0;          /* disable sound output (zero: no)      */
                                    /*   bit 0 is set: disabled in cfg file */
                                    /*   bit 1 is set: disabled at run-time */
char    *sound_device = "default";  /* sound device name                    */

/* ---- video ---- */

char  *video_driver = NULL;         /* video output module name           */

int   emulator_ui_mode = 0;         /* 0: emulation, 1: program control   */

int   display_fullscreen = 0;       /* 1: enable fullscreen mode          */
int   display_hardware_mode = 0;    /* 1: use direct framebuffer access   */
int   display_doublebuf = 0;        /* 1: enable double buffered display  */
int   display_half_size = 0;        /* 1: half resolution                 */
int   display_interlace = 0;        /* 1: enable interlaced display       */
int   display_blit_on_change = 1;   /* 1: update display on change only   */
int   display_half_refresh = 0;     /* !=0: blit 25 frames per second     */
                                    /*   bit 0: controlled by user        */
                                    /*   bit 1: controlled by snd driver  */
int   display_window_width = 720;   /* window width in pixels             */
                                    /*   (at full resolution)             */
int   display_window_height = 540;  /* window height in pixels            */
                                    /*   (at full resolution)             */
int   display_x_shift = 0;          /* display shift right (in pixels)    */
int   display_y_shift = 0;          /* display shift down (in pixels)     */

double  min_intensity = 0.125;      /* color correction parameters */
double  min_intensity_R = 0.0;
double  min_intensity_G = 0.0;
double  min_intensity_B = 0.0;
double  max_intensity = 1.0;
double  max_intensity_R = 1.0;
double  max_intensity_G = 1.0;
double  max_intensity_B = 1.0;
double  color_gamma = 1.0;
double  color_gamma_R = 1.0;
double  color_gamma_G = 1.0;
double  color_gamma_B = 1.0;

/* OpenGL parameters */
int     gl_antialias = 0;           /* enable linear filtering               */
int     gl_txtheight = 3;           /* texture height is (1 << gl_txtheight) */
double  gl_zoom = 1.0;              /* zoom window size by this factor       */

/* the following globals are internal variables, and are not set by the user */

uint8_t key_matrix[16];                 /* keyboard matrix                  */
int     key_matrix_row_select = 0;      /* keyboard matrix row select       */
int     half_refresh_is_allowed = 0;    /* if this variable is non-zero,    */
                                        /*   the sound driver may set half  */
                                        /*   refresh mode on buf. underrun  */

int     display_min_line = 42;      /* (624 - display_window_height) / 2    */
int     display_max_line = 582;     /* 624 - display_min_line               */
int     display_sync_line = 622;    /* (590 + display_min_line)             */
                                    /*   + display_y_shift                  */
int     display_left_offset = 136;  /* (992 - display_window_width) / 2     */
                                    /*   - display_x_shift                  */

/* ======== interface functions ======== */

/* ---- sound ---- */

/* initialize sound card (returns zero on success) */
int     (*soundcard_initialize)(void);
/* send a sample to DAC */
void    (*soundcard_write_data)(int16_t sample_left, int16_t sample_right);
/* close sound output */
void    (*soundcard_close)(void);

/* ---- video ---- */

/* initialize graphics system */
int     (*init_graphics)(int *argc, char ***argv);
/* draw a line (line number should be in the range 0 to 623) */
/* 'data' is an array of 1024 8-bit integers */
/* borders are drawn with 'border_color', using margin positions */
/* 'lmarg' and 'rmarg' (specified in character units, 0 to 63) */
void    (*draw_line)(int line_number, const uint8_t *data,
                     uint8_t border_color, int lmarg, int rmarg);
/* read keyboard events and update matrix values */
/* returns non-zero if the event is "close window" */
int     (*process_events)(void);
/* de-initialize graphics (this function may not return) */
void    (*destroy_graphics)(void);

/* load the modules selected by user; returns zero on success */

int load_driver_modules(void)
{
    int     i;
    char    snddrv[256], videodrv[256];

    /* copy sound driver name */
    if (sound_driver == NULL || sound_driver[0] == '\0') {
      /* use default driver */
      strcpy(&(snddrv[0]), DEFAULT_SOUND_DRIVER);
    }
    else {
      /* convert to lower case */
      i = 0;
      while (i < 255 && sound_driver[i] != '\0') {
        if (isupper(sound_driver[i]))
          snddrv[i] = tolower(sound_driver[i]);
        else
          snddrv[i] = sound_driver[i];
        i++;
      }
      snddrv[i] = '\0';
      if (strcmp(&(snddrv[0]), "default") == 0) {
        /* use default driver */
        strcpy(&(snddrv[0]), DEFAULT_SOUND_DRIVER);
      }
    }
    /* copy video driver name */
    if (video_driver == NULL || video_driver[0] == '\0') {
      /* use default driver */
      strcpy(&(videodrv[0]), DEFAULT_VIDEO_DRIVER);
    }
    else {
      /* convert to lower case */
      i = 0;
      while (i < 255 && video_driver[i] != '\0') {
        if (isupper(video_driver[i]))
          videodrv[i] = tolower(video_driver[i]);
        else
          videodrv[i] = video_driver[i];
        i++;
      }
      videodrv[i] = '\0';
      if (strcmp(&(videodrv[0]), "default") == 0) {
        /* use default driver */
        strcpy(&(videodrv[0]), DEFAULT_VIDEO_DRIVER);
      }
    }
    /* find sound driver in list */
    i = -1;
    do {
      i++;
      if (sound_drivers[i] == NULL) {
        /* end of list, the driver name specified is invalid */
        printMsg(" *** ep128emu: invalid sound driver name: %s\n",
                 &(snddrv[0]));
        printMsg(" *** valid driver names are: ");
        i = 0;
        while (sound_drivers[i] != NULL) {
          printMsg("%s, ", sound_drivers[i]->DriverName);
          i++;
        }
        printMsg("default (same as %s)\n", DEFAULT_SOUND_DRIVER);
        return -1;
      }
    } while (strcmp(&(snddrv[0]), sound_drivers[i]->DriverName) != 0);
    /* set sound driver function pointers */
    printMsg("load_driver_modules(): using sound driver \"%s\"\n",
             sound_drivers[i]->DriverName);
    soundcard_initialize = sound_drivers[i]->InitFunction;
    soundcard_write_data = sound_drivers[i]->PlayFunction;
    soundcard_close = sound_drivers[i]->CloseFunction;
    /* find video driver in list */
    i = -1;
    do {
      i++;
      if (video_drivers[i] == NULL) {
        /* end of list, the driver name specified is invalid */
        printMsg(" *** ep128emu: invalid video driver name: %s\n",
                 &(videodrv[0]));
        printMsg(" *** valid driver names are: ");
        i = 0;
        while (video_drivers[i] != NULL) {
          printMsg("%s, ", video_drivers[i]->DriverName);
          i++;
        }
        printMsg("default (same as %s)\n", DEFAULT_VIDEO_DRIVER);
        return -1;
      }
    } while (strcmp(&(videodrv[0]), video_drivers[i]->DriverName) != 0);
    /* set video driver function pointers */
    printMsg("load_driver_modules(): using video driver \"%s\"\n",
             video_drivers[i]->DriverName);
    init_graphics = video_drivers[i]->InitFunction;
    draw_line = video_drivers[i]->DrawFunction;
    process_events = video_drivers[i]->EventFunction;
    destroy_graphics = video_drivers[i]->CloseFunction;
    /* report success */
    return 0;
}

