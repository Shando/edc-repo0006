
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* decode8.c: extract files from 8-bit stereo 48 kHz tape file */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

double	esr = 48000.0;			/* sample rate of input file */
int	chnl_reqd = 0;			/* requested channel (0: L, 1: R) */

FILE	*infile = NULL;			/* input file */

char	outflname[256];			/* output file name */
FILE	*outfl = NULL;			/* output file */

unsigned char	buf[4096];

int	cursamp = 0, prvsamp1 = 0, prvsamp2 = 0, prvsamp3 = 0, prvsamp4 = 0;
int	time_smp = 0;
double	time_sec = 0.0;
int	cur_edge = 0, prv_edge_1 = 0, prv_edge_2 = 0;
double	cur_edge_time = 0.0, prv_edge_time_1 = 0.0, prv_edge_time_2 = 0.0;
double	ref_period_time = 0.0;
int	crc_val = 0;

typedef struct decode_state_s {
	int	chnl_reqd;
	int	cursamp, prvsamp1, prvsamp2, prvsamp3, prvsamp4;
	int	time_smp;
	double	time_sec;
	int	cur_edge, prv_edge_1, prv_edge_2;
	double	cur_edge_time, prv_edge_time_1, prv_edge_time_2;
	double	ref_period_time;
	int	crc_val;
} decode_state_t;

/* print current time (for debugging) */

void	print_time(void)
{
	fprintf(stderr, "at time %f: ", time_sec);
}

/* set file position to the specified time */

void	seek_to_time(double t)
{
	/* set current time in seconds and samples */
	time_sec = t;
	time_smp = (int) (t * esr + 0.5);
	/* reset other time dependent variables */
	cursamp = prvsamp1 = prvsamp2 = prvsamp3 = prvsamp4 = 0;
	cur_edge = prv_edge_1 = prv_edge_2 = 0;
	cur_edge_time = prv_edge_time_1 = prv_edge_time_2 = t;
	ref_period_time = 0.0;
	crc_val = 0;
	/* seek to the requested time position */
	if (infile == NULL)
		return;
	fseek(infile, (long) (time_smp << 1), SEEK_SET);
}

void save_current_state(decode_state_t *p)
{
	p->chnl_reqd = chnl_reqd;
	p->cursamp = cursamp;
	p->prvsamp1 = prvsamp1;
	p->prvsamp2 = prvsamp2;
	p->prvsamp3 = prvsamp3;
	p->prvsamp4 = prvsamp4;
	p->time_smp = time_smp;
	p->time_sec = time_sec;
	p->cur_edge = cur_edge;
	p->prv_edge_1 = prv_edge_1;
	p->prv_edge_2 = prv_edge_2;
	p->cur_edge_time = cur_edge_time;
	p->prv_edge_time_1 = prv_edge_time_1;
	p->prv_edge_time_2 = prv_edge_time_2;
	p->ref_period_time = ref_period_time;
	p->crc_val = crc_val;
}

void restore_previous_state(decode_state_t *p)
{
	chnl_reqd = p->chnl_reqd;
	cursamp = p->cursamp;
	prvsamp1 = p->prvsamp1;
	prvsamp2 = p->prvsamp2;
	prvsamp3 = p->prvsamp3;
	prvsamp4 = p->prvsamp4;
	time_smp = p->time_smp;
	time_sec = p->time_sec;
	cur_edge = p->cur_edge;
	prv_edge_1 = p->prv_edge_1;
	prv_edge_2 = p->prv_edge_2;
	cur_edge_time = p->cur_edge_time;
	prv_edge_time_1 = p->prv_edge_time_1;
	prv_edge_time_2 = p->prv_edge_time_2;
	ref_period_time = p->ref_period_time;
	crc_val = p->crc_val;
	if (infile == NULL)
		return;
	fseek(infile, (long) (time_smp << 1), SEEK_SET);
}

void	store_sample(unsigned char samp)
{
	/* update time */
	time_smp++;
	time_sec += (1.0 / esr);
	/* shift old samples */
	prvsamp4 = prvsamp3;
	prvsamp3 = prvsamp2;
	prvsamp2 = prvsamp1;
	prvsamp1 = cursamp;
	/* store new sample */
	cursamp = (int) samp;
}

/* return value is -1 for edge down, 1 for edge up, and 0 for no edge */

int	detect_edge(void)
{
	if (prvsamp4 < 64 && cursamp > 192) {
		int     avg = (prvsamp1 + prvsamp2 + prvsamp3) / 3;
		if (avg > 80 && avg < 176) {
			/* edge up */
			prvsamp1 = prvsamp2 = prvsamp3 = prvsamp4 = cursamp;
			return 1;
		} else {
			return 0;
		}
	} else if (prvsamp4 > 192 && cursamp < 64) {
		int     avg = (prvsamp1 + prvsamp2 + prvsamp3) / 3;
		if (avg > 80 && avg < 176) {
			/* edge down */
			prvsamp1 = prvsamp2 = prvsamp3 = prvsamp4 = cursamp;
			return -1;
		} else {
			return 0;
		}
	}
	return 0;	/* no edge */
}

/* open input file */

void	open_file(char *name)
{
	infile = fopen(name, "rb");
	if (infile == NULL) {
		fprintf(stderr, "cannot open input file\n");
		exit(-1);
	}
}

/* open file for writing (name is specified in outflname) */

FILE	*open_output_file(void)
{
	struct stat	tmp;
	char		s[256];
	int		outflcnt = 0;
	FILE		*f = NULL;

	strcpy(s, outflname);
	do {
		/* check if the file already exists */
		if (stat(s, &tmp) != 0) {
			if (errno != ENOENT) return (FILE*) NULL;
		} else {
			/* try a new name */
			outflcnt++;
			sprintf(s, "%s-%04d", outflname, outflcnt);
			continue;
		}
		/* does not exist yet */
		strcpy(outflname, s);
		f = fopen(outflname, "wb");
	} while (!f);
	return f;
}

/* read a sample from input file, and store in buffer */
/* return value is zero if end of file is reached */
/* (in this case, the input file is closed) */

int	read_next_sample(void)
{
	int	c1, c2;
	if (!infile) {
		store_sample((unsigned char) 0);	/* end of file */
		return 0;
	}
	c1 = getc(infile);
	if (c1 == EOF) {
		fclose(infile); infile = NULL; return read_next_sample();
	}
	c2 = getc(infile);
	if (c2 == EOF) {
		fclose(infile); infile = NULL; return read_next_sample();
	}
	store_sample((unsigned char) (chnl_reqd ? c2 : c1));
	return 1;
}

/* read input file until an edge is found, and update edge times */
/* return value is zero at end of file, 1 otherwise */

int	scan_for_edge(void)
{
	int	e;
	do {
		if (!read_next_sample()) return 0;	/* end of file */
		e = detect_edge();
	} while (!e);
	/* shift old edges */
	prv_edge_2 = prv_edge_1;
	prv_edge_1 = cur_edge;
	cur_edge = e;
	/* and edge times */
	prv_edge_time_2 = prv_edge_time_1;
	prv_edge_time_1 = cur_edge_time;
	cur_edge_time = time_sec;
	return 1;
}

/* read a single bit, and update CRC */
/* returns zero on error or end of file, -1 for bit=0, and 1 for bit=1 */

int	read_bit(void)
{
	double	x;
	int	n = 0;

	if (!scan_for_edge()) return 0;
	if (!scan_for_edge()) return 0;
	x = (cur_edge_time - prv_edge_time_2) / ref_period_time;
	/* check if we have found a valid bit */
	if (x > 0.500 && x < 0.950) {
		/* found bit 1 */
		n = 0x8000;
	} else if (x > 1.050 && x < 1.400) {
		/* found bit 0 */
		n = 0x0000;
	} else {
		/* invalid period time */
		print_time();
		fprintf(stderr, "invalid period time for bit: %f\n", x);
		return 0;
	}
	/* update CRC */
	crc_val ^= n;
	if (crc_val & 0x8000) crc_val ^= 0x0810;
	crc_val <<= 1;
	crc_val = (crc_val & 0xFFFE) + ((crc_val & 0x10000) >> 16);
	/* return -1 for bit=0 and 1 for bit=1 */
	n = (n ? 1 : -1);
	return n;
}

/* read a byte from input file */
/* returns the byte read, or -1 in case of error or end of file */

int	read_byte(void)
{
	int	n = 0, m, i = 8;
	do {
		m = read_bit();
		if (!m) return -1;	/* error or end of file */
		n >>= 1;
		if (m > 0) n |= 0x80;
	} while (--i);
	return n;
}

/* scan input file until a data chunk is found */
/* a return value of 1 means success, and zero is returned on error or EOF */

int	scan_for_sync(void)
{
	int	i;
	double	avg_period_time = 0.0, x, cnt;

restart:
	/* search for lead-in signal */
	do {
		if (!scan_for_edge()) return 0;
		if (!scan_for_edge()) return 0;
		/* set initial period time */
		avg_period_time = cur_edge_time - prv_edge_time_2;
		cnt = 1.0; i = 64;
		do {
			if (!scan_for_edge()) return 0;
			if (!scan_for_edge()) return 0;
			/* check for a constant period time */
			x = cur_edge_time - prv_edge_time_2;
			if ((x / avg_period_time) < 0.85
			    || (x / avg_period_time) > 1.15) break;
			/* average period times for better accuracy */
			avg_period_time = (avg_period_time * cnt + x)
					  / (cnt + 1.0);
			cnt += 1.0;
		} while (--i);
	} while (i);
	/* check for standard period times (424 us and 1000 us) */
	if (!((avg_period_time > 3.84e-4 && avg_period_time < 4.64e-4)
	      || (avg_period_time > 9.2e-4 && avg_period_time < 1.08e-3)))
		goto restart;
	ref_period_time = avg_period_time;
	print_time();
	fprintf(stderr, "attempting to synchronize to period time %f ...\n",
			ref_period_time);
resync:
	/* skip rest of lead-in signal, and search for sync bit */
	do {
		if (!scan_for_edge()) return 0;
		x = (cur_edge_time - prv_edge_time_2) / ref_period_time;
	} while (x < 1.5);
	if (x > 2.0) goto resync;		/* failed to find sync bit */
	/* sync bit found, now check for dummy byte and 0x6A */
	print_time();
	fprintf(stderr, "found sync bit (period = %f)\n", x);
	for (i = 0; i < 8; i++) {
		/* skip dummy byte */
		if (!scan_for_edge()) return 0;
		if (!scan_for_edge()) return 0;
	}
	i = read_byte();
	if (i < 0) {
		if (!infile) return 0;		/* end of file */
		else goto resync;
	}
	print_time();
	fprintf(stderr, "byte 0x6A ... ");
	if (i == 0x6A) {
		fprintf(stderr, "OK\n");
		return 1;
	} else {
		fprintf(stderr, "error: found %d instead\n", i);
		goto restart;
	}
}

int	do_read_chunk(void)
{
	int	i, hdrblk = 0, nblks, nbytes, nread = 0, crc, crc_reqd;

	/* determine chunk type */
	i = read_byte(); if (i < 0) return -1;
	print_time();
	fprintf(stderr, "block number: %d\n", i);
	if (i == 0xFF) {
		hdrblk = 1;	/* header */
		nblks = 1;
	} else if (!i) {
		return 0;	/* no data */
	} else if (i <= 16) {
		nblks = i;
	} else {
		fprintf(stderr, " *** invalid block number\n");
		return -1;
	}
	do {
		/* number of bytes to read */
		nbytes = read_byte();
		if (nbytes < 0) return -1;
		if (!nbytes) nbytes = 0x100;
		/* reset CRC */
		crc_val = 0;
		do {
			i = read_byte(); if (i < 0) return -1;
			buf[nread++] = (unsigned char) i;
		} while (--nbytes);
		/* check crc */
		crc = crc_val;
		i = read_byte(); if (i < 0) return -1;
		crc_reqd = i;
		i = read_byte(); if (i < 0) return -1;
		crc_reqd |= (i << 8);
		crc_val = 0;
		fprintf(stderr, "CRC: stored: %d, calculated: %d\n",
				crc_reqd, crc);
		if (crc_reqd != crc) {
			/* detected CRC error */
			fprintf(stderr, " *** ");
			print_time();
			fprintf(stderr, "CRC error\n");
			return -1;
		}
	} while (--nblks);
	/* return the number of bytes read */
	print_time();
	fprintf(stderr, "read data chunk (size = %d bytes)\n", nread);
	if (hdrblk) nread = -nread;
	return nread;
}

/* read a chunk of data (max 4096 bytes) to buffer */
/* return value is the number of bytes read (negative for header block), */
/* or -1 for error or EOF */

int	read_chunk(void)
{
	int		badchns = 0, i, chn;
	decode_state_t	saved_state_1, saved_state_2;

	/* try to sync on both channels */
	save_current_state(&saved_state_2);
	chn = chnl_reqd;
	chnl_reqd = 0;				/* left */
	if (!scan_for_sync())
		return -1;
	save_current_state(&saved_state_1);
	restore_previous_state(&saved_state_2);
	chnl_reqd = 1;				/* right */
	if (!scan_for_sync())
		return -1;
	save_current_state(&saved_state_2);
	if ((saved_state_2.time_sec - saved_state_1.time_sec) > 1.0) {
		badchns |= 2;
		print_time();
		fprintf(stderr, "WARNING: could not sync on right channel\n");
		chnl_reqd = 0;
	} else if ((saved_state_1.time_sec - saved_state_2.time_sec) > 1.0) {
		badchns |= 1;
		print_time();
		fprintf(stderr, "WARNING: could not sync on left channel\n");
		chnl_reqd = 1;
	} else {
		chnl_reqd = chn;
	}
nxtchn:
	/* select channel */
	if (!chnl_reqd) {
		/* use left channel */
		restore_previous_state(&saved_state_1);
	} else {
		/* use right channel */
		restore_previous_state(&saved_state_2);
	}
	/* read data */
	i = do_read_chunk();
	if (i == -1) {
		badchns |= (chnl_reqd ? 2 : 1);
		print_time();
		if (badchns != 3) {
			fprintf(stderr, "error reading channel %d, trying ",
					chnl_reqd + 1);
			chnl_reqd = 1 - chnl_reqd;
			fprintf(stderr, "channel %d instead\n", chnl_reqd + 1);
			goto nxtchn;
		}
		fprintf(stderr, "both channels have errors, bailing out ...\n");
	}
	return i;
}

/* read and decode a single file */
/* returns zero on error or end of file */

int	read_file(void)
{
	int	i, nread = 0;
	int	retval = 0;

	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "new output file\n");
	/* read header or first chunk */
	i = read_chunk();
	if (i == -1) goto endwrt;
	if (i < 0) {
		char	*c = (char*) outflname, *s = (char*) buf + 2;
		/* found header */
		i = -(i + 2);
		if (i < 1 || i > 28 || i != (int) buf[1]) {
			fprintf(stderr, " *** incorrect file name length ");
			fprintf(stderr, "(read: %d, stored: %d)\n",
					i, (int) buf[1]);
			goto endwrt;
		}
		/* store file name */
		do *c++ = *s++; while (--i);
		*c++ = '\0';
	} else {
		/* no header (possibly truncated file) */
		strcpy(outflname, "FILE");
		if (!i) goto endwrt;	/* empty file ? */
	}
	/* open output file */
	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "new output file: %s\n", outflname);
	outfl = open_output_file();
	if (!outfl) {
		fprintf(stderr, " *** error opening %s\n", outflname);
		goto endwrt;
	}
	/* store any remaining bytes */
	while (i--) {
		int	c = (int) buf[nread++];
		putc(c, outfl);
	}
	if (nread && nread < 4096) goto scwrt;	/* no more data */
	/* read all data chunks */
	do {
		i = read_chunk();
		if (i < 0) goto endwrt;		/* error */
		if (!i) goto scwrt;	/* end of data */
		do {
			int	c = (int) buf[nread++ & 0x0FFF];
			putc(c, outfl);
		} while (--i);
	} while (!(nread & 0x0FFF));
scwrt:
	retval = 1;
	/* report success */
	fprintf(stderr, " === ");
	print_time();
	fprintf(stderr, "file %s successfully decoded\n", outflname);
endwrt:
	if (outfl) {
		/* report number of bytes written */
		fflush(outfl); fclose(outfl);
		outfl = NULL;
		fprintf(stderr, " === wrote %d bytes to %s ",
				nread, outflname);
		if (!retval) fprintf(stderr, "(with errors)");
		fprintf(stderr, "\n");
	}
	return retval;
}

int	main(int argc, char **argv)
{
	int	i;
	char	*fname = NULL;

	/* parse command line args */
	i = 0;
	while (++i < argc) {
		if (!strcmp(argv[i], "-1")) {
			chnl_reqd = 0;
		} else if (!strcmp(argv[i], "-2")) {
			chnl_reqd = 1;
		} else {
			fname = argv[i];	/* input file name */
		}
	}
	if (!fname) {
		infile = stdin;
	} else {
		open_file(fname);
	}
	do {
		read_file();
	} while (infile);
	return 0;
}

