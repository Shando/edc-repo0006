
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* tape_enc.c: create 1-bit mono 24 kHz tape file from a set of input files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include <ctype.h>

static const int    lead_in_smps = 5;
static const int    bit_1_smps = 4;
static const int    bit_0_smps = 6;
static const int    sync_smps = 8;

static  FILE    *infile, *outfile;
static  char    *infile_name, *outfile_name, *infile_stored_name;
static  char    fname_buf[4096];

static  uint8_t *file_data = NULL;

static  int     bit_cnt = 0;
static  int     out_byte = 0;

static  int     fsize;

static  uint16_t    crcval = (uint16_t) 0;

/* write a single pulse to output file, with the specified half-period time */

void write_pulse(int half_period_time)
{
    int i;
    /* positive */
    for (i = 0; i < half_period_time; i++) {
      out_byte = (out_byte << 1) | 1;
      if (++bit_cnt >= 8) {
        bit_cnt = 0;
        putc(out_byte, outfile);
        out_byte = 0;
      }
    }
    /* negative */
    for (i = 0; i < half_period_time; i++) {
      out_byte = (out_byte << 1);
      if (++bit_cnt >= 8) {
        bit_cnt = 0;
        putc(out_byte, outfile);
        out_byte = 0;
      }
    }
}

/* write the specified number of cycles of lead-in signal */

void write_lead_in(int nperiods)
{
   int i;
   for (i = 0; i < nperiods; i++)
     write_pulse(lead_in_smps);
}

/* write a byte of data, and update CRC value */

void write_byte(int value)
{
    int i;
    for (i = 0; i < 8; i++) {
      if (value & 0x01) {
        write_pulse(bit_1_smps);
        crcval ^= (uint16_t) 0x8000;
      }
      else {
        write_pulse(bit_0_smps);
      }
      if (crcval & (uint16_t) 0x8000)
        crcval ^= (uint16_t) 0x0810;
      crcval = (crcval << 1) | (crcval >> 15);
      value >>= 1;
    }
}

/* write chunk header */

void write_chunk_header(void)
{
    write_lead_in(5000);
    write_pulse(sync_smps);
    write_byte(0x00);
    write_byte(0x6A);
}

/* write a block of data */

void write_data_block(uint8_t *buf, int nbytes)
{
    int new_crc;

    crcval = (uint16_t) 0;      /* reset CRC */
    while (nbytes--) {
      write_byte((int) *buf);
      buf++;
    }
    new_crc = (int) crcval;
    write_byte(new_crc & 0xFF);
    write_byte((new_crc & 0xFF00) >> 8);
}

/* write file header */

void write_header(const char *filename)
{
    uint8_t buf[256];

    write_chunk_header();
    write_byte(0xFF);
    write_byte((int) strlen(filename) + 2);
    buf[0] = (uint8_t) 0xFF;
    buf[1] = (uint8_t) strlen(filename);
    memcpy(&(buf[2]), filename, strlen(filename));
    write_data_block(&(buf[0]), (int) strlen(filename) + 2);
    write_lead_in(1000);
}

/* write a chunk (max. 4096 bytes) of data */

void write_chunk(uint8_t *buf, int nbytes)
{
    int nblocks;

    nblocks = (nbytes + 0xFF) >> 8;
    write_chunk_header();
    write_byte(nblocks);
    while (nblocks--) {
      if (nbytes > 255)
        write_byte(0x00);
      else
        write_byte(nbytes);
      write_data_block(buf, (nbytes > 255 ? 256 : nbytes));
      buf += (nbytes > 255 ? 256 : nbytes);
      nbytes -= (nbytes > 255 ? 256 : nbytes);
    }
    write_lead_in(1000);
}

/* write an entire file */

void write_file(const char *filename, uint8_t *buf, int nbytes)
{
    /* header */
    write_header(filename);
    /* data */
    while (nbytes >= 0) {
      write_chunk(buf, (nbytes > 4095 ? 4096 : nbytes));
      if (!nbytes)
        break;
      buf += (nbytes > 4095 ? 4096 : nbytes);
      nbytes -= 4096;
    }
}

int main(int argc, char **argv)
{
    int i, j;

    /* check arguments */
    if (argc < 3) {
      fprintf(stderr,
              "usage: tape_enc <infile1> [infile2 [infile3...]] <outfile>\n");
      if (argc == 2 &&
          (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-help") == 0 ||
           strcmp(argv[1], "--help") == 0))
        return 0;
      else
        return -1;
    }
    /* output file name */
    outfile_name = argv[argc - 1];
    if (outfile_name[0] == '\0') {
      fprintf(stderr, "tape_enc: invalid output file name\n");
      return -1;
    }
    /* open output file */
    outfile = fopen(outfile_name, "wb");
    if (outfile == NULL) {
      fprintf(stderr, "tape_enc: error opening '%s': %s\n",
                      outfile_name, strerror(errno));
      return -1;
    }
    /* process all input files */
    for (i = 1; i < (argc - 1); i++) {
      /* input file name */
      infile_name = argv[i];
      if (infile_name[0] == '\0') {
        fprintf(stderr, "tape_enc: invalid input file name\n");
        fflush(outfile); fclose(outfile);
        return -1;
      }
      /* stored file name: convert to upper case, and strip directory name */
      strcpy(&(fname_buf[0]), infile_name);
      for (j = (int) strlen(infile_name) - 1; j >= 0; j--) {
        if (islower((int) fname_buf[j]))
          fname_buf[j] = (char) toupper((int) fname_buf[j]);
        if (fname_buf[j] == '/' || fname_buf[j] == '\\' || fname_buf[j] == ':')
          break;
      }
      j++;
      infile_stored_name = &(fname_buf[j]);
      if (infile_stored_name[0] == '\0') {
        fprintf(stderr, "tape_enc: invalid input file name\n");
        fflush(outfile); fclose(outfile);
        return -1;
      }
      /* open input file */
      infile = fopen(infile_name, "rb");
      if (infile == NULL) {
        fprintf(stderr, "tape_enc: error opening '%s': %s\n",
                        infile_name, strerror(errno));
        fflush(outfile); fclose(outfile);
        return -1;
      }
      /* find out input file size */
      fseek(infile, 0L, SEEK_END);
      fsize = (int) ftell(infile);
      if (fsize < 1 || fsize > 262144) {
        fprintf(stderr, "tape_enc: '%s': invalid file size (%d bytes)\n",
                        infile_name, fsize);
        fclose(infile); fflush(outfile); fclose(outfile);
        return -1;
      }
      /* allocate memory */
      file_data = (uint8_t*) malloc((size_t) fsize);
      if (file_data == NULL) {
        fprintf(stderr, "tape_enc: not enough memory\n");
        fclose(infile); fflush(outfile); fclose(outfile);
        return -1;
      }
      /* print file information */
      printf("%6.1f seconds: '%s' (stored as '%s')\n",
             (double) ((int) ftell(outfile)) / 3000.0,
             infile_name, infile_stored_name);
      /* read and encode file */
      rewind(infile);
      fread((void*) file_data, (size_t) 1, (size_t) fsize, infile);
      fclose(infile);
      write_file(infile_stored_name, &(file_data[0]), fsize);
      free(file_data);
      file_data = NULL;
    }
    fflush(outfile); fclose(outfile);

    /* successfully finished encoding */
    return 0;
}

