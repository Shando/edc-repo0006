#!/bin/bash

if [ "$#" != "1" ] ; then
	echo -e "Usage: fix_tape.sh <infile>"
	exit -1 ;
fi

INFILE="$1"

TEMP_DIR="__tmpdir-$$"

if ( test -e "./conv1to8" ) ; then
	CONV1TO8="./conv1to8" ;
else
	CONV1TO8="conv1to8" ;
fi

if ( test -e "./decode2" ) ; then
	DECODE2="../decode2" ;
else
	DECODE2="decode2" ;
fi

if ( test -e "./tape_enc" ) ; then
	TAPE_ENC="../tape_enc" ;
else
	TAPE_ENC="tape_enc" ;
fi

rm -Rf "$TEMP_DIR"
mkdir "$TEMP_DIR"

"$CONV1TO8" < "$INFILE" > "${TEMP_DIR}/__tmp__XfQlcNrS__.dat"
cd "$TEMP_DIR"
"$DECODE2" < "__tmp__XfQlcNrS__.dat"
rm -f "__tmp__XfQlcNrS__.dat"
find . -type f -exec "$TAPE_ENC" '{}' '../{}.tap' ';'
cd ..
rm -Rf "$TEMP_DIR"

