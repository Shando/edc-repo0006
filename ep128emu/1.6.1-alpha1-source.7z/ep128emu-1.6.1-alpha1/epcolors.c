
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#include <ep128.h>

/* apply gamma correction, contrast, and brightness */

static double
        do_color_correction(double old_intensity,
                            double color_gamma_1, double color_gamma_2,
                            double min_intensity_1, double min_intensity_2,
                            double max_intensity_1, double max_intensity_2)
{
    double  gamma, scale, offset, new_intensity;

    /* calculate overall gamma, contrast, and brightness */
    gamma = color_gamma_1 * color_gamma_2;
    scale = (max_intensity_1 - min_intensity_1)
            * (max_intensity_2 - min_intensity_2);
    offset = min_intensity_1 + min_intensity_2;
    /* apply in order of gamma, contrast, and brightness */
    new_intensity = pow(old_intensity, gamma);
    new_intensity *= scale;
    new_intensity += offset;
    /* limit to valid range */
    if (new_intensity < 0.0)
      new_intensity = 0.0;
    if (new_intensity > 1.0)
      new_intensity = 1.0;
    /* return new intensity value */
    return new_intensity;
}

/* convert 8-bit NICK color value to 24-bit RGB with color correction */
/* (gamma, contrast, and brightness) */

void NICKColorToRGB(int nick_color, int *r, int *g, int *b)
{
    double  r0, g0, b0;         /* in the range 0 to 1 */
    int     r1, g1, b1;         /* in the range 0 to 255 */

    /* raw intensity values (red: 0 to 7, green: 0 to 7, blue: 0 to 3) */
    /* bit 0 */
    r1 = (nick_color & 1);
    g1 = (nick_color & 2) >> 1;
    b1 = (nick_color & 4) >> 2;
    /* bit 1 */
    r1 <<= 1; g1 <<= 1; b1 <<= 1;
    nick_color >>= 3;
    r1 |= (nick_color & 1);
    g1 |= (nick_color & 2) >> 1;
    b1 |= (nick_color & 4) >> 2;
    /* bit 2 (red and green only) */
    r1 <<= 1; g1 <<= 1;
    nick_color >>= 3;
    r1 |= (nick_color & 1);
    g1 |= (nick_color & 2) >> 1;
    /* convert to floating point 0 to 1 range */
    r0 = (double) r1 / 7.0;
    g0 = (double) g1 / 7.0;
    b0 = (double) b1 / 3.0;
    /* apply color correction */
    r0 = do_color_correction(r0, color_gamma, color_gamma_R,
                                 min_intensity, min_intensity_R,
                                 max_intensity, max_intensity_R);
    g0 = do_color_correction(g0, color_gamma, color_gamma_G,
                                 min_intensity, min_intensity_G,
                                 max_intensity, max_intensity_G);
    b0 = do_color_correction(b0, color_gamma, color_gamma_B,
                                 min_intensity, min_intensity_B,
                                 max_intensity, max_intensity_B);
    /* convert to integer 0 to 255 range */
    /* do_color_correction() should have already limited the floating point */
    /* intensity values to the valid range */
    *r = (int) (r0 * 255.0 + 0.5);
    *g = (int) (g0 * 255.0 + 0.5);
    *b = (int) (b0 * 255.0 + 0.5);
}

