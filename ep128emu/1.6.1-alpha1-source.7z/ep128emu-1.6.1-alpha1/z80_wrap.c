
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* z80_wrap.c: wrapper interface to Kevin Thacker's Z80 emulator */

#include <ep128.h>
#include "z80/z80.h"

double  cpu_frequency = 4000000.0;      /* CPU clock frequency in Hz         */
double  cpu_alternate_frequency = 25000000.0;   /* alternate CPU clock freq. */
double  no_memory_wait_frequency = 8000000.0;   /* disable memory timing if  */
                                                /*   CPU frq. >= this value  */
double  vram_clock_ratio = 0.22;        /* video memory frequency / CPU frq. */
double  vram_latency_f = 0.25;          /* video mem. latency in Z80 cycles  */

/* the following cycle counts are all multiplied by 65536 */
static  int     cpu_extra_wait_cycles = 0;  /* cycles to wait on opcode read */
static  int     memory_wait_cycles = 0;     /* cycles to wait on any memory */
                                            /*   access */

static  uint32_t  vram_timeslice;       /* in CPU cycles * 65536 */
static  uint32_t  vram_latency;
static  uint32_t  Z80CyclesToVRAMCycles[32];
/* number of CPU cycles * 65536 in a single system sync frame */
static  int       cpu_cycles_per_master_cycle = 0;
static  int       memory_timing_is_enabled = -1;

static  uint32_t  cpu_cycles = (uint32_t) 0;
static  uint32_t  vram_cycles = (uint32_t) 0;

static  int     is_initialized = 0;

extern  void    Z80_Init(void);
extern  void    Z80_Reset(void);
extern  void    Z80_ExecuteInstruction(void);
extern  void    Z80_TriggerInterrupt(void);
extern  void    Z80_ClearInterrupt(void);

extern  void    (*Z80_ErrorFunction)(char*);
extern  void    (*Z80_UserInterruptFunction)(void);
extern  void    (*Z80_UserAckInterruptFunction)(void);

static  void    ErrorFunction(char *msg);
static  void    UserInterruptFunction(void);
static  void    UserAckInterruptFunction(void);

/* update the number of CPU cycles elapsed */
void              (*Z80_UpdateCycles)(int x) = NULL;
static  void      Z80_UpdateCycles_Normal(int x);
static  void      Z80_UpdateCycles_Fast(int x);
/* read a byte from memory */
uint8_t           (*Z80_RD_MEM)(uint16_t addr) = NULL;
static  uint8_t   Z80_RD_MEM_Normal(uint16_t addr);
static  uint8_t   Z80_RD_MEM_Fast(uint16_t addr);
/* write a byte to memory */
void              (*Z80_WR_MEM)(uint16_t addr, uint8_t value) = NULL;
static  void      Z80_WR_MEM_Normal(uint16_t addr, uint8_t value);
static  void      Z80_WR_MEM_Fast(uint16_t addr, uint8_t value);
/* read the first byte of an opcode */
uint8_t           (*Z80_RD_OPCODE_FIRST_BYTE)(void) = NULL;
static  uint8_t   Z80_RD_OPCODE_FIRST_BYTE_Normal(void);
static  uint8_t   Z80_RD_OPCODE_FIRST_BYTE_Fast(void);
/* read an opcode byte ('Offset' should not be zero) */
uint8_t           (*Z80_RD_OPCODE_BYTE)(int Offset) = NULL;
static  uint8_t   Z80_RD_OPCODE_BYTE_Normal(int Offset);
static  uint8_t   Z80_RD_OPCODE_BYTE_Fast(int Offset);

static  Z80_REGISTERS   *z80_registers_ptr = NULL;

/* set Z80 clock frequency to 'frq' (in Hz) */

void set_cpu_frequency(double frq)
{
    /* set new frequency */
    cpu_frequency = frq;
    /* calculate timeslice */
    cpu_cycles_per_master_cycle =
      (int) (65536.0 * (cpu_frequency / master_clock_freq) + 0.5);
    /* check if memory wait configuration needs to be changed */
    if (memory_timing_is_enabled != 1 &&
        cpu_frequency < no_memory_wait_frequency) {
      /* select timing functions */
      Z80_UpdateCycles = Z80_UpdateCycles_Normal;
      Z80_RD_MEM = Z80_RD_MEM_Normal;
      Z80_WR_MEM = Z80_WR_MEM_Normal;
      Z80_RD_OPCODE_FIRST_BYTE = Z80_RD_OPCODE_FIRST_BYTE_Normal;
      Z80_RD_OPCODE_BYTE = Z80_RD_OPCODE_BYTE_Normal;
      /* correct video memory cycle count */
      vram_cycles = cpu_cycles;
      /* now enabled */
      memory_timing_is_enabled = 1;
      printMsg("Memory timing ON\n");
    }
    else if (memory_timing_is_enabled != 0 &&
             cpu_frequency >= no_memory_wait_frequency) {
      /* select timing functions */
      Z80_UpdateCycles = Z80_UpdateCycles_Fast;
      Z80_RD_MEM = Z80_RD_MEM_Fast;
      Z80_WR_MEM = Z80_WR_MEM_Fast;
      Z80_RD_OPCODE_FIRST_BYTE = Z80_RD_OPCODE_FIRST_BYTE_Fast;
      Z80_RD_OPCODE_BYTE = Z80_RD_OPCODE_BYTE_Fast;
      /* now disabled */
      memory_timing_is_enabled = 0;
      printMsg("Memory timing OFF\n");
    }
}

/* perform next (1 / master_clock_freq) timeslice of Z80 emulation        */
/* returns zero in case of success, and -1 if an invalid instruction was  */
/* encountered (in the latter case, PC will point to the bad instruction) */

int cpu_perform(void)
{
    while ((int) cpu_cycles < cpu_cycles_per_master_cycle) {
      Z80_ExecuteInstruction();
    }
    /* flush cycle counts, knowing that */
    /* cpu_cycles_per_master_cycle <= cpu_cycles <= vram_cycles */
    cpu_cycles -= (uint32_t) cpu_cycles_per_master_cycle;
    vram_cycles -= (uint32_t) cpu_cycles_per_master_cycle;

    return 0;
}

/* reset CPU */

void reset_cpu(void)
{
    int i;

    if (!is_initialized) {
      /* convert video memory timing parameters */
      vram_timeslice = (uint32_t) ((65536.0 / vram_clock_ratio) + 0.5);
      vram_latency = (uint32_t) (vram_latency_f * 65536.0 + 65535.5);
      /* calculate look-up table for synchronizing Z80 and video memory */
      for (i = 0; i < 32; i++) {
        /* all Z80 opcodes take less than 32 cycles to execute, */
        /* so a table of this size is safe */
        Z80CyclesToVRAMCycles[i] =
          ((uint32_t) (i << 16) / vram_timeslice) * vram_timeslice;
      }
      /* initialize CPU on first call */
      set_cpu_frequency(cpu_frequency);
      Z80_Init();
      Z80_ErrorFunction = ErrorFunction;
      Z80_UserInterruptFunction = UserInterruptFunction;
      Z80_UserAckInterruptFunction = UserAckInterruptFunction;
      is_initialized = 1;
      /* get pointer to registers */
      z80_registers_ptr = Z80_GetReg();
    }
    Z80_Reset();
    /* reset cycle counts */
    cpu_cycles = (uint32_t) 0;
    vram_cycles = (uint32_t) 0;
    /* hack to get some programs using interrupt mode 2 working */
    Z80_SetVectorBase(0xFF);
}

/* interrupt call */

void cpu_interrupt(void)
{
    Z80_TriggerInterrupt();
}

void cpu_clear_interrupt(void)
{
    Z80_ClearInterrupt();
}

/* interface functions for external Z80 implementation */

static void ErrorFunction(char *msg)
{
    printMsg("%s\n", msg);
}

static void UserInterruptFunction(void)
{
}

static void UserAckInterruptFunction(void)
{
}

/* ---- Z80 and memory timing functions ---- */

/* update the number of CPU cycles elapsed */

static void Z80_UpdateCycles_Normal(int x)
{
    cpu_cycles += ((uint32_t) (x << 16));
    vram_cycles += Z80CyclesToVRAMCycles[x];
    if (vram_cycles <= cpu_cycles)
      vram_cycles += vram_timeslice;
}

static void Z80_UpdateCycles_Fast(int x)
{
    cpu_cycles += ((uint32_t) (x << 16));
}

/* memory wait functions, take page number (0-3) as argument */

static inline void Z80_OpcodeWait(int p)
{
    uint32_t  ncycles;

    if (page_segment[p] < 0xFC)
      ncycles = (uint32_t) cpu_extra_wait_cycles;
    else
      ncycles = ((vram_cycles - cpu_cycles) + vram_latency)
                & (uint32_t) 0xFFFF0000UL;
    cpu_cycles += ncycles;
    vram_cycles += Z80CyclesToVRAMCycles[ncycles >> 16];
    if (vram_cycles <= cpu_cycles)
      vram_cycles += vram_timeslice;
}

static inline void Z80_MemoryWait(int p)
{
    uint32_t  ncycles;

    if (page_segment[p] < 0xFC)
      ncycles = (uint32_t) memory_wait_cycles;
    else
      ncycles = ((vram_cycles - cpu_cycles) + vram_latency)
                & (uint32_t) 0xFFFF0000UL;
    cpu_cycles += ncycles;
    vram_cycles += Z80CyclesToVRAMCycles[ncycles >> 16];
    if (vram_cycles <= cpu_cycles)
      vram_cycles += vram_timeslice;
}

/* read a byte from memory */

static uint8_t Z80_RD_MEM_Normal(uint16_t addr)
{
    int p = (int) addr >> 14;
    Z80_MemoryWait(p);
    return (*((uint8_t*) (page_address_table[p]) + (int) addr));
}

static uint8_t Z80_RD_MEM_Fast(uint16_t addr)
{
    return (*((uint8_t*) (page_address_table[(int) addr >> 14]) + (int) addr));
}

/* write a byte to memory */

static void Z80_WR_MEM_Normal(uint16_t addr, uint8_t value)
{
    int p = (int) addr >> 14;
    Z80_MemoryWait(p);
    if (is_page_rom[p])
      return;                   /* cannot write ROM */
    *((uint8_t*) (page_address_table[p]) + (int) addr) = value;
}

static void Z80_WR_MEM_Fast(uint16_t addr, uint8_t value)
{
    int p = (int) addr >> 14;
    if (is_page_rom[p])
      return;                   /* cannot write ROM */
    *((uint8_t*) (page_address_table[p]) + (int) addr) = value;
}

/* read a 16-bit word from memory */

uint16_t Z80_RD_MEM_WORD(uint16_t addr)
{
    return (((uint16_t) Z80_RD_MEM(addr))
            | ((uint16_t) Z80_RD_MEM(addr + (uint16_t) 1) << 8));
}

/* write a 16-bit word to memory */

void Z80_WR_MEM_WORD(uint16_t addr, uint16_t value)
{
    Z80_WR_MEM(addr, (uint8_t) (value & (uint16_t) 0x00FF));
    Z80_WR_MEM(addr + (uint16_t) 1,
               (uint8_t) ((value & (uint16_t) 0xFF00) >> 8));
}

/* write a byte to an I/O port */

void Z80_DoOut(uint16_t addr, uint8_t value)
{
    addr &= (uint16_t) 0x00FF;
    io_write_8(addr, value);
}

/* read a byte from an I/O port */

uint8_t Z80_DoIn(uint16_t addr)
{
    addr &= (uint16_t) 0x00FF;
    return (uint8_t) io_read_8(addr);
}

/* read the first byte of an opcode */

static uint8_t Z80_RD_OPCODE_FIRST_BYTE_Normal(void)
{
    uint8_t   *pAddr;
    int       p;
    uint16_t  Addr;

    Addr = (uint16_t) (z80_registers_ptr->PC.W.l);
    p = (int) Addr >> 14;
    Z80_OpcodeWait(p);
    pAddr = (uint8_t *) (page_address_table[p]) + (size_t) Addr;

    return (*pAddr);
}

static uint8_t Z80_RD_OPCODE_FIRST_BYTE_Fast(void)
{
    uint8_t   *pAddr;
    uint16_t  Addr;

    Addr = (uint16_t) (z80_registers_ptr->PC.W.l);
    pAddr = (uint8_t *) (page_address_table[(int) Addr >> 14]) + (size_t) Addr;

    return (*pAddr);
}

/* read an opcode byte ('Offset' should not be zero) */

static uint8_t Z80_RD_OPCODE_BYTE_Normal(int Offset)
{
    uint8_t   *pAddr;
    int       p;
    uint16_t  Addr;

    Addr = (uint16_t) ((int) z80_registers_ptr->PC.W.l + Offset);
    p = (int) Addr >> 14;
    Z80_MemoryWait(p);
    pAddr = (uint8_t *) (page_address_table[p]) + (size_t) Addr;

    return (*pAddr);
}

static uint8_t Z80_RD_OPCODE_BYTE_Fast(int Offset)
{
    uint8_t   *pAddr;
    uint16_t  Addr;

    Addr = (uint16_t) ((int) z80_registers_ptr->PC.W.l + Offset);
    pAddr = (uint8_t *) (page_address_table[(int) Addr >> 14]) + (size_t) Addr;

    return (*pAddr);
}

/* read an opcode word ('Offset' should not be zero) */

uint16_t Z80_RD_OPCODE_WORD(int Offset)
{
    return ((uint16_t) Z80_RD_OPCODE_BYTE(Offset)
            | (uint16_t) (Z80_RD_OPCODE_BYTE(Offset + 1)) << 8);
}

/* set memory wait states */

void set_memory_wait(int opcode_read, int all_access)
{
    cpu_extra_wait_cycles = opcode_read << 16;
    memory_wait_cycles = all_access << 16;
}

/* save all CPU registers to file 'f', writing 64 bytes of data */
/* returns zero in case of success */

int save_cpu_state(FILE *f)
{
    int retval = 0;
    Z80_REGISTERS *r;

    r = z80_registers_ptr;

    fputc((int) r->PC.B.h, f);
    fputc((int) r->PC.B.l, f);
    fputc((int) r->AF.B.h, f);
    fputc((int) r->AF.B.l, f);
    fputc((int) r->BC.B.h, f);
    fputc((int) r->BC.B.l, f);
    fputc((int) r->DE.B.h, f);
    fputc((int) r->DE.B.l, f);
    fputc((int) r->HL.B.h, f);
    fputc((int) r->HL.B.l, f);
    fputc((int) r->SP.B.h, f);
    fputc((int) r->SP.B.l, f);

    fputc((int) r->IX.B.h, f);
    fputc((int) r->IX.B.l, f);
    fputc((int) r->IY.B.h, f);
    fputc((int) r->IY.B.l, f);
    snapshot_write_uint16((uint16_t) r->IndexPlusOffset, f);

    fputc((int) r->altAF.B.h, f);
    fputc((int) r->altAF.B.l, f);
    fputc((int) r->altBC.B.h, f);
    fputc((int) r->altBC.B.l, f);
    fputc((int) r->altDE.B.h, f);
    fputc((int) r->altDE.B.l, f);
    fputc((int) r->altHL.B.h, f);
    fputc((int) r->altHL.B.l, f);

    fputc((int) r->I, f);
    fputc((int) r->R, f);
    fputc((int) r->IFF1, f);
    fputc((int) r->IFF2, f);
    fputc((int) r->RBit7, f);
    fputc((int) r->IM, f);
    fputc((int) r->TempByte, f);
    fputc((int) r->InterruptVectorBase, f);

    snapshot_write_uint32((uint32_t) r->Flags, f);

    /* padding */
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint16((uint16_t) 0, f);

    return retval;      /* TODO: error handling */
}

/* load all CPU registers from file 'f', using file format specified by */
/* 'file_version'. Returns zero in case of success. */

int load_cpu_state(FILE *f, int file_version)
{
    int retval = 0;
    Z80_REGISTERS *r;

    if (file_version != 0x0101 && file_version != 0x0102)
      return -1;

    r = z80_registers_ptr;
    memset(r, 0, sizeof(Z80_REGISTERS));

    r->PC.B.h = (Z80_BYTE) fgetc(f);
    r->PC.B.l = (Z80_BYTE) fgetc(f);
    r->AF.B.h = (Z80_BYTE) fgetc(f);
    r->AF.B.l = (Z80_BYTE) fgetc(f);
    r->BC.B.h = (Z80_BYTE) fgetc(f);
    r->BC.B.l = (Z80_BYTE) fgetc(f);
    r->DE.B.h = (Z80_BYTE) fgetc(f);
    r->DE.B.l = (Z80_BYTE) fgetc(f);
    r->HL.B.h = (Z80_BYTE) fgetc(f);
    r->HL.B.l = (Z80_BYTE) fgetc(f);
    r->SP.B.h = (Z80_BYTE) fgetc(f);
    r->SP.B.l = (Z80_BYTE) fgetc(f);

    r->IX.B.h = (Z80_BYTE) fgetc(f);
    r->IX.B.l = (Z80_BYTE) fgetc(f);
    r->IY.B.h = (Z80_BYTE) fgetc(f);
    r->IY.B.l = (Z80_BYTE) fgetc(f);
    r->IndexPlusOffset = (Z80_WORD) snapshot_read_uint16(f);

    r->altAF.B.h = (Z80_BYTE) fgetc(f);
    r->altAF.B.l = (Z80_BYTE) fgetc(f);
    r->altBC.B.h = (Z80_BYTE) fgetc(f);
    r->altBC.B.l = (Z80_BYTE) fgetc(f);
    r->altDE.B.h = (Z80_BYTE) fgetc(f);
    r->altDE.B.l = (Z80_BYTE) fgetc(f);
    r->altHL.B.h = (Z80_BYTE) fgetc(f);
    r->altHL.B.l = (Z80_BYTE) fgetc(f);

    r->I        = (Z80_BYTE) fgetc(f);
    r->R        = (Z80_BYTE) fgetc(f);
    r->IFF1     = (Z80_BYTE) fgetc(f);
    r->IFF2     = (Z80_BYTE) fgetc(f);
    r->RBit7    = (Z80_BYTE) fgetc(f);
    r->IM       = (Z80_BYTE) fgetc(f);
    r->TempByte = (Z80_BYTE) fgetc(f);
    r->InterruptVectorBase = (Z80_BYTE) fgetc(f);
    /* hack to get some programs using interrupt mode 2 working */
    r->InterruptVectorBase = (Z80_BYTE) 0xFF;

    r->Flags = (unsigned long) snapshot_read_uint32(f);

    /* padding */
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint16(f);

    /* reset cycle counts */
    cpu_cycles = (uint32_t) 0;
    vram_cycles = (uint32_t) 0;

    return retval;      /* TODO: error handling */
}

/* return the size of CPU snapshot data (in bytes) for snapshot file */
/* version 'file_version' */

int cpu_snapshot_bytes(int file_version)
{
    switch (file_version) {
    case 0x0101:
    case 0x0102:
      return 64;
    default:
      return -1;
    }
}

