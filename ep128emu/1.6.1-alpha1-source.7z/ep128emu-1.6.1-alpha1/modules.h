
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_MODULES_H
#define EP128_MODULES_H

/* modules.h -- interface to audio and video driver modules */

#include <stdint.h>

/* ======== global configuration variables ======== */

/* ---- sound ---- */

extern  char    *sound_driver;  /* sound output module name             */

extern  int     buffer_size;    /* total buffer size in samples         */
extern  int     period_size;    /* buffer fragment size in samples      */
extern  int     disable_sound;  /* disable sound output (zero: no)      */
                                /*   bit 0 is set: disabled in cfg file */
                                /*   bit 1 is set: disabled at run-time */
extern  char    *sound_device;  /* sound device name                    */

/* ---- video ---- */

extern  char  *video_driver;          /* video output module name           */

extern  int   emulator_ui_mode;       /* 0: emulation, 1: program control   */

extern  int   display_fullscreen;     /* 1: enable fullscreen mode          */
extern  int   display_hardware_mode;  /* 1: use direct framebuffer access   */
extern  int   display_doublebuf;      /* 1: enable double buffered display  */
extern  int   display_half_size;      /* 1: half resolution                 */
extern  int   display_interlace;      /* 1: enable interlaced display       */
extern  int   display_blit_on_change; /* 1: update display on change only   */
extern  int   display_half_refresh;   /* !=0: blit 25 frames per second     */
                                      /*   bit 0: controlled by user        */
                                      /*   bit 1: controlled by snd driver  */
extern  int   display_window_width;   /* window width in pixels             */
                                      /*   (at full resolution)             */
extern  int   display_window_height;  /* window height in pixels            */
                                      /*   (at full resolution)             */
extern  int   display_x_shift;        /* display shift right (in pixels)    */
extern  int   display_y_shift;        /* display shift down (in pixels)     */
/* color correction parameters */
extern  double  min_intensity;
extern  double  min_intensity_R, min_intensity_G, min_intensity_B;
extern  double  max_intensity;
extern  double  max_intensity_R, max_intensity_G, max_intensity_B;
extern  double  color_gamma;
extern  double  color_gamma_R, color_gamma_G, color_gamma_B;
/* OpenGL parameters */
extern  int     gl_antialias;       /* enable linear filtering               */
extern  int     gl_txtheight;       /* texture height is (1 << gl_txtheight) */
extern  double  gl_zoom;            /* zoom window size by this factor       */

/* the following globals are internal variables, and are not set by the user */

extern uint8_t key_matrix[];            /* keyboard matrix                  */
extern int     key_matrix_row_select;   /* keyboard matrix row select       */
extern int     half_refresh_is_allowed; /* if this variable is non-zero,    */
                                        /*   the sound driver may set half  */
                                        /*   refresh mode on buf. underrun  */

extern  int     display_min_line;     /* (624 - display_window_height) / 2  */
extern  int     display_max_line;     /* 624 - display_min_line             */
extern  int     display_sync_line;    /* (590 + display_min_line)           */
                                      /*   + display_y_shift                */
extern  int     display_left_offset;  /* (992 - display_window_width) / 2   */
                                      /*   - display_x_shift                */

/* ======== types ======== */

/* sound driver description */

typedef struct SoundModule_s {
    char    *DriverName;
    int     (*InitFunction)(void);
    void    (*PlayFunction)(int16_t sample_left, int16_t sample_right);
    void    (*CloseFunction)(void);
} SoundModule_t;

/* video driver description */

typedef struct VideoModule_s {
    char    *DriverName;
    int     (*InitFunction)(int *argc, char ***argv);
    void    (*DrawFunction)(int line_number, const uint8_t *data,
                            uint8_t border_color, int lmarg, int rmarg);
    int     (*EventFunction)(void);
    void    (*CloseFunction)(void);
} VideoModule_t;

/* ======== interface functions ======== */

/* load the modules selected by user; returns zero on success */

extern  int     load_driver_modules(void);

/* ---- sound ---- */

/* initialize sound card (returns zero on success) */

extern  int     (*soundcard_initialize)(void);

/* send a sample to DAC */

extern  void    (*soundcard_write_data)(int16_t sample_left,
                                        int16_t sample_right);

/* close sound output */

extern  void    (*soundcard_close)(void);

/* ---- video ---- */

/* initialize graphics system */

extern  int     (*init_graphics)(int *argc, char ***argv);

/* draw a line (line number should be in the range 0 to 623) */
/* 'data' is an array of 1024 8-bit integers */
/* borders are drawn with 'border_color', using margin positions */
/* 'lmarg' and 'rmarg' (specified in character units, 0 to 63) */

extern  void    (*draw_line)(int line_number, const uint8_t *data,
                             uint8_t border_color, int lmarg, int rmarg);

/* read keyboard events and update matrix values */
/* returns non-zero if the event is "close window" */

extern  int     (*process_events)(void);

/* de-initialize graphics (this function may not return) */

extern  void    (*destroy_graphics)(void);

#endif      /* EP128_MODULES_H */

