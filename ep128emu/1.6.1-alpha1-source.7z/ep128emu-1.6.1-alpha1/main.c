
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* main.c: ep128emu main function */

#include <ep128.h>
#ifdef LINUX
#include <unistd.h>
#include <sys/types.h>
#endif

double  master_clock_freq = 96000.0;    /* system sync frequency */
int     ram_kilobytes = 128;            /* amount of RAM in kilobytes */

/* limit options to useful range */

static void check_options(void)
{
    limit_double_to_range(&master_clock_freq, 10000.0, 1000000.0);
    limit_double_to_range(&sound_sample_rate, 11025.0, 192000.0);
    limit_int_to_range(&sound_oversample, 1, 16);
    fix_boolean_value(&disable_sound);
    limit_double_to_range(&DC_block_1_frq, 0.1, 100.0);
    limit_double_to_range(&DC_block_2_frq, 0.1, 100.0);
    limit_double_to_range(&amplitude_scale, -4.0, 4.0);
    limit_double_to_range(&cpu_frequency, 1000000.0, 200000000.0);
    limit_double_to_range(&cpu_alternate_frequency, 1000000.0, 200000000.0);
    limit_double_to_range(&no_memory_wait_frequency, 1000000.0, 200000000.0);
    limit_double_to_range(&vram_clock_ratio, 0.1, 1.0);
    limit_double_to_range(&vram_latency_f, 0.0, 4.0);
    limit_int_to_range(&ram_kilobytes, 64, 3968);
    limit_double_to_range(&tape_sample_rate, 12000.0, 96000.0);
    fix_boolean_value(&tape_feedback_enable);
    fix_boolean_value(&fast_tape_mode);
    limit_double_to_range(&color_gamma, 0.1, 10.0);
    limit_double_to_range(&min_intensity, 0.0, 1.0);
    limit_double_to_range(&max_intensity, 0.0, 1.0);
    limit_double_to_range(&color_gamma_R, 0.1, 10.0);
    limit_double_to_range(&min_intensity_R, 0.0, 1.0);
    limit_double_to_range(&max_intensity_R, 0.0, 1.0);
    limit_double_to_range(&color_gamma_G, 0.1, 10.0);
    limit_double_to_range(&min_intensity_G, 0.0, 1.0);
    limit_double_to_range(&max_intensity_G, 0.0, 1.0);
    limit_double_to_range(&color_gamma_B, 0.1, 10.0);
    limit_double_to_range(&min_intensity_B, 0.0, 1.0);
    limit_double_to_range(&max_intensity_B, 0.0, 1.0);
    limit_int_to_range(&display_window_width, 320, 1024);
    limit_int_to_range(&display_window_height, 240, 624);
    limit_int_to_range(&display_x_shift, -64, 64);
    limit_int_to_range(&display_y_shift, -64, 64);
    fix_boolean_value(&display_fullscreen);
    fix_boolean_value(&display_hardware_mode);
    fix_boolean_value(&display_doublebuf);
    fix_boolean_value(&display_half_size);
    fix_boolean_value(&display_interlace);
    fix_boolean_value(&display_blit_on_change);
    fix_boolean_value(&display_half_refresh);
    fix_boolean_value(&gl_antialias);
    limit_int_to_range(&gl_txtheight, 2, 6);
    limit_double_to_range(&gl_zoom, 0.25, 4.0);
    fix_boolean_value(&GLconsole_is_enabled);
    limit_double_to_range(&console_bg_R, 0.0, 1.0);
    limit_double_to_range(&console_bg_G, 0.0, 1.0);
    limit_double_to_range(&console_bg_B, 0.0, 1.0);
    limit_double_to_range(&console_bg_A, 0.0, 1.0);
    limit_double_to_range(&console_fg_R, 0.0, 1.0);
    limit_double_to_range(&console_fg_G, 0.0, 1.0);
    limit_double_to_range(&console_fg_B, 0.0, 1.0);
    limit_double_to_range(&console_fg_A, 0.0, 1.0);
    fix_boolean_value(&console_to_stderr);
}

int main(int argc, char **argv)
{
    int nlines, tsmps;
    int retval = -1;

    /* read command line and configuration file options */
    if (parse_config_file(argc, argv) != 0)
      return -1;
    /* initialize message printing system */
    if (msg_initialize() != 0)
      return -1;
    /* print copyright information */
    print_copyright_info();
    /* limit parameters to a useful range */
    check_options();
    /* calculate time constants */
    nlines = time_to_nlines(1.0 / master_clock_freq);
    tsmps = time_to_tape_samples(1.0 / master_clock_freq);
    /* load sound and video drivers */
    if (load_driver_modules() != 0)
      goto err_1;
    /* initialize system */
    if (init_graphics(&argc, &argv) != 0)
      goto err_1;
#ifdef LINUX
    if ((int) geteuid() == 0)
      setuid(getuid());         /* give up root privileges */
#endif
    reset_cpu();
    if (wd177x_initialize() == -1)
      goto err_1;
    if (initialize_memory(ram_kilobytes >> 4) != 0)
      goto err_2;
    if (initialize_dave() != 0)
      goto err_3;
    tape_file_name = tape_file_name_0;      /* default tape file */
    tape_init();
    nick_reset();
    /* loop until window is closed, or a fatal error occurs */
    do {
      nick_draw_lines(nlines);
      dave_perform();
      tape_play(tsmps);
      if (process_events()) break;
    } while (!cpu_perform());
    /* shut down */
    retval = 0;     /* no error */
    close_dave();
    tape_close();
 err_3:
    destroy_memory();
 err_2:
    wd177x_close();
 err_1:
    msg_close();

    return retval;
}

