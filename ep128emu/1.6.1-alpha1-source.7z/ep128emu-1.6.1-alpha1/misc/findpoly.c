
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static inline int parity17(int n)
{
    n = (n & 0x00555555) ^ ((n & 0x00AAAAAA) >> 1);
    n = (n & 0x00111111) ^ ((n & 0x00444444) >> 2);
    n = (n & 0x00010101) ^ ((n & 0x00101010) >> 4);
    n = (n & 0x00010001) ^ ((n & 0x00000100) >> 8);
    n = (n & 0x00000001) ^ ((n & 0x00010000) >> 16);

    return n;
}

static int buf[262144];
static int pattern_buf[131072];

int main(int argc, char **argv)
{
    int i, j, k, bits, n, out, poly, pl, len;

    if (argc != 3) {
      fprintf(stderr, "Usage: findpoly <nBits> <pattern>\n");
      return -1;
    }
    bits = (int) atoi(argv[1]);
    len = (1 << bits) - 1;
    pl = (int) strlen(argv[2]);
    if (pl < 4 || pl > len) {
      fprintf(stderr, " *** pattern has invalid length\n");
      return -1;
    }
    for (i = 0; i < pl; i++) {
      if (argv[2][i] != '0' && argv[2][i] != '1') {
        fprintf(stderr, " *** invalid character in pattern\n");
        return -1;
      }
      /* store in reverse order */
      pattern_buf[(pl - 1) - i] = (int) argv[2][i] - '0';
    }

    for (poly = (1 << (bits - 1)); poly <= len; poly++) {
      n = 0x7FFFFFFF;
      out = 1;
      fprintf(stderr, "\rtesting polynomial %08X ...", (unsigned int) poly);
      /* twice so that the pattern can be found even at wrap-around */
      for (i = 0; i < (len << 1); i++) {
        buf[i] = (1 - out);
        if (i >= (pl - 1)) {
          k = i - pl;
          for (j = 0; j < pl; j++) {
            k++;
            if (buf[k] != pattern_buf[j])
              break;
          }
          if (j >= pl) {
            fprintf(stderr,
                    "\n === found polynomial %08X\n", (unsigned int) poly);
            break;
          }
        }
        out ^= parity17(n & poly);
        n = (n << 1) | out;
      }
    }
    fprintf(stderr, "\n\n");

    return 0;
}

