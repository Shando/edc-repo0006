
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* s_alsa.c: ALSA sound output */

#include <ep128.h>

/* check if use of old (0.9.x) ALSA API was requested */

#if (defined(USE_OLD_ALSA_API) || defined(ALSA_PCM_OLD_HW_PARAMS_API))
#ifndef USE_OLD_ALSA_API
#define USE_OLD_ALSA_API 1
#endif
#ifndef ALSA_PCM_OLD_HW_PARAMS_API
#define ALSA_PCM_OLD_HW_PARAMS_API 1
#endif
#ifndef ALSA_PCM_OLD_SW_PARAMS_API
#define ALSA_PCM_OLD_SW_PARAMS_API 1
#endif
#endif

#include <alsa/asoundlib.h>
#include <unistd.h>

/* find out which ALSA API version is to be used */

#ifdef USE_OLD_ALSA_API
#define NEW_ALSA_API 0
#elif (SND_LIB_MAJOR == 1)
#define NEW_ALSA_API 1
#elif (SND_LIB_MAJOR == 0 && SND_LIB_MINOR == 9)
#define NEW_ALSA_API 0
#else
#error "unsupported ALSA version"
#endif

#define MIN_BUFFER_SIZE 128
#define MAX_BUFFER_SIZE 16384
#define MIN_PERIOD_SIZE 16
#define MAX_PERIOD_SIZE 8192

static  int16_t snd_buf[MAX_PERIOD_SIZE << 1];
static  int     bufpos = 0;

static  int     device_is_open  = 0;

static  snd_pcm_t               *dev_handle;
static  snd_pcm_hw_params_t     *dev_hw_params;
static  snd_pcm_sw_params_t     *dev_sw_params;

/* initialize sound card (returns zero on success) */

static int soundcard_initialize_(void)
{
    int                 sr_int, dir;
#if (NEW_ALSA_API == 1)
    snd_pcm_uframes_t   buf_size;
#endif

    /* there is nothing to do if sound is disabled */
    if (disable_sound & 1) {
      device_is_open = 1;
      return 0;
    }

    /* make sure that buffer sizes are valid */
    if (buffer_size < MIN_BUFFER_SIZE)
      buffer_size = MIN_BUFFER_SIZE;
    if (buffer_size > MAX_BUFFER_SIZE)
      buffer_size = MAX_BUFFER_SIZE;
    if (period_size < MIN_PERIOD_SIZE)
      period_size = MIN_PERIOD_SIZE;
    if (period_size > MAX_PERIOD_SIZE)
      period_size = MAX_PERIOD_SIZE;
    /* round up to power of two buffer size */
    /* could be done better, but speed does not really matter here */
    while (buffer_size & (buffer_size - 1))
      buffer_size++;
    while (period_size & (period_size - 1))
      period_size++;
    /* must have at least two buffer fragments, but four is better */
    if (period_size > (buffer_size >> 2))
      period_size = buffer_size >> 2;

    /* not opened yet */
    device_is_open = 0;
    /* open the device for playback */
    if ((int) snd_pcm_open(&dev_handle, sound_device,
                           SND_PCM_STREAM_PLAYBACK, 0) < 0)
      return -1;
    /* allocate hardware and software parameters */
    snd_pcm_hw_params_alloca(&dev_hw_params);
    snd_pcm_sw_params_alloca(&dev_sw_params);
    if ((int) snd_pcm_hw_params_any(dev_handle, dev_hw_params) < 0)
      return -1;
    /* now set the various hardware parameters: */
    /* access method, */
    if (snd_pcm_hw_params_set_access(dev_handle, dev_hw_params,
                                     SND_PCM_ACCESS_RW_INTERLEAVED) < 0)
      return -1;
    /* sample format, */
    if (snd_pcm_hw_params_set_format(dev_handle, dev_hw_params,
                                     SND_PCM_FORMAT_S16) < 0)
      return -1;
    /* number of channels, */
    if (snd_pcm_hw_params_set_channels(dev_handle, dev_hw_params, 2) < 0)
      return -1;
    /* sample rate, */
    sr_int = (int) (sound_sample_rate + 0.5);
    dir = 0;
#if (NEW_ALSA_API == 0)
    if (sr_int != (int) snd_pcm_hw_params_set_rate_near(dev_handle,
                                                        dev_hw_params,
                                                        sr_int, &dir))
      return -1;
#else
    if ((int) snd_pcm_hw_params_set_rate_near(dev_handle, dev_hw_params,
                                              &sr_int, &dir) < 0 ||
        sr_int != (int) (sound_sample_rate + 0.5))
      return -1;
#endif
    /* buffer size, */
#if (NEW_ALSA_API == 0)
    if (buffer_size !=
        (int) snd_pcm_hw_params_set_buffer_size_near(dev_handle, dev_hw_params,
                                              (snd_pcm_uframes_t) buffer_size))
      return -1;
#else
    buf_size = (snd_pcm_uframes_t) buffer_size;
    if ((int) snd_pcm_hw_params_set_buffer_size_near(dev_handle, dev_hw_params,
                                                     &buf_size) < 0 ||
        buf_size != (snd_pcm_uframes_t) buffer_size)
      return -1;
#endif
    /* and period size */
    dir = 0;
#if (NEW_ALSA_API == 0)
    if (period_size !=
        (int) snd_pcm_hw_params_set_period_size_near(dev_handle, dev_hw_params,
                                               (snd_pcm_uframes_t) period_size,
                                                     &dir))
      return -1;
#else
    buf_size = (snd_pcm_uframes_t) period_size;
    if ((int) snd_pcm_hw_params_set_period_size_near(dev_handle, dev_hw_params,
                                                     &buf_size, &dir) < 0 ||
        buf_size != (snd_pcm_uframes_t) period_size)
      return -1;
#endif
    /* set up device according to the above parameters */
    if (snd_pcm_hw_params(dev_handle, dev_hw_params) < 0)
      return -1;
    /* now set software parameters */
    if (snd_pcm_sw_params_current(dev_handle, dev_sw_params) < 0 ||
        snd_pcm_sw_params_set_start_threshold(dev_handle, dev_sw_params,
                                              (snd_pcm_uframes_t) buffer_size)
          < 0 ||
        snd_pcm_sw_params_set_avail_min(dev_handle, dev_sw_params,
                                        period_size) < 0 ||
        snd_pcm_sw_params_set_xfer_align(dev_handle, dev_sw_params, 1) < 0 ||
        snd_pcm_sw_params(dev_handle, dev_sw_params) < 0)
      return -1;

    bufpos = 0;
    /* mark as open, */
    device_is_open = 1;
    /* and report success */
    return 0;
}

/* send a sample to DAC */

static void soundcard_write_data_(int16_t sample_left, int16_t sample_right)
{
    int     err, nsmps;

    /* there is nothing to do if sound is disabled */
    if (disable_sound || !device_is_open)
      return;
    /* store sample in buffer */
    snd_buf[bufpos] = sample_left;  bufpos++;
    snd_buf[bufpos] = sample_right; bufpos++;
    if (bufpos < (period_size << 1)) return;
    /* if buffer is full, send to sound hardware */
    bufpos = 0;
    nsmps = period_size;
    while (nsmps) {
      err = (int) snd_pcm_writei(dev_handle,
                                 (void*) &(snd_buf[(period_size - nsmps) << 1]),
                                 (snd_pcm_uframes_t) nsmps);
      if (err >= 0) {
        nsmps -= err; continue;
      }
      else {
        /* handle I/O errors */
        if (err == -EPIPE) {
          /* buffer underrun */
          if (snd_pcm_prepare(dev_handle) >= 0)
            continue;
        }
        else if (err == -ESTRPIPE) {
          /* suspend */
          while (snd_pcm_resume(dev_handle) == -EAGAIN)
            sleep(1);
          if (snd_pcm_prepare(dev_handle) >= 0) continue;
        }
        /* could not recover from error */
        device_is_open = 0;
        return;
      }
    }
}

/* close sound output */

static void soundcard_close_(void)
{
    if (!device_is_open)
      return;
    if (!(disable_sound & 1))
      snd_pcm_close(dev_handle);
    dev_handle = NULL;
    device_is_open = 0;
}

/* module interface */

SoundModule_t   ALSASoundDriver = {
    "alsa",
    soundcard_initialize_,
    soundcard_write_data_,
    soundcard_close_
};

