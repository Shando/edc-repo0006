
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* tape.c: tape emulation */

#include <ep128.h>

double  tape_sample_rate = 24000.0;

char    *tape_file_name = "tape.dat";   /* tape I/O file */
int     tape_output = 0;        /* 0: tape signal is low, non-zero: high */
int     tape_feedback = 0;      /* non-zero: send tape signal to sound card */
int     tape_feedback_enable = 1; /* non-zero: enable tape feedback control */
int     tape_input = 0;         /* tape input signal (written from dave.c) */
int     fast_tape_mode = 1;     /* != 0: disable sound when tape is running */

/* list of tape file names */

char    *tape_file_name_0 = "tape0.dat";
char    *tape_file_name_1 = "tape1.dat";
char    *tape_file_name_2 = "tape2.dat";
char    *tape_file_name_3 = "tape3.dat";
char    *tape_file_name_4 = "tape4.dat";
char    *tape_file_name_5 = "tape5.dat";
char    *tape_file_name_6 = "tape6.dat";
char    *tape_file_name_7 = "tape7.dat";
char    *tape_file_name_8 = "tape8.dat";
char    *tape_file_name_9 = "tape9.dat";

static  FILE        *tape_file = NULL;
static  uint32_t    tape_file_size;             /* in bits */
static  uint32_t    tape_ptr = (uint32_t) 0xFFFFFFFFUL;
static  int         buf_ptr = 0;
/* non-zero if the current buffer has been modified */
static  int         buf_modified = 0;
/* bit 0: user PLAY ON/OFF, bit 1: REM1/REM2 ON/OFF */
/* must be 3 (both bits set) to enable playback */
static  int         tape_motor_mode = 0;
/* non-zero in record mode */
static  int         record_mode = 0;
static  uint8_t     tape_cur_block[4096];       /* current data block */

/* update tape file if buffer has been modified */

static void flush_tape_file(void)
{
    uint8_t     buf[512];
    uint32_t    prv_pos;
    int         i;

    /* if the buffer is unchanged, there is nothing to do */
    if (!buf_modified)
      return;

    fflush(tape_file);
    memset((void*) &(buf[0]), 0, (size_t) 512);
    /* save file position */
    prv_pos = (uint32_t) ftell(tape_file);
    /* convert 8-bit data to 1-bit */
    for (i = 0; i < 4096; i++) {
      buf[i >> 3] =
        (buf[i >> 3] << 1) | (uint8_t) ((int) tape_cur_block[i] ? 1 : 0);
    }
    /* the actual file position must be divided by 8 because */
    /* sample data has only 1 bit resolution */
    fseek(tape_file,
          (long) ((tape_ptr & (uint32_t) 0xFFFFF000UL) >> 3), SEEK_SET);
    /* write to file (512 bytes == 4096 bits) */
    fwrite((void*) &(buf[0]), (size_t) 1, (size_t) 512, tape_file);
    fflush(tape_file);
    /* restore original file position */
    fseek(tape_file, (long) prv_pos, SEEK_SET);
    /* file is now up to date */
    buf_modified = 0;
}

/* set tape position, depending on 'mode':                      */
/*   mode = 0: seek to absolute time 'value' in seconds         */
/*   mode = 1: seek forward/backward by 'value' seconds         */
/*   mode = 2: absolute position in samples                     */
/*   mode = 3: relative (+: forward, -: backward) in samples    */

static void tape_set_position(int value, int mode)
{
    uint32_t    new_ptr = tape_ptr;

    switch (mode) {
    case 0:
      new_ptr = (uint32_t) (value * (int) (tape_sample_rate + 0.5));
      break;
    case 1:
      new_ptr += (int) (value * (int) (tape_sample_rate + 0.5));
      break;
    case 2:
      new_ptr = (uint32_t) value;
      break;
    case 3:
      new_ptr += (int) value;
      break;
    default:
      return;
    }
    /* limit to disk file length */
    if ((uint32_t) new_ptr & (uint32_t) 0x80000000UL)
      new_ptr = (uint32_t) 0;
    if ((uint32_t) new_ptr >= (uint32_t) tape_file_size)
      new_ptr = tape_file_size - (uint32_t) 1;
    /* may need to read a new block from disk */
    if ((new_ptr & (uint32_t) 0xFFFFF000UL)
        != (tape_ptr & (uint32_t) 0xFFFFF000UL)) {
      int   i;
      /* write data first, if buffer has been modified */
      flush_tape_file();
      /* the actual file position must be divided by 8 because */
      /* sample data has only 1 bit resolution */
      fseek(tape_file,
            (long) ((new_ptr & (uint32_t) 0xFFFFF000UL) >> 3), SEEK_SET);
      /* clear buffer */
      memset(&(tape_cur_block[0]), 0, (size_t) 4096);
      /* read from file (512 bytes == 4096 bits) */
      fread(&(tape_cur_block[0]), (size_t) 1, (size_t) 512, tape_file);
      /* convert 1-bit data to 8-bit */
      i = 4096;
      do {
        tape_cur_block[i >> 3] >>= 1;
        i--;
        tape_cur_block[i] = (uint8_t) ((int) tape_cur_block[i >> 3] & 1);
      } while (i);
    }
    /* update buffer position */
    buf_ptr = (int) (new_ptr & (uint32_t) 0x0FFF);
    tape_ptr = new_ptr;
}

/* seek forward or backward (depending on sign) by 'nsecs' seconds */

void tape_seek(int nsecs)
{
    if (tape_file == NULL) {
      printMsg("ep128: no tape file is available\n");
      return;
    }
    tape_set_position(nsecs, 1);
    printMsg("Tape position is now %f seconds\n",
             (double) tape_ptr / tape_sample_rate);
}

/* this function turns off sound when the tape is running (both the motor */
/* and PLAY or RECORD are on), so that the emulator can run at full speed, */
/* reducing tape load/save times */
/* this feature is enabled by setting 'fast_tape_mode' to a non-zero value */

static void tape_speed_control(void)
{
    if (fast_tape_mode) {
      if (tape_motor_mode == 3) {
        /* full speed without sound */
        disable_sound |= 2;
      }
      else {
        /* revert to normal emulation speed */
        disable_sound &= (~2);
      }
    }
}

/* rewind tape to position zero */

void tape_rewind(void)
{
    if (tape_file == NULL) {
      printMsg("ep128: no tape file is available\n");
      return;
    }
    tape_set_position(0, 2);
    printMsg("Tape position is now %f seconds\n",
             (double) tape_ptr / tape_sample_rate);
}

/* start playback */

void tape_start_play(void)
{
    if (tape_file == NULL) {
      printMsg("ep128: no tape file is available\n");
      return;
    }
    tape_motor_mode |= 1;
    record_mode = 0;
    if (tape_feedback_enable && tape_motor_mode == 3)
      tape_feedback = 1;
    printMsg("Tape: PLAY ON\n");
    tape_speed_control();
}

/* start recording */

void tape_start_record(void)
{
    if (tape_file == NULL) {
      printMsg("ep128: no tape file is available\n");
      return;
    }
    tape_motor_mode |= 1;
    record_mode = 1;
    if (tape_feedback_enable && tape_motor_mode == 3)
      tape_feedback = 1;
    printMsg("Tape: RECORD ON\n");
    tape_speed_control();
}

/* stop playback or recording */

void tape_stop(void)
{
    if (tape_file == NULL) {
      printMsg("ep128: no tape file is available\n");
      return;
    }
    flush_tape_file();
    tape_motor_mode &= 2;
    record_mode = 0;
    tape_feedback = 0;
    printMsg("Tape: PLAY/RECORD OFF\n");
    tape_speed_control();
}

/* turn on tape motor (enables playback/record) */

void tape_motor_on(void)
{
    tape_motor_mode |= 2;
    if (tape_feedback_enable && tape_motor_mode == 3)
      tape_feedback = 1;
    tape_speed_control();
}

/* turn off tape motor (disables playback/record) */

void tape_motor_off(void)
{
    flush_tape_file();
    tape_motor_mode &= 1;
    tape_feedback = 0;
    tape_speed_control();
}

/* initialize tape emulation */
/* returns zero on success */

int tape_init(void)
{
    if (tape_file != NULL)      /* already initialized */
      return 0;
    if (tape_file_name == NULL || tape_file_name[0] == '\0')
      return 0;                 /* no file */
    /* open file */
    tape_file = fopen(tape_file_name, "r+b");
    if (tape_file == NULL) {
      printMsg("ep128: error opening tape file '%s': %s\n",
               tape_file_name, strerror(errno));
      return -1;
    }
    /* find out file size */
    fseek(tape_file, 0L, SEEK_END);
    tape_file_size = (uint32_t) ftell(tape_file) << 3;
    if (tape_file_size < 4096) {
      printMsg("ep128: invalid tape file: '%s'\n", tape_file_name);
      fclose(tape_file);
      return -1;
    }
    /* set position */
    rewind(tape_file);
    tape_stop();
    tape_set_position(0, 2);
    /* report success */
    printMsg("ep128: opened tape file '%s', length = %f seconds\n",
             tape_file_name, (double) tape_file_size / tape_sample_rate);
    return 0;
}

/* close tape file */

void tape_close(void)
{
    if (tape_file == NULL)
      return;                   /* nothing to close */
    flush_tape_file();
    fclose(tape_file);
    tape_file = NULL;
}

/* return the number of tape samples played in 'timeval' seconds, */
/* multiplied by 65536 */

int time_to_tape_samples(double timeval)
{
    return (int) (timeval * tape_sample_rate * 65536.0 + 0.5);
}

/* play 'nsmps' / 65536 samples of tape (assuming playback is on) */

static  int     smps_rem = 0;
static  int     prv_tape_input = -1;
static  int     tape_input_state = 0;

void tape_play(int nsmps)
{
    int i;

    if (tape_file == NULL)
      return;                   /* no tape */
    if (tape_motor_mode != 3)
      return;                   /* stopped */

    /* calculate the number of samples to play */
    i = smps_rem + nsmps;
    nsmps = (i & 0x7FFF0000) >> 16;
    smps_rem = i - (nsmps << 16);

    if (record_mode) {
      /* record */
      while (nsmps--) {
        /* detect edges in signal, and set state (low / high) */
        if (tape_input < prv_tape_input)
          tape_input_state = 0;
        else if (tape_input > prv_tape_input)
          tape_input_state = 1;
        prv_tape_input = tape_input;
        tape_cur_block[buf_ptr] = (uint8_t) tape_input_state;
        buf_modified = 1;
        tape_set_position(1, 3);
      }
    }
    else {
      /* play */
      while (nsmps--) {
        tape_output = ((int) tape_cur_block[buf_ptr] ? 1 : 0);
        tape_set_position(1, 3);
      }
    }
}

