
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* dave.c: DAVE chip emulation */

#include <ep128.h>

double  sound_sample_rate = 48000.0;
int     sound_oversample = 4;
/* DAVE clock frequency, 250000 Hz if bit 1 of I/O port 0xBF is 0, */
/* and 166666.6667 Hz otherwise */
double  dave_clock_freq = 250000.0;
/* DC block filter 1 cutoff frequency (in Hz) */
double  DC_block_1_frq = 10.0;
/* DC block filter 2 cutoff frequency (in Hz) */
double  DC_block_2_frq = 10.0;
/* output volume */
double  amplitude_scale = -0.75;

/* number of DAVE clock cycles * 65536 in a single system sync frame */
static  int     dave_cycles_per_master_cycle = 0;

/* internal variables used by sample rate conversion */
static const int  sound_output_maxcnt = 0x04000000;
static  int       sound_output_cnt = 0;
static  int       sound_output_frq = 0;
static  int       sound_subsample_cnt = 1;

/* downsample parameters */

/* buffer size is 8*oversample, and the maximum allowed oversample is 16 */
#define DOWNSAMP_MAX_BUFSIZ     128
#define DOWNSAMP_BUFMSK         127

static  int     downsamp_bufsiz = 0;
static  int     window_table[DOWNSAMP_MAX_BUFSIZ];
static  int     downsample_buf_L[DOWNSAMP_MAX_BUFSIZ];
static  int     downsample_buf_R[DOWNSAMP_MAX_BUFSIZ];
static  int     downsample_buf_pos = 0;

/* DC block filters */

static  int     DC_block_1_coeff, DC_block_1_xnm1_L, DC_block_1_ynm1_L;
static  int     DC_block_1_xnm1_R, DC_block_1_ynm1_R;
static  int     DC_block_2_coeff, DC_block_2_xnm1_L, DC_block_2_ynm1_L;
static  int     DC_block_2_xnm1_R, DC_block_2_ynm1_R;

/* tables for polynomial counters */
/* (note: the table data is stored in reverse order) */

static  uint8_t polycnt4_table[15];
static  uint8_t polycnt5_table[31];
static  uint8_t polycnt7_table[127];
static  uint8_t polycnt9_table[511];
static  uint8_t polycnt11_table[2047];
static  uint8_t polycnt15_table[32767];
static  uint8_t polycnt17_table[131071];
/* variable length counter uses one of the 9, 11, 15, and 17 bit tables */
static  uint8_t *polycntVL_table = NULL;

/* polynomial counters */

static  int     polycnt4_phase = 0;     /* 4-bit counter phase (14 -> 0) */
static  int     polycnt5_phase = 0;     /* 5-bit counter phase (30 -> 0) */
static  int     polycnt7_phase = 0;     /* 7-bit counter phase (126 -> 0) */
static  int     polycntVL_phase = 0;    /* variable length counter phase ... */
static  int     polycntVL_maxphase = 0; /* ... counts from this value to zero */
static  int     polycnt4_state = 0;     /* 4-bit counter output */
static  int     polycnt5_state = 0;     /* 5-bit counter output */
static  int     polycnt7_state = 0;     /* 7-bit counter output */
static  int     polycntVL_state = 0;    /* variable length counter output */

/* fixed frequency counters (f = 250000 / (n + 1)) */

static  const   int     clk_62500_frq = 3;
static  const   int     clk_1000_frq = 249;
static  const   int     clk_50_frq = 4999;
static  const   int     clk_1_frq = 249999;

static  int     clk_62500_phase = 0;
static  int     clk_1000_phase  = 0;
static  int     clk_50_phase    = 0;
static  int     clk_1_phase     = 0;

static  int     clk_62500_state = 0;

/* channel 0 parameters */

static  int     chn0_state          = 0;        /* current output state */
static  int     chn0_prv            = 0;        /* previous output state */
static  int     chn0_state1         = 0;        /* oscillator output */
static  int     chn0_phase          = 0;        /* phase (frqcode -> 0) */
static  int     chn0_frqcode        = 0;        /* frequency code (0 - 4095) */
static  int     *chn0_input_polycnt = NULL;     /* polynomial counter */
static  int     chn0_hp_1           = 0;        /* enable highpass filter */
static  int     chn0_rm_2           = 0;        /* enable ring modulation */
static  int     chn0_run            = 0;        /* 1: oscillator is running */
static  int     chn0_left           = 0;        /* left volume (0 - 2^28) */
static  int     chn0_right          = 0;        /* right volume (0 - 2^28) */

/* channel 1 parameters */

static  int     chn1_state          = 0;        /* current output state */
static  int     chn1_prv            = 0;        /* previous output state */
static  int     chn1_state1         = 0;        /* oscillator output */
static  int     chn1_phase          = 0;        /* phase (frqcode -> 0) */
static  int     chn1_frqcode        = 0;        /* frequency code (0 - 4095) */
static  int     *chn1_input_polycnt = NULL;     /* polynomial counter */
static  int     chn1_hp_2           = 0;        /* enable highpass filter */
static  int     chn1_rm_3           = 0;        /* enable ring modulation */
static  int     chn1_run            = 0;        /* 1: oscillator is running */
static  int     chn1_left           = 0;        /* left volume (0 - 2^28) */
static  int     chn1_right          = 0;        /* right volume (0 - 2^28) */

/* channel 2 parameters */

static  int     chn2_state          = 0;        /* current output state */
static  int     chn2_prv            = 0;        /* previous output state */
static  int     chn2_state1         = 0;        /* oscillator output */
static  int     chn2_phase          = 0;        /* phase (frqcode -> 0) */
static  int     chn2_frqcode        = 0;        /* frequency code (0 - 4095) */
static  int     *chn2_input_polycnt = NULL;     /* polynomial counter */
static  int     chn2_hp_3           = 0;        /* enable highpass filter */
static  int     chn2_rm_0           = 0;        /* enable ring modulation */
static  int     chn2_run            = 0;        /* 1: oscillator is running */
static  int     chn2_left           = 0;        /* left volume (0 - 2^28) */
static  int     chn2_right          = 0;        /* right volume (0 - 2^28) */

/* channel 3 (noise) parameters */

static  int     chn3_state          = 0;        /* current output state */
static  int     chn3_prv            = 0;        /* previous output state */
static  int     chn3_state1         = 0;        /* polynomial counter output */
static  int     chn3_state2         = 0;        /* lowpass filter output */
static  int     *chn3_clk_source    = NULL;     /* clock input signal */
static  int     chn3_clk_source_prv = 0;        /* previous clock input */
static  int     noise_polycnt_is_7bit = 0;      /* 0xA6 port bit 4 */
static  int     *chn3_input_polycnt = NULL;     /* polynomial counter */
static  int     chn3_lp_2           = 0;        /* enable lowpass filter */
static  int     chn3_hp_0           = 0;        /* enable highpass filter */
static  int     chn3_rm_1           = 0;        /* enable ring modulation */
static  int     chn3_left           = 0;        /* left volume (0 - 2^28) */
static  int     chn3_right          = 0;        /* right volume (0 - 2^28) */

/* enable DAC mode for left/right channel */

static  int     dac_mode_left       = 0;
static  int     dac_mode_right      = 0;

/* interrupts */

static  int     *int_snd_phase      = &clk_1000_phase;

static  int     enable_int_snd      = 0;
static  int     enable_int_1hz      = 0;
static  int     enable_int_1        = 0;
static  int     enable_int_2        = 0;

static  int     int_snd_state       = 0;
static  int     int_1hz_state       = 0;
static  int     int_1_state         = 1;
static  int     int_2_state         = 1;

static  int     int_snd_active      = 0;
static  int     int_1hz_active      = 0;
static  int     int_1_active        = 0;
static  int     int_2_active        = 0;

static  int     dave_is_initialized = 0;

/* This macro multiplies two signed 32-bit integers, and returns the upper */
/* 32 bit of the resulting 64-bit integer. Optimizes well on platforms that */
/* have machine code instructions to multiply 32-bit integers and place the */
/* result in a pair of 32-bit registers. */

#define IMUL32TO64(x,y)  ((int) (((int64_t) ((int32_t) (x)) * (int32_t) (y)) >> 32))

/* calculate parity of 'n' */
/* returns 0 if parity is even, and 1 if parity is odd */

static int parity_32(uint32_t n)
{
    n = (n & (uint32_t) 0x55555555UL) ^ ((n & (uint32_t) 0xAAAAAAAAUL) >> 1);
    n = (n & (uint32_t) 0x11111111UL) ^ ((n & (uint32_t) 0x44444444UL) >> 2);
    n = (n & (uint32_t) 0x01010101UL) ^ ((n & (uint32_t) 0x10101010UL) >> 4);
    n = (n & (uint32_t) 0x00010001UL) ^ ((n & (uint32_t) 0x01000100UL) >> 8);
    n = (n & (uint32_t) 0x00000001UL) ^ ((n & (uint32_t) 0x00010000UL) >> 16);

    return (int) n;
}

/* generate polynomial counter of 'nbits' length, and store */
/* ((2 ^ nbits) - 1) samples at 'tabptr' */
/* the table will be played back in reverse order, so the 'poly' constant */
/* should be set to a value that reproduces the output of a tone channel */
/* sampling the polynomial counter of 'nbits' length on a real DAVE chip, */
/* with a frequency code of (((2 ^ nbits) - 3) + (k * ((2 ^ nbits) - 1))), */
/* where k is any integer */

static void calculate_polycnt(uint8_t *tabptr, int nbits, int poly)
{
    int i, j, k;

    j = 0x7FFFFFFF;
    k = 1;
    for (i = 0; i < ((1 << nbits) - 1); i++) {
      k = (k ^ (int) parity_32((uint32_t) (j & poly))) & 1;
      j = (j << 1) | k;
      tabptr[i] = (uint8_t) k;
    }
}

static void initialize_tables(void)
{
    int     i, j;
    double  x;

    /* 4-bit polynomial counter (poly = 8) */
    calculate_polycnt(&(polycnt4_table[0]), 4, 8);
    /* 5-bit polynomial counter (poly = 19) */
    calculate_polycnt(&(polycnt5_table[0]), 5, 19);
    /* 7-bit polynomial counter (poly = 64) */
    calculate_polycnt(&(polycnt7_table[0]), 7, 64);
    /* 9-bit polynomial counter (poly = 265) */
    calculate_polycnt(&(polycnt9_table[0]), 9, 265);
    /* 11-bit polynomial counter (poly = 1027) */
    calculate_polycnt(&(polycnt11_table[0]), 11, 1027);
    /* 15-bit polynomial counter (poly = 16384) */
    calculate_polycnt(&(polycnt15_table[0]), 15, 16384);
    /* 17-bit polynomial counter (poly = 65541) */
    calculate_polycnt(&(polycnt17_table[0]), 17, 65541);
    /* initialize DC block filters */
    x = 6.28318530717958647692 / sound_sample_rate;
    DC_block_1_coeff = (int) ((double) 0x40000000 * x * DC_block_1_frq + 0.5);
    DC_block_1_coeff = 0x40000000 - DC_block_1_coeff;
    DC_block_2_coeff = (int) ((double) 0x40000000 * x * DC_block_2_frq + 0.5);
    DC_block_2_coeff = 0x40000000 - DC_block_2_coeff;
    DC_block_1_xnm1_L = DC_block_1_ynm1_L = 0;
    DC_block_1_xnm1_R = DC_block_1_ynm1_R = 0;
    DC_block_2_xnm1_L = DC_block_2_ynm1_L = 0;
    DC_block_2_xnm1_R = DC_block_2_ynm1_R = 0;
    /* the following tables are used for downsampling */
    downsamp_bufsiz = sound_oversample * 8;
    for (i = 0; i < downsamp_bufsiz; i++) {
      j = i - (downsamp_bufsiz >> 1);
      x = (double) j * 3.14159265358979323846 / (double) sound_oversample;
      x = (j == 0 ? 1.0 : (sin(x) / x));
      x *= ((double) 0x10000000 * amplitude_scale / (double) sound_oversample);
      window_table[i] = (int) (x + (x < 0.0 ? -0.5 : 0.5));
    }
    memset(&(downsample_buf_L[0]), 0, sizeof(int) * DOWNSAMP_MAX_BUFSIZ);
    memset(&(downsample_buf_R[0]), 0, sizeof(int) * DOWNSAMP_MAX_BUFSIZ);
    downsample_buf_pos = 0;
}

/* handle timer interrupts */

static inline void dave_trigger_int_snd(void)
{
    /* trigger interrupt on edge only */
    if (int_snd_active)
      return;
    /* mark as active */
    int_snd_active = 1;
    cpu_interrupt();
}

static inline void dave_trigger_int_1hz(void)
{
    /* trigger interrupt on edge only */
    if (int_1hz_active)
      return;
    /* mark as active */
    int_1hz_active = 1;
    cpu_interrupt();
}

/* set the clock frequency of DAVE emulation to 'frq' (in Hz) */
/* the standard value for 'frq' is 250000 */

static void dave_set_clock_frequency(double frq)
{
    dave_clock_freq = frq;
    dave_cycles_per_master_cycle =
      (int) ((65536.0 * frq / master_clock_freq) + 0.5);
    sound_output_frq =
      (int) (((double) sound_output_maxcnt
              * (sound_sample_rate * (double) sound_oversample)
              / dave_clock_freq) + 0.5);
}

/* run DAVE emulation, and also trigger any sound or timer interrupts */

static  int     cycles_rem = 0;

void dave_perform(void)
{
    int lval, rval, j, k, ncycles, outL, outR;

    /* calculate the actual number of DAVE clock cycles to run */
    ncycles = dave_cycles_per_master_cycle;
    j = cycles_rem + ncycles;
    ncycles = (j & 0x7FFF0000) >> 16;
    cycles_rem = j - (ncycles << 16);

    while (ncycles--) {
      /* update polynomial counters */
      if (--polycnt4_phase < 0)                 /* 4-bit */
        polycnt4_phase = 14;
      if (--polycnt5_phase < 0)                 /* 5-bit */
        polycnt5_phase = 30;
      if (!noise_polycnt_is_7bit) {
        /* channel 3 uses the variable length polynomial counter */
        if (--polycnt7_phase < 0)               /* 7-bit */
          polycnt7_phase = 126;
        /* channel 3 polynomial counter: updated on negative edge */
        if (*chn3_clk_source < chn3_clk_source_prv) {
          if (--polycntVL_phase < 0)            /* variable length */
            polycntVL_phase = polycntVL_maxphase;
        }
        chn3_clk_source_prv = *chn3_clk_source;
      }
      else {
        /* channel 3 uses the 7-bit polynomial counter */
        if (*chn3_clk_source < chn3_clk_source_prv) {
          /* update on negative edge */
          if (--polycnt7_phase < 0)             /* 7-bit */
            polycnt7_phase = 126;
        }
        chn3_clk_source_prv = *chn3_clk_source;
        if (--polycntVL_phase < 0)              /* variable length */
          polycntVL_phase = polycntVL_maxphase;
      }
      /* read polynomial counter tables */
      polycnt4_state = (int) polycnt4_table[polycnt4_phase];
      polycnt5_state = (int) polycnt5_table[polycnt5_phase];
      polycnt7_state = (int) polycnt7_table[polycnt7_phase];
      polycntVL_state = (int) polycntVL_table[polycntVL_phase];

      /* update the phase of all oscillators */
      clk_62500_phase--;
      clk_1000_phase--;
      clk_50_phase--;
      clk_1_phase--;
      if (chn0_run)
        chn0_phase--;
      if (chn1_run)
        chn1_phase--;
      if (chn2_run)
        chn2_phase--;

      /* trigger interrupts if enabled */
      if ((*int_snd_phase) < 0) {
        /* will reload counter later */
        int_snd_state = (int_snd_state & 1) ^ 1;        /* invert state */
        if (enable_int_snd)
          dave_trigger_int_snd();
      }
      if (clk_1_phase < 0) {
        clk_1_phase = clk_1_frq;                        /* reload counter */
        int_1hz_state = (int_1hz_state & 1) ^ 1;        /* invert state */
        if (enable_int_1hz)
          dave_trigger_int_1hz();
      }

      /* reload phase counters if necessary */
      if (clk_1000_phase < 0)
        clk_1000_phase = clk_1000_frq;
      if (clk_50_phase < 0)
        clk_50_phase = clk_50_frq;

      /* calculate oscillator outputs */
      if (clk_62500_phase < 0) {
        /* simple 31250 Hz oscillator */
        clk_62500_phase = clk_62500_frq;                /* reload counter */
        clk_62500_state = (clk_62500_state & 1) ^ 1;    /* invert state */
      }
      /* ---- channel 3 ---- */
      chn3_prv = chn3_state;                    /* save previous output */
      chn3_state1 = *chn3_input_polycnt;        /* get input signal */
      if (!chn3_lp_2 || (chn2_state < chn2_prv)) {
        /* lowpass filter holds signal until negative edge in channel 2 */
        chn3_state2 = chn3_state1;
      }
      if (chn3_hp_0 && (chn0_state < chn0_prv)) {
        /* highpass filter: sets level to 0 on negative edge in channel 0 */
        chn3_state2 = 0;
      }
      /* store final output signal in chn3_state */
      chn3_state = chn3_state2;
      if (chn3_rm_1) {
        /* ring modulation: XOR by channel 1 */
        chn3_state ^= chn1_state;
      }
      /* ---- channel 2 ---- */
      chn2_prv = chn2_state;                    /* save previous output */
      if (chn2_phase < 0) {
        chn2_phase = chn2_frqcode;              /* reload counter */
        if (chn2_input_polycnt == NULL) {
          /* square wave */
          chn2_state1 = (chn2_state1 & 1) ^ 1;
        }
        else {
          /* get input from polynomial counter */
          chn2_state1 = *chn2_input_polycnt;
        }
      }
      if (chn2_hp_3 && (chn3_state < chn3_prv)) {
        /* highpass filter: sets level to 0 on negative edge in channel 3 */
        chn2_state1 = 0;
      }
      /* store final output signal in chn2_state */
      chn2_state = chn2_state1;
      if (chn2_rm_0) {
        /* ring modulation: XOR by channel 0 */
        chn2_state ^= chn0_state;
      }
      /* ---- channel 1 ---- */
      chn1_prv = chn1_state;                    /* save previous output */
      if (chn1_phase < 0) {
        chn1_phase = chn1_frqcode;              /* reload counter */
        if (chn1_input_polycnt == NULL) {
          /* square wave */
          chn1_state1 = (chn1_state1 & 1) ^ 1;
        }
        else {
          /* get input from polynomial counter */
          chn1_state1 = *chn1_input_polycnt;
        }
      }
      if (chn1_hp_2 && (chn2_state < chn2_prv)) {
        /* highpass filter: sets level to 0 on negative edge in channel 2 */
        chn1_state1 = 0;
      }
      /* store final output signal in chn1_state */
      chn1_state = chn1_state1;
      if (chn1_rm_3) {
        /* ring modulation: XOR by channel 3 */
        chn1_state ^= chn3_state;
      }
      /* ---- channel 0 ---- */
      chn0_prv = chn0_state;                    /* save previous output */
      if (chn0_phase < 0) {
        chn0_phase = chn0_frqcode;              /* reload counter */
        if (chn0_input_polycnt == NULL) {
          /* square wave */
          chn0_state1 = (chn0_state1 & 1) ^ 1;
        }
        else {
          /* get input from polynomial counter */
          chn0_state1 = *chn0_input_polycnt;
        }
      }
      if (chn0_hp_1 && (chn1_state < chn1_prv)) {
        /* highpass filter: sets level to 0 on negative edge in channel 1 */
        chn0_state1 = 0;
      }
      /* store final output signal in chn0_state */
      chn0_state = chn0_state1;
      if (chn0_rm_2) {
        /* ring modulation: XOR by channel 2 */
        chn0_state ^= chn2_state;
      }

      /* and now the final DAC output (left/right) values */
      /* channel output range: 0 to 2^28 */
      /* total output range (not including tape feedback): 0 to 2^30 */
      if (tape_feedback && tape_output) {
        /* tape feedback (if enabled) */
        lval = 0x10000000;
        rval = 0x10000000;
      }
      else {
        lval = 0;
        rval = 0;
      }
      if (dac_mode_left) {
        lval += (chn0_left << 2);
        if (dac_mode_right) {
          /* simplest case: both channels in DAC mode */
          rval += (chn0_right << 2);
        }
        else {
          /* left channel is in DAC mode, but right is not */
          if (chn0_state) rval += chn0_right;
          if (chn1_state) rval += chn1_right;
          if (chn2_state) rval += chn2_right;
          if (chn3_state) rval += chn3_right;
        }
      }
      else if (dac_mode_right) {
        /* right channel is in DAC mode, but left is not */
        rval += (chn0_right << 2);
        if (chn0_state) lval += chn0_left;
        if (chn1_state) lval += chn1_left;
        if (chn2_state) lval += chn2_left;
        if (chn3_state) lval += chn3_left;
      }
      else {
        /* neither channel is in DAC mode */
        if (chn0_state) { lval += chn0_left; rval += chn0_right; }
        if (chn1_state) { lval += chn1_left; rval += chn1_right; }
        if (chn2_state) { lval += chn2_left; rval += chn2_right; }
        if (chn3_state) { lval += chn3_left; rval += chn3_right; }
      }

      /* send to tape */
      tape_input = lval;

      /* if sound output is disabled, downsampling and */
      /* playback can be skipped */
      if (disable_sound)
        continue;

      /* downsample and send output to sound card */
      sound_output_cnt -= sound_output_frq;
      while (sound_output_cnt < 0) {
        sound_output_cnt += sound_output_maxcnt;
        /* store in downsample buffer */
        sound_subsample_cnt--;
        j = downsample_buf_pos;
        k = sound_subsample_cnt;
        do {
          /* output range after downsample filter: */
          /* 0 to (2^26 * amplitude_scale) */
          if (window_table[k]) {
            downsample_buf_L[j] += IMUL32TO64(lval, window_table[k]);
            downsample_buf_R[j] += IMUL32TO64(rval, window_table[k]);
          }
          k += sound_oversample;
          j++; j &= DOWNSAMP_BUFMSK;
        } while (k < downsamp_bufsiz);
        /* check if we have completed the calculation of a sample frame */
        if (!sound_subsample_cnt) {
          sound_subsample_cnt = sound_oversample;
          /* downsample */
          outL = downsample_buf_L[downsample_buf_pos];
          outR = downsample_buf_R[downsample_buf_pos];
          downsample_buf_L[downsample_buf_pos] = 0;
          downsample_buf_R[downsample_buf_pos] = 0;
          downsample_buf_pos++;
          downsample_buf_pos &= DOWNSAMP_BUFMSK;
          /* apply DC block filters: */
          /* y(n) = x(n) - x(n - 1) + (c * y(n - 1)) */
          DC_block_1_ynm1_L = (IMUL32TO64(DC_block_1_ynm1_L, DC_block_1_coeff)
                               << 2) + (outL - DC_block_1_xnm1_L);
          DC_block_1_ynm1_R = (IMUL32TO64(DC_block_1_ynm1_R, DC_block_1_coeff)
                               << 2) + (outR - DC_block_1_xnm1_R);
          DC_block_1_xnm1_L = outL;
          DC_block_1_xnm1_R = outR;
          outL = DC_block_1_ynm1_L;
          outR = DC_block_1_ynm1_R;
          /* second filter */
          DC_block_2_ynm1_L = (IMUL32TO64(DC_block_2_ynm1_L, DC_block_2_coeff)
                               << 2) + (outL - DC_block_2_xnm1_L);
          DC_block_2_ynm1_R = (IMUL32TO64(DC_block_2_ynm1_R, DC_block_2_coeff)
                               << 2) + (outR - DC_block_2_xnm1_R);
          DC_block_2_xnm1_L = outL;
          DC_block_2_xnm1_R = outR;
          /* peak amplitude is now (2^26 * amplitude_scale), */
          /* convert to 16-bit range */
          outL = DC_block_2_ynm1_L >> 11;
          outR = DC_block_2_ynm1_R >> 11;
          if (outL < -32767) outL = -32767;
          if (outL > 32767) outL = 32767;
          if (outR < -32767) outR = -32767;
          if (outR > 32767) outR = 32767;
          /* send to sound card */
          soundcard_write_data((int16_t) outL, (int16_t) outR);
        }
      }
    }
}

/* returns pointer to the polynomial counter for channels 0, 1, and 2 */
/* selected by 'n' (allowed values for 'n' are 0x00, 0x10, 0x20, and 0x30) */

static int *find_polycnt_for_tone_channel(int n)
{
    switch (n) {
      case 0x10:
        return (&polycnt4_state);       /* 4-bit */
      case 0x20:
        return (&polycnt5_state);       /* 5-bit */
      case 0x30:
        if (!noise_polycnt_is_7bit) {
          return (&polycnt7_state);     /* 7-bit */
        }
        else {
          return (&polycntVL_state);    /* variable length */
        }
    }
    /* defaunt to square wave */
    return (int*) NULL;
}

/* write to DAVE registers (called from io_write_8()) */

void dave_register_write(uint16_t addr, uint8_t value)
{
    switch ((int) addr & 0x00FF) {
    case 0xA0:
      /* channel 0 frequency */
      chn0_frqcode = (chn0_frqcode & 0x0F00) | (int) value;
      break;
    case 0xA1:
      /* channel 0 frequency and mode */
      chn0_frqcode = (chn0_frqcode & 0x00FF) | (((int) value & 0x0F) << 8);
      /* select distortion mode */
      chn0_input_polycnt = find_polycnt_for_tone_channel((int) value & 0x30);
      chn0_hp_1 = ((int) value & 0x40 ? 1 : 0);         /* highpass */
      chn0_rm_2 = ((int) value & 0x80 ? 1 : 0);         /* ringmod */
      break;
    case 0xA2:
      /* channel 1 frequency */
      chn1_frqcode = (chn1_frqcode & 0x0F00) | (int) value;
      break;
    case 0xA3:
      /* channel 1 frequency and mode */
      chn1_frqcode = (chn1_frqcode & 0x00FF) | (((int) value & 0x0F) << 8);
      /* select distortion mode */
      chn1_input_polycnt = find_polycnt_for_tone_channel((int) value & 0x30);
      chn1_hp_2 = ((int) value & 0x40 ? 1 : 0);         /* highpass */
      chn1_rm_3 = ((int) value & 0x80 ? 1 : 0);         /* ringmod */
      break;
    case 0xA4:
      /* channel 2 frequency */
      chn2_frqcode = (chn2_frqcode & 0x0F00) | (int) value;
      break;
    case 0xA5:
      /* channel 2 frequency and mode */
      chn2_frqcode = (chn2_frqcode & 0x00FF) | (((int) value & 0x0F) << 8);
      /* select distortion mode */
      chn2_input_polycnt = find_polycnt_for_tone_channel((int) value & 0x30);
      chn2_hp_3 = ((int) value & 0x40 ? 1 : 0);         /* highpass */
      chn2_rm_0 = ((int) value & 0x80 ? 1 : 0);         /* ringmod */
      break;
    case 0xA6:
      /* channel 3 parameters */
      switch ((int) value & 0x03) {
        /* polynomial counter clock source */
        case 0x00: chn3_clk_source = &clk_62500_state; break;
        case 0x01: chn3_clk_source = &chn0_state; break;
        case 0x02: chn3_clk_source = &chn1_state; break;
        case 0x03: chn3_clk_source = &chn2_state; break;
      }
      /* select variable length polynomial counter */
      switch ((int) value & 0x0C) {
        case 0x00:
          polycntVL_table = &(polycnt17_table[0]);      /* 17-bit */
          polycntVL_maxphase = 131070;
          break;
        case 0x04:
          polycntVL_table = &(polycnt15_table[0]);      /* 15-bit */
          polycntVL_maxphase = 32766;
          break;
        case 0x08:
          polycntVL_table = &(polycnt11_table[0]);      /* 11-bit */
          polycntVL_maxphase = 2046;
          break;
        case 0x0C:
          polycntVL_table = &(polycnt9_table[0]);       /* 9-bit */
          polycntVL_maxphase = 510;
          break;
      }
      /* wrap the phase of variable length polynomial counter to table length */
      polycntVL_phase = polycntVL_phase % (polycntVL_maxphase + 1);
      /* bit 4: exchange 7-bit and variable length polynomial counters if set */
      if ((int) value & 0x10) {
        noise_polycnt_is_7bit = 1;
        chn3_input_polycnt = &polycnt7_state;
        if (chn0_input_polycnt == &polycnt7_state)
          chn0_input_polycnt = &polycntVL_state;
        if (chn1_input_polycnt == &polycnt7_state)
          chn1_input_polycnt = &polycntVL_state;
        if (chn2_input_polycnt == &polycnt7_state)
          chn2_input_polycnt = &polycntVL_state;
      }
      else {
        noise_polycnt_is_7bit = 0;
        chn3_input_polycnt = &polycntVL_state;
        if (chn0_input_polycnt == &polycntVL_state)
          chn0_input_polycnt = &polycnt7_state;
        if (chn1_input_polycnt == &polycntVL_state)
          chn1_input_polycnt = &polycnt7_state;
        if (chn2_input_polycnt == &polycntVL_state)
          chn2_input_polycnt = &polycnt7_state;
      }
      chn3_lp_2 = ((int) value & 0x20 ? 1 : 0); /* lowpass with channel 2 */
      chn3_hp_0 = ((int) value & 0x40 ? 1 : 0); /* highpass with channel 0 */
      chn3_rm_1 = ((int) value & 0x80 ? 1 : 0); /* ring mod. with channel 1 */
      break;
    case 0xA7:
      /* sound/interrupt control register */
      if ((int) value & 0x01) {
        chn0_run = 0;                     /* channel 0 sync */
        chn0_phase = chn0_frqcode;        /* reset phase */
      }
      else
        chn0_run = 1;
      if ((int) value & 0x02) {
        chn1_run = 0;                     /* channel 1 sync */
        chn1_phase = chn1_frqcode;        /* reset phase */
      }
      else
        chn1_run = 1;
      if ((int) value & 0x04) {
        chn2_run = 0;                     /* channel 2 sync */
        chn2_phase = chn2_frqcode;        /* reset phase */
      }
      else
        chn2_run = 1;
      dac_mode_left  = ((int) value & 0x08 ? 1 : 0);    /* analogue mode */
      dac_mode_right = ((int) value & 0x10 ? 1 : 0);
      switch ((int) value & 0x60) {
      /* sound interrupt mode */
      case 0x00:
        int_snd_phase = &clk_1000_phase;
        break;
      case 0x20:
        int_snd_phase = &clk_50_phase;
        break;
      case 0x40:
        int_snd_phase = &chn0_phase;
        break;
      case 0x60:
        int_snd_phase = &chn1_phase;
        break;
      }
      break;
    case 0xA8:
      /* channel 0 left volume */
      chn0_left = ((int) value & 0x3F) << 22;
      break;
    case 0xA9:
      /* channel 1 left volume */
      chn1_left = ((int) value & 0x3F) << 22;
      break;
    case 0xAA:
      /* channel 2 left volume */
      chn2_left = ((int) value & 0x3F) << 22;
      break;
    case 0xAB:
      /* channel 3 left volume */
      chn3_left = ((int) value & 0x3F) << 22;
      break;
    case 0xAC:
      /* channel 0 right volume */
      chn0_right = ((int) value & 0x3F) << 22;
      break;
    case 0xAD:
      /* channel 1 right volume */
      chn1_right = ((int) value & 0x3F) << 22;
      break;
    case 0xAE:
      /* channel 2 right volume */
      chn2_right = ((int) value & 0x3F) << 22;
      break;
    case 0xAF:
      /* channel 3 right volume */
      chn3_right = ((int) value & 0x3F) << 22;
      break;
    case 0xB4:
      /* interrupt control register */
      {
        int prv = (int_snd_active | int_1hz_active
                   | int_1_active | int_2_active);
        uint8_t tmp = (uint8_t) value ^ (uint8_t) 0x55;
        /* sound/timer interrupt */
        enable_int_snd = (tmp & (uint8_t) 0x01 ? 0 : 1);
        if (tmp & (uint8_t) 0x03)
          int_snd_active = 0;
        /* 1 Hz interrupt */
        enable_int_1hz = (tmp & (uint8_t) 0x04 ? 0 : 1);
        if (tmp & (uint8_t) 0x0C)
          int_1hz_active = 0;
        /* INT 1 (video interrupt) */
        enable_int_1 = (tmp & (uint8_t) 0x10 ? 0 : 1);
        if (tmp & (uint8_t) 0x30)
          int_1_active = 0;
        /* INT 2 */
        enable_int_2 = (tmp & (uint8_t) 0x40 ? 0 : 1);
        if (tmp & (uint8_t) 0xC0)
          int_2_active = 0;
        if (prv && !(int_snd_active | int_1hz_active
                     | int_1_active | int_2_active)) {
          /* no more active interrupts: clear request to CPU */
          cpu_clear_interrupt();
        }
      }
      break;
    case 0xBF:          /* system configuration register */
      {
        /* CPU wait cycle control */
        switch ((int) value & 0x0C) {
          case 0x00:    set_memory_wait(1, 1);  break;
          case 0x04:    set_memory_wait(1, 0);  break;
          case 0x08:    set_memory_wait(0, 0);  break;
          case 0x0C:    set_memory_wait(0, 0);  break;
        }
        /* input clock frequency (note: the frequency is always 8 MHz, */
        /* this bit sets the assumed value) */
        /*   0:  8 MHz, dave_clock_freq = input_freq / 32 */
        /*   1: 12 MHz, dave_clock_freq = input_freq / 48 */
        dave_set_clock_frequency((int) value & 0x02 ? 166666.6667 : 250000.0);
      }
      break;
    }
}

/* read from DAVE registers (called from io_read_8()) */

uint8_t dave_register_read(uint16_t addr)
{
    int n;

    switch ((int) addr) {
    case 0xB4:
      /* interrupt state */
      n = 0;
      int_snd_state &= 1;
      int_1hz_state &= 1;
      if (int_snd_state)    n |= 0x01;
      if (int_snd_active)   n |= 0x02;
      if (int_1hz_state)    n |= 0x04;
      if (int_1hz_active)   n |= 0x08;
      if (int_1_state)      n |= 0x10;
      if (int_1_active)     n |= 0x20;
      if (int_2_state)      n |= 0x40;
      if (int_2_active)     n |= 0x80;
      return (uint8_t) n;
      break;
    }
    /* anything else is either handled elsewhere, or is write-only */
    return (uint8_t) 0xFF;
}

/* set hardware interrupt 1 state, and (possibly) trigger interrupt */

void dave_set_int_1_state(int new_state)
{
    int prv = int_1_state;
    /* set new state */
    int_1_state = (new_state ? 1 : 0);
    /* on negative edge, trigger CPU interrupt */
    /* (assuming it is enabled, and not active already) */
    if (!enable_int_1)
      return;           /* disabled */
    if (int_1_state || !prv)
      return;           /* not on negative edge */
    if (int_1_active)
      return;           /* already active */
    /* now active */
    int_1_active = 1;
    /* send request to CPU */
    cpu_interrupt();
}

/* set hardware interrupt 2 state, and (possibly) trigger interrupt */

void dave_set_int_2_state(int new_state)
{
    int prv = int_2_state;
    /* set new state */
    int_2_state = (new_state ? 1 : 0);
    /* on negative edge, trigger CPU interrupt */
    /* (assuming it is enabled, and not active already) */
    if (!enable_int_2)
      return;           /* disabled */
    if (int_2_state || !prv)
      return;           /* not on negative edge */
    if (int_2_active)
      return;           /* already active */
    /* now active */
    int_2_active = 1;
    /* send request to CPU */
    cpu_interrupt();
}

/* initialize (on first call only) or reset DAVE */
/* also initialize low level sound I/O on first call */
/* return value is zero on success */

int initialize_dave(void)
{
    int i, retval = 0;

    if (!dave_is_initialized) {
      /* on first call: initialize */
      initialize_tables();      /* set up tables */
      /* open sound card */
      if (soundcard_initialize() != 0) {
        printMsg(" *** ep128: error opening sound card\n");
        retval = -1;    /* an error occured */
      }
      sound_subsample_cnt = sound_oversample;
      /* set the default clock frequency */
      dave_set_clock_frequency(250000.0);
      /* mark as initialized */
      dave_is_initialized = 1;
    }
    /* ---- reset code: always executed ---- */
    polycnt4_phase = 0;
    polycnt5_phase = 0;
    polycnt7_phase = 0;
    polycntVL_phase = 0;
    chn0_phase = 0;
    chn1_phase = 0;
    chn2_phase = 0;
    clk_62500_phase = 0;
    clk_1000_phase = 0;
    clk_50_phase = 0;
    clk_1_phase = 0;
    /* initialize registers */
    /* this will also reset many variables to the default value */
    for (i = 0xA0; i < 0xC0; i++)
      io_write_8((uint16_t) i, (uint8_t) 0x00);
    /* clear all interrupts */
    io_write_8((uint16_t) 0x00B4, (uint8_t) 0xAA);
    /* successfully initialized */
    return retval;
}

/* de-initialize DAVE */

void close_dave(void)
{
    if (!dave_is_initialized)
      return;
    soundcard_close();
    dave_is_initialized = 0;
}

/* return the size of DAVE snapshot data (in bytes) for snapshot file */
/* version 'file_version' */

int dave_snapshot_bytes(int file_version)
{
    switch (file_version) {
    case 0x0101:
    case 0x0102:
      return 128;
    default:
      return -1;
    }
}

/* save DAVE snapshot to file 'f' */
/* returns zero in case of success */

int save_dave_snapshot(FILE *f)
{
    /* oscillator phase for channels 0, 1, and 2 */
    snapshot_write_uint32((uint32_t) chn0_phase, f);
    snapshot_write_uint32((uint32_t) chn1_phase, f);
    snapshot_write_uint32((uint32_t) chn2_phase, f);
    /* 31.25 kHz oscillator state */
    snapshot_write_uint32((uint32_t) clk_62500_state, f);
    /* polynomial counter positions */
    snapshot_write_uint32((uint32_t) polycnt4_phase, f);
    snapshot_write_uint32((uint32_t) polycnt5_phase, f);
    snapshot_write_uint32((uint32_t) polycnt7_phase, f);
    snapshot_write_uint32((uint32_t) polycntVL_phase, f);
    /* fixed frequency oscillators */
    snapshot_write_uint32((uint32_t) clk_62500_phase, f);
    snapshot_write_uint32((uint32_t) clk_1000_phase, f);
    snapshot_write_uint32((uint32_t) clk_50_phase, f);
    snapshot_write_uint32((uint32_t) clk_1_phase, f);
    /* interrupt enable (1) / disable (0) */
    snapshot_write_uint32((uint32_t) enable_int_snd, f);
    snapshot_write_uint32((uint32_t) enable_int_1hz, f);
    snapshot_write_uint32((uint32_t) enable_int_1, f);
    snapshot_write_uint32((uint32_t) enable_int_2, f);
    /* interrupt states */
    snapshot_write_uint32((uint32_t) int_snd_state, f);
    snapshot_write_uint32((uint32_t) int_1hz_state, f);
    /* hack: in ep128emu versions earlier than 1.5.2 these interrupt states */
    /* had incorrect polarity, need to invert them here for compatibility */
    snapshot_write_uint32((uint32_t) ((int_1_state ^ 1) & 1), f);
    snapshot_write_uint32((uint32_t) ((int_2_state ^ 1) & 1), f);
    /* interrupt active/unhandled (1) or not active (0) */
    snapshot_write_uint32((uint32_t) int_snd_active, f);
    snapshot_write_uint32((uint32_t) int_1hz_active, f);
    snapshot_write_uint32((uint32_t) int_1_active, f);
    snapshot_write_uint32((uint32_t) int_2_active, f);
    /* padding */
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);
    snapshot_write_uint32((uint32_t) 0, f);

    return 0;           /* TODO: error handling */
}

/* convert phase values from old (version 0x0101) snapshot files */
/* to new format */

static int convert_oscillator_phase(int old_phase, int frq_code)
{
    /* check for trivial case */
    if (frq_code == 0)
      return 0;
    /* old phase values are 0->0x7FFFFFFF, new format is frq_code->0 */
    return (((0x0007FFFF - (old_phase >> 12)) * (frq_code + 1)) >> 19);
}

/* load DAVE snapshot from file 'f', using file format */
/* specified by 'file_version'. Returns zero in case of success. */

int load_dave_snapshot(FILE *f, int file_version)
{
    /* check file version */
    if (file_version != 0x0101 && file_version != 0x0102)
      return -1;

    /* oscillator phase for channels 0, 1, and 2 */
    chn0_phase      = (int) snapshot_read_uint32(f);
    chn1_phase      = (int) snapshot_read_uint32(f);
    chn2_phase      = (int) snapshot_read_uint32(f);
    if (file_version == 0x0101) {
      /* old version: need to convert oscillator phase values */
      chn0_phase = convert_oscillator_phase(chn0_phase, chn0_frqcode);
      chn1_phase = convert_oscillator_phase(chn1_phase, chn1_frqcode);
      chn2_phase = convert_oscillator_phase(chn2_phase, chn2_frqcode);
      /* the old format does not have clk_62500_state */
      snapshot_read_uint32(f);
    }
    else {
      /* 31.25 kHz oscillator state */
      clk_62500_state = (int) snapshot_read_uint32(f);
    }
    if (file_version != 0x0101) {
      /* polynomial counter positions ... */
      polycnt4_phase  = (int) snapshot_read_uint32(f);
      polycnt5_phase  = (int) snapshot_read_uint32(f);
      polycnt7_phase  = (int) snapshot_read_uint32(f);
      polycntVL_phase = (int) snapshot_read_uint32(f);
    }
    else {
      /* ... not available in the old version */
      snapshot_read_uint32(f);
      snapshot_read_uint32(f);
      snapshot_read_uint32(f);
      snapshot_read_uint32(f);
    }
    /* fixed frequency oscillators */
    clk_62500_phase = (int) snapshot_read_uint32(f);
    clk_1000_phase  = (int) snapshot_read_uint32(f);
    clk_50_phase    = (int) snapshot_read_uint32(f);
    clk_1_phase     = (int) snapshot_read_uint32(f);
    if (file_version == 0x0101) {
      /* convert phase values if necessary */
      clk_62500_phase =
        convert_oscillator_phase(clk_62500_phase, clk_62500_frq);
      clk_1000_phase = convert_oscillator_phase(clk_1000_phase, clk_1000_frq);
      clk_50_phase = convert_oscillator_phase(clk_50_phase, clk_50_frq);
      clk_1_phase = convert_oscillator_phase(clk_1_phase, clk_1_frq);
    }
    /* interrupt enable (1) / disable (0) */
    enable_int_snd  = (int) snapshot_read_uint32(f);
    enable_int_1hz  = (int) snapshot_read_uint32(f);
    enable_int_1    = (int) snapshot_read_uint32(f);
    enable_int_2    = (int) snapshot_read_uint32(f);
    /* interrupt states */
    int_snd_state   = (int) snapshot_read_uint32(f);
    int_1hz_state   = (int) snapshot_read_uint32(f);
    /* hack: in ep128emu versions earlier than 1.5.2 these interrupt states */
    /* had incorrect polarity, need to invert them here for compatibility */
    int_1_state     = ((int) snapshot_read_uint32(f) ^ 1) & 1;
    int_2_state     = ((int) snapshot_read_uint32(f) ^ 1) & 1;
    /* interrupt active/unhandled (1) or not active (0) */
    int_snd_active  = (int) snapshot_read_uint32(f);
    int_1hz_active  = (int) snapshot_read_uint32(f);
    int_1_active    = (int) snapshot_read_uint32(f);
    int_2_active    = (int) snapshot_read_uint32(f);
    /* padding */
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);
    snapshot_read_uint32(f);

    return 0;           /* TODO: error handling */
}

