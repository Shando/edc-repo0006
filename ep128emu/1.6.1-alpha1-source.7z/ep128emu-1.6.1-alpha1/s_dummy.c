
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* s_dummy.c: dummy sound driver */

#include <ep128.h>
#include <SDL/SDL.h>

static  uint64_t    prv_ms;
static  uint64_t    prv_time;
static  uint64_t    period_time;
static  int         period_cnt;

/* initialize sound card (returns zero on success) */

static int soundcard_initialize_(void)
{
    /* there is nothing to do if sound is disabled */
    if (disable_sound & 1)
      return 0;

    /* calculate period time, */
    if (period_size < 16)
      period_size = 16;
    if (period_size > 16384)
      period_size = 16384;
    period_time = (uint64_t)
                  ((int) (((double) period_size / (double) sound_sample_rate)
                          * 1024000.0 + 0.5));
    /* initialize timer, */
    prv_ms = (uint64_t) SDL_GetTicks();
    prv_time = prv_ms << 10;
    period_cnt = period_size;
    /* and report success */
    return 0;
}

/* send a sample to DAC */

static void soundcard_write_data_(int16_t sample_left, int16_t sample_right)
{
    uint64_t    cur_ms, cur_time;

    /* there is nothing to do if sound is disabled */
    if (disable_sound)
      return;

    if (--period_cnt)
      return;
    period_cnt = period_size;
    /* avoid compiler warnings */
    sample_left = sample_left;
    sample_right = sample_right;
    /* get current time */
    cur_ms = (uint64_t) SDL_GetTicks();
    cur_time = cur_ms << 10;
    if (cur_ms < prv_ms) {
      prv_time = prv_ms = (uint64_t) 0;         /* wrap-around */
    }
    prv_time += period_time;
    prv_ms = prv_time >> 10;
    if (cur_ms < prv_ms) {
      SDL_Delay((Uint32) (prv_ms - cur_ms));
    }
    prv_ms = cur_ms;
}

/* close sound output */

static void soundcard_close_(void)
{
    /* nothing to do */
}

/* module interface */

SoundModule_t   DummySoundDriver = {
    "null",
    soundcard_initialize_,
    soundcard_write_data_,
    soundcard_close_
};

