
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_Z80_WRAP_H
#define EP128_Z80_WRAP_H

#include <stdio.h>
#include <stdint.h>

extern  double  cpu_frequency;          /* CPU clock frequency in Hz */
extern  double  cpu_alternate_frequency;  /* alternate CPU clock frequency */
extern  double  no_memory_wait_frequency; /* disable memory timing if CPU */
                                          /*   frequency >= this variable */
extern  double  vram_clock_ratio;       /* video memory frequency / CPU frq. */
extern  double  vram_latency_f;         /* video mem. latency in Z80 cycles */

/* set Z80 clock frequency to 'frq' (in Hz) */

void set_cpu_frequency(double frq);

/* perform next (1 / master_clock_freq) timeslice of Z80 emulation        */
/* returns zero in case of success, and -1 if an invalid instruction was  */
/* encountered (in the latter case, PC will point to the bad instruction) */

int cpu_perform(void);

/* reset CPU */

void reset_cpu(void);

/* interrupt call */

void cpu_interrupt(void);
void cpu_clear_interrupt(void);

/* save all CPU registers to file 'f', writing 64 bytes of data */
/* returns zero in case of success */

int save_cpu_state(FILE *f);

/* load all CPU registers from file 'f', using file format specified by */
/* 'file_version'. Returns zero in case of success. */

int load_cpu_state(FILE *f, int file_version);

/* return the size of CPU snapshot data (in bytes) for snapshot file */
/* version 'file_version' */

int cpu_snapshot_bytes(int file_version);

/* set memory wait states */

void set_memory_wait(int opcode_read, int all_access);

/* the following functions are called from z80.c */

/* update the number of CPU cycles elapsed */
extern  void      (*Z80_UpdateCycles)(int x);
/* read a byte from memory */
extern  uint8_t   (*Z80_RD_MEM)(uint16_t addr);
/* write a byte to memory */
extern  void      (*Z80_WR_MEM)(uint16_t addr, uint8_t value);
/* read a 16-bit word from memory */
extern  uint16_t  Z80_RD_MEM_WORD(uint16_t addr);
/* write a 16-bit word to memory */
extern  void      Z80_WR_MEM_WORD(uint16_t addr, uint16_t value);
/* write a byte to an I/O port */
extern  void      Z80_DoOut(uint16_t addr, uint8_t value);
/* read a byte from an I/O port */
extern  uint8_t   Z80_DoIn(uint16_t addr);
/* read the first byte of an opcode */
extern  uint8_t   (*Z80_RD_OPCODE_FIRST_BYTE)(void);
/* read an opcode byte ('Offset' should not be zero) */
extern  uint8_t   (*Z80_RD_OPCODE_BYTE)(int Offset);
/* read an opcode word ('Offset' should not be zero) */
extern  uint16_t  Z80_RD_OPCODE_WORD(int Offset);

#endif      /* EP128_Z80_WRAP_H */

