
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_DAVE_H
#define EP128_DAVE_H

#include <stdio.h>
#include <stdint.h>

extern  double  sound_sample_rate;
extern  int     sound_oversample;
extern  double  dave_clock_freq;
/* DC block filter 1 cutoff frequency (in Hz) */
extern  double  DC_block_1_frq;
/* DC block filter 2 cutoff frequency (in Hz) */
extern  double  DC_block_2_frq;
/* output volume */
extern  double  amplitude_scale;

/* calculate and play sound output, and trigger any sound or timer interrupts */

void dave_perform(void);

/* write to DAVE registers (called from io_write_8()) */

void dave_register_write(uint16_t addr, uint8_t value);

/* read from DAVE registers (called from io_read_8()) */

uint8_t dave_register_read(uint16_t addr);

/* set hardware interrupt 1 state, and (possibly) trigger interrupt */

void dave_set_int_1_state(int new_state);

/* set hardware interrupt 2 state, and (possibly) trigger interrupt */

void dave_set_int_2_state(int new_state);

/* initialize (on first call only) or reset DAVE */
/* also initialize low level sound I/O on first call */
/* return value is zero on success */

int initialize_dave(void);

/* de-initialize DAVE */

void close_dave(void);

/* return the size of DAVE snapshot data (in bytes) for snapshot file */
/* version 'file_version' */

int dave_snapshot_bytes(int file_version);

/* save DAVE snapshot to file 'f' */
/* returns zero in case of success */

int save_dave_snapshot(FILE *f);

/* load DAVE snapshot from file 'f', using file format */
/* specified by 'file_version'. Returns zero in case of success. */

int load_dave_snapshot(FILE *f, int file_version);

#endif      /* EP128_DAVE_H */

