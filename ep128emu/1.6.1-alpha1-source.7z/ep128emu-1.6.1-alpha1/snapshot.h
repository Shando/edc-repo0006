
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_SNAPSHOT_H
#define EP128_SNAPSHOT_H

#include <stdio.h>
#include <stdint.h>

/* list of snapshot file names */

extern  char    *snapshot_files[];

/* index of currently selected snapshot file (0 to 25) */

extern  int     cur_snapshot;

/* save snapshot file */
/* returns zero on success */

int save_snapshot(int snap_idx);

/* load snapshot file */
/* returns zero on success */

int load_snapshot(int snap_idx);

/* read a signed 16-bit integer (big-endian) from file 'f' */

int16_t snapshot_read_int16(FILE *f);

/* read an unsigned 16-bit integer (big-endian) from file 'f' */

uint16_t snapshot_read_uint16(FILE *f);

/* read a signed 32-bit integer (big-endian) from file 'f' */

int32_t snapshot_read_int32(FILE *f);

/* read an unsigned 32-bit integer (big-endian) from file 'f' */

uint32_t snapshot_read_uint32(FILE *f);

/* write a signed 16-bit integer (big-endian) to file 'f' */

void snapshot_write_int16(int16_t c, FILE *f);

/* write an unsigned 16-bit integer (big-endian) to file 'f' */

void snapshot_write_uint16(uint16_t c, FILE *f);

/* write a signed 32-bit integer (big-endian) to file 'f' */

void snapshot_write_int32(int32_t c, FILE *f);

/* write an unsigned 32-bit integer (big-endian) to file 'f' */

void snapshot_write_uint32(uint32_t c, FILE *f);

#endif      /* EP128_SNAPSHOT_H */

