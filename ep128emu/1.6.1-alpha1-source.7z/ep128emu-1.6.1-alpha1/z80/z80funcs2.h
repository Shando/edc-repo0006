/*
 *  ENTER emulator (c) Copyright, Kevin Thacker 1995-2001
 *
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

void (*Z80_ErrorFunction) (char *) = NULL;
void (*Z80_UserInterruptFunction) (void) = NULL;
void (*Z80_UserAckInterruptFunction) (void) = NULL;

void Z80_ExecuteInterrupt()
{
    if (R.IFF1) {
      R.IFF1 = 0;
      R.IFF2 = 0;

      if (R.Flags & Z80_EXECUTING_HALT_FLAG) {
        ADD_PC(1);
      }

      R.Flags &= ~Z80_EXECUTING_HALT_FLAG;

      Z80_UserAckInterruptFunction();

      switch (R.IM) {
      case 0x00:
        /* unsupported */
        break;
      case 0x01:
        {
          /* The number of cycles required to complete the instruction
             is two more than normal due to the two added wait states */
          Z80_UpdateCycles(13);
          /* push return address onto stack */
          PUSH(R.PC.W.l);
          /* set program counter address */
          R.PC.W.l = 0x0038;
        }
        break;
      case 0x02:
        {
          Z80_WORD Vector;
          Z80_WORD Address;
          /* 19 clock cycles for this mode. 8 for vector, */
          /* six for program counter, six to obtain jump address */
          Z80_UpdateCycles(19);
          PUSH(R.PC.W.l);
          Vector = (R.I << 8) | (R.InterruptVectorBase);
          Address = Z80_RD_WORD(Vector);
          R.PC.W.l = Address;
        }
        break;
      }
    }
}

void Z80_SetVectorBase(int Base)
{
    R.InterruptVectorBase = Base & 0x0ff;
}

/*
 A value has even parity when all the binary digits added together give an even
 number. (result = 0). A value has an odd parity when all the digits added
 together give an odd number. (result = 1)
*/

void BuildParityTable(void)
{
    int i, j;
    int sum;

    for (i = 0; i < 256; i++) {
      Z80_BYTE data;

      sum = 0;                    /* will hold sum of all bits */

      data = i;                   /* data byte to find sum of */

      for (j = 0; j < 8; j++) {
        sum += data & 0x01;       /* isolate bit and add */
        data = data >> 1;         /* shift for next bit */
      }

      /* in flags register, if result has even parity, then */
      /* bit is set to 1, if result has odd parity, then bit */
      /* is set to 0. */

      /* check bit 0 of sum. If 1, then odd parity, else even parity. */
      if ((sum & 0x01) != 0) {
        /* odd parity */
        ParityTable[i] = 0;
      }
      else {
        /* even parity */
        ParityTable[i] = Z80_PARITY_FLAG;
      }

    }

    for (i = 0; i < 256; i++) {
      ZeroSignTable[i] = 0;

      if ((i & 0x0ff) == 0) {
        ZeroSignTable[i] |= Z80_ZERO_FLAG;
      }

      if (i & 0x080) {
        ZeroSignTable[i] |= Z80_SIGN_FLAG;
      }
    }

    for (i = 0; i < 256; i++) {
      unsigned char Data;

      Data = 0;

      if ((i & 0x0ff) == 0) {
        Data |= Z80_ZERO_FLAG;
      }

      if (i & 0x080) {
        Data |= Z80_SIGN_FLAG;
      }

      Data |= (i & (Z80_UNUSED_FLAG1 | Z80_UNUSED_FLAG2));

      ZeroSignTable2[i] = Data;

    }

    for (i = 0; i < 256; i++) {
      ZeroSignParityTable[i] = 0;

      if ((i & 0x0ff) == 0) {
        ZeroSignParityTable[i] |= Z80_ZERO_FLAG;
      }

      if ((i & 0x080) == 0x080) {
        ZeroSignParityTable[i] |= Z80_SIGN_FLAG;
      }
      /* included unused flag1 and 2 for AND,XOR,OR, IN, RLD, RRD */
      ZeroSignParityTable[i] |=
          ParityTable[i] | (i & Z80_UNUSED_FLAG1) | (i & Z80_UNUSED_FLAG2);
    }
}

void Z80_Init()
{
    BuildParityTable();
}

void Z80_Reset(void)
{
    R.PC.L = 0;
    R.I = 0;
    R.IM = 0;
    R.IFF1 = 0;
    R.IFF2 = 0;
    R.RBit7 = 0;
    R.R = 0;
    R.IX.W = 0x0ffff;
    R.IY.W = 0x0ffff;
    R.AF.B.l = Z80_ZERO_FLAG;
    R.Flags &= ~
        (Z80_EXECUTING_HALT_FLAG |
         Z80_CHECK_INTERRUPT_FLAG |
         Z80_EXECUTE_INTERRUPT_HANDLER_FLAG | Z80_INTERRUPT_FLAG);
}

void Z80_NMI(void)
{
    /* disable maskable ints */
    R.IFF1 = 0;
    /* push return address on stack */
    PUSH(R.PC.W.l);
    /* set program counter address */
    R.PC.W.l = 0x0066;
}

Z80_REGISTERS *Z80_GetReg(void)
{
    return &R;
}

void Z80_TriggerInterrupt(void)
{
    R.Flags |= Z80_INTERRUPT_FLAG;
    R.Flags |= Z80_EXECUTE_INTERRUPT_HANDLER_FLAG;
}

void Z80_ClearInterrupt(void)
{
    R.Flags &= ~Z80_INTERRUPT_FLAG;
    R.Flags &= ~Z80_EXECUTE_INTERRUPT_HANDLER_FLAG;
}

void Z80_SetUserInterruptFunction(void (*pUserFunction) (void))
{
    Z80_UserInterruptFunction = pUserFunction;
}

void Z80_SetUserAckInterruptFunction(void (*pUserFunction) (void))
{
    Z80_UserAckInterruptFunction = pUserFunction;
}

void Z80_DisplayErrorFunction(void (*pErrorFunction) (char *))
{
    Z80_ErrorFunction = pErrorFunction;
}

void Z80_Test()
{
}

/* Istvan Varga (Jul 2004): replaced this function with a macro (z80_wrap.h) */

/* extern void Z80_UpdateCycles(int Cycles); */

/* dummy function */
static void Z80_FlushCycles(void)
{
}
