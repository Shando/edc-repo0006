/*
 *  ENTER emulator (c) Copyright, Kevin Thacker 1999-2001
 *
 *  This file is part of the ENTER emulator source code distribution.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */
#ifndef __Z80_HEADER_INCLUDED__
#define __Z80_HEADER_INCLUDED__

#include <ep128.h>

#define Z80_ZERO_FLAG_BIT                       6
#define Z80_HALFCARRY_FLAG_BIT                  4
#define Z80_PARITY_FLAG_BIT                     2

#define Z80_SIGN_FLAG                           0x080
#define Z80_ZERO_FLAG                           0x040
#define Z80_UNUSED_FLAG1                        0x020
#define Z80_HALFCARRY_FLAG                      0x010
#define Z80_UNUSED_FLAG2                        0x008

#define Z80_PARITY_FLAG                         0x004
#define Z80_OVERFLOW_FLAG                       0x004

#define Z80_SUBTRACT_FLAG                       0x002
#define Z80_CARRY_FLAG                          0x001

#define X86_SIGN_FLAG                           0x080
#define X86_ZERO_FLAG                           0x040
#define X86_UNUSED_FLAG3                        0x020
#define X86_AUXILIARY_FLAG                      0x010
#define X86_UNUSED_FLAG2                        0x008
#define X86_PARITY_FLAG                         0x004
#define X86_UNUSED_FLAG1                        0x002
#define X86_CARRY_FLAG                          0x001

/* size defines */
typedef uint8_t   Z80_BYTE;
typedef uint16_t  Z80_WORD;
typedef int8_t    Z80_BYTE_OFFSET;
typedef int16_t   Z80_WORD_OFFSET;
typedef uint32_t  Z80_LONG;

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

/* opcode emulation function definition */
typedef void (*Z80_OPCODE_FUNCTION) (void);

#ifdef CPC_LSB_FIRST
/* register pair definition */
typedef union {
    /* read as a word */
    /* Z80_WORD W; */
    Z80_WORD W;
    /* read as seperate bytes, l for low, h for high bytes */
    struct {
      Z80_BYTE l;
      Z80_BYTE h;
    } B;
} Z80_REGISTER_PAIR;
#else
/* register pair definition */
typedef union {
    /* read as a word */
    Z80_WORD W;

    /* read as seperate bytes, l for low, h for high bytes */
    struct {
      Z80_BYTE h;
      Z80_BYTE l;
    } B;
} Z80_REGISTER_PAIR;
#endif

#ifdef CPC_LSB_FIRST
typedef union {
    Z80_LONG L;

    struct {
      Z80_WORD l;
      Z80_WORD h;
    } W;

    struct {
      Z80_BYTE l;
      Z80_BYTE h;
      Z80_BYTE pad[2];
    } B;
} Z80_REGISTER_LONG;
#else
typedef union {
    Z80_LONG L;

    struct {
      Z80_WORD l;
      Z80_WORD h;
    } W;

    struct {
      Z80_BYTE pad[2];
      Z80_BYTE h;
      Z80_BYTE l;
    } B;
} Z80_REGISTER_LONG;
#endif

/* structure holds all register data */
typedef struct Z80_REGISTERS {
    Z80_REGISTER_LONG PC;
    Z80_REGISTER_PAIR AF;
    Z80_REGISTER_PAIR HL;
    Z80_REGISTER_PAIR SP;
    Z80_REGISTER_PAIR DE;
    Z80_REGISTER_PAIR BC;

    Z80_REGISTER_PAIR IX;
    Z80_REGISTER_PAIR IY;
    Z80_WORD IndexPlusOffset;

    Z80_REGISTER_PAIR altHL;
    Z80_REGISTER_PAIR altDE;
    Z80_REGISTER_PAIR altBC;
    Z80_REGISTER_PAIR altAF;

    Z80_WORD TempWordResult;
    Z80_LONG TempLongResult;
    /* interrupt vector register. High byte of address */
    Z80_BYTE I;

    /* refresh register */
    Z80_BYTE R;

    /* interrupt status */
    Z80_BYTE IFF1;
    Z80_BYTE IFF2;

    /* bit 7 of R register */
    Z80_BYTE RBit7;

    /* interrupt mode 0,1,2 */
    Z80_BYTE IM;
    Z80_BYTE TempByte;
    Z80_BYTE TempWord;
    Z80_REGISTER_PAIR TempRegister;
    Z80_BYTE InterruptVectorBase;
    unsigned long Flags;
} Z80_REGISTERS;

#define GET_R   (R.RBit7 | (R.R & 0x07f))

inline  Z80_BYTE  RD_BYTE_INDEX(Z80_WORD Index);
inline  void      WR_BYTE_INDEX(Z80_WORD Index, Z80_BYTE Data);

#define Z80_FLAGS_REG                       R.AF.B.l

#define Z80_TEST_CARRY_SET          ((Z80_FLAGS_REG & Z80_CARRY_FLAG)!=0)
#define Z80_TEST_CARRY_NOT_SET      (Z80_FLAGS_REG & Z80_CARRY_FLAG)==0
#define Z80_TEST_ZERO_SET           (Z80_FLAGS_REG & Z80_ZERO_FLAG)!=0
#define Z80_TEST_ZERO_NOT_SET       (Z80_FLAGS_REG & Z80_ZERO_FLAG)==0
#define Z80_TEST_MINUS              (Z80_FLAGS_REG & Z80_SIGN_FLAG)!=0
#define Z80_TEST_POSITIVE           (Z80_FLAGS_REG & Z80_SIGN_FLAG)==0

/* parity even. bit = 1, parity odd, bit = 0 */
#define Z80_TEST_PARITY_EVEN        ((Z80_FLAGS_REG & Z80_PARITY_FLAG)!=0)
#define Z80_TEST_PARITY_ODD         ((Z80_FLAGS_REG & Z80_PARITY_FLAG)==0)
#define Z80_KEEP_UNUSED_FLAGS       (Z80_UNUSED1_FLAG | Z80_UNUSED2_FLAG)

void Z80_Init(void);
void Z80_Reset(void);
void Z80_ExecuteInterrupt(void);
Z80_REGISTERS *Z80_GetReg(void);
void Z80_SetReg(Z80_REGISTERS *);

void Z80_NMI(void);
void Z80_TriggerInterrupt(void);

typedef void (*USER_INTERRUPT_FUNCTION) (void);
typedef void (*USER_OPCODE_FUNCTION) (int);
typedef void (*USER_ACK_INTERRUPT_FUNCTION) (void);
typedef void (*DISPLAY_ERROR_FUNCTION) (char *);

void Z80_SetUserInterruptFunction(USER_INTERRUPT_FUNCTION);
void Z80_SetUserOpcodeFunction(USER_OPCODE_FUNCTION);

void Z80_SetUserAckInterruptFunction(USER_ACK_INTERRUPT_FUNCTION);

void Z80_SetVectorBase(int);
void Z80_ClearInterrupt(void);
void Z80_ExecuteOpcode2OpcodeCount(int OpcodeCount);

void Z80_DisplayErrorFunction(DISPLAY_ERROR_FUNCTION);

void Z80_PatchFunction();
void Z80_Patch(Z80_REGISTERS *);
void Z80_OpcodeFunc(int);

#define Z80_CHECK_INTERRUPT_FLAG                0x0001
#define Z80_EXECUTE_INTERRUPT_HANDLER_FLAG      0x0002
#define Z80_EXECUTING_HALT_FLAG                 0x0004
#define Z80_INTERRUPT_FLAG                      0x0008

void Z80_ExecuteInstruction(void);

#endif

