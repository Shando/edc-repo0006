
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* ui.c: user interface functions */

#include <ep128.h>

static void select_tape_file(char *fname)
{
    tape_close();
    tape_file_name = fname;
    if (tape_init() == 0) {
      tape_rewind();
    }
}

/* handle program control keys */
/* keynum is 0 to 9 for keys '0' to '9', 11 to 22 for keys 'F1' to 'F12', */
/* 40 to 65 for 'A' - 'Z', and 10 for 'Escape' */
/* 'Keypad Enter' is 80, 'Keypad -' is 81, 'Keypad +' is 82, */
/* 'Keypad Ins' is 83, and 'Keypad Del' is 84 */

void handle_special_key(int keynum)
{
    switch (keynum) {
    case 0:                     /* select tape file */
      select_tape_file(tape_file_name_0); break;
    case 1:
      select_tape_file(tape_file_name_1); break;
    case 2:
      select_tape_file(tape_file_name_2); break;
    case 3:
      select_tape_file(tape_file_name_3); break;
    case 4:
      select_tape_file(tape_file_name_4); break;
    case 5:
      select_tape_file(tape_file_name_5); break;
    case 6:
      select_tape_file(tape_file_name_6); break;
    case 7:
      select_tape_file(tape_file_name_7); break;
    case 8:
      select_tape_file(tape_file_name_8); break;
    case 9:
      select_tape_file(tape_file_name_9); break;
    case 11:                    /* tape position control */
      tape_seek(-60);   break;
    case 12:
      tape_seek(-5);    break;
    case 13:
      tape_seek(5);     break;
    case 14:
      tape_seek(60);    break;
    case 15:
      tape_rewind();    break;
    case 17:                    /* snapshot save */
      save_snapshot(cur_snapshot);
      break;
    case 18:                    /* snapshot load */
      load_snapshot(cur_snapshot);
      break;
    case 19:                    /* tape playback control */
      tape_start_play();    break;
    case 20:
      tape_stop();          break;
    case 21:
      tape_start_record();  break;
    case 40:                    /* select snapshot file */
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
    case 48:
    case 49:
    case 50:
    case 51:
    case 52:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
    case 58:
    case 59:
    case 60:
    case 61:
    case 62:
    case 63:
    case 64:
    case 65:
      cur_snapshot = (int) keynum - 40;
      if (snapshot_files[cur_snapshot] != NULL &&
          (int) strlen(snapshot_files[cur_snapshot]) > 0)
        printMsg("Selected snapshot file '%c' (file name: '%s')\n",
                 ((int) 'A' + cur_snapshot), snapshot_files[cur_snapshot]);
      else
        printMsg("WARNING: no snapshot file for '%c'\n",
                 ((int) 'A' + cur_snapshot));
      break;
    case 80:                    /* KEYPAD ENTER: set CPU frequency to 4 MHz */
      printMsg("CPU frequency has been reset to 4 MHz\n");
      set_cpu_frequency(4000000.0);
      break;
    case 81:                    /* KEYPAD -: decrease CPU frequency by 5% */
      set_cpu_frequency((cpu_frequency * 0.95) > 1000000.0 ?
                        (cpu_frequency * 0.95) : 1000000.0);
      printMsg("CPU frequency is now %.3f MHz\n", cpu_frequency * 0.000001);
      break;
    case 82:                    /* KEYPAD +: increase CPU frequency by 5% */
      set_cpu_frequency((cpu_frequency * 1.05) < 200000000.0 ?
                        (cpu_frequency * 1.05) : 200000000.0);
      printMsg("CPU frequency is now %.3f MHz\n", cpu_frequency * 0.000001);
      break;
    case 83:                    /* KEYPAD INS: print keyboard usage */
      print_keyboard_usage();
      break;
    case 84:                    /* KEYPAD DEL: set 'alternate' CPU frequency */
      set_cpu_frequency(cpu_alternate_frequency);
      printMsg("CPU frequency is now %.3f MHz\n", cpu_frequency * 0.000001);
      break;
    case 10:                    /* ESCAPE: RESET */
      {
        int     i;
        reset_cpu();
        for (i = 0xA0; i <= 0xBF; i++)
          io_write_8((uint16_t) i, (uint8_t) 0x00);
        tape_motor_off();
        WD177x_Reset();
      }
      break;
    }
}

