
/* ep128emu -- portable Enterprise 128 emulator                              */
/* Copyright (C) 2003, 2004, 2005 Istvan Varga <istvan_v@mailbox.hu>         */
/* http://ep128emu.sourceforge.net/index.html                                */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify      */
/* it under the terms of the GNU General Public License as published by      */
/* the Free Software Foundation; either version 2 of the License, or         */
/* (at your option) any later version.                                       */
/*                                                                           */
/* This program is distributed in the hope that it will be useful,           */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/* GNU General Public License for more details.                              */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef EP128_TAPE_H
#define EP128_TAPE_H

#include <stdint.h>

extern  double  tape_sample_rate;

extern  char  *tape_file_name;  /* tape I/O file */
extern  int   tape_output;      /* 0: tape signal is low, non-zero: high */
extern  int   tape_feedback;    /* non-zero: send tape signal to sound card */
extern  int   tape_feedback_enable; /* non-zero: enable tape feedback control */
extern  int   tape_input;       /* tape input signal (written from dave.c) */
extern  int   fast_tape_mode;   /* != 0: disable sound when tape is running */

/* list of tape file names */

extern  char  *tape_file_name_0;
extern  char  *tape_file_name_1;
extern  char  *tape_file_name_2;
extern  char  *tape_file_name_3;
extern  char  *tape_file_name_4;
extern  char  *tape_file_name_5;
extern  char  *tape_file_name_6;
extern  char  *tape_file_name_7;
extern  char  *tape_file_name_8;
extern  char  *tape_file_name_9;

/* seek forward or backward (depending on sign) by 'nsecs' seconds */

void tape_seek(int nsecs);

/* rewind tape to position zero */

void tape_rewind(void);

/* start playback */

void tape_start_play(void);

/* start recording */

void tape_start_record(void);

/* stop playback or recording */

void tape_stop(void);

/* turn on tape motor (enables playback/record) */

void tape_motor_on(void);

/* turn off tape motor (disables playback/record) */

void tape_motor_off(void);

/* initialize tape emulation */
/* returns zero on success */

int tape_init(void);

/* close tape file */

void tape_close(void);

/* return the number of tape samples played in 'timeval' seconds, */
/* multiplied by 65536 */

int time_to_tape_samples(double timeval);

/* play 'nsmps' / 65536 samples of tape (assuming playback is on) */

void tape_play(int nsmps);

#endif      /* EP128_TAPE_H */

