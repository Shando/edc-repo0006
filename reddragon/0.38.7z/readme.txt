+===========================+
| Red Dragon v0.38          |
| 21-September-2004         |
|                           |
| by frostgiant             |
| and Parasyte              |
| http://www.frostgiant.org |
+===========================+

=----------------------------------------------------------------------------=

A. Introduction

I have always been a fan of the Nintendo Virtual Boy. Also enjoying the
world of programming, I have fused my interests into making a Virtual Boy
emulator.  This emulator, as of right now, is mainly a pretty shell on top
of all David Tucker's hard work. There is no new functionality related to
emulation, but I have added many handy features, such as reconfigurable
keys and a GUI layer.  Also, I have cracked the first four sound channels on
the Virtual Boy but sound support has been left out of this release. Look
for it soon!

Please e-mail me and give me your comments on this emulator. You can reach
me at frostgiant@yifan.net or frostgiant@msn.com.
Or, give our IRC channel a spin. Log on to EFNet and join #virtualboy. If you
do not know what IRC is, visit www.mirc.com for a good Windows client (works
well in Linux with Wine, too).

Do not bundle this emulator with ROMs or ask me where to find them, please.

=----------------------------------------------------------------------------=

B. Installation

If you grabbed a binary release for Windows or DOS, just execute "rdragon"
and go!  For the Linux version, you will need the Allegro 4.0 libraries. You
can download Allegro at http://alleg.sourceforge.net

If you grabbed a source code release, there is a little more work involved.
You will need a compiler along with the Allegro 4.x.x library (older 3.9.x
source trees should work fine, but I make no guarantees to that).  Edit the
main makefile to include the makefile for the system that you use.  Then exit,
and, using your favorite text editor, edit the system-specific file for the
path to the Allegro library.  Type "make" and everything should snap into
action.

=----------------------------------------------------------------------------=

C. Usage Notes

Load up a ROM and play it.

If you are having problems getting the emulator to remember your video
settings, force your video mode to something other than an autodetect mode.
These seem to vary from system to system and phases of the moon...

If the emulator simply refuses to run properly, try renaming the options.dat.
Should this fix the problem, mail me the old file so I can try to figure out
what went wrong...

There is a decent cheat engine. If you do not care about making cheat, just
go to Emulation->Cheats->Browse Cheats and select one for your game.

Notice to all Cheat Hackers:
Red Dragon currently supports only 64 games total in the cheat list, only 64
cheats per game, and only 16 lines per cheat. If you go beyond these limits,
your cheats will not work properly.

=----------------------------------------------------------------------------=

C. Disclaimer

This emulator provides no warranties or guarantees whatsoever.  Any damage
that may occur is not the fault of anyone but yourself.  This emulator is
not designed as a piece of software for which to pirate Nintendo games.

=----------------------------------------------------------------------------=

D. Thanks to (alphabetical)

First off, thanks to you for actually downloading this file.  I write this
emulator for myself and all Virtual Boy fans.  Please e-mail me your comments!

Alberto Covarrubias - wrote the awesome VECC compiler (check it out and write
a demo!) and Virtual-E emulator

DanB - many bug reports, and writing demo ROMs to help pin-point the problems

David Tucker - without his excellent documentation of the system or Reality
Boy this project would not exist.

DogP - help with so many things, including nice bug reports and feature
requests, along with wonderful VB hacking information

Ferry Groenendijk - being the leader of the VB scene for years and too many 
other things to list.

KR155E - nice VB page, keep up the game development!

Parasyte - figuring out affine mode and finding subopcodes AND writing the
code for them!

...and everyone else out on the VB scene, including: Pete, Gil Pedersen,
Richard Bannister, pm5k00, Runner Pack, and lameboy

=----------------------------------------------------------------------------=

E. Links

http://www.frostgiant.org                    My site
http://www.virtual-boy.net                   Great VB page
http://www.vr32.de                           PlanetVB, in German and English!
http://www.vgchat.com                        Nice place to talk about the VB
http://dana.ucc.nau.edu/~dbt/VBMain.html     David's site, home of Reality Boy
http://www.emuunlim.com/VirtualE             Virtual-E homepage

=----------------------------------------------------------------------------=

F. Compatability

Fully Playable (Or nearly perfect):
  Galactic Pinball (JU)
  Innsumausu no Yakata (J)
  Jack Bros. (J)
  Jack Bros. (U)
  Mario Clash (JU)
  Mario's Tennis (JU)
  Nester's Funky Bowling (U)
  Panic Bomber (J)
  Panic Bomber (U)
  SD Gundam: Dimension War (J)
  Space Invaders- Virtual Collection (J)
  Space Squash (J)
  Teleroboxer (JU)
  V Tetris (J)
  Vertical Force (J)     [Adjustment screen does not appear, skipable.]
  Vertical Force (U)     [Adjustment screen does not appear, skipable.]
  Virtual Bowling (J)
  Virtual Boy Wario Land (JU)
  Virtual Fishing (J)
  Virtual League Baseball (U)
  Virtual Pro Yakyuu '95 (J)
  WaterWorld (U)


Almost Playable:
  3D Tetris (JU)         [Bad GFX\crashes.]
  Golf (U)               [Bad GFX\crashes.]
  Red Alarm (J)          [Bad GFX\crashes.]
  Red Alarm (U)          [Bad GFX\crashes.]
  T&E Virtual Golf (J)   [Bad GFX\crashes.]


Unplayable:
  Virtual Lab (J)        [Shows Startup Screens Only]

=----------------------------------------------------------------------------=

G. Changes

Red Dragon 0.38:
 * Second Release

Red Dragon 0.37 (Unreleased beta):
 * See changelog.txt

Red Dragon 0.36 (Unreleased beta):
 * affine mode supported (now you can play Tennis and Virtual League Baseball) (Parasyte)
 * SRAM is now saved correctly (fixes Galactic Pinball)
 * 3 new FPU subopcodes added (fixes Panic Bomber palette) (Parasyte)
 * cheat code support added
 * database of known ROM dumps added
 * numerous GUI bugs fixed

Red Dragon 0.35:
 * initial release
