+===========================+
| Red Dragon v0.35          |
| 09-April-2002             |
|                           |
| by frostgiant             |
| http://www.frostgiant.org |
+===========================+

=----------------------------------------------------------------------------=

A. Introduction
I have always been a fan of the Nintendo Virtual Boy. Also enjoying the
world of programming, I have fused my interests into making a Virtual Boy
emulator.  This emulator, as of right now, is mainly a pretty shell on top
of all David Tucker's hard work. There is no new functionality related to
emulation, but I have added many handy features, such as reconfigurable
keys and a GUI layer.  Also, I have cracked the first four sound channels on
the Virtual Boy but sound support has been left out of this release. Look
for it soon!

Please e-mail me and give me your comments on this emulator. You can reach
me at frostgiant@yifan.net or frostgiant@msn.com.

Do not bundle this emulator with ROMs or ask me where to find them, please.

=----------------------------------------------------------------------------=

B. Installation
If you grabbed a binary release for Windows or DOS, just execute "rdragon"
and go!  For the Linux version, you will need the Allegro 4.0 libraries. You
can download Allegro at http://alleg.sourceforge.net

If you grabbed a source code release, there is a little more work involved.
You will need a compiler with the  Allegro 4.0.1 library (older 3.9.x source
trees should work find, but I make no guarantees to that).  Edit the main
makefile to include the makefile for the system that you use.  Then exit,
and, using your favorite text editor, edit the system-specific file for the
path to the Allegro library.  Type "make" and everything should snap into
action.

=----------------------------------------------------------------------------=

C. Disclaimer
This emulator proviedes no warranties or guarantees whatsoever.  Any damage
that may occur is not the fault of anyone but yourself.  This emulator is
not designed as a piece of software for which to pirate Nintendo games.

=----------------------------------------------------------------------------=

D. Thanks to.....
First off, thanks to you for actually downloading this file.  I write this
emulator for myself and all Virtual Boy fans.  Please e-mail me your comments!

David Tucker - without his excellent documentation of the system or Reality
Boy this project would not exist.

Alberto Covarrubias - wrote the awesome VECC compiler (check it out and write
a demo!) and Virtual-E emulator

Ferry Groenendijk - thanks for making your site and having nice
Virtual Boy chats with me. :-)

Amos Bieler - we've never talked, but the VB Programmer's Manual has come
in to be very handy.

...and everyone else out on the VB scene, including: Pete, DogP, KR155E,
Richard Bannister, pm5k00, and lameboyadvance

=----------------------------------------------------------------------------=

E. Links

http://www.frostgiant.org                    My site
http://www.virtual-boy.net                   Great VB page
http://www.vgchat.com                        Nice place to talk about the VB
http://dana.ucc.nau.edu/~dbt/VBMain.html     David's site, home of Reality Boy
http://www.emuunlim.com/VirtualE             Virtual-E homepage
